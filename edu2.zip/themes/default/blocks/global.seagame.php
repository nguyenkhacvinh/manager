<?php
/**
 * @Project NUKEVIET 3.0
 * @Author VINADES., JSC (contact@vinades.vn)
 * @Copyright (C) 2011 VINADES ., JSC. All rights reserved
 * @Createdate Jan 10, 2011  6:04:30 PM
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

function nv_get_content($filter1,$filter2,$html) {
	$content='';
    $filter = '#(?<='.$filter1.').*(?='.$filter2.')#imsU';
	$a = preg_match($filter,$html,$co_non);
	if($a)$content = $co_non[0];
    return $content;
}
global $global_config;


$html=file_get_contents('http://www.vnpost.vn/TrackandTrace/tabid/130/n/EG721756576VN/t/0/s/1/Default.aspx');
$content="";
$filter1='<div id="pnView">';
$filter2='</siv>';
$content.="<style>
.box_news_box_358_ADS_62_15s_1_headerBongda-row-w{
	background:#fff;
	padding:2px 3px 1px 3px;
	padding-bottom:0px;
}
.box_news_box_358_ADS_62_15s_1_headerBongda-top{
	padding-left:5px;
	height:26px;
	overflow:hidden;
	background:#45780e url(http://static-hn.24hstatic.com/images/headerBoxLeftBGnew.gif) repeat-x;
	text-align:center;color:#fff;font-weight:bold
}
.box_news_box_358_ADS_62_15s_1_headerBongda-row-au{
	background:#ffeea1;
	padding:2px 3px 1px 3px;
}
.box_news_box_358_ADS_62_15s_1_headerBongda-row-ag{
	background:#f1f3f3;
	padding:2px 3px 1px 3px;
}
.box_news_box_358_ADS_62_15s_1_headerBongda-row-cu{
	background:#e8daca;
	padding:2px 3px 1px 3px;
}

.box_news_box_358_ADS_62_15s_1_headerBongda-RightBox{
	width:226px;
	height:253px;
	overflow:hidden;
	background-color:#ffffff;
	font-family:Arial, Helvetica, sans-serif;
	font-size:12px;
	border-left:#699f23 solid 1px;
	border-right:#699f23 solid 1px;
	border-bottom:#699f23 solid 2px;
}
</style>";
$content.="<table id=\"pnView\">";
$content.=nv_get_content($filter1,$filter2,$html);
$content.="</table>";


?>