-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 09, 2016 at 04:55 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 7.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `truonghoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_authors`
--

CREATE TABLE `pacorp_authors` (
  `admin_id` mediumint(8) UNSIGNED NOT NULL,
  `editor` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lev` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `files_level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `position` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `susp_reason` text COLLATE utf8mb4_unicode_ci,
  `check_num` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `last_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_authors`
--

INSERT INTO `pacorp_authors` (`admin_id`, `editor`, `lev`, `files_level`, `position`, `addtime`, `edittime`, `is_suspend`, `susp_reason`, `check_num`, `last_login`, `last_ip`, `last_agent`) VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', '03f6caf58aa0d6a56c6b1a227501128e', 1457536905, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_authors_config`
--

CREATE TABLE `pacorp_authors_config` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `keyname` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_authors_module`
--

CREATE TABLE `pacorp_authors_module` (
  `mid` mediumint(8) NOT NULL,
  `module` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang_key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  `act_1` tinyint(4) NOT NULL DEFAULT '0',
  `act_2` tinyint(4) NOT NULL DEFAULT '1',
  `act_3` tinyint(4) NOT NULL DEFAULT '1',
  `checksum` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_authors_module`
--

INSERT INTO `pacorp_authors_module` (`mid`, `module`, `lang_key`, `weight`, `act_1`, `act_2`, `act_3`, `checksum`) VALUES
(1, 'siteinfo', 'mod_siteinfo', 1, 1, 1, 1, '28ba95c3a12af016c2b2f0359f97b2cf'),
(2, 'authors', 'mod_authors', 2, 1, 1, 1, '7db285b7e8cf87caffb01d02738dec12'),
(3, 'settings', 'mod_settings', 3, 1, 1, 0, '72a22d37fcf3bf97dad49822e3db8e60'),
(4, 'database', 'mod_database', 4, 1, 0, 0, 'f73d17204770fbae11ae1011ca4c3ec1'),
(5, 'webtools', 'mod_webtools', 5, 1, 0, 0, 'b87308f6d14ea1d96f5f65b5db7d8d40'),
(6, 'seotools', 'mod_seotools', 6, 1, 0, 0, 'e7e44a4686a34b38630bd744a27ff318'),
(7, 'language', 'mod_language', 7, 1, 1, 0, '5ec84171e817a008a24eb1d4b114df72'),
(8, 'modules', 'mod_modules', 8, 1, 1, 0, '89a8bc8ec770bdf7acaee83c837f5245'),
(9, 'themes', 'mod_themes', 9, 1, 1, 0, 'abee6ee41e476a0c0b9bbe24d57328ac'),
(10, 'extensions', 'mod_extensions', 10, 1, 0, 0, '9bf7f2cd517f111056eafa9814556858'),
(11, 'upload', 'mod_upload', 11, 1, 1, 1, 'aa0f183490b641f8c2b90281b94fd2bc');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_banip`
--

CREATE TABLE `pacorp_banip` (
  `id` mediumint(8) NOT NULL,
  `ip` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_banners_click`
--

CREATE TABLE `pacorp_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_country` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_browse_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_browse_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_os_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_os_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_ref` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_banners_clients`
--

CREATE TABLE `pacorp_banners_clients` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pass` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reg_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `full_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `yim` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `act` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `check_num` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `last_ip` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploadtype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_banners_plans`
--

CREATE TABLE `pacorp_banners_plans` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `blang` char(2) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `form` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `width` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `height` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `act` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_banners_plans`
--

INSERT INTO `pacorp_banners_plans` (`id`, `blang`, `title`, `description`, `form`, `width`, `height`, `act`) VALUES
(2, '', 'Quang cao trai', '', 'sequential', 212, 800, 1),
(3, '', 'Quang cao Phai', '', 'random', 250, 500, 1),
(4, '', 'Quảng cáo top banner', '', 'sequential', 700, 100, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_banners_rows`
--

CREATE TABLE `pacorp_banners_rows` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `clid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_ext` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_mime` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `width` int(4) UNSIGNED NOT NULL DEFAULT '0',
  `height` int(4) UNSIGNED NOT NULL DEFAULT '0',
  `file_alt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageforswf` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `click_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `target` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_blank',
  `add_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `publ_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exp_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `act` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_banners_rows`
--

INSERT INTO `pacorp_banners_rows` (`id`, `title`, `pid`, `clid`, `file_name`, `file_ext`, `file_mime`, `width`, `height`, `file_alt`, `imageforswf`, `click_url`, `target`, `add_time`, `publ_time`, `exp_time`, `hits_total`, `act`, `weight`) VALUES
(5, 'Quảng cáo top banner', 4, 0, 'banner_single.png', 'png', 'image/png', 1349, 276, '', '', '', '_blank', 1453914565, 1453914565, 0, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_config`
--

CREATE TABLE `pacorp_config` (
  `lang` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sys',
  `module` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `config_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `config_value` text COLLATE utf8mb4_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_config`
--

INSERT INTO `pacorp_config` (`lang`, `module`, `config_name`, `config_value`) VALUES
('sys', 'site', 'closed_site', '0'),
('sys', 'site', 'admin_theme', 'admin_default'),
('sys', 'site', 'date_pattern', 'l, d/m/Y'),
('sys', 'site', 'time_pattern', 'H:i'),
('sys', 'site', 'online_upd', '1'),
('sys', 'site', 'statistic', '1'),
('sys', 'site', 'mailer_mode', ''),
('sys', 'site', 'smtp_host', 'smtp.gmail.com'),
('sys', 'site', 'smtp_ssl', '1'),
('sys', 'site', 'smtp_port', '465'),
('sys', 'site', 'smtp_username', 'user@gmail.com'),
('sys', 'site', 'smtp_password', ''),
('sys', 'site', 'googleAnalyticsID', 'UA-69270736-1'),
('sys', 'site', 'googleAnalyticsSetDomainName', '0'),
('sys', 'site', 'googleAnalyticsMethod', 'classic'),
('sys', 'site', 'searchEngineUniqueID', ''),
('sys', 'site', 'metaTagsOgp', '1'),
('sys', 'site', 'pageTitleMode', 'pagetitle'),
('sys', 'site', 'description_length', '170'),
('sys', 'global', 'ssl_https', '0'),
('sys', 'global', 'notification_active', '1'),
('sys', 'global', 'notification_autodel', '15'),
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'),
('sys', 'global', 'site_phone', ''),
('sys', 'global', 'block_admin_ip', '0'),
('sys', 'global', 'admfirewall', '0'),
('sys', 'global', 'dump_autobackup', '1'),
('sys', 'global', 'dump_backup_ext', 'gz'),
('sys', 'global', 'dump_backup_day', '30'),
('sys', 'global', 'gfx_chk', '3'),
('sys', 'global', 'file_allowed_ext', 'adobe,archives,audio,documents,flash,images,real,video'),
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'),
('sys', 'global', 'forbid_mimes', ''),
('sys', 'global', 'nv_max_size', '134217728'),
('sys', 'global', 'upload_checking_mode', 'strong'),
('sys', 'global', 'upload_alt_require', '1'),
('sys', 'global', 'upload_auto_alt', '1'),
('sys', 'global', 'allowuserreg', '1'),
('sys', 'global', 'allowuserlogin', '1'),
('sys', 'global', 'allowuserloginmulti', '0'),
('sys', 'global', 'allowloginchange', '0'),
('sys', 'global', 'allowquestion', '0'),
('sys', 'global', 'allowuserpublic', '1'),
('sys', 'global', 'useactivate', '2'),
('sys', 'global', 'allowmailchange', '1'),
('sys', 'global', 'allow_sitelangs', 'vi'),
('sys', 'global', 'read_type', '0'),
('sys', 'global', 'rewrite_optional', '1'),
('sys', 'global', 'rewrite_endurl', '/'),
('sys', 'global', 'rewrite_exturl', '.html'),
('sys', 'global', 'rewrite_op_mod', 'news'),
('sys', 'global', 'autocheckupdate', '0'),
('sys', 'global', 'autoupdatetime', '24'),
('sys', 'global', 'gzip_method', '1'),
('sys', 'global', 'is_user_forum', '0'),
('sys', 'global', 'authors_detail_main', '0'),
('sys', 'global', 'spadmin_add_admin', '1'),
('sys', 'global', 'openid_servers', ''),
('sys', 'global', 'timestamp', '17'),
('sys', 'global', 'openid_processing', '0'),
('sys', 'global', 'captcha_type', '1'),
('sys', 'global', 'version', '4.0.27'),
('sys', 'global', 'whoviewuser', '2'),
('sys', 'global', 'facebook_client_id', ''),
('sys', 'global', 'facebook_client_secret', ''),
('sys', 'global', 'google_client_id', ''),
('sys', 'global', 'google_client_secret', ''),
('sys', 'global', 'cookie_httponly', '1'),
('sys', 'global', 'admin_check_pass_time', '1800'),
('sys', 'global', 'user_check_pass_time', '1800'),
('sys', 'global', 'auto_login_after_reg', '1'),
('sys', 'global', 'adminrelogin_max', '3'),
('sys', 'global', 'cookie_secure', '0'),
('sys', 'global', 'nv_unick_type', '4'),
('sys', 'global', 'nv_upass_type', '0'),
('sys', 'global', 'is_flood_blocker', '1'),
('sys', 'global', 'max_requests_60', '40'),
('sys', 'global', 'max_requests_300', '150'),
('sys', 'global', 'nv_display_errors_list', '1'),
('sys', 'global', 'display_errors_list', '1'),
('sys', 'global', 'nv_auto_resize', '1'),
('sys', 'global', 'dump_interval', '1'),
('sys', 'global', 'cdn_url', ''),
('sys', 'define', 'nv_unickmin', '4'),
('sys', 'define', 'nv_unickmax', '20'),
('sys', 'define', 'nv_upassmin', '5'),
('sys', 'define', 'nv_upassmax', '20'),
('sys', 'define', 'nv_gfx_num', '6'),
('sys', 'define', 'nv_gfx_width', '150'),
('sys', 'define', 'nv_gfx_height', '40'),
('sys', 'define', 'nv_max_width', '1500'),
('sys', 'define', 'nv_max_height', '1500'),
('sys', 'define', 'nv_live_cookie_time', '31104000'),
('sys', 'define', 'nv_live_session_time', '0'),
('sys', 'define', 'nv_anti_iframe', '0'),
('sys', 'define', 'nv_anti_agent', '0'),
('sys', 'define', 'nv_allowed_html_tags', 'embed, object, param, a, b, blockquote, br, caption, col, colgroup, div, em, h1, h2, h3, h4, h5, h6, hr, i, img, li, p, span, strong, sub, sup, table, tbody, td, th, tr, u, ul, ol, iframe, figure, figcaption, video, audio, source, track, code, pre'),
('sys', 'define', 'dir_forum', ''),
('vi', 'global', 'site_domain', ''),
('vi', 'global', 'site_name', 'CÔNG TY TNHH PACORP'),
('vi', 'global', 'site_logo', ''),
('vi', 'global', 'site_banner', ''),
('vi', 'global', 'site_favicon', ''),
('vi', 'global', 'site_description', 'Chuyên rip theme, module, block nukeviet'),
('vi', 'global', 'site_keywords', 'padding&#x3A; 20px 10px 10px 10px'),
('vi', 'global', 'site_theme', 'default'),
('vi', 'global', 'mobile_theme', ''),
('vi', 'global', 'site_home_module', 'news'),
('vi', 'global', 'switch_mobi_des', '0'),
('vi', 'global', 'upload_logo', ''),
('vi', 'global', 'upload_logo_pos', 'bottomRight'),
('vi', 'global', 'autologosize1', '50'),
('vi', 'global', 'autologosize2', '40'),
('vi', 'global', 'autologosize3', '30'),
('vi', 'global', 'autologomod', ''),
('vi', 'global', 'name_show', '0'),
('vi', 'global', 'cronjobs_next_time', '1457539164'),
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'),
('vi', 'global', 'ssl_https_modules', ''),
('vi', 'seotools', 'prcservice', ''),
('vi', 'about', 'activecomm', '1'),
('vi', 'about', 'auto_postcomm', '1'),
('vi', 'about', 'allowed_comm', '-1'),
('vi', 'about', 'view_comm', '6'),
('vi', 'about', 'setcomm', '4'),
('vi', 'news', 'captcha', '1'),
('vi', 'about', 'emailcomm', '0'),
('vi', 'news', 'config_source', '0'),
('vi', 'news', 'show_no_image', ''),
('vi', 'news', 'allowed_rating_point', '1'),
('vi', 'news', 'facebookappid', ''),
('vi', 'news', 'socialbutton', '1'),
('vi', 'news', 'alias_lower', '1'),
('vi', 'news', 'tags_alias', '0'),
('vi', 'news', 'auto_tags', '0'),
('vi', 'news', 'tags_remind', '1'),
('vi', 'news', 'structure_upload', 'Ym'),
('vi', 'news', 'imgposition', '2'),
('vi', 'news', 'auto_postcomm', '1'),
('vi', 'news', 'allowed_comm', '-1'),
('vi', 'news', 'view_comm', '6'),
('vi', 'news', 'imagefull', '460'),
('vi', 'news', 'copyright', ''),
('vi', 'news', 'showtooltip', '1'),
('vi', 'news', 'tooltip_position', 'bottom'),
('vi', 'news', 'tooltip_length', '150'),
('vi', 'news', 'showhometext', '1'),
('vi', 'news', 'timecheckstatus', '0'),
('vi', 'page', 'auto_postcomm', '1'),
('vi', 'page', 'allowed_comm', '-1'),
('vi', 'page', 'view_comm', '6'),
('vi', 'page', 'setcomm', '4'),
('vi', 'page', 'activecomm', '0'),
('vi', 'page', 'emailcomm', '0'),
('vi', 'page', 'adminscomm', ''),
('vi', 'page', 'sortcomm', '0'),
('vi', 'page', 'captcha', '1'),
('vi', 'xep-hang-thi-dua', 'auto_postcomm', '1'),
('vi', 'news', 'setcomm', '4'),
('vi', 'news', 'activecomm', '1'),
('vi', 'news', 'emailcomm', '0'),
('vi', 'news', 'adminscomm', ''),
('vi', 'news', 'sortcomm', '0'),
('vi', 'contact', 'bodytext', 'Mọi liên hệ của các tổ chức và cá nhân tới nhà trường xin vui lòng điền vào biểu mẫu dưới đây. Nhà trường có các bộ phận được phân công sẽ tiếp nhận và giải quyết các vấn đề theo chức năng và nhiệm vụ của mình.'),
('vi', 'videos', 'emailcomm', '0'),
('vi', 'videos', 'allowed_comm', '-1'),
('sys', 'site', 'statistics_timezone', 'Asia/Bangkok'),
('sys', 'site', 'site_email', 'ngocanh@pacorp.vn'),
('sys', 'global', 'error_set_logs', '1'),
('sys', 'global', 'error_send_email', 'ngocanh@pacorp.vn'),
('sys', 'global', 'site_lang', 'vi'),
('sys', 'global', 'my_domains', 'www.truonghoc.com,localhost,edu.phangia.net'),
('sys', 'global', 'cookie_prefix', 'nv4c_j55wa'),
('sys', 'global', 'session_prefix', 'nv4s_o8qbzz'),
('sys', 'global', 'site_timezone', 'byCountry'),
('sys', 'global', 'proxy_blocker', '0'),
('sys', 'global', 'str_referer_blocker', '0'),
('sys', 'global', 'lang_multi', '0'),
('sys', 'global', 'lang_geo', '0'),
('sys', 'global', 'ftp_server', 'localhost'),
('sys', 'global', 'ftp_port', '21'),
('sys', 'global', 'ftp_user_name', ''),
('sys', 'global', 'ftp_user_pass', 'YpbafCTIIIP08ZnnfeIbemKW2nwkyCCD9PGZ533iG3o,'),
('sys', 'global', 'ftp_path', '/'),
('sys', 'global', 'ftp_check_login', '0'),
('vi', 'xep-hang-thi-dua', 'captcha', '1'),
('vi', 'xep-hang-thi-dua', 'allowed_comm', '-1'),
('vi', 'xep-hang-thi-dua', 'view_comm', '6'),
('vi', 'xep-hang-thi-dua', 'setcomm', '4'),
('vi', 'xep-hang-thi-dua', 'activecomm', '1'),
('vi', 'xep-hang-thi-dua', 'emailcomm', '0'),
('vi', 'xep-hang-thi-dua', 'adminscomm', ''),
('vi', 'xep-hang-thi-dua', 'sortcomm', '0'),
('vi', 'cbdoan', 'toplip', '1'),
('vi', 'cbdoan', 'per_page', '30'),
('vi', 'cbdoan', 'search', '1'),
('vi', 'about', 'sortcomm', '0'),
('vi', 'about', 'captcha', '1'),
('vi', 'laws', 'view_type', 'view_listall'),
('vi', 'laws', 'view_num', '30'),
('vi', 'laws', 'who_upload', '0'),
('vi', 'laws', 'groups_view', ''),
('vi', 'laws', 'status', '0'),
('vi', 'about', 'adminscomm', ''),
('vi', 'news', 'indexfile', 'viewcat_main_right'),
('vi', 'news', 'per_page', '20'),
('vi', 'news', 'st_links', '10'),
('vi', 'news', 'homewidth', '100'),
('vi', 'news', 'homeheight', '150'),
('vi', 'news', 'blockwidth', '70'),
('vi', 'news', 'blockheight', '75'),
('vi', 'photos', 'origin_size_width', '1500'),
('vi', 'photos', 'origin_size_height', '1500'),
('vi', 'photos', 'cr_thumb_width', '270'),
('vi', 'photos', 'cr_thumb_height', '210'),
('vi', 'photos', 'cr_thumb_quality', '90'),
('vi', 'photos', 'per_line', '3'),
('vi', 'photos', 'home_view', 'home_view_grid_by_album'),
('vi', 'photos', 'home_layout', 'body-right'),
('vi', 'photos', 'album_view', 'album_view_grid'),
('vi', 'photos', 'home_title_cut', '60'),
('vi', 'photos', 'per_page_album', '30'),
('vi', 'photos', 'per_page_photo', '30'),
('vi', 'photos', 'social_tool', '1'),
('vi', 'photos', 'fbappid', ''),
('vi', 'photos', 'structure_upload', 'Y_m'),
('vi', 'photos', 'maxupload', '2684354'),
('vi', 'photos', 'active_logo', '1'),
('vi', 'photos', 'autologosize1', '50'),
('vi', 'photos', 'autologosize2', '40'),
('vi', 'photos', 'autologosize3', '30'),
('vi', 'photos', 'module_logo', 'images/logo.png'),
('vi', 'photos', 'auto_postcomm', '1'),
('vi', 'photos', 'allowed_comm', '-1'),
('vi', 'photos', 'view_comm', '6'),
('vi', 'photos', 'setcomm', '4'),
('vi', 'photos', 'activecomm', '1'),
('vi', 'photos', 'emailcomm', '0'),
('vi', 'photos', 'adminscomm', ''),
('vi', 'photos', 'sortcomm', '0'),
('vi', 'photos', 'captcha', '1'),
('vi', 'videos', 'jwplayer_logo', '0'),
('vi', 'videos', 'jwplayer_logo_file', ''),
('vi', 'videos', 'tags_remind', '1'),
('vi', 'videos', 'structure_upload', 'Ym'),
('vi', 'videos', 'allow_user_plist', '1'),
('vi', 'videos', 'playlist_moderate', '1'),
('vi', 'videos', 'playlist_allow_detele', '1'),
('vi', 'videos', 'playlist_max_items', '20'),
('vi', 'videos', 'jwplayer_license', '0DnPZiLL7ji+GARa4m8qRvK+6vuJ9yUPP6KDBg=='),
('vi', 'videos', 'jwplayer_autoplay', 'false'),
('vi', 'videos', 'jwplayer_loop', 'false'),
('vi', 'videos', 'jwplayer_controlbar', 'true'),
('vi', 'videos', 'jwplayer_mute', 'false'),
('vi', 'videos', 'homeheight', '200'),
('vi', 'videos', 'blockwidth', '150'),
('vi', 'videos', 'blockheight', '100'),
('vi', 'videos', 'titlecut', '75'),
('vi', 'videos', 'copyright', ''),
('vi', 'videos', 'timecheckstatus', '0'),
('vi', 'videos', 'config_source', '0'),
('vi', 'videos', 'show_no_image', ''),
('vi', 'videos', 'allowed_rating_point', '1'),
('vi', 'videos', 'facebookappid', ''),
('vi', 'videos', 'socialbutton', '1'),
('vi', 'videos', 'alias_lower', '1'),
('vi', 'videos', 'tags_alias', '0'),
('vi', 'videos', 'auto_tags', '0'),
('vi', 'download', 'auto_postcomm', '1'),
('vi', 'download', 'allowed_comm', '-1'),
('vi', 'download', 'view_comm', '6'),
('vi', 'download', 'setcomm', '4'),
('vi', 'download', 'activecomm', '1'),
('vi', 'download', 'emailcomm', '0'),
('vi', 'download', 'adminscomm', ''),
('vi', 'download', 'sortcomm', '0'),
('vi', 'download', 'captcha', '1'),
('vi', 'videos', 'activecomm', '1'),
('vi', 'videos', 'auto_postcomm', '1'),
('vi', 'videos', 'view_comm', '6'),
('vi', 'videos', 'setcomm', '4'),
('vi', 'videos', 'indexfile', 'viewgrid_by_cat'),
('vi', 'videos', 'per_page', '20'),
('vi', 'videos', 'st_links', '10'),
('vi', 'videos', 'per_line', '3'),
('vi', 'videos', 'homewidth', '270'),
('vi', 'videos', 'adminscomm', ''),
('vi', 'videos', 'sortcomm', '0'),
('vi', 'videos', 'captcha', '1');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_cookies`
--

CREATE TABLE `pacorp_cookies` (
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(11) NOT NULL DEFAULT '0',
  `secure` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_counter`
--

CREATE TABLE `pacorp_counter` (
  `c_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_val` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_update` int(11) NOT NULL DEFAULT '0',
  `c_count` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `vi_count` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_counter`
--

INSERT INTO `pacorp_counter` (`c_type`, `c_val`, `last_update`, `c_count`, `vi_count`) VALUES
('c_time', 'start', 0, 0, 0),
('c_time', 'last', 0, 1457538719, 0),
('total', 'hits', 1457538719, 12639, 12639),
('year', '2016', 1457538719, 12639, 12639),
('year', '2017', 0, 0, 0),
('year', '2018', 0, 0, 0),
('year', '2019', 0, 0, 0),
('year', '2020', 0, 0, 0),
('year', '2021', 0, 0, 0),
('year', '2022', 0, 0, 0),
('year', '2023', 0, 0, 0),
('year', '2024', 0, 0, 0),
('month', 'Jan', 1454253010, 1764, 1764),
('month', 'Feb', 1456736368, 10866, 10866),
('month', 'Mar', 1457538719, 9, 9),
('month', 'Apr', 0, 0, 0),
('month', 'May', 0, 0, 0),
('month', 'Jun', 0, 0, 0),
('month', 'Jul', 0, 0, 0),
('month', 'Aug', 0, 0, 0),
('month', 'Sep', 0, 0, 0),
('month', 'Oct', 0, 0, 0),
('month', 'Nov', 0, 0, 0),
('month', 'Dec', 0, 0, 0),
('day', '01', 1454344553, 0, 0),
('day', '02', 1454432351, 0, 0),
('day', '03', 1456991391, 1, 1),
('day', '04', 1454605177, 0, 0),
('day', '05', 1457123674, 1, 1),
('day', '06', 1457281096, 5, 5),
('day', '07', 1454863882, 0, 0),
('day', '08', 1454949985, 0, 0),
('day', '09', 1457538719, 2, 2),
('day', '10', 1455123337, 0, 0),
('day', '11', 1455133813, 0, 0),
('day', '12', 1455296079, 0, 0),
('day', '13', 1455382625, 0, 0),
('day', '14', 1455468772, 0, 0),
('day', '15', 1455535855, 0, 0),
('day', '16', 1455641994, 0, 0),
('day', '17', 1455721630, 0, 0),
('day', '18', 1455814238, 0, 0),
('day', '19', 1455897849, 0, 0),
('day', '20', 1455987439, 0, 0),
('day', '21', 1456073721, 0, 0),
('day', '22', 1456159656, 0, 0),
('day', '23', 1456245627, 0, 0),
('day', '24', 1456332819, 0, 0),
('day', '25', 1456419382, 0, 0),
('day', '26', 1456495054, 0, 0),
('day', '27', 1456570539, 0, 0),
('day', '28', 1454000245, 0, 0),
('day', '29', 1456736368, 0, 0),
('day', '30', 1454173171, 0, 0),
('day', '31', 1454253010, 0, 0),
('dayofweek', 'Sunday', 1457281096, 1700, 1700),
('dayofweek', 'Monday', 1456736368, 1575, 1575),
('dayofweek', 'Tuesday', 1456245627, 1917, 1917),
('dayofweek', 'Wednesday', 1457538719, 1626, 1626),
('dayofweek', 'Thursday', 1456991391, 1702, 1702),
('dayofweek', 'Friday', 1456495054, 2216, 2216),
('dayofweek', 'Saturday', 1457123674, 1903, 1903),
('hour', '00', 1456423192, 0, 0),
('hour', '01', 1456426737, 0, 0),
('hour', '02', 1456429738, 0, 0),
('hour', '03', 1457123674, 0, 0),
('hour', '04', 1456437239, 0, 0),
('hour', '05', 1456526933, 0, 0),
('hour', '06', 1456527874, 0, 0),
('hour', '07', 1456533988, 0, 0),
('hour', '08', 1456537393, 0, 0),
('hour', '09', 1456538945, 0, 0),
('hour', '10', 1456459149, 0, 0),
('hour', '11', 1456548923, 0, 0),
('hour', '12', 1456550203, 0, 0),
('hour', '13', 1456555017, 0, 0),
('hour', '14', 1456991391, 0, 0),
('hour', '15', 1456736368, 0, 0),
('hour', '16', 1456566935, 0, 0),
('hour', '17', 1457260441, 0, 0),
('hour', '18', 1456487468, 0, 0),
('hour', '19', 1456489415, 0, 0),
('hour', '20', 1456495054, 0, 0),
('hour', '21', 1456411793, 0, 0),
('hour', '22', 1457538719, 2, 2),
('hour', '23', 1457281096, 0, 0),
('bot', 'googlebot', 0, 0, 0),
('bot', 'msnbot', 0, 0, 0),
('bot', 'bingbot', 0, 0, 0),
('bot', 'yahooslurp', 0, 0, 0),
('bot', 'w3cvalidator', 0, 0, 0),
('browser', 'opera', 0, 0, 0),
('browser', 'operamini', 0, 0, 0),
('browser', 'webtv', 0, 0, 0),
('browser', 'explorer', 0, 0, 0),
('browser', 'edge', 0, 0, 0),
('browser', 'pocket', 0, 0, 0),
('browser', 'konqueror', 0, 0, 0),
('browser', 'icab', 0, 0, 0),
('browser', 'omniweb', 0, 0, 0),
('browser', 'firebird', 0, 0, 0),
('browser', 'firefox', 0, 0, 0),
('browser', 'iceweasel', 0, 0, 0),
('browser', 'shiretoko', 0, 0, 0),
('browser', 'mozilla', 0, 0, 0),
('browser', 'amaya', 0, 0, 0),
('browser', 'lynx', 0, 0, 0),
('browser', 'safari', 0, 0, 0),
('browser', 'iphone', 0, 0, 0),
('browser', 'ipod', 0, 0, 0),
('browser', 'ipad', 0, 0, 0),
('browser', 'chrome', 1457538719, 14, 14),
('browser', 'android', 0, 0, 0),
('browser', 'googlebot', 0, 0, 0),
('browser', 'yahooslurp', 0, 0, 0),
('browser', 'w3cvalidator', 0, 0, 0),
('browser', 'blackberry', 0, 0, 0),
('browser', 'icecat', 0, 0, 0),
('browser', 'nokias60', 0, 0, 0),
('browser', 'nokia', 0, 0, 0),
('browser', 'msn', 0, 0, 0),
('browser', 'msnbot', 0, 0, 0),
('browser', 'bingbot', 0, 0, 0),
('browser', 'netscape', 0, 0, 0),
('browser', 'galeon', 0, 0, 0),
('browser', 'netpositive', 0, 0, 0),
('browser', 'phoenix', 0, 0, 0),
('browser', 'Mobile', 0, 0, 0),
('browser', 'bots', 0, 0, 0),
('browser', 'Unknown', 0, 0, 0),
('os', 'unknown', 0, 0, 0),
('os', 'win', 0, 0, 0),
('os', 'win10', 0, 0, 0),
('os', 'win8', 0, 0, 0),
('os', 'win7', 0, 0, 0),
('os', 'win2003', 0, 0, 0),
('os', 'winvista', 0, 0, 0),
('os', 'wince', 0, 0, 0),
('os', 'winxp', 0, 0, 0),
('os', 'win2000', 0, 0, 0),
('os', 'apple', 1457538719, 14, 14),
('os', 'linux', 0, 0, 0),
('os', 'os2', 0, 0, 0),
('os', 'beos', 0, 0, 0),
('os', 'iphone', 0, 0, 0),
('os', 'ipod', 0, 0, 0),
('os', 'ipad', 0, 0, 0),
('os', 'blackberry', 0, 0, 0),
('os', 'nokia', 0, 0, 0),
('os', 'freebsd', 0, 0, 0),
('os', 'openbsd', 0, 0, 0),
('os', 'netbsd', 0, 0, 0),
('os', 'sunos', 0, 0, 0),
('os', 'opensolaris', 0, 0, 0),
('os', 'android', 0, 0, 0),
('os', 'irix', 0, 0, 0),
('os', 'palm', 0, 0, 0),
('country', 'AD', 0, 0, 0),
('country', 'AE', 0, 0, 0),
('country', 'AF', 0, 0, 0),
('country', 'AG', 0, 0, 0),
('country', 'AI', 0, 0, 0),
('country', 'AL', 0, 0, 0),
('country', 'AM', 0, 0, 0),
('country', 'AN', 0, 0, 0),
('country', 'AO', 0, 0, 0),
('country', 'AQ', 0, 0, 0),
('country', 'AR', 0, 0, 0),
('country', 'AS', 0, 0, 0),
('country', 'AT', 1455912531, 1, 1),
('country', 'AU', 1454019930, 1, 1),
('country', 'AW', 0, 0, 0),
('country', 'AZ', 0, 0, 0),
('country', 'BA', 0, 0, 0),
('country', 'BB', 0, 0, 0),
('country', 'BD', 0, 0, 0),
('country', 'BE', 0, 0, 0),
('country', 'BF', 0, 0, 0),
('country', 'BG', 0, 0, 0),
('country', 'BH', 0, 0, 0),
('country', 'BI', 0, 0, 0),
('country', 'BJ', 0, 0, 0),
('country', 'BM', 0, 0, 0),
('country', 'BN', 0, 0, 0),
('country', 'BO', 0, 0, 0),
('country', 'BR', 1454159719, 5, 5),
('country', 'BS', 0, 0, 0),
('country', 'BT', 0, 0, 0),
('country', 'BW', 0, 0, 0),
('country', 'BY', 0, 0, 0),
('country', 'BZ', 0, 0, 0),
('country', 'CA', 1455511137, 9, 9),
('country', 'CD', 0, 0, 0),
('country', 'CF', 0, 0, 0),
('country', 'CG', 0, 0, 0),
('country', 'CH', 0, 0, 0),
('country', 'CI', 0, 0, 0),
('country', 'CK', 0, 0, 0),
('country', 'CL', 0, 0, 0),
('country', 'CM', 0, 0, 0),
('country', 'CN', 0, 0, 0),
('country', 'CO', 0, 0, 0),
('country', 'CR', 0, 0, 0),
('country', 'CS', 0, 0, 0),
('country', 'CU', 0, 0, 0),
('country', 'CV', 0, 0, 0),
('country', 'CY', 0, 0, 0),
('country', 'CZ', 1456273627, 2, 2),
('country', 'DE', 1456468526, 653, 653),
('country', 'DJ', 0, 0, 0),
('country', 'DK', 1456064791, 1, 1),
('country', 'DM', 0, 0, 0),
('country', 'DO', 0, 0, 0),
('country', 'DZ', 0, 0, 0),
('country', 'EC', 0, 0, 0),
('country', 'EE', 1454503330, 1, 1),
('country', 'EG', 0, 0, 0),
('country', 'ER', 0, 0, 0),
('country', 'ES', 0, 0, 0),
('country', 'ET', 0, 0, 0),
('country', 'EU', 0, 0, 0),
('country', 'FI', 0, 0, 0),
('country', 'FJ', 0, 0, 0),
('country', 'FK', 0, 0, 0),
('country', 'FM', 0, 0, 0),
('country', 'FO', 0, 0, 0),
('country', 'FR', 1456411205, 119, 119),
('country', 'GA', 0, 0, 0),
('country', 'GB', 1456402746, 53, 53),
('country', 'GD', 0, 0, 0),
('country', 'GE', 0, 0, 0),
('country', 'GF', 0, 0, 0),
('country', 'GH', 0, 0, 0),
('country', 'GI', 0, 0, 0),
('country', 'GL', 0, 0, 0),
('country', 'GM', 0, 0, 0),
('country', 'GN', 0, 0, 0),
('country', 'GP', 0, 0, 0),
('country', 'GQ', 0, 0, 0),
('country', 'GR', 0, 0, 0),
('country', 'GS', 0, 0, 0),
('country', 'GT', 0, 0, 0),
('country', 'GU', 0, 0, 0),
('country', 'GW', 0, 0, 0),
('country', 'GY', 0, 0, 0),
('country', 'HK', 1454058383, 6, 6),
('country', 'HN', 0, 0, 0),
('country', 'HR', 0, 0, 0),
('country', 'HT', 0, 0, 0),
('country', 'HU', 0, 0, 0),
('country', 'ID', 0, 0, 0),
('country', 'IE', 1456020526, 5, 5),
('country', 'IL', 0, 0, 0),
('country', 'IN', 1456332819, 2, 2),
('country', 'IO', 0, 0, 0),
('country', 'IQ', 0, 0, 0),
('country', 'IR', 0, 0, 0),
('country', 'IS', 0, 0, 0),
('country', 'IT', 1455752980, 12, 12),
('country', 'JM', 0, 0, 0),
('country', 'JO', 0, 0, 0),
('country', 'JP', 1456319672, 5, 5),
('country', 'KE', 0, 0, 0),
('country', 'KG', 0, 0, 0),
('country', 'KH', 0, 0, 0),
('country', 'KI', 0, 0, 0),
('country', 'KM', 0, 0, 0),
('country', 'KN', 0, 0, 0),
('country', 'KR', 0, 0, 0),
('country', 'KW', 0, 0, 0),
('country', 'KY', 0, 0, 0),
('country', 'KZ', 0, 0, 0),
('country', 'LA', 0, 0, 0),
('country', 'LB', 0, 0, 0),
('country', 'LC', 0, 0, 0),
('country', 'LI', 0, 0, 0),
('country', 'LK', 0, 0, 0),
('country', 'LR', 0, 0, 0),
('country', 'LS', 0, 0, 0),
('country', 'LT', 0, 0, 0),
('country', 'LU', 0, 0, 0),
('country', 'LV', 0, 0, 0),
('country', 'LY', 0, 0, 0),
('country', 'MA', 0, 0, 0),
('country', 'MC', 0, 0, 0),
('country', 'MD', 0, 0, 0),
('country', 'MG', 0, 0, 0),
('country', 'MH', 0, 0, 0),
('country', 'MK', 0, 0, 0),
('country', 'ML', 0, 0, 0),
('country', 'MM', 0, 0, 0),
('country', 'MN', 0, 0, 0),
('country', 'MO', 0, 0, 0),
('country', 'MP', 0, 0, 0),
('country', 'MQ', 0, 0, 0),
('country', 'MR', 0, 0, 0),
('country', 'MT', 0, 0, 0),
('country', 'MU', 0, 0, 0),
('country', 'MV', 0, 0, 0),
('country', 'MW', 0, 0, 0),
('country', 'MX', 1454975550, 1, 1),
('country', 'MY', 0, 0, 0),
('country', 'MZ', 0, 0, 0),
('country', 'NA', 0, 0, 0),
('country', 'NC', 0, 0, 0),
('country', 'NE', 0, 0, 0),
('country', 'NF', 0, 0, 0),
('country', 'NG', 0, 0, 0),
('country', 'NI', 0, 0, 0),
('country', 'NL', 1456561018, 116, 116),
('country', 'NO', 1455483635, 3, 3),
('country', 'NP', 0, 0, 0),
('country', 'NR', 0, 0, 0),
('country', 'NU', 0, 0, 0),
('country', 'NZ', 0, 0, 0),
('country', 'OM', 0, 0, 0),
('country', 'PA', 0, 0, 0),
('country', 'PE', 0, 0, 0),
('country', 'PF', 0, 0, 0),
('country', 'PG', 0, 0, 0),
('country', 'PH', 0, 0, 0),
('country', 'PK', 0, 0, 0),
('country', 'PL', 0, 0, 0),
('country', 'PR', 0, 0, 0),
('country', 'PS', 0, 0, 0),
('country', 'PT', 0, 0, 0),
('country', 'PW', 0, 0, 0),
('country', 'PY', 0, 0, 0),
('country', 'QA', 0, 0, 0),
('country', 'RE', 0, 0, 0),
('country', 'RO', 1456162423, 5, 5),
('country', 'RU', 1456560312, 19, 19),
('country', 'RW', 0, 0, 0),
('country', 'SA', 0, 0, 0),
('country', 'SB', 0, 0, 0),
('country', 'SC', 0, 0, 0),
('country', 'SD', 0, 0, 0),
('country', 'SE', 0, 0, 0),
('country', 'SG', 0, 0, 0),
('country', 'SI', 0, 0, 0),
('country', 'SK', 0, 0, 0),
('country', 'SL', 0, 0, 0),
('country', 'SM', 0, 0, 0),
('country', 'SN', 0, 0, 0),
('country', 'SO', 0, 0, 0),
('country', 'SR', 0, 0, 0),
('country', 'ST', 0, 0, 0),
('country', 'SV', 0, 0, 0),
('country', 'SY', 0, 0, 0),
('country', 'SZ', 0, 0, 0),
('country', 'TD', 0, 0, 0),
('country', 'TF', 0, 0, 0),
('country', 'TG', 0, 0, 0),
('country', 'TH', 0, 0, 0),
('country', 'TJ', 0, 0, 0),
('country', 'TK', 0, 0, 0),
('country', 'TL', 0, 0, 0),
('country', 'TM', 0, 0, 0),
('country', 'TN', 1455852188, 1, 1),
('country', 'TO', 0, 0, 0),
('country', 'TR', 1454756173, 1, 1),
('country', 'TT', 0, 0, 0),
('country', 'TV', 0, 0, 0),
('country', 'TW', 1455980910, 2, 2),
('country', 'TZ', 0, 0, 0),
('country', 'UA', 1456339851, 66, 66),
('country', 'UG', 0, 0, 0),
('country', 'US', 1456548923, 2293, 2293),
('country', 'UY', 0, 0, 0),
('country', 'UZ', 0, 0, 0),
('country', 'VA', 0, 0, 0),
('country', 'VC', 0, 0, 0),
('country', 'VE', 0, 0, 0),
('country', 'VG', 0, 0, 0),
('country', 'VI', 0, 0, 0),
('country', 'VN', 1456562505, 9194, 9194),
('country', 'VU', 0, 0, 0),
('country', 'WS', 0, 0, 0),
('country', 'YE', 0, 0, 0),
('country', 'YT', 0, 0, 0),
('country', 'YU', 0, 0, 0),
('country', 'ZA', 1455931242, 1, 1),
('country', 'ZM', 0, 0, 0),
('country', 'ZW', 0, 0, 0),
('country', 'ZZ', 1457538719, 62, 62),
('country', 'unkown', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_cronjobs`
--

CREATE TABLE `pacorp_cronjobs` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `start_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `inter_val` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `run_file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_func` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `del` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `act` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `last_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `last_result` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_cronjobs`
--

INSERT INTO `pacorp_cronjobs` (`id`, `start_time`, `inter_val`, `run_file`, `run_func`, `params`, `del`, `is_sys`, `act`, `last_time`, `last_result`, `vi_cron_name`) VALUES
(1, 1453703239, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1457538864, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'),
(2, 1453703239, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1457536899, 1, 'Tự động lưu CSDL'),
(3, 1453703239, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1457536899, 1, 'Xóa các file tạm trong thư mục tmp'),
(4, 1453703239, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1457538864, 1, 'Xóa IP log files, Xóa các file nhật ký truy cập'),
(5, 1453703239, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1457536899, 1, 'Xóa các file error_log quá hạn'),
(6, 1453703239, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin'),
(7, 1453703239, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1457536899, 1, 'Xóa các referer quá hạn'),
(8, 1453703239, 1440, 'siteDiagnostic_update.php', 'cron_siteDiagnostic_update', '', 0, 0, 1, 1457536899, 1, 'Cập nhật đánh giá site từ các máy chủ tìm kiếm'),
(9, 1453703239, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1457536899, 1, 'Kiểm tra phiên bản NukeViet'),
(10, 1453703239, 1440, 'notification_autodel.php', 'cron_notification_autodel', '', 0, 1, 1, 1457536899, 1, 'Xóa thông báo cũ');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_extension_files`
--

CREATE TABLE `pacorp_extension_files` (
  `idfile` mediumint(8) UNSIGNED NOT NULL,
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `title` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lastmodified` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `duplicate` smallint(4) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_googleplus`
--

CREATE TABLE `pacorp_googleplus` (
  `gid` smallint(5) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `idprofile` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `add_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edit_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_groups`
--

CREATE TABLE `pacorp_groups` (
  `group_id` smallint(5) UNSIGNED NOT NULL,
  `title` varchar(240) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `content` text COLLATE utf8mb4_unicode_ci,
  `group_type` tinyint(4) UNSIGNED NOT NULL DEFAULT '0' COMMENT '0:Sys, 1:approval, 2:public',
  `group_color` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_avatar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `weight` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `act` tinyint(1) UNSIGNED NOT NULL,
  `idsite` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `numbers` mediumint(9) UNSIGNED NOT NULL DEFAULT '0',
  `siteus` tinyint(4) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_groups`
--

INSERT INTO `pacorp_groups` (`group_id`, `title`, `description`, `content`, `group_type`, `group_color`, `group_avatar`, `is_default`, `add_time`, `exp_time`, `weight`, `act`, `idsite`, `numbers`, `siteus`) VALUES
(1, 'Super admin', 'Super Admin', '', 0, '', '', 0, 1453703239, 0, 1, 1, 0, 0, 0),
(2, 'General admin', 'General Admin', '', 0, '', '', 0, 1453703239, 0, 2, 1, 0, 4, 0),
(3, 'Module admin', 'Module Admin', '', 0, '', '', 0, 1453703239, 0, 3, 1, 0, 10, 0),
(4, 'Users', 'Users', '', 0, '', '', 0, 1453703239, 0, 4, 1, 0, 16, 0),
(5, 'Guest', 'Guest', '', 0, '', '', 0, 1453703239, 0, 5, 1, 0, 0, 0),
(6, 'All', 'All', '', 0, '', '', 0, 1453703239, 0, 6, 1, 0, 0, 0),
(7, 'New Users', 'New Users', '', 0, '', '', 0, 1456564968, 0, 5, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_groups_users`
--

CREATE TABLE `pacorp_groups_users` (
  `group_id` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `userid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `is_leader` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `approved` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_groups_users`
--

INSERT INTO `pacorp_groups_users` (`group_id`, `userid`, `is_leader`, `approved`, `data`) VALUES
(2, 2, 0, 1, '0'),
(2, 3, 0, 1, '0'),
(2, 4, 0, 1, '0'),
(3, 6, 0, 1, '0'),
(3, 5, 0, 1, '0'),
(3, 7, 0, 1, '0'),
(3, 8, 0, 1, '0'),
(3, 9, 0, 1, '0'),
(3, 10, 0, 1, '0'),
(3, 11, 0, 1, '0'),
(3, 12, 0, 1, '0'),
(2, 13, 0, 1, '0'),
(3, 14, 0, 1, '0'),
(3, 15, 0, 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_language`
--

CREATE TABLE `pacorp_language` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `idfile` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `lang_key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_language_file`
--

CREATE TABLE `pacorp_language_file` (
  `idfile` mediumint(8) UNSIGNED NOT NULL,
  `module` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_file` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `langtype` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_logs`
--

CREATE TABLE `pacorp_logs` (
  `id` int(11) NOT NULL,
  `lang` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note_action` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_acess` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `userid` mediumint(8) UNSIGNED NOT NULL,
  `log_time` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_logs`
--

INSERT INTO `pacorp_logs` (`id`, `lang`, `module_name`, `name_key`, `note_action`, `link_acess`, `userid`, `log_time`) VALUES
(1, 'vi', 'siteinfo', 'Xóa toàn bộ nhật kí hệ thống', 'All', '', 1, 1454137386),
(2, 'vi', 'login', '[admin2] Đăng nhập', ' Client IP:58.187.163.39', '', 0, 1454169339),
(3, 'vi', 'videos', 'Thêm chuyên mục', 'Ngoại khóa', '', 2, 1454169568),
(4, 'vi', 'videos', 'Thêm Videos', '&#91;12B4&#93; - Bảo vệ môi trường', '', 2, 1454169673),
(5, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:14.169.78.146', '', 0, 1454234558),
(6, 'vi', 'modules', 'Xóa module "videos"', '', '', 1, 1454234624),
(7, 'vi', 'modules', 'Thiết lập module mới videos', '', '', 1, 1454234628),
(8, 'vi', 'modules', 'Sửa module &ldquo;videos&rdquo;', '', '', 1, 1454234745),
(9, 'vi', 'videos', 'Thêm chuyên mục', 'Sự kiện', '', 1, 1454234760),
(10, 'vi', 'videos', 'Thêm chuyên mục', 'Ngoại khóa', '', 1, 1454234766),
(11, 'vi', 'videos', 'Thêm Videos', '&#91;12B4&#93; - Bảo vệ môi trường', '', 1, 1454234804),
(12, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:14.169.78.146', '', 0, 1454306174),
(13, 'vi', 'login', '[admin2] Đăng nhập', ' Client IP:116.111.14.52', '', 0, 1454368705),
(14, 'vi', 'authors', 'Thêm Quản trị', 'Username: pdtu', '', 2, 1454369084),
(15, 'vi', 'upload', 'Upload file', 'uploads/about/anh-to-toan.jpg', '', 2, 1454369901),
(16, 'vi', 'modules', 'Thứ tự module: download', '21 -> 10', '', 2, 1454371659),
(17, 'vi', 'modules', 'Thứ tự module: statistics', '21 -> 18', '', 2, 1454371669),
(18, 'vi', 'modules', 'Thứ tự module: banners', '21 -> 19', '', 2, 1454371673),
(19, 'vi', 'modules', 'Thứ tự module: xep-hang-thi-dua', '21 -> 11', '', 2, 1454371684),
(20, 'vi', 'modules', 'Thứ tự module: photos', '21 -> 12', '', 2, 1454371690),
(21, 'vi', 'modules', 'Thứ tự module: videos', '21 -> 13', '', 2, 1454371692),
(22, 'vi', 'login', '[admin2] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454376707),
(23, 'vi', 'authors', 'Thêm Quản trị', 'Username: english-hhg', '', 2, 1454376929),
(24, 'vi', 'login', '[ daongan1991 ] Đăng nhập Thất bại', ' Client IP:117.4.53.146', '', 0, 1454376960),
(25, 'vi', 'login', '[english-hhg] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454376963),
(26, 'vi', 'authors', 'Thêm Quản trị', 'Username: daongan1991', '', 2, 1454377022),
(27, 'vi', 'login', '[daongan1991] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454377034),
(28, 'vi', 'authors', 'Thêm Quản trị', 'Username: hường', '', 2, 1454377084),
(29, 'vi', 'login', '[hường] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454377097),
(30, 'vi', 'authors', 'Thêm Quản trị', 'Username: kmyen', '', 2, 1454377194),
(31, 'vi', 'authors', 'Thêm Quản trị', 'Username: Quyen', '', 2, 1454377275),
(32, 'vi', 'authors', 'Thêm Quản trị', 'Username: Vanhg', '', 2, 1454377321),
(33, 'vi', 'login', '[Quyen] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454377385),
(34, 'vi', 'login', '[kmyen] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454377385),
(35, 'vi', 'login', '[ sudiagdcdhg ] Đăng nhập Thất bại', ' Client IP:117.4.53.146', '', 0, 1454377405),
(36, 'vi', 'login', '[ sudiagdcdhg ] Đăng nhập Thất bại', ' Client IP:117.4.53.146', '', 0, 1454377428),
(37, 'vi', 'authors', 'Thêm Quản trị', 'Username: sudiagdcdhg', '', 2, 1454377430),
(38, 'vi', 'login', '[Vanhg] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454377445),
(39, 'vi', 'login', '[sudiagdcdhg] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454377451),
(40, 'vi', 'authors', 'Sửa thông tin Quản trị website', 'Username: english-hhg', '', 2, 1454377461),
(41, 'vi', 'authors', 'Sửa thông tin Quản trị website', 'Username: english-hhg', '', 2, 1454377469),
(42, 'vi', 'authors', 'Sửa thông tin Quản trị website', 'Username: hường', '', 2, 1454377991),
(43, 'vi', 'authors', 'Sửa thông tin Quản trị website', 'Username: daongan1991', '', 2, 1454378044),
(44, 'vi', 'news', 'edit_tags', 'thông-báo', '', 2, 1454378114),
(45, 'vi', 'authors', 'Thêm Quản trị', 'Username: nguyenthithu', '', 2, 1454378341),
(46, 'vi', 'login', '[nguyenthithu] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454379355),
(47, 'vi', 'login', '[sudiagdcdhg] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454379638),
(48, 'vi', 'upload', 'Upload file', 'uploads/about/anh.jpg', '', 5, 1454380536),
(49, 'vi', 'about', 'Add', ' ', '', 5, 1454380678),
(50, 'vi', 'upload', 'Upload file', 'uploads/about/12494951_1258617394164757_3605795044239102670_n.jpg', '', 6, 1454380778),
(51, 'vi', 'upload', 'Upload file', 'uploads/about/sngw.jpg', '', 8, 1454380902),
(52, 'vi', 'about', 'Add', ' ', '', 8, 1454380965),
(53, 'vi', 'about', 'Edit', 'ID: 3', '', 5, 1454381012),
(54, 'vi', 'about', 'Edit', 'ID: 3', '', 5, 1454381043),
(55, 'vi', 'about', 'Add', ' ', '', 6, 1454381123),
(56, 'vi', 'upload', 'Upload file', 'uploads/about/616604_580892198720951_3403248310021076647_o.jpg', '', 7, 1454381172),
(57, 'vi', 'about', 'Add', ' ', '', 9, 1454381338),
(58, 'vi', 'about', 'Add', ' ', '', 7, 1454381431),
(59, 'vi', 'about', 'Edit', 'ID: 5', '', 6, 1454381435),
(60, 'vi', 'about', 'Edit', 'ID: 7', '', 7, 1454381506),
(61, 'vi', 'upload', 'Upload file', 'uploads/news/to-sdgdcd.jpg', '', 11, 1454381610),
(62, 'vi', 'login', '[admin2] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454381924),
(63, 'vi', 'upload', 'Upload file', 'uploads/about/to-sdgdcd.jpg', '', 11, 1454382102),
(64, 'vi', 'login', '[ doantn.hongai ] Đăng nhập Thất bại', ' Client IP:117.4.53.146', '', 0, 1454382165),
(65, 'vi', 'authors', 'Thêm Quản trị', 'Username: doantn.hongai', '', 2, 1454382196),
(66, 'vi', 'login', '[doantn.hongai] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454382212),
(67, 'vi', 'download', 'Thêm chủ đề', 'Đề thi &amp; Đáp án', '', 5, 1454382297),
(68, 'vi', 'about', 'Add', ' ', '', 11, 1454382332),
(69, 'vi', 'download', 'Sửa chủ đề', 'Đề thi &amp; Đáp án', '', 5, 1454382335),
(70, 'vi', 'about', 'Edit', 'ID: 8', '', 11, 1454382395),
(71, 'vi', 'upload', 'Upload file', 'uploads/about/1-de.jpg', '', 5, 1454382700),
(72, 'vi', 'login', '[doantn.hongai] Thoát khỏi tài khoản Quản trị', ' Client IP:117.4.53.146', '', 0, 1454382892),
(73, 'vi', 'login', '[nguyenthithu] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454382896),
(74, 'vi', 'upload', 'Upload file', 'uploads/download/images/12631541_1684973511743253_5387227554684466025_n.png', '', 6, 1454382928),
(75, 'vi', 'upload', 'Upload file', 'uploads/download/images/12548875_1684973501743254_3781019922407815351_n.png', '', 6, 1454382946),
(76, 'vi', 'upload', 'Upload file', 'uploads/about/to-van.jpg', '', 10, 1454382948),
(77, 'vi', 'upload', 'Upload file', 'uploads/download/images/12541141_1684973535076584_8753308090250855472_n.png', '', 6, 1454382958),
(78, 'vi', 'upload', 'Upload file', 'uploads/download/images/12540875_1684973525076585_5655432020833042099_n.png', '', 6, 1454382968),
(79, 'vi', 'upload', 'Upload file', 'uploads/download/images/12507433_1684973518409919_1868711769373160982_n.png', '', 6, 1454382983),
(80, 'vi', 'upload', 'Upload file', 'uploads/download/images/944039_1684973548409916_8676470728969654299_n.png', '', 6, 1454383004),
(81, 'vi', 'about', 'Add', ' ', '', 10, 1454383059),
(82, 'vi', 'photos', 'Add A Album', 'album_id: 2', '', 7, 1454383136),
(83, 'vi', 'login', '[ vatlihg ] Đăng nhập Thất bại', ' Client IP:117.4.53.146', '', 0, 1454383217),
(84, 'vi', 'login', '[ vatlihg ] Đăng nhập Thất bại', ' Client IP:117.4.53.146', '', 0, 1454383225),
(85, 'vi', 'login', '[ vatlihg ] Đăng nhập Thất bại', ' Client IP:117.4.53.146', '', 0, 1454383271),
(86, 'vi', 'login', '[ vatlihg@gmail.com ] Đăng nhập Thất bại', ' Client IP:117.4.53.146', '', 0, 1454383298),
(87, 'vi', 'photos', 'Add A Album', 'album_id: 3', '', 8, 1454383347),
(88, 'vi', 'upload', 'Upload file', 'uploads/download/files/speaking-topics10cb2015.doc', '', 6, 1454383348),
(89, 'vi', 'login', '[ vatlihg ] Đăng nhập Thất bại', ' Client IP:117.4.53.146', '', 0, 1454383397),
(90, 'vi', 'upload', 'Upload file', 'uploads/about/to-sdgdcd_1.jpg', '', 11, 1454383418),
(91, 'vi', 'download', 'Thêm file mới', 'Speaking topics-g10 &#40;2015-2016&#41;', '', 6, 1454383435),
(92, 'vi', 'upload', 'Upload file', 'uploads/download/1-de.jpg', '', 5, 1454383438),
(93, 'vi', 'upload', 'Upload file', 'uploads/download/2-da.jpg', '', 5, 1454383439),
(94, 'vi', 'upload', 'Upload file', 'uploads/download/3-da.jpg', '', 5, 1454383439),
(95, 'vi', 'upload', 'Upload file', 'uploads/download/4-da.jpg', '', 5, 1454383441),
(96, 'vi', 'upload', 'Upload file', 'uploads/download/5-da.jpg', '', 5, 1454383442),
(97, 'vi', 'upload', 'Upload file', 'uploads/download/6-da.jpg', '', 5, 1454383443),
(98, 'vi', 'upload', 'Upload file', 'uploads/download/7-da.jpg', '', 5, 1454383443),
(99, 'vi', 'authors', 'Thêm Quản trị', 'Username: vatlihg', '', 2, 1454383497),
(100, 'vi', 'login', '[vatlihg] Đăng nhập', ' Client IP:117.4.53.146', '', 0, 1454383513),
(101, 'vi', 'upload', 'Upload file', 'uploads/download/files/de-thi-thu-lan-1-2016.rar', '', 14, 1454383653),
(102, 'vi', 'upload', 'Upload file', 'uploads/download/files/thi-thu-dh-lan-1c3-hg-15-16-1.doc', '', 5, 1454383686),
(103, 'vi', 'download', 'Thêm file mới', 'Đề thi thử đại học lần 1 &amp; Đáp án năm học 2015 - 2016', '', 5, 1454383736),
(104, 'vi', 'download', 'Thêm file mới', 'ĐỀ THI THỬ THPT QG LẦN 1 MÔN VẬT LÍ', '', 14, 1454383840),
(105, 'vi', 'download', 'Sửa file', 'Đề thi thử THPTQG lần 1 &amp; Đáp án năm học 2015 - 2016', '', 5, 1454383916),
(106, 'vi', 'login', '[daongan1991] Thoát khỏi tài khoản Quản trị', ' Client IP:117.4.53.146', '', 0, 1454383972),
(107, 'vi', 'about', 'Edit', 'ID: 8', '', 11, 1454384128),
(108, 'vi', 'login', '[admin2] Đăng nhập', ' Client IP:116.111.14.52', '', 0, 1454560035),
(109, 'vi', 'videos', 'Thêm Videos', '&#91;Sơ kết HKI 2015-2016&#93; Nhảy hiện đại', '', 2, 1454560149),
(110, 'vi', 'videos', 'Thêm chuyên mục', 'Công tác phong trào', '', 2, 1454560602),
(111, 'vi', 'videos', 'Thêm chuyên mục', 'Hoạt động Dạy-Học', '', 2, 1454560624),
(112, 'vi', 'videos', 'Thêm Videos', '&#91;Văn nghệ sơ kết HKI&#93; - Năm mới bình an', '', 2, 1454561418),
(113, 'vi', 'login', '[admin2] Đăng nhập', ' Client IP:171.234.100.245', '', 0, 1454847606),
(114, 'vi', 'themes', 'Sửa block', 'Name : VIDEO GIỚI THIỆU', '', 2, 1454847819),
(115, 'vi', 'login', '[admin2] Đăng nhập', ' Client IP:171.234.100.245', '', 0, 1454931965),
(116, 'vi', 'login', '[admin2] Đăng nhập', ' Client IP:116.111.43.131', '', 0, 1455838117),
(117, 'vi', 'login', '[admin2] Đăng nhập', ' Client IP:116.111.43.131', '', 0, 1456180676),
(118, 'vi', 'authors', 'Thêm Quản trị', 'Username: Adelyn Nguyễn', '', 2, 1456180795),
(119, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:14.169.14.27', '', 0, 1456562542),
(120, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1456564925),
(121, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1456564937),
(122, 'vi', 'menu', 'Delete menu item', 'Item ID 119', '', 1, 1456565075),
(123, 'vi', 'menu', 'Delete menu item', 'Item ID 120', '', 1, 1456565075),
(124, 'vi', 'menu', 'Delete menu item', 'Item ID 122', '', 1, 1456565075),
(125, 'vi', 'menu', 'Delete menu item', 'Item ID 123', '', 1, 1456565075),
(126, 'vi', 'menu', 'Delete menu item', 'Item ID 124', '', 1, 1456565075),
(127, 'vi', 'menu', 'Delete menu item', 'Item ID 126', '', 1, 1456565075),
(128, 'vi', 'menu', 'Delete menu item', 'Item ID 127', '', 1, 1456565075),
(129, 'vi', 'menu', 'Delete menu item', 'Item ID 128', '', 1, 1456565075),
(130, 'vi', 'menu', 'Delete menu item', 'Item ID 130', '', 1, 1456565075),
(131, 'vi', 'menu', 'Delete menu item', 'Item ID 131', '', 1, 1456565075),
(132, 'vi', 'menu', 'Delete menu item', 'Item ID 132', '', 1, 1456565075),
(133, 'vi', 'menu', 'Delete menu item', 'Item ID 135', '', 1, 1456565075),
(134, 'vi', 'menu', 'Delete menu item', 'Item ID 136', '', 1, 1456565075),
(135, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1456991297),
(136, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1456991531),
(137, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1456991623),
(138, 'vi', 'xep-hang-thi-dua', 'Edit', 'ID: 3', '', 1, 1456991659),
(139, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1456991665),
(140, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1456992751),
(141, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1456992871),
(142, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1456992913),
(143, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1456992953),
(144, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1456992986),
(145, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1457123630),
(146, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1457276547),
(147, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1457401532),
(148, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1457401549),
(149, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1457536905),
(150, 'vi', 'themes', 'Sửa block', 'Name : Mạng xã hội', '', 1, 1457537605),
(151, 'vi', 'modules', 'Thiết lập module mới lichct', '', '', 1, 1457537789),
(152, 'vi', 'modules', 'Sửa module &ldquo;lichct&rdquo;', '', '', 1, 1457537796),
(153, 'vi', 'lichct', 'Sửa lịch công tác', 'noticeid 1', '', 1, 1457537815),
(154, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1457538258),
(155, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1457538425),
(156, 'vi', 'themes', 'Sửa block', 'Name : CÔNG TY TNHH PACORP', '', 1, 1457538560),
(157, 'vi', 'themes', 'Sửa block', 'Name : CÔNG TY TNHH PACORP', '', 1, 1457538578),
(158, 'vi', 'videos', 'log_add_blockcat', ' ', '', 1, 1457538636),
(159, 'vi', 'themes', 'Sửa block', 'Name : Video clip', '', 1, 1457538665),
(160, 'vi', 'users', 'log_edit_user', 'userid 1', '', 1, 1457538864);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_notification`
--

CREATE TABLE `pacorp_notification` (
  `id` int(11) UNSIGNED NOT NULL,
  `send_to` mediumint(8) UNSIGNED NOT NULL,
  `send_from` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `area` tinyint(1) UNSIGNED NOT NULL,
  `language` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `obid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(11) UNSIGNED NOT NULL,
  `view` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_plugin`
--

CREATE TABLE `pacorp_plugin` (
  `pid` tinyint(4) NOT NULL,
  `plugin_file` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plugin_area` tinyint(4) NOT NULL,
  `weight` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_plugin`
--

INSERT INTO `pacorp_plugin` (`pid`, `plugin_file`, `plugin_area`, `weight`) VALUES
(1, 'qrcode.php', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_sessions`
--

CREATE TABLE `pacorp_sessions` (
  `session_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `onl_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_sessions`
--

INSERT INTO `pacorp_sessions` (`session_id`, `userid`, `username`, `onl_time`) VALUES
('3k2gmi4jduss6hivnegn8ett02', 1, 'admin', 1457538719);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_setup`
--

CREATE TABLE `pacorp_setup` (
  `lang` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tables` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setup_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_setup_extensions`
--

CREATE TABLE `pacorp_setup_extensions` (
  `id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `title` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_sys` tinyint(1) NOT NULL DEFAULT '0',
  `is_virtual` tinyint(1) NOT NULL DEFAULT '0',
  `basename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `table_prefix` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `version` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_setup_extensions`
--

INSERT INTO `pacorp_setup_extensions` (`id`, `type`, `title`, `is_sys`, `is_virtual`, `basename`, `table_prefix`, `version`, `addtime`, `author`, `note`) VALUES
(0, 'module', 'about', 1, 1, 'about', 'about', '4.0.21 1287532800', 1453879455, 'VINADES (contact@vinades.vn)', ''),
(0, 'module', 'xep-hang-thi-dua', 0, 1, 'xep-hang-thi-dua', 'xep_hang_thi_dua', '4.0.21 1287532800', 1453887346, 'VINADES (contact@vinades.vn)', ''),
(19, 'module', 'banners', 1, 0, 'banners', 'banners', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(20, 'module', 'contact', 0, 1, 'contact', 'contact', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(1, 'module', 'news', 0, 1, 'news', 'news', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(21, 'module', 'voting', 0, 0, 'voting', 'voting', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(0, 'module', 'c34to40', 0, 0, 'c34to40', 'c34to40', '4.0.0 1389262729', 1453703402, 'VINADES (contact@vinades.vn)', ''),
(284, 'module', 'seek', 1, 0, 'seek', 'seek', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(24, 'module', 'users', 1, 0, 'users', 'users', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(27, 'module', 'statistics', 0, 0, 'statistics', 'statistics', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(29, 'module', 'menu', 0, 0, 'menu', 'menu', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(283, 'module', 'feeds', 1, 0, 'feeds', 'feeds', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(282, 'module', 'page', 1, 1, 'page', 'page', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(281, 'module', 'comment', 1, 0, 'comment', 'comment', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(312, 'module', 'freecontent', 0, 0, 'freecontent', 'freecontent', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(307, 'theme', 'default', 0, 0, 'default', 'default', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(311, 'theme', 'mobile_default', 0, 0, 'mobile_default', 'mobile_default', '4.0.21 1436199600', 1453703239, 'VINADES (contact@vinades.vn)', ''),
(0, 'module', 'download', 0, 1, 'download', 'download', '4.0.25 1287532800', 1453703402, 'VINADES (contact@vinades.vn)', ''),
(0, 'module', 'faq', 0, 1, 'faq', 'faq', '4.0.25 1287532800', 1453703402, 'VINADES (contact@vinades.vn)', ''),
(0, 'module', 'weblinks', 0, 1, 'weblinks', 'weblinks', '4.0.25 1287532800', 1453703402, 'VINADES (contact@vinades.vn)', ''),
(0, 'module', 'lichct', 0, 0, 'lichct', 'lichct', '4.0.0 1442509200', 1453719419, 'webvang (hoang.nguyen@webvang.vn)', ''),
(0, 'module', 'support', 0, 0, 'support', 'support', '4.0.21 1273225635', 1453913560, 'VINADES (contact@vinades.vn)', ''),
(0, 'module', 'lichcongtac', 0, 0, 'lichcongtac', 'lichcongtac', '3.0.01 1292579235', 1453706646, 'PHAN DINH BAO (baocatg@gmail.com)', ''),
(0, 'module', 'tkblop', 0, 1, 'tkblop', 'tkblop', '4.0.16 1279469595', 1453728318, 'Trần Thế Vinh (gangucay@gmail.com)', 'update to 4.x by webvang'),
(0, 'module', 'cbdoan', 0, 0, 'cbdoan', 'cbdoan', '4.0.16 1343001600', 1453729370, 'hongoctrien (01692777913@yahoo.com)', ''),
(0, 'module', 'laws', 0, 1, 'laws', 'laws', '4.0.16 1432885794', 1453733713, 'PCD-GROUP (contact@dinhpc.com)', 'Update to 4.x webvang (hoang.nguyen@webvang.vn)'),
(0, 'module', 'slider', 1, 0, 'slider', 'slider', '4.0.21 1273225635', 1453913560, 'VINADES (contact@vinades.vn)', ''),
(0, 'module', 'photos', 0, 1, 'photos', 'photos', '1.3.07 1448882339', 1453917741, 'KENNYNGUYEN (nguyentiendat713@gmail.com)', ''),
(0, 'module', 'videos', 0, 0, 'videos', 'videos', '4.0.25 1453917826', 1453917826, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_setup_language`
--

CREATE TABLE `pacorp_setup_language` (
  `lang` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_setup_language`
--

INSERT INTO `pacorp_setup_language` (`lang`, `setup`) VALUES
('vi', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_upload_dir`
--

CREATE TABLE `pacorp_upload_dir` (
  `did` mediumint(8) NOT NULL,
  `dirname` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `thumb_type` tinyint(4) NOT NULL DEFAULT '0',
  `thumb_width` smallint(6) NOT NULL DEFAULT '0',
  `thumb_height` smallint(6) NOT NULL DEFAULT '0',
  `thumb_quality` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_upload_dir`
--

INSERT INTO `pacorp_upload_dir` (`did`, `dirname`, `time`, `thumb_type`, `thumb_width`, `thumb_height`, `thumb_quality`) VALUES
(0, '', 0, 3, 100, 150, 90),
(1, 'uploads', 1454041679, 0, 0, 0, 0),
(51, 'uploads/about', 1454380566, 0, 0, 0, 0),
(3, 'uploads/banners', 1454005873, 0, 0, 0, 0),
(4, 'uploads/contact', 0, 0, 0, 0, 0),
(52, 'uploads/xep-hang-thi-dua', 0, 0, 0, 0, 0),
(6, 'uploads/menu', 0, 0, 0, 0, 0),
(7, 'uploads/news', 1453879148, 0, 0, 0, 0),
(8, 'uploads/news/2016_01', 1453879110, 0, 0, 0, 0),
(9, 'uploads/news/source', 1453879144, 0, 0, 0, 0),
(10, 'uploads/news/temp_pic', 1453879144, 0, 0, 0, 0),
(11, 'uploads/news/topics', 1453879145, 0, 0, 0, 0),
(12, 'uploads/page', 0, 0, 0, 0, 0),
(14, 'uploads/users', 0, 0, 0, 0, 0),
(15, 'uploads/weblinks', 0, 0, 0, 0, 0),
(16, 'uploads/weblinks/cat', 0, 0, 0, 0, 0),
(32, 'uploads/news/2015_04', 1453879112, 0, 0, 0, 0),
(31, 'uploads/news/2015_03', 1453879112, 0, 0, 0, 0),
(29, 'uploads/laws', 0, 0, 0, 0, 0),
(26, 'uploads/cbdoan', 1453729818, 0, 0, 0, 0),
(25, 'uploads/tkblop', 0, 0, 0, 0, 0),
(33, 'uploads/news/2015_05', 1453879113, 0, 0, 0, 0),
(34, 'uploads/news/2015_05/01', 1453879114, 0, 0, 0, 0),
(35, 'uploads/news/2015_06', 1453879117, 0, 0, 0, 0),
(36, 'uploads/news/2015_12', 1453879118, 0, 0, 0, 0),
(37, 'uploads/photo', 0, 0, 0, 0, 0),
(38, 'uploads/photo/images', 0, 0, 0, 0, 0),
(39, 'uploads/photo/images/2015', 0, 0, 0, 0, 0),
(40, 'uploads/photo/images/2015/05', 0, 0, 0, 0, 0),
(41, 'uploads/photo/images/2015_12', 0, 0, 0, 0, 0),
(42, 'uploads/photo/images/2015_12/chuyendetoan1516', 0, 0, 0, 0, 0),
(43, 'uploads/photo/images/2015_12/khkt2015', 0, 0, 0, 0, 0),
(44, 'uploads/photo/images/2015_12/ngoaikhoa1516', 0, 0, 0, 0, 0),
(45, 'uploads/photo/temp', 0, 0, 0, 0, 0),
(46, 'uploads/photo/thumb', 0, 0, 0, 0, 0),
(47, 'uploads/photo/thumb/2015', 0, 0, 0, 0, 0),
(48, 'uploads/photo/thumb/2015/05', 0, 0, 0, 0, 0),
(49, 'uploads/photo/thumb/2015_12', 0, 0, 0, 0, 0),
(50, 'uploads/photo/thumbs', 0, 0, 0, 0, 0),
(53, 'uploads/support', 1453913732, 0, 0, 0, 0),
(54, 'uploads/photos', 0, 0, 0, 0, 0),
(55, 'uploads/photos/images', 0, 0, 0, 0, 0),
(56, 'uploads/photos/thumbs', 0, 0, 0, 0, 0),
(57, 'uploads/photos/temp', 0, 0, 0, 0, 0),
(58, 'uploads/download', 1454382682, 0, 0, 0, 0),
(59, 'uploads/download/files', 1454382017, 0, 0, 0, 0),
(60, 'uploads/download/images', 1454381989, 0, 0, 0, 0),
(61, 'uploads/download/temp', 0, 0, 0, 0, 0),
(62, 'uploads/laws/2016_01', 1454009704, 0, 0, 0, 0),
(63, 'uploads/photos/images/2016', 0, 0, 0, 0, 0),
(64, 'uploads/photos/images/2016/01', 0, 0, 0, 0, 0),
(65, 'uploads/photos/thumbs/2016', 0, 0, 0, 0, 0),
(66, 'uploads/photos/thumbs/2016/01', 0, 0, 0, 0, 0),
(67, 'uploads/photos/images/2016/01/giai-bong-nem-nu-2016', 0, 0, 0, 0, 0),
(81, 'uploads/videos/thumbs', 0, 0, 0, 0, 0),
(77, 'uploads/videos/img', 0, 0, 0, 0, 0),
(78, 'uploads/videos/vid', 0, 0, 0, 0, 0),
(79, 'uploads/videos/img/playlists', 0, 0, 0, 0, 0),
(80, 'uploads/videos/img/groups', 0, 0, 0, 0, 0),
(76, 'uploads/videos', 1454379016, 0, 0, 0, 0),
(82, 'uploads/videos/img/2016_01', 0, 0, 0, 0, 0),
(83, 'uploads/videos/vid/2016_01', 0, 0, 0, 0, 0),
(84, 'uploads/news/2016_02', 1454380359, 0, 0, 0, 0),
(85, 'uploads/photos/images/2016/02', 0, 0, 0, 0, 0),
(86, 'uploads/photos/thumbs/2016/02', 0, 0, 0, 0, 0),
(87, 'uploads/photos/images/2016/02/to-the-duc-nhac-hoa', 0, 0, 0, 0, 0),
(88, 'uploads/photos/images/2016/02/to-sn', 0, 0, 0, 0, 0),
(89, 'uploads/videos/img/2016_02', 0, 0, 0, 0, 0),
(90, 'uploads/videos/vid/2016_02', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_upload_file`
--

CREATE TABLE `pacorp_upload_file` (
  `name` varchar(245) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ext` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `src` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `srcwidth` int(11) NOT NULL DEFAULT '0',
  `srcheight` int(11) NOT NULL DEFAULT '0',
  `sizes` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `userid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `mtime` int(11) NOT NULL DEFAULT '0',
  `did` int(11) NOT NULL DEFAULT '0',
  `title` varchar(245) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_upload_file`
--

INSERT INTO `pacorp_upload_file` (`name`, `ext`, `type`, `filesize`, `src`, `srcwidth`, `srcheight`, `sizes`, `userid`, `mtime`, `did`, `title`, `alt`) VALUES
('nguyen-linh.gif', 'gif', 'image', 6135, 'assets/cbdoan/nguyen-linh.gif', 60, 80, '114|152', 2, 1453917325, 26, 'nguyen-linh.gif', 'Nguyen Linh'),
('c3hongai-d...jpg', 'jpg', 'image', 11050, 'assets/cbdoan/c3hongai-dothiphuong.jpg', 60, 80, '121|160', 2, 1453918234, 26, 'c3hongai-dothiphuong.jpg', 'c3hongai dothiphuong'),
('anh-1-1430...jpg', 'jpg', 'image', 65535, 'assets/news/2015_05/anh-1-1430419430_490x294.jpg', 80, 48, '490|294', 1, 1453879063, 33, 'anh-1-1430419430_490x294.jpg', 'anh 1 1430419430 490x294'),
('googlecove...jpg', 'jpg', 'image', 56862, 'assets/news/2015_05/googlecover360.jpg', 80, 46, '629|354', 1, 1453879063, 33, 'googlecover360.jpg', 'googlecover360'),
('0041415114...jpg', 'jpg', 'image', 104745, 'assets/news/2015_05/01/0041415114349-7.jpg', 80, 58, '500|359', 1, 1453879046, 34, '0041415114349-7.jpg', '0041415114349 7'),
('0145345578...jpg', 'jpg', 'image', 100075, 'assets/news/2015_05/01/01453455780247-21.jpg', 80, 54, '500|337', 1, 1453879049, 34, '01453455780247-21.jpg', '01453455780247 21'),
('0155092029...jpg', 'jpg', 'image', 72979, 'assets/news/2015_05/01/01550920298951-69.jpg', 80, 48, '550|326', 1, 1453879049, 34, '01550920298951-69.jpg', '01550920298951 69'),
('0248592213...jpg', 'jpg', 'image', 101081, 'assets/news/2015_05/01/02485922130791-69.jpg', 80, 55, '550|376', 1, 1453879050, 34, '02485922130791-69.jpg', '02485922130791 69'),
('0309638823...jpg', 'jpg', 'image', 53441, 'assets/news/2015_05/01/0309638823032-16.jpg', 80, 54, '500|333', 1, 1453879047, 34, '0309638823032-16.jpg', '0309638823032 16'),
('0336025722...jpg', 'jpg', 'image', 51310, 'assets/news/2015_05/01/033602572265469-68.jpg', 80, 46, '535|309', 1, 1453879054, 34, '033602572265469-68.jpg', '033602572265469 68'),
('0396027272...jpg', 'jpg', 'image', 65100, 'assets/news/2015_05/01/039602727200672-39.jpg', 80, 54, '450|305', 1, 1453879055, 34, '039602727200672-39.jpg', '039602727200672 39'),
('0413513945...jpg', 'jpg', 'image', 93825, 'assets/news/2015_05/01/04135139458114-69.jpg', 80, 54, '550|366', 1, 1453879051, 34, '04135139458114-69.jpg', '04135139458114 69'),
('0438642230...jpg', 'jpg', 'image', 47026, 'assets/news/2015_05/01/04386422302420-61.jpg', 80, 52, '455|292', 1, 1453879051, 34, '04386422302420-61.jpg', '04386422302420 61'),
('0515203261...jpg', 'jpg', 'image', 102155, 'assets/news/2015_05/01/051520326144739-67.jpg', 80, 60, '600|450', 1, 1453879056, 34, '051520326144739-67.jpg', '051520326144739 67'),
('0558558646...jpg', 'jpg', 'image', 62285, 'assets/news/2015_05/01/0558558646327-54.jpg', 80, 58, '480|351', 1, 1453879048, 34, '0558558646327-54.jpg', '0558558646327 54'),
('0585425291...jpg', 'jpg', 'image', 9698, 'assets/news/2015_05/01/058542529181451-47.jpg', 80, 62, '130|100', 1, 1453879056, 34, '058542529181451-47.jpg', '058542529181451 47'),
('0671152733...jpg', 'jpg', 'image', 57677, 'assets/news/2015_05/01/06711527336435-60.jpg', 62, 80, '400|518', 1, 1453879052, 34, '06711527336435-60.jpg', '06711527336435 60'),
('0796290604...jpg', 'jpg', 'image', 62439, 'assets/news/2015_05/01/079629060440-77.jpg', 80, 50, '600|373', 1, 1453879047, 34, '079629060440-77.jpg', '079629060440 77'),
('0861303099...jpg', 'jpg', 'image', 142378, 'assets/news/2015_05/01/08613030997849-67.jpg', 60, 80, '550|733', 1, 1453879053, 34, '08613030997849-67.jpg', '08613030997849 67'),
('0916288239...jpg', 'jpg', 'image', 52395, 'assets/news/2015_05/01/0916288239433-76.jpg', 80, 54, '600|402', 1, 1453879049, 34, '0916288239433-76.jpg', '0916288239433 76'),
('0979261420...jpg', 'jpg', 'image', 48353, 'assets/news/2015_05/01/09792614206552-83.jpg', 80, 51, '448|284', 1, 1453879053, 34, '09792614206552-83.jpg', '09792614206552 83'),
('1197349841...jpg', 'jpg', 'image', 53229, 'assets/news/2015_05/01/11973498419064-45.jpg', 71, 80, '400|454', 1, 1453879054, 34, '11973498419064-45.jpg', '11973498419064 45'),
('1199435357...jpg', 'jpg', 'image', 101425, 'assets/news/2015_05/01/1199435357703-19.jpg', 80, 57, '500|355', 1, 1453879049, 34, '1199435357703-19.jpg', '1199435357703 19'),
('1253131377...jpg', 'jpg', 'image', 55282, 'assets/news/2015_05/01/125313137705933-38.jpg', 80, 60, '405|304', 1, 1453879059, 34, '125313137705933-38.jpg', '125313137705933 38'),
('1555425841...jpg', 'jpg', 'image', 72437, 'assets/news/2015_05/01/15554258416949-17.jpg', 80, 50, '500|308', 1, 1453879054, 34, '15554258416949-17.jpg', '15554258416949 17'),
('1612494558...jpg', 'jpg', 'image', 68458, 'assets/news/2015_05/01/1612494558450-8.jpg', 80, 56, '500|350', 1, 1453879049, 34, '1612494558450-8.jpg', '1612494558450 8'),
('1660817598...jpg', 'jpg', 'image', 64483, 'assets/news/2015_05/01/166081759831660-61.jpg', 62, 80, '400|513', 1, 1453879059, 34, '166081759831660-61.jpg', '166081759831660 61'),
('2024884730...jpg', 'jpg', 'image', 62627, 'assets/news/2015_05/01/202488473005318-90.jpg', 80, 51, '448|287', 1, 1453879059, 34, '202488473005318-90.jpg', '202488473005318 90'),
('2123109237...jpg', 'jpg', 'image', 62288, 'assets/news/2015_05/01/21231092374186-46.jpg', 80, 55, '600|412', 1, 1453879054, 34, '21231092374186-46.jpg', '21231092374186 46'),
('2222969520...jpg', 'jpg', 'image', 37480, 'assets/news/2015_05/01/2222969520328-37.jpg', 80, 46, '450|259', 1, 1453879049, 34, '2222969520328-37.jpg', '2222969520328 37'),
('2272759704...jpg', 'jpg', 'image', 77215, 'assets/news/2015_05/01/22727597041594-67.jpg', 80, 60, '550|412', 1, 1453879054, 34, '22727597041594-67.jpg', '22727597041594 67'),
('2444070621...jpg', 'jpg', 'image', 99346, 'assets/news/2015_05/01/244407062155311-72.jpg', 80, 80, '482|484', 1, 1453879059, 34, '244407062155311-72.jpg', '244407062155311 72'),
('2532734385...jpg', 'jpg', 'image', 61938, 'assets/news/2015_05/01/253273438501-48.jpg', 80, 56, '500|346', 1, 1453879047, 34, '253273438501-48.jpg', '253273438501 48'),
('2622764561...jpg', 'jpg', 'image', 76833, 'assets/news/2015_05/01/262276456101-72.jpg', 74, 80, '480|511', 1, 1453879047, 34, '262276456101-72.jpg', '262276456101 72'),
('2624818517...jpg', 'jpg', 'image', 45831, 'assets/news/2015_05/01/262481851743359-80.jpg', 80, 50, '540|334', 1, 1453879060, 34, '262481851743359-80.jpg', '262481851743359 80'),
('2665282485...jpg', 'jpg', 'image', 89733, 'assets/news/2015_05/01/2665282485563-69.jpg', 80, 54, '550|372', 1, 1453879050, 34, '2665282485563-69.jpg', '2665282485563 69'),
('2775097126...jpg', 'jpg', 'image', 92285, 'assets/news/2015_05/01/277509712689578-49.jpg', 80, 54, '540|360', 1, 1453879060, 34, '277509712689578-49.jpg', '277509712689578 49'),
('2813209233...jpg', 'jpg', 'image', 147116, 'assets/news/2015_05/01/281320923342503-66.jpg', 58, 80, '600|837', 1, 1453879060, 34, '281320923342503-66.jpg', '281320923342503 66'),
('2845272328...jpg', 'jpg', 'image', 78768, 'assets/news/2015_05/01/284527232851576-83.jpg', 80, 50, '448|280', 1, 1453879060, 34, '284527232851576-83.jpg', '284527232851576 83'),
('3077529387...jpg', 'jpg', 'image', 71896, 'assets/news/2015_05/01/307752938700458-88.jpg', 80, 58, '500|360', 1, 1453879060, 34, '307752938700458-88.jpg', '307752938700458 88'),
('3088429404...jpg', 'jpg', 'image', 62346, 'assets/news/2015_05/01/308842940486914-30.jpg', 80, 60, '400|299', 1, 1453879060, 34, '308842940486914-30.jpg', '308842940486914 30'),
('3160273888...jpg', 'jpg', 'image', 60425, 'assets/news/2015_05/01/3160273888784-64.jpg', 80, 54, '450|299', 1, 1453879050, 34, '3160273888784-64.jpg', '3160273888784 64'),
('3232588827...jpg', 'jpg', 'image', 63081, 'assets/news/2015_05/01/32325888278358-7.jpg', 80, 57, '500|354', 1, 1453879054, 34, '32325888278358-7.jpg', '32325888278358 7'),
('3260697117...jpg', 'jpg', 'image', 61148, 'assets/news/2015_05/01/326069711746428-64.jpg', 80, 50, '450|281', 1, 1453879060, 34, '326069711746428-64.jpg', '326069711746428 64'),
('3265421527...jpg', 'jpg', 'image', 48730, 'assets/news/2015_05/01/326542152772971-39.jpg', 80, 53, '450|294', 1, 1453879060, 34, '326542152772971-39.jpg', '326542152772971 39'),
('3325310403...jpg', 'jpg', 'image', 77125, 'assets/news/2015_05/01/332531040342614-19.jpg', 80, 50, '500|309', 1, 1453879060, 34, '332531040342614-19.jpg', '332531040342614 19'),
('3405499460...jpg', 'jpg', 'image', 68715, 'assets/news/2015_05/01/340549946053-48.jpg', 80, 56, '500|348', 1, 1453879048, 34, '340549946053-48.jpg', '340549946053 48'),
('3514320693...jpg', 'jpg', 'image', 89546, 'assets/news/2015_05/01/351432069305906-14.jpg', 80, 52, '500|326', 1, 1453879061, 34, '351432069305906-14.jpg', '351432069305906 14'),
('3570674718...jpg', 'jpg', 'image', 68000, 'assets/news/2015_05/01/35706747187058-71.jpg', 80, 54, '600|400', 1, 1453879055, 34, '35706747187058-71.jpg', '35706747187058 71'),
('3883190912...jpg', 'jpg', 'image', 89233, 'assets/news/2015_05/01/38831909122281-46.jpg', 80, 54, '600|399', 1, 1453879055, 34, '38831909122281-46.jpg', '38831909122281 46'),
('3922886474...jpg', 'jpg', 'image', 58516, 'assets/news/2015_05/01/392288647418295-57.jpg', 80, 54, '450|300', 1, 1453879061, 34, '392288647418295-57.jpg', '392288647418295 57'),
('3928912964...jpg', 'jpg', 'image', 123051, 'assets/news/2015_05/01/3928912964647-1.jpg', 80, 56, '500|346', 1, 1453879050, 34, '3928912964647-1.jpg', '3928912964647 1'),
('3966191658...jpg', 'jpg', 'image', 103630, 'assets/news/2015_05/01/3966191658103-82.jpg', 80, 46, '600|338', 1, 1453879050, 34, '3966191658103-82.jpg', '3966191658103 82'),
('4022190932...jpg', 'jpg', 'image', 41502, 'assets/news/2015_05/01/40221909324-83.jpg', 80, 52, '448|290', 1, 1453879046, 34, '40221909324-83.jpg', '40221909324 83'),
('4033376297...jpg', 'jpg', 'image', 104314, 'assets/news/2015_05/01/40333762972667-20.jpg', 80, 54, '500|333', 1, 1453879055, 34, '40333762972667-20.jpg', '40333762972667 20'),
('4041017923...jpg', 'jpg', 'image', 46642, 'assets/news/2015_05/01/40410179232035-43.jpg', 80, 46, '440|250', 1, 1453879055, 34, '40410179232035-43.jpg', '40410179232035 43'),
('4075197970-12.jpg', 'jpg', 'image', 70517, 'assets/news/2015_05/01/4075197970-12.jpg', 80, 51, '500|316', 1, 1453879046, 34, '4075197970-12.jpg', '4075197970 12'),
('4113294030...jpg', 'jpg', 'image', 78400, 'assets/news/2015_05/01/41132940307910-89.jpg', 80, 60, '600|450', 1, 1453879055, 34, '41132940307910-89.jpg', '41132940307910 89'),
('4126055911...jpg', 'jpg', 'image', 63068, 'assets/news/2015_05/01/4126055911654-73.jpg', 80, 54, '600|401', 1, 1453879050, 34, '4126055911654-73.jpg', '4126055911654 73'),
('4200941899...jpg', 'jpg', 'image', 66202, 'assets/news/2015_05/01/420094189994301-81.jpg', 80, 54, '600|400', 1, 1453879061, 34, '420094189994301-81.jpg', '420094189994301 81'),
('4280988116...jpg', 'jpg', 'image', 44566, 'assets/news/2015_05/01/42809881169253-39.jpg', 80, 80, '400|400', 1, 1453879055, 34, '42809881169253-39.jpg', '42809881169253 39'),
('4365449373...jpg', 'jpg', 'image', 122813, 'assets/news/2015_05/01/4365449373089-4.jpg', 80, 55, '500|341', 1, 1453879051, 34, '4365449373089-4.jpg', '4365449373089 4'),
('4422138867...jpg', 'jpg', 'image', 74806, 'assets/news/2015_05/01/442213886723626-61.jpg', 65, 80, '400|495', 1, 1453879061, 34, '442213886723626-61.jpg', '442213886723626 61'),
('4545932289...jpg', 'jpg', 'image', 50771, 'assets/news/2015_05/01/4545932289715-64.jpg', 80, 58, '450|321', 1, 1453879051, 34, '4545932289715-64.jpg', '4545932289715 64'),
('4624371902...jpg', 'jpg', 'image', 37895, 'assets/news/2015_05/01/4624371902760-62.jpg', 67, 80, '360|431', 1, 1453879051, 34, '4624371902760-62.jpg', '4624371902760 62'),
('4642143667...jpg', 'jpg', 'image', 109959, 'assets/news/2015_05/01/464214366790546-1.jpg', 80, 55, '500|345', 1, 1453879061, 34, '464214366790546-1.jpg', '464214366790546 1'),
('4881814016...jpg', 'jpg', 'image', 77226, 'assets/news/2015_05/01/48818140166088-12.jpg', 80, 54, '500|331', 1, 1453879055, 34, '48818140166088-12.jpg', '48818140166088 12'),
('4882551468...jpg', 'jpg', 'image', 92342, 'assets/news/2015_05/01/488255146837247-27.jpg', 80, 57, '500|351', 1, 1453879061, 34, '488255146837247-27.jpg', '488255146837247 27'),
('4928350636...jpg', 'jpg', 'image', 50035, 'assets/news/2015_05/01/492835063670823-67.jpg', 80, 70, '458|396', 1, 1453879061, 34, '492835063670823-67.jpg', '492835063670823 67'),
('4951554146...jpg', 'jpg', 'image', 53562, 'assets/news/2015_05/01/495155414612777-45.jpg', 72, 80, '400|444', 1, 1453879061, 34, '495155414612777-45.jpg', '495155414612777 45'),
('5135934435...jpg', 'jpg', 'image', 96276, 'assets/news/2015_05/01/513593443590832-15.jpg', 80, 57, '500|354', 1, 1453879061, 34, '513593443590832-15.jpg', '513593443590832 15'),
('5383118118...jpg', 'jpg', 'image', 85237, 'assets/news/2015_05/01/53831181187092-53.jpg', 80, 56, '600|419', 1, 1453879056, 34, '53831181187092-53.jpg', '53831181187092 53'),
('5439527691...jpg', 'jpg', 'image', 84724, 'assets/news/2015_05/01/543952769153011-60.jpg', 58, 80, '400|553', 1, 1453879062, 34, '543952769153011-60.jpg', '543952769153011 60'),
('5490594628...jpg', 'jpg', 'image', 103079, 'assets/news/2015_05/01/54905946289610-81.jpg', 80, 46, '600|338', 1, 1453879056, 34, '54905946289610-81.jpg', '54905946289610 81'),
('5647008837...jpg', 'jpg', 'image', 47614, 'assets/news/2015_05/01/564700883728474-56.jpg', 80, 60, '450|338', 1, 1453879062, 34, '564700883728474-56.jpg', '564700883728474 56'),
('5706873256...jpg', 'jpg', 'image', 77103, 'assets/news/2015_05/01/5706873256724-19.jpg', 80, 55, '500|343', 1, 1453879051, 34, '5706873256724-19.jpg', '5706873256724 19'),
('5713546828...jpg', 'jpg', 'image', 67315, 'assets/news/2015_05/01/571354682836-40.jpg', 80, 50, '450|280', 1, 1453879048, 34, '571354682836-40.jpg', '571354682836 40'),
('5782515796...jpg', 'jpg', 'image', 56223, 'assets/news/2015_05/01/57825157962994-17.jpg', 80, 53, '500|327', 1, 1453879056, 34, '57825157962994-17.jpg', '57825157962994 17'),
('6061217581...jpg', 'jpg', 'image', 84599, 'assets/news/2015_05/01/6061217581157-6.jpg', 80, 54, '500|339', 1, 1453879051, 34, '6061217581157-6.jpg', '6061217581157 6'),
('6200386103...jpg', 'jpg', 'image', 94296, 'assets/news/2015_05/01/620038610345-66.jpg', 80, 54, '600|400', 1, 1453879048, 34, '620038610345-66.jpg', '620038610345 66'),
('6219200836...jpg', 'jpg', 'image', 96952, 'assets/news/2015_05/01/62192008367665-14.jpg', 80, 50, '500|310', 1, 1453879056, 34, '62192008367665-14.jpg', '62192008367665 14'),
('6296945323...jpg', 'jpg', 'image', 57930, 'assets/news/2015_05/01/62969453233-78.jpg', 80, 52, '528|341', 1, 1453879047, 34, '62969453233-78.jpg', '62969453233 78'),
('6299735702...jpg', 'jpg', 'image', 49452, 'assets/news/2015_05/01/62997357022554-32.jpg', 80, 47, '450|263', 1, 1453879056, 34, '62997357022554-32.jpg', '62997357022554 32'),
('6431595731...jpg', 'jpg', 'image', 140139, 'assets/news/2015_05/01/64315957313022-55.jpg', 45, 80, '360|640', 1, 1453879056, 34, '64315957313022-55.jpg', '64315957313022 55'),
('6504015531...jpg', 'jpg', 'image', 76240, 'assets/news/2015_05/01/65040155316902-5.jpg', 80, 54, '500|333', 1, 1453879056, 34, '65040155316902-5.jpg', '65040155316902 5'),
('6577356525...jpg', 'jpg', 'image', 11161, 'assets/news/2015_05/01/657735652534193-42.jpg', 80, 62, '130|100', 1, 1453879062, 34, '657735652534193-42.jpg', '657735652534193 42'),
('6723682455...jpg', 'jpg', 'image', 55502, 'assets/news/2015_05/01/67236824552384-39.jpg', 80, 53, '450|297', 1, 1453879057, 34, '67236824552384-39.jpg', '67236824552384 39'),
('6768164126...jpg', 'jpg', 'image', 103901, 'assets/news/2015_05/01/67681641267266-5.jpg', 80, 54, '500|333', 1, 1453879057, 34, '67681641267266-5.jpg', '67681641267266 5'),
('6777832588...jpg', 'jpg', 'image', 63592, 'assets/news/2015_05/01/67778325887786-50.jpg', 80, 60, '600|446', 1, 1453879057, 34, '67778325887786-50.jpg', '67778325887786 50'),
('6831749332...jpg', 'jpg', 'image', 6059, 'assets/news/2015_05/01/68317493328510-65.jpg', 80, 62, '130|100', 1, 1453879057, 34, '68317493328510-65.jpg', '68317493328510 65'),
('6841283958...jpg', 'jpg', 'image', 73921, 'assets/news/2015_05/01/6841283958333-86.jpg', 80, 50, '600|375', 1, 1453879052, 34, '6841283958333-86.jpg', '6841283958333 86'),
('6900642344...jpg', 'jpg', 'image', 76988, 'assets/news/2015_05/01/6900642344321-60.jpg', 80, 66, '455|376', 1, 1453879052, 34, '6900642344321-60.jpg', '6900642344321 60'),
('6939519716...jpg', 'jpg', 'image', 73368, 'assets/news/2015_05/01/69395197162170-59.jpg', 80, 60, '448|336', 1, 1453879057, 34, '69395197162170-59.jpg', '69395197162170 59'),
('7125374782...jpg', 'jpg', 'image', 47368, 'assets/news/2015_05/01/712537478200241-90.jpg', 80, 46, '448|252', 1, 1453879062, 34, '712537478200241-90.jpg', '712537478200241 90'),
('7241148749...jpg', 'jpg', 'image', 48629, 'assets/news/2015_05/01/72411487496783-33.jpg', 80, 43, '460|249', 1, 1453879057, 34, '72411487496783-33.jpg', '72411487496783 33'),
('7245996774...jpg', 'jpg', 'image', 80516, 'assets/news/2015_05/01/7245996774107-9.jpg', 80, 54, '500|332', 1, 1453879052, 34, '7245996774107-9.jpg', '7245996774107 9'),
('7271590138...jpg', 'jpg', 'image', 55079, 'assets/news/2015_05/01/727159013886944-83.jpg', 80, 50, '448|282', 1, 1453879062, 34, '727159013886944-83.jpg', '727159013886944 83'),
('7308631446...jpg', 'jpg', 'image', 105575, 'assets/news/2015_05/01/73086314469855-28.jpg', 80, 48, '500|297', 1, 1453879057, 34, '73086314469855-28.jpg', '73086314469855 28'),
('7427298447...jpg', 'jpg', 'image', 96676, 'assets/news/2015_05/01/74272984479176-50.jpg', 80, 59, '450|334', 1, 1453879057, 34, '74272984479176-50.jpg', '74272984479176 50'),
('7470514679...jpg', 'jpg', 'image', 43254, 'assets/news/2015_05/01/74705146794806-30.jpg', 80, 54, '400|268', 1, 1453879057, 34, '74705146794806-30.jpg', '74705146794806 30'),
('7488048606...jpg', 'jpg', 'image', 99420, 'assets/news/2015_05/01/748804860638007-34.jpg', 80, 54, '600|400', 1, 1453879062, 34, '748804860638007-34.jpg', '748804860638007 34'),
('7490201501...jpg', 'jpg', 'image', 100062, 'assets/news/2015_05/01/74902015015153-15.jpg', 80, 51, '500|318', 1, 1453879057, 34, '74902015015153-15.jpg', '74902015015153 15'),
('7598374999...jpg', 'jpg', 'image', 104114, 'assets/news/2015_05/01/7598374999081-27.jpg', 80, 54, '500|334', 1, 1453879052, 34, '7598374999081-27.jpg', '7598374999081 27'),
('7818011060...jpg', 'jpg', 'image', 76294, 'assets/news/2015_05/01/78180110600718-74.jpg', 71, 80, '500|558', 1, 1453879057, 34, '78180110600718-74.jpg', '78180110600718 74'),
('7851996177...jpg', 'jpg', 'image', 7157, 'assets/news/2015_05/01/785199617766316-70.jpg', 80, 62, '130|100', 1, 1453879062, 34, '785199617766316-70.jpg', '785199617766316 70'),
('7888719959...jpg', 'jpg', 'image', 157736, 'assets/news/2015_05/01/7888719959986-44.jpg', 80, 50, '600|373', 1, 1453879052, 34, '7888719959986-44.jpg', '7888719959986 44'),
('7897706277...jpg', 'jpg', 'image', 77646, 'assets/news/2015_05/01/78977062779722-41.jpg', 80, 54, '600|400', 1, 1453879058, 34, '78977062779722-41.jpg', '78977062779722 41'),
('7945433220...jpg', 'jpg', 'image', 45440, 'assets/news/2015_05/01/79454332204931-68.jpg', 80, 34, '570|238', 1, 1453879058, 34, '79454332204931-68.jpg', '79454332204931 68'),
('7949180318...jpg', 'jpg', 'image', 64401, 'assets/news/2015_05/01/794918031815665-17.jpg', 80, 53, '500|327', 1, 1453879062, 34, '794918031815665-17.jpg', '794918031815665 17'),
('7976555756...jpg', 'jpg', 'image', 31898, 'assets/news/2015_05/01/79765557566344-74.jpg', 80, 40, '480|240', 1, 1453879058, 34, '79765557566344-74.jpg', '79765557566344 74'),
('8038950217...jpg', 'jpg', 'image', 82326, 'assets/news/2015_05/01/8038950217414-60.jpg', 65, 80, '400|496', 1, 1453879052, 34, '8038950217414-60.jpg', '8038950217414 60'),
('8214233682...jpg', 'jpg', 'image', 79909, 'assets/news/2015_05/01/82142336820055-31.jpg', 80, 54, '450|303', 1, 1453879058, 34, '82142336820055-31.jpg', '82142336820055 31'),
('8338126515...jpg', 'jpg', 'image', 96838, 'assets/news/2015_05/01/83381265154708-68.jpg', 80, 60, '600|450', 1, 1453879058, 34, '83381265154708-68.jpg', '83381265154708 68'),
('8414491700...jpg', 'jpg', 'image', 51639, 'assets/news/2015_05/01/841449170014322-63.jpg', 80, 51, '450|285', 1, 1453879062, 34, '841449170014322-63.jpg', '841449170014322 63'),
('8448829653...jpg', 'jpg', 'image', 27001, 'assets/news/2015_05/01/84488296537-54.jpg', 80, 37, '470|216', 1, 1453879047, 34, '84488296537-54.jpg', '84488296537 54'),
('8468944091...jpg', 'jpg', 'image', 61835, 'assets/news/2015_05/01/84689440917084-32.jpg', 80, 46, '450|253', 1, 1453879058, 34, '84689440917084-32.jpg', '84689440917084 32'),
('8520489689...jpg', 'jpg', 'image', 53172, 'assets/news/2015_05/01/8520489689290-68.jpg', 80, 54, '600|400', 1, 1453879053, 34, '8520489689290-68.jpg', '8520489689290 68'),
('8583146295...jpg', 'jpg', 'image', 45808, 'assets/news/2015_05/01/85831462956193-58.jpg', 80, 54, '448|299', 1, 1453879058, 34, '85831462956193-58.jpg', '85831462956193 58'),
('8634406946...jpg', 'jpg', 'image', 30926, 'assets/news/2015_05/01/86344069460880-79.jpg', 80, 46, '464|261', 1, 1453879058, 34, '86344069460880-79.jpg', '86344069460880 79'),
('8698099075...jpg', 'jpg', 'image', 66645, 'assets/news/2015_05/01/869809907556-75.jpg', 80, 55, '568|389', 1, 1453879048, 34, '869809907556-75.jpg', '869809907556 75'),
('8707498525...jpg', 'jpg', 'image', 121109, 'assets/news/2015_05/01/8707498525403-1.jpg', 80, 50, '500|310', 1, 1453879053, 34, '8707498525403-1.jpg', '8707498525403 1'),
('8723086862...jpg', 'jpg', 'image', 85071, 'assets/news/2015_05/01/872308686209-51.jpg', 80, 46, '580|326', 1, 1453879048, 34, '872308686209-51.jpg', '872308686209 51'),
('8753959087...jpg', 'jpg', 'image', 78292, 'assets/news/2015_05/01/875395908762219-50.jpg', 80, 53, '450|295', 1, 1453879062, 34, '875395908762219-50.jpg', '875395908762219 50'),
('8793414794...jpg', 'jpg', 'image', 73502, 'assets/news/2015_05/01/8793414794177-41.jpg', 80, 54, '600|400', 1, 1453879053, 34, '8793414794177-41.jpg', '8793414794177 41'),
('8810021858...jpg', 'jpg', 'image', 89536, 'assets/news/2015_05/01/881002185800-66.jpg', 47, 80, '587|1000', 1, 1453879048, 34, '881002185800-66.jpg', '881002185800 66'),
('8832875758...jpg', 'jpg', 'image', 42322, 'assets/news/2015_05/01/88328757584699-36.jpg', 80, 50, '450|280', 1, 1453879059, 34, '88328757584699-36.jpg', '88328757584699 36'),
('8921668229...jpg', 'jpg', 'image', 108599, 'assets/news/2015_05/01/89216682294433-81.jpg', 80, 57, '500|354', 1, 1453879059, 34, '89216682294433-81.jpg', '89216682294433 81'),
('8923406506...jpg', 'jpg', 'image', 44178, 'assets/news/2015_05/01/892340650656186-54.jpg', 80, 46, '440|250', 1, 1453879062, 34, '892340650656186-54.jpg', '892340650656186 54'),
('8950854358...jpg', 'jpg', 'image', 11186, 'assets/news/2015_05/01/895085435801487-23.jpg', 80, 48, '180|108', 1, 1453879062, 34, '895085435801487-23.jpg', '895085435801487 23'),
('9125460885...jpg', 'jpg', 'image', 35701, 'assets/news/2015_05/01/9125460885988-45.jpg', 80, 79, '400|394', 1, 1453879053, 34, '9125460885988-45.jpg', '9125460885988 45'),
('9163297648...jpg', 'jpg', 'image', 48658, 'assets/news/2015_05/01/9163297648442-40.jpg', 80, 50, '450|281', 1, 1453879053, 34, '9163297648442-40.jpg', '9163297648442 40'),
('9193122067...jpg', 'jpg', 'image', 56387, 'assets/news/2015_05/01/919312206708804-46.jpg', 54, 80, '306|458', 1, 1453879062, 34, '919312206708804-46.jpg', '919312206708804 46'),
('9263493192...jpg', 'jpg', 'image', 54168, 'assets/news/2015_05/01/92634931926521-35.jpg', 80, 50, '450|282', 1, 1453879059, 34, '92634931926521-35.jpg', '92634931926521 35'),
('95320378091-6.jpg', 'jpg', 'image', 66069, 'assets/news/2015_05/01/95320378091-6.jpg', 80, 58, '500|363', 1, 1453879047, 34, '95320378091-6.jpg', '95320378091 6'),
('9656430147...jpg', 'jpg', 'image', 113484, 'assets/news/2015_05/01/9656430147144-20.jpg', 80, 46, '500|281', 1, 1453879053, 34, '9656430147144-20.jpg', '9656430147144 20'),
('9805649563...jpg', 'jpg', 'image', 62793, 'assets/news/2015_05/01/9805649563835-72.jpg', 53, 80, '319|481', 1, 1453879054, 34, '9805649563835-72.jpg', '9805649563835 72'),
('9863656465...jpg', 'jpg', 'image', 20910, 'assets/news/2015_05/01/9863656465523-7.jpg', 55, 80, '150|219', 1, 1453879054, 34, '9863656465523-7.jpg', '9863656465523 7'),
('9959120929...jpg', 'jpg', 'image', 98873, 'assets/news/2015_05/01/995912092909556-20.jpg', 80, 56, '500|350', 1, 1453879063, 34, '995912092909556-20.jpg', '995912092909556 20'),
('9984633136...jpg', 'jpg', 'image', 100924, 'assets/news/2015_05/01/99846331369924-84.jpg', 80, 66, '540|441', 1, 1453879059, 34, '99846331369924-84.jpg', '99846331369924 84'),
('bui-thu-th...jpg', 'jpg', 'image', 261214, 'assets/news/2015_12/bui-thu-thuy-giai-3-asean-2008.jpg', 80, 60, '1500|1125', 1, 1453879063, 36, 'bui-thu-thuy-giai-3-asean-2008.jpg', 'bui thu thuy giai 3 asean 2008'),
('day-gay-ca...jpg', 'jpg', 'image', 69077, 'assets/news/2015_12/day-gay-cap-tinh.jpg', 80, 54, '444|295', 1, 1453879064, 36, 'day-gay-cap-tinh.jpg', 'day gay cap tinh'),
('hsg2015-2016.jpg', 'jpg', 'image', 112226, 'assets/news/2015_12/hsg2015-2016.jpg', 80, 42, '598|309', 1, 1453879064, 36, 'hsg2015-2016.jpg', 'hsg2015 2016'),
('image001.jpg', 'jpg', 'image', 71434, 'assets/news/2015_12/image001.jpg', 80, 54, '444|296', 1, 1453879064, 36, 'image001.jpg', 'image001'),
('image003.jpg', 'jpg', 'image', 69077, 'assets/news/2015_12/image003.jpg', 80, 54, '444|295', 1, 1453879064, 36, 'image003.jpg', 'image003'),
('image005.jpg', 'jpg', 'image', 89804, 'assets/news/2015_12/image005.jpg', 80, 54, '444|295', 1, 1453879064, 36, 'image005.jpg', 'image005'),
('images7303...jpg', 'jpg', 'image', 238306, 'assets/news/2015_12/images730378_dsc_1000.jpg', 80, 54, '460|306', 1, 1453879064, 36, 'images730378_dsc_1000.jpg', 'images730378 dsc 1000'),
('images7303...jpg', 'jpg', 'image', 99983, 'assets/news/2015_12/images730381_dsc_1025.jpg', 80, 54, '460|306', 1, 1453879065, 36, 'images730381_dsc_1025.jpg', 'images730381 dsc 1025'),
('images7303...jpg', 'jpg', 'image', 165964, 'assets/news/2015_12/images730384_dsc_1016.jpg', 80, 54, '460|306', 1, 1453879065, 36, 'images730384_dsc_1016.jpg', 'images730384 dsc 1016'),
('images7303...jpg', 'jpg', 'image', 156260, 'assets/news/2015_12/images730385_dsc_1023.jpg', 80, 54, '460|306', 1, 1453879065, 36, 'images730385_dsc_1023.jpg', 'images730385 dsc 1023'),
('images7303...jpg', 'jpg', 'image', 167115, 'assets/news/2015_12/images730386_dsc_1002.jpg', 80, 54, '460|306', 1, 1453879065, 36, 'images730386_dsc_1002.jpg', 'images730386 dsc 1002'),
('images7303...jpg', 'jpg', 'image', 167115, 'assets/news/2015_12/images730386_dsc_1002_1.jpg', 80, 54, '460|306', 1, 1453879065, 36, 'images730386_dsc_1002_1.jpg', 'images730386 dsc 1002 1'),
('images7303...jpg', 'jpg', 'image', 148989, 'assets/news/2015_12/images730387_dsc_1006.jpg', 80, 54, '460|306', 1, 1453879065, 36, 'images730387_dsc_1006.jpg', 'images730387 dsc 1006'),
('images7303...jpg', 'jpg', 'image', 179552, 'assets/news/2015_12/images730388_dsc_1030.jpg', 80, 54, '460|306', 1, 1453879065, 36, 'images730388_dsc_1030.jpg', 'images730388 dsc 1030'),
('images7303...jpg', 'jpg', 'image', 192730, 'assets/news/2015_12/images730390_dsc_1013.jpg', 80, 54, '460|306', 1, 1453879066, 36, 'images730390_dsc_1013.jpg', 'images730390 dsc 1013'),
('images7303...jpg', 'jpg', 'image', 196945, 'assets/news/2015_12/images730391_dsc_1018.jpg', 80, 54, '460|306', 1, 1453879066, 36, 'images730391_dsc_1018.jpg', 'images730391 dsc 1018'),
('images7303...jpg', 'jpg', 'image', 172604, 'assets/news/2015_12/images730393_dsc_1048.jpg', 80, 54, '460|306', 1, 1453879066, 36, 'images730393_dsc_1048.jpg', 'images730393 dsc 1048'),
('images7303...jpg', 'jpg', 'image', 96680, 'assets/news/2015_12/images730396_dsc_1165.jpg', 80, 54, '460|306', 1, 1453879066, 36, 'images730396_dsc_1165.jpg', 'images730396 dsc 1165'),
('images7303...jpg', 'jpg', 'image', 210959, 'assets/news/2015_12/images730397_dsc_1080.jpg', 80, 54, '460|306', 1, 1453879066, 36, 'images730397_dsc_1080.jpg', 'images730397 dsc 1080'),
('images7303...jpg', 'jpg', 'image', 267542, 'assets/news/2015_12/images730398_dsc_1087.jpg', 80, 68, '460|391', 1, 1453879066, 36, 'images730398_dsc_1087.jpg', 'images730398 dsc 1087'),
('images7304...jpg', 'jpg', 'image', 125627, 'assets/news/2015_12/images730401_dsc_1129.jpg', 80, 54, '460|306', 1, 1453879067, 36, 'images730401_dsc_1129.jpg', 'images730401 dsc 1129'),
('images7304...jpg', 'jpg', 'image', 110867, 'assets/news/2015_12/images730402_dsc_1070.jpg', 80, 54, '460|306', 1, 1453879067, 36, 'images730402_dsc_1070.jpg', 'images730402 dsc 1070'),
('images7304...jpg', 'jpg', 'image', 197283, 'assets/news/2015_12/images730403_dsc_1058.jpg', 80, 54, '460|306', 1, 1453879067, 36, 'images730403_dsc_1058.jpg', 'images730403 dsc 1058'),
('images7304...jpg', 'jpg', 'image', 182663, 'assets/news/2015_12/images730410_dsc_1854.jpg', 80, 58, '460|333', 1, 1453879067, 36, 'images730410_dsc_1854.jpg', 'images730410 dsc 1854'),
('images7304...jpg', 'jpg', 'image', 262258, 'assets/news/2015_12/images730411_dsc_1845.jpg', 50, 80, '400|644', 1, 1453879067, 36, 'images730411_dsc_1845.jpg', 'images730411 dsc 1845'),
('images7304...jpg', 'jpg', 'image', 148474, 'assets/news/2015_12/images730412_dsc_1875.jpg', 80, 55, '460|316', 1, 1453879067, 36, 'images730412_dsc_1875.jpg', 'images730412 dsc 1875'),
('images7304...jpg', 'jpg', 'image', 175887, 'assets/news/2015_12/images730413_dsc_1884.jpg', 80, 51, '460|290', 1, 1453879068, 36, 'images730413_dsc_1884.jpg', 'images730413 dsc 1884'),
('images7304...jpg', 'jpg', 'image', 150161, 'assets/news/2015_12/images730414_dsc_1886.jpg', 70, 80, '400|461', 1, 1453879068, 36, 'images730414_dsc_1886.jpg', 'images730414 dsc 1886'),
('images7304...jpg', 'jpg', 'image', 121634, 'assets/news/2015_12/images730415_a.jpg', 80, 53, '460|303', 1, 1453879068, 36, 'images730415_a.jpg', 'images730415 a'),
('images7304...jpg', 'jpg', 'image', 128598, 'assets/news/2015_12/images730416_dsc_1893.jpg', 80, 58, '460|330', 1, 1453879068, 36, 'images730416_dsc_1893.jpg', 'images730416 dsc 1893'),
('images7304...jpg', 'jpg', 'image', 184829, 'assets/news/2015_12/images730417_dsc_1905.jpg', 80, 54, '460|306', 1, 1453879068, 36, 'images730417_dsc_1905.jpg', 'images730417 dsc 1905'),
('images7304...jpg', 'jpg', 'image', 183312, 'assets/news/2015_12/images730418_dsc_1925.jpg', 80, 65, '460|370', 1, 1453879069, 36, 'images730418_dsc_1925.jpg', 'images730418 dsc 1925'),
('images7304...jpg', 'jpg', 'image', 153587, 'assets/news/2015_12/images730419_dsc_1945.jpg', 80, 66, '460|378', 1, 1453879069, 36, 'images730419_dsc_1945.jpg', 'images730419 dsc 1945'),
('images7304...jpg', 'jpg', 'image', 119462, 'assets/news/2015_12/images730420_dsc_1923.jpg', 80, 53, '460|303', 1, 1453879069, 36, 'images730420_dsc_1923.jpg', 'images730420 dsc 1923'),
('images7304...jpg', 'jpg', 'image', 165448, 'assets/news/2015_12/images730421_dsc_1966.jpg', 80, 54, '460|306', 1, 1453879069, 36, 'images730421_dsc_1966.jpg', 'images730421 dsc 1966'),
('images7304...jpg', 'jpg', 'image', 160110, 'assets/news/2015_12/images730422_dsc_1930.jpg', 80, 54, '460|306', 1, 1453879070, 36, 'images730422_dsc_1930.jpg', 'images730422 dsc 1930'),
('khai-mac.jpg', 'jpg', 'image', 677581, 'assets/news/2015_12/khai-mac.jpg', 80, 54, '1000|667', 1, 1453879070, 36, 'khai-mac.jpg', 'khai mac'),
('tham-gia-q...jpg', 'jpg', 'image', 656969, 'assets/news/2015_12/tham-gia-qg2016.jpg', 80, 51, '1000|632', 1, 1453879070, 36, 'tham-gia-qg2016.jpg', 'tham gia qg2016'),
('thi-khkt-2...jpg', 'jpg', 'image', 71143, 'assets/news/2015_12/thi-khkt-2015-cap-tinh-1.jpg', 80, 54, '960|640', 1, 1453879070, 36, 'thi-khkt-2015-cap-tinh-1.jpg', 'thi khkt 2015 cap tinh 1'),
('thi-khkt-2...jpg', 'jpg', 'image', 71143, 'assets/news/2015_12/thi-khkt-2015-cap-tinh-1_1.jpg', 80, 54, '960|640', 1, 1453879070, 36, 'thi-khkt-2015-cap-tinh-1_1.jpg', 'thi khkt 2015 cap tinh 1 1'),
('thi-khkt-2...jpg', 'jpg', 'image', 40848, 'assets/news/2015_12/thi-khkt-2015-cap-tinh-2.jpg', 80, 54, '960|640', 1, 1453879071, 36, 'thi-khkt-2015-cap-tinh-2.jpg', 'thi khkt 2015 cap tinh 2'),
('thi-khkt-2...jpg', 'jpg', 'image', 92702, 'assets/news/2015_12/thi-khkt-2015-cap-tinh-3.jpg', 80, 54, '960|640', 1, 1453879071, 36, 'thi-khkt-2015-cap-tinh-3.jpg', 'thi khkt 2015 cap tinh 3'),
('tkb.jpg', 'jpg', 'image', 83254, 'assets/news/2015_12/tkb.jpg', 80, 50, '426|263', 1, 1453879071, 36, 'tkb.jpg', 'tkb'),
('hoptac.jpg', 'jpg', 'image', 12871, 'assets/news/hoptac.jpg', 80, 66, '382|314', 1, 1453879071, 7, 'hoptac.jpg', 'hoptac'),
('nangly.jpg', 'jpg', 'image', 34802, 'assets/news/nangly.jpg', 80, 53, '500|332', 1, 1453879071, 7, 'nangly.jpg', 'nangly'),
('nukeviet-job.jpg', 'jpg', 'image', 23576, 'assets/news/nukeviet-job.jpg', 80, 60, '400|300', 1, 1453879071, 7, 'nukeviet-job.jpg', 'nukeviet job'),
('nukeviet-n...jpg', 'jpg', 'image', 18611, 'assets/news/nukeviet-nhantaidatviet2011.jpg', 80, 54, '400|268', 1, 1453879071, 7, 'nukeviet-nhantaidatviet2011.jpg', 'nukeviet nhantaidatviet2011'),
('nukeviet3.jpg', 'jpg', 'image', 17464, 'assets/news/nukeviet3.jpg', 80, 65, '310|250', 1, 1453879071, 7, 'nukeviet3.jpg', 'nukeviet3'),
('product_box.jpg', 'jpg', 'image', 23063, 'assets/news/product_box.jpg', 80, 73, '400|363', 1, 1453879071, 7, 'product_box.jpg', 'product box'),
('screenshot.jpg', 'jpg', 'image', 35078, 'assets/news/screenshot.jpg', 80, 63, '400|317', 1, 1453879071, 7, 'screenshot.jpg', 'screenshot'),
('webnhanh-vn.jpg', 'jpg', 'image', 38259, 'assets/news/webnhanh-vn.jpg', 80, 57, '400|281', 1, 1453879072, 7, 'webnhanh-vn.jpg', 'webnhanh vn'),
('50-nam-toa...jpg', 'jpg', 'image', 1062365, 'assets/about/50-nam-toan-canh.jpg', 80, 49, '1000|603', 2, 1453916018, 51, '50-nam-toan-canh.jpg', '50 nam toan canh'),
('12438964_1...jpg', 'jpg', 'image', 55927, 'assets/support/12438964_1239149622778201_1379376839578412410_n.jpg', 80, 80, '960|960', 1, 1453913739, 53, '12438964_1239149622778201_1379376839578412410_n.jpg', '12438964 1239149622778201 1379376839578412410 n'),
('banner_single.png', 'png', 'image', 164033, 'assets/banners/banner_single.png', 80, 17, '1349|276', 2, 1453916018, 3, 'banner_single.png', 'banner single'),
('mai-tuan-linh.png', 'png', 'image', 466901, 'assets/news/2016_01/mai-tuan-linh.png', 55, 80, '508|738', 2, 1454008688, 8, 'mai-tuan-linh.png', 'Mai Tuấn Linh'),
('untitled.png', 'png', 'image', 933213, 'assets/news/2016_01/untitled.png', 60, 80, '600|800', 2, 1454008781, 8, 'untitled.png', 'untitled'),
('untitled_2.png', 'png', 'image', 954763, 'assets/news/2016_01/untitled_2.png', 80, 53, '960|632', 2, 1454008881, 8, 'untitled_2.png', 'Hoàng ngồi thứ 2 hàng thứ 1 từ phải sang'),
('untitled_3.png', 'png', 'image', 694312, 'assets/news/2016_01/untitled_3.png', 80, 55, '960|656', 2, 1454008922, 8, 'untitled_3.png', 'untitled 3'),
('2013_11-qu...doc', 'doc', 'file', 116224, 'assets/images/msword.png', 32, 32, '|', 2, 1454009711, 62, '2013_11-quy-che-thuc-hien-dan-chu.doc', '2013 11 quy che thuc hien dan chu'),
('1.jpg', 'jpg', 'image', 121309, 'assets/news/2016_01/1.jpg', 80, 46, '609|349', 2, 1454009950, 8, '1.jpg', 'Thành lập CLB tiếng Anh'),
('2.jpg', 'jpg', 'image', 108619, 'assets/news/2016_01/2.jpg', 80, 61, '446|338', 2, 1454010057, 8, '2.jpg', '2'),
('3.jpg', 'jpg', 'image', 192509, 'assets/news/2016_01/3.jpg', 80, 46, '624|351', 2, 1454010071, 8, '3.jpg', '3'),
('4.jpg', 'jpg', 'image', 171209, 'assets/news/2016_01/4.jpg', 80, 46, '624|351', 2, 1454010087, 8, '4.jpg', '4'),
('5.jpg', 'jpg', 'image', 179588, 'assets/news/2016_01/5.jpg', 80, 60, '624|468', 2, 1454010107, 8, '5.jpg', '5'),
('bietthuhie...jpg', 'jpg', 'image', 87122, 'assets/news/2016_01/bietthuhiendai3.jpg', 60, 80, '344|461', 2, 1454010123, 8, 'bietthuhiendai3.jpg', 'bietthuhiendai3'),
('img2015040...jpg', 'jpg', 'image', 246228, 'assets/news/2016_01/img20150403105313.jpg', 80, 60, '653|490', 3, 1454032497, 8, 'img20150403105313.jpg', 'img20150403105313'),
('20141222_0...jpg', 'jpg', 'image', 331917, 'assets/news/2016_01/20141222_075648.jpg', 80, 48, '832|500', 3, 1454032938, 8, '20141222_075648.jpg', '20141222 075648'),
('c3dongtrie...jpg', 'jpg', 'image', 6449, 'assets/cbdoan/c3dongtrieu-nguyenthituyethong.jpg', 53, 80, '106|160', 3, 1454033532, 26, 'c3dongtrieu-nguyenthituyethong.jpg', 'c3dongtrieu nguyenthituyethong'),
('logo_bdecd...png', 'png', 'image', 12337, 'assets/logo_bdecd399b22a909dd37d6636768c582e.png', 80, 31, '144|56', 2, 1453918435, 1, 'logo_bdecd399b22a909dd37d6636768c582e.png', 'logo bdecd399b22a909dd37d6636768c582e'),
('tieu-chi-c...doc', 'doc', 'file', 57856, 'assets/images/msword.png', 32, 32, '|', 2, 1454041689, 62, 'tieu-chi-cham-thi-gvst-2016.doc', 'Tieu chi cham thi GVST 2016'),
('thong-bao-...jpg', 'jpg', 'image', 48865, 'assets/news/2016_01/thong-bao-khan.jpg', 80, 71, '238|211', 2, 1454128286, 8, 'thong-bao-khan.jpg', 'Thong bao khan'),
('anh-to-toan.jpg', 'jpg', 'image', 437123, 'assets/about/anh-to-toan.jpg', 80, 58, '992|718', 2, 1454369902, 51, 'anh-to-toan.jpg', 'Anh to Toan'),
('anh.jpg', 'jpg', 'image', 455840, 'assets/about/anh.jpg', 80, 58, '1000|723', 5, 1454380537, 51, 'anh.jpg', 'ANH'),
('12494951_1...jpg', 'jpg', 'image', 131974, 'assets/about/12494951_1258617394164757_3605795044239102670_n.jpg', 80, 58, '960|685', 6, 1454380779, 51, '12494951_1258617394164757_3605795044239102670_n.jpg', '12494951 1258617394164757 3605795044239102670 n'),
('sngw.jpg', 'jpg', 'image', 176545, 'assets/about/sngw.jpg', 80, 54, '791|529', 8, 1454380902, 51, 'sngw.jpg', 'Sngw'),
('616604_580...jpg', 'jpg', 'image', 142794, 'assets/about/616604_580892198720951_3403248310021076647_o.jpg', 53, 80, '640|960', 7, 1454381172, 51, '616604_580892198720951_3403248310021076647_o.jpg', '616604 580892198720951 3403248310021076647 o'),
('to-sdgdcd.jpg', 'jpg', 'image', 159070, 'assets/news/to-sdgdcd.jpg', 80, 58, '960|695', 11, 1454381610, 7, 'to-sdgdcd.jpg', 'to sdgdcd'),
('to-sdgdcd.jpg', 'jpg', 'image', 159070, 'assets/about/to-sdgdcd.jpg', 80, 58, '960|695', 11, 1454382102, 51, 'to-sdgdcd.jpg', 'to sdgdcd'),
('1-de.jpg', 'jpg', 'image', 282965, 'assets/about/1-de.jpg', 54, 80, '674|1008', 5, 1454382700, 51, '1-de.jpg', '1 DE'),
('12631541_1...png', 'png', 'image', 126085, 'assets/download/images/12631541_1684973511743253_5387227554684466025_n.png', 55, 80, '659|960', 6, 1454382928, 60, '12631541_1684973511743253_5387227554684466025_n.png', '12631541 1684973511743253 5387227554684466025 n'),
('12548875_1...png', 'png', 'image', 92112, 'assets/download/images/12548875_1684973501743254_3781019922407815351_n.png', 55, 80, '659|960', 6, 1454382946, 60, '12548875_1684973501743254_3781019922407815351_n.png', '12548875 1684973501743254 3781019922407815351 n'),
('to-van.jpg', 'jpg', 'image', 136915, 'assets/about/to-van.jpg', 80, 58, '960|695', 10, 1454382948, 51, 'to-van.jpg', 'to van'),
('12541141_1...png', 'png', 'image', 45149, 'assets/download/images/12541141_1684973535076584_8753308090250855472_n.png', 55, 80, '659|960', 6, 1454382959, 60, '12541141_1684973535076584_8753308090250855472_n.png', '12541141 1684973535076584 8753308090250855472 n'),
('12540875_1...png', 'png', 'image', 100639, 'assets/download/images/12540875_1684973525076585_5655432020833042099_n.png', 55, 80, '659|960', 6, 1454382969, 60, '12540875_1684973525076585_5655432020833042099_n.png', '12540875 1684973525076585 5655432020833042099 n'),
('12507433_1...png', 'png', 'image', 123803, 'assets/download/images/12507433_1684973518409919_1868711769373160982_n.png', 55, 80, '659|960', 6, 1454382983, 60, '12507433_1684973518409919_1868711769373160982_n.png', '12507433 1684973518409919 1868711769373160982 n'),
('944039_168...png', 'png', 'image', 41801, 'assets/download/images/944039_1684973548409916_8676470728969654299_n.png', 55, 80, '659|960', 6, 1454383004, 60, '944039_1684973548409916_8676470728969654299_n.png', '944039 1684973548409916 8676470728969654299 n'),
('speaking-t...doc', 'doc', 'file', 24064, 'assets/images/msword.png', 32, 32, '|', 6, 1454383348, 59, 'speaking-topics10cb2015.doc', 'SPEAKING TOPICS  10cb  2015'),
('to-sdgdcd_1.jpg', 'jpg', 'image', 159070, 'assets/about/to-sdgdcd_1.jpg', 80, 58, '960|695', 11, 1454383418, 51, 'to-sdgdcd_1.jpg', 'to sdgdcd'),
('1-de.jpg', 'jpg', 'image', 282965, 'assets/download/1-de.jpg', 54, 80, '674|1008', 5, 1454383438, 58, '1-de.jpg', '1 DE'),
('2-da.jpg', 'jpg', 'image', 149577, 'assets/download/2-da.jpg', 62, 80, '752|972', 5, 1454383439, 58, '2-da.jpg', '2 DA'),
('3-da.jpg', 'jpg', 'image', 182198, 'assets/download/3-da.jpg', 56, 80, '764|1084', 5, 1454383441, 58, '3-da.jpg', '3 DA'),
('4-da.jpg', 'jpg', 'image', 270066, 'assets/download/4-da.jpg', 58, 80, '726|996', 5, 1454383442, 58, '4-da.jpg', '4 DA'),
('5-da.jpg', 'jpg', 'image', 200285, 'assets/download/5-da.jpg', 54, 80, '734|1090', 5, 1454383442, 58, '5-da.jpg', '5 DA'),
('6-da.jpg', 'jpg', 'image', 174550, 'assets/download/6-da.jpg', 77, 80, '776|804', 5, 1454383443, 58, '6-da.jpg', '6 DA'),
('7-da.jpg', 'jpg', 'image', 170869, 'assets/download/7-da.jpg', 63, 80, '752|952', 5, 1454383444, 58, '7-da.jpg', '7 DA'),
('de-thi-thu...rar', 'rar', 'file', 273590, 'assets/images/zip.gif', 32, 32, '|', 14, 1454383653, 59, 'de-thi-thu-lan-1-2016.rar', 'ĐỀ THI THỬ LẦN 1 &#40;2016&#41;'),
('thi-thu-dh...doc', 'doc', 'file', 2193920, 'assets/images/msword.png', 32, 32, '|', 5, 1454383688, 59, 'thi-thu-dh-lan-1c3-hg-15-16-1.doc', 'THI THU ĐH LAN 1c3 HG 15 16 &#40;1&#41;');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_users`
--

CREATE TABLE `pacorp_users` (
  `userid` mediumint(8) UNSIGNED NOT NULL,
  `group_id` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `md5username` char(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `gender` char(1) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text COLLATE utf8mb4_unicode_ci,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `passlostkey` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `view_mail` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `remember` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `in_groups` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `checknum` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_login` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `last_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_openid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `idsite` int(11) NOT NULL DEFAULT '0',
  `safemode` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `safekey` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_users`
--

INSERT INTO `pacorp_users` (`userid`, `group_id`, `username`, `md5username`, `password`, `email`, `first_name`, `last_name`, `gender`, `photo`, `birthday`, `sig`, `regdate`, `question`, `answer`, `passlostkey`, `view_mail`, `remember`, `in_groups`, `active`, `checknum`, `last_login`, `last_ip`, `last_agent`, `last_openid`, `idsite`, `safemode`, `safekey`) VALUES
(1, 0, 'admin', '21232f297a57a5a743894a0e4a801fc3', '{SSHA}E7YGhxQwExoXH/5vmSxqHrJb9fo5Smpk', 'ngocanh@pacorp.vn', 'admin', '', '', '', 0, '', 1453703262, 'a', 'a', '', 0, 1, '', 1, '', 1453703262, '', '', '', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_users_config`
--

CREATE TABLE `pacorp_users_config` (
  `config` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `edit_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_users_config`
--

INSERT INTO `pacorp_users_config` (`config`, `content`, `edit_time`) VALUES
('access_admin', 'a:6:{s:12:"access_addus";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:14:"access_waiting";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:"access_editus";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:12:"access_delus";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:"access_passus";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:"access_groups";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}}', 1453916521),
('password_simple', '000000|1234|2000|12345|111111|123123|123456|654321|696969|1234567|1234569|11223344|12345678|12345679|23456789|66666666|66668888|68686868|87654321|88888888|99999999|123456789|999999999|1234567890|aaaaaa|abc123|abc123@|abc@123|admin123|admin123@|admin@123|adobe1|adobe123|azerty|baseball|dragon|football|harley|hoilamgi|iloveyou|jennifer|jordan|khongbiet|khongco|khongcopass|letmein|macromedia|master|michael|monkey|mustang|nuke123|nuke123@|nuke@123|password|photoshop|pussy|qwerty|shadow|superman', 1453916521),
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1453916521),
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1453916521),
('avatar_width', '80', 1453916521),
('avatar_height', '80', 1453916521),
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br /> <br /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br /> <br /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br /> <br /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129),
('active_group_newusers', '0', 1456564968);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_users_field`
--

CREATE TABLE `pacorp_users_field` (
  `fid` mediumint(8) NOT NULL,
  `field` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'textbox',
  `field_choices` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sql_choices` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `match_regex` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `func_callback` varchar(75) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `required` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `show_register` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `user_editable` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `show_profile` tinyint(4) NOT NULL DEFAULT '1',
  `class` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_users_info`
--

CREATE TABLE `pacorp_users_info` (
  `userid` mediumint(8) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_users_info`
--

INSERT INTO `pacorp_users_info` (`userid`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_users_openid`
--

CREATE TABLE `pacorp_users_openid` (
  `userid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `openid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `opid` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_users_question`
--

CREATE TABLE `pacorp_users_question` (
  `qid` smallint(5) UNSIGNED NOT NULL,
  `title` varchar(240) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lang` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `add_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edit_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_users_question`
--

INSERT INTO `pacorp_users_question` (`qid`, `title`, `lang`, `weight`, `add_time`, `edit_time`) VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238),
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250),
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257),
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264),
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270),
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278),
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_users_reg`
--

CREATE TABLE `pacorp_users_reg` (
  `userid` mediumint(8) UNSIGNED NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `md5username` char(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `regdate` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `checknum` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `users_info` text COLLATE utf8mb4_unicode_ci,
  `openid_info` text COLLATE utf8mb4_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_about`
--

CREATE TABLE `pacorp_vi_about` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_about`
--

INSERT INTO `pacorp_vi_about` (`id`, `title`, `alias`, `image`, `imagealt`, `description`, `bodytext`, `keywords`, `socialbutton`, `activecomm`, `layout_func`, `gid`, `weight`, `admin_id`, `add_time`, `edit_time`, `status`) VALUES
(1, 'Giới thiệu về nhà trường', 'Gioi-thieu-ve-nha-truong', '', '', '', '<strong>TRƯỜNG THPT HÒN GAI - 50 NĂM XÂY DỰNG VÀ TRƯỞNG THÀNH</strong><br  />\r\n&nbsp;\r\n<div style="text-align:center"><img alt="50 nam toan canh" height="362" src="/uploads/about/50-nam-toan-canh.jpg" style="cursor: default;" width="600" /></div>\r\n<br  />\r\n<strong>I. VÀI NÉT VỀ LỊCH SỬ</strong><br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Trường Trung học phổ thông Hòn Gai được thành lập từ năm 1959. Đây là ngôi trường Trung học phổ thông đầu tiên của tỉnh Quảng Ninh.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Khi mới thành lập trường mang tên cấp II - III Hòn Gai. Năm học 1965-1966, khối cấp III sơ tán vào Giáp khẩu, khối cấp II sơ tán vào Đại Yên. Từ năm học 1966-1967, khối cấp II được tách thành trường riêng. Khối cấp III gồm: 2 lớp 8, 2 lớp 9 và 1 lớp 10 hình thành nên Trường cấp III Hòn Gai. Trong thời kỳ chiến tranh phá hoại của giặc Mỹ, trường đã phải sơ tán ở nhiều địa điểm mhư: Bằng Cả, Giáp Khẩu, Sơn Dương, Công Kêu, Cái Đá ... .Tên trường cũng đã nhiều lần thay đổi: lúc đầu mang tên trường cấp II-III Hòn Gai, Trường phổ thông trung học Hồng Gai, Trường Trung học chuyên ban Hồng Gai và nay là trường Trung học phổ thông Hòn Gai.<br  />\r\nLịch sử nhà trường trong suốt 50 năm qua có thể chia ra thành 3 giai đoạn:<br  />\r\n<strong>1- Thời kỳ 1959 đến 1975</strong>: Giai đoạn sơ khai, đi sơ tán chống chiến tranh phá hoại của giặc Mỹ ở miền Bắc và đấu tranh thống nhất nước nhà.<br  />\r\n+ Giai đoạn 1959 đến 1964: trường vừa mới thành lập, lúc đầu chỉ có 1 lớp 8,&nbsp; sau đó khi liên cấp II + III mới có khối lớp 9 và 10. Cơ sở vật chất và đội ngũ giáo viên còn nhiều bất cập.<br  />\r\n+ Giai đoạn 1964 đến 1975: Quy mô khối lớp đã tăng lên, vừa học vừa sơ tán chống chiến tranh phá hoại của giặc Mỹ, vừa chi viện sức người sức của cho giải phóng miền Nam. Trong đội ngũ điệp trùng đi cứu nước có đông đảo thầy giáo và học sinh của nhà trường tham gia.<br  />\r\n<strong>2- Thời kỳ 1976 đến 1986</strong>: Thời kỳ cả nước xây dựng chủ nghĩa xã hội.<br  />\r\nThầy và trò nhà trường đã có những đóng góp xứng đáng trong việc “Nâng cao dân trí, đào tạo nhân lực và bồi dưỡng nhân tài”. Quy mô lớp ngày một tăng lên, có thời điểm lên tới 54 lớp với trên 2.000 học sinh, tạo nguồn nhân lực dồi dào cho công cuộc xây dựng chủ nghĩa xã hội.Vị thế, vai trò của người thầy được xã hội tôn vinh.<br  />\r\n<strong>3- Thời kỳ&nbsp; 1987 đến 2010</strong>: Thời kỳ công nghiệp hoá, hiện đại hoá.<br  />\r\n+ Giai đoạn 1987 đến 2002: Bắt đầu của thời kỳ đổi mới.<br  />\r\n+ Giai đoạn 2002 đến 2010: Xây dựng và hình thành cơ chế mới trong trường Trung học phổ thông Hòn Gai với cơ chế tự chủ, tự chịu trách nhiệm về thực hiện nhiệm vụ tổ chức bộ máy biên chế và tài chính. Tổ chức triển khai đổi mới, tạo bước đi phù hợp với xu thế hội nhập quốc tế của nhà trường.<br  />\r\n<strong>II. VINH DỰ VÀ TỰ HÀO</strong><br  />\r\n<strong>1. Nhà trường góp phần nâng cao dân trí.</strong><br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cùng với các trường Trung học phổ thông trong tỉnh, hàng năm trường Trung học phổ thông Hòn Gai đã tiếp nhận từ 495 đến 525 học sinh trung học cơ sở&nbsp; vào học tập tại trường và có từ 499 đến 527 học sinh tốt nghiệp trung học phổ thông, góp phần đào tạo nguồn nhân lực cho Thành phố Hạ long, tỉnh Quảng Ninh và toàn quốc.<br  />\r\n<strong>2. Đào tạo nhân lực.</strong><br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Rời ghế nhà trường, qua đào tạo Trung cấp, Cao đẳng và Đại học, nhiều học sinh của mái trường THPT Hòn Gai đã trưởng thành và đang đóng góp cho công cuộc xây dựng chủ nghĩa xã hội. Hơn nửa thế kỷ qua, nhà trường đã góp phần tích cực trong việc đào tạo nguồn nhân lực cho đất nước. Đó là hàng trăm trí thức có học hàm, học vị cao, đội ngũ các Giám đốc, phó Giám đốc mỏ, lãnh đạo các ban ngành đoàn thể trong và ngoài tỉnh. Nhiều học sinh đã trở thành cô giáo, thầy giáo, kỹ sư, bác sỹ, nhà báo, nhà văn và nhà hoạt động chính trị có uy tín. Số còn lại, các em đang có mặt trên nhiều lĩnh vực công tác, góp sức xây dựng quê hương Quảng Ninh giàu đẹp, văn minh.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Chúng ta cũng không thể quên hàng trăm học sinh cùng các thầy giáo đã tham gia quân ngũ. Trong số họ, nhiều người đã anh dũng hy sinh cho Tổ quốc. Tấm gương của các anh hùng, liệt sỹ mãi mãi là gương sáng cho chúng ta noi theo.<br  />\r\n<strong>3. Bồi dưỡng nhân tài.</strong><br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Trong 50 năm qua, học sinh của trường nhiều người đã thành danh, tên tuổi của họ đã làm rạng rỡ trang sử truyền thống của nhà trường, được cả nước biết đến và bạn bè quốc tế khâm phục. Đó là anh hùng quân đội Đỗ Viết Cường, nghệ sỹ nhân dân Lê Dung.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Nhiều Học viện, Trường Đại học trong nước và Quốc tế có học sinh trường Trung học phổ thông Hòn Gai theo học hoặc làm công tác nghiên cứu, giảng dạy, các em đã&nbsp; trở&nbsp; thành niềm tự hào của nhà trường.<br  />\r\n<strong>4. Tôn sư trọng đạo.</strong><br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Do chiến tranh phá hoại, trường đã 4 lần đi sơ tán thay đổi địa điểm nên việc lưu trữ, quản lý hồ sơ gặp nhiều khó khăn.Vì vậy, công việc thống kê số lượng các thầy cô giáo và cán bộ công nhân viên công tác tại trường qua các thời kỳ không tránh khỏi những thiếu sót. Song với sự cố gắng, đến nay nhà trường đã có những số liệu cụ thể là:&nbsp;<br  />\r\nTrong hơn 50 năm qua, nhà trường đã đón nhận 468 thầy cô giáo về công tác tại trường :<br  />\r\n+&nbsp; Hiệu trưởng: 11 đồng chí<br  />\r\n+&nbsp; Phó Hiệu trưởng: 22 đồng chí<br  />\r\n+ Giáo viên cấp II: 45 thầy cô giáo<br  />\r\n+ Giáo viên THPT: 424 thầy cô giáo;&nbsp; trong đó tính theo môn:<br  />\r\nNgữ văn : 74&nbsp; Lịch sử : 21&nbsp;&nbsp; Địa lý : 18&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; GDCD : 17<br  />\r\nNgoại ngữ : 38&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Song ngữ : 26&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Toán - Tin : 74&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Vật lý - KTCN : 49<br  />\r\nHoá học : 31&nbsp; Sinh vật - KTNN : 25&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Thể dục-Nhạc- Hoạ :23&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hành chính : 27<br  />\r\nHầu hết cán bộ công nhân viên và giáo viên đều tâm huyết với nghề, tích cực tham gia lao động cống hiến xây dựng nhà trường.<br  />\r\n<strong>III. TRUYỀN THỐNG NHÀ TRƯỜNG</strong><br  />\r\n- Năm 1994, nhà trường vinh dự được Chủ tịch nước tặng thưởng Huân chương Lao động hạng Ba.<br  />\r\n- Năm 1999, nhà trường vinh dự được Chủ tịch nước tặng thưởng Huân chương Lao động hạng Nhì.<br  />\r\n- Năm 2004, nhà trường vinh dự được Chủ tịch nước tặng thưởng Huân chương Lao động hạng Nhất.<br  />\r\n- Năm 2010, nhà trường vinh dự được Chủ tịch nước tặng thưởng Huân chương Độc lập hạng Ba.<br  />\r\nTự hào về truyền thống, thày và trò nhà trường đã không ngừng phấn đấu để phát huy truyền thống tốt đẹp “Dạy tốt - Học tốt”.<br  />\r\n<strong>1. Xây dựng đội ngũ nhà giáo.</strong><br  />\r\n&nbsp; &nbsp; Xuất phát từ quan điểm “Giáo viên là nhân tố quyết định chất lượng giáo dục ...”, nhà trường đã không ngừng đầu tư cho việc xây dựng đội ngũ bằng các hình thức :<br  />\r\n&nbsp; &nbsp; -&nbsp; Tuyển dụng những sinh viên tốt nghiệp loại giỏi, Thạc sỹ.<br  />\r\n&nbsp; &nbsp; -&nbsp; Xem xét tuyển chọn giáo viên đi học để nâng cao trình độ.<br  />\r\n&nbsp; &nbsp; -&nbsp; Tổ chức đào tạo tại chỗ.<br  />\r\n&nbsp; &nbsp; -&nbsp; Thực hiện tinh giảm biên chế.<br  />\r\n&nbsp; &nbsp; Với cách làm trên, đến nay nhà trường đã tuyển được 24 Thạc sỹ ở các bộ môn khoa học cơ bản. Hàng năm trường có từ 58 đến 68 giáo viên giỏi cấp cơ sở và 19 đến 23 giáo viên giỏi cấp tỉnh. Nhiều thầy cô giáo được công nhận là Chiến sỹ thi đua cấp cơ sở, cấp Tỉnh và Chiến sỹ thi đua Toàn Quốc.<br  />\r\n&nbsp; &nbsp; Đội ngũ cán bộ cốt cán của trường năng động sáng tạo, dám nghĩ, dám làm, tích cực đổi mới trong chỉ đạo chuyên môn và quản lý nhà trường.<br  />\r\n<strong>2. Đáp ứng nhu cầu của người học.</strong><br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; “Mô hình cung ứng dịch vụ giáo dục chất lượng cao trong trường Trung học phổ thông Hòn Gai với cơ chế tự chủ, tự chịu trách nhiệm về thực hiện nhiệm vụ tổ chức bộ máy biên chế và tài chính” đã khẳng định chất lượng đào tạo và đáp ứng được nhu cầu của người học trong xu thế hiện nay.<br  />\r\n<strong>3. Duy trì chất lượng văn hóa ( tính từ năm 2004 đến 2010).</strong><br  />\r\n&nbsp; &nbsp; - Học sinh lớp 10 và 11 lên lớp sau khi thi lại đạt 98 đến 99 %.<br  />\r\n&nbsp; &nbsp; - Học sinh&nbsp; tốt nghiệp trung học phổ thông đạt 99,98%.<br  />\r\n&nbsp; &nbsp; - Tỷ lệ học sinh thi đỗ Đại học, Cao đẳng từ 50,7 đến 82%. Riêng năm học 2009 - 2010, trường đứng thứ 180 trong tốp 200 trường có điểm thi cao trên tổng số hơn 3.000 trường THPT toàn quốc.<br  />\r\n&nbsp; &nbsp; - Số giải học sinh giỏi cấp tỉnh tăng từ&nbsp; 93 lên 123 giải; đứng thứ nhì toàn tỉnh.<br  />\r\n&nbsp; &nbsp; - Số học sinh đạt giải quốc gia từ 5 đến 9 em.<br  />\r\n&nbsp; &nbsp; - Số học sinh đạt giải quốc tế có từ 1- 2 em.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br  />\r\n<strong>4. Tăng cường giáo dục đạo đức học sinh.</strong><br  />\r\n&nbsp; &nbsp; Giáo dục đạo đức học sinh được nhà trường quan tâm đúng mức, gắn việc dạy chữ cùng với dạy người. Do đó, hạnh kiểm học sinh có tiến bộ, tỷ lệ học sinh xếp loại tốt khá chiếm trên 90%. Loại yếu giảm dần.<br  />\r\n<strong>5. Đầu tư cơ sở vật chất hiện đại.</strong><br  />\r\n&nbsp; &nbsp; Kết hợp nguồn ngân sách được cấp, đóng góp của giáo viên và các nguồn huy động hợp pháp khác, nhà trường đã xây dựng thêm khu nhà học chất lượng cao 5 tầng và Nhà tập Đa năng cho học sinh luyện tập.<br  />\r\n&nbsp; &nbsp; Đến nay, trường đã có trên 50 phòng học và 8 phòng bộ môn đảm bảo để toàn trường về học một ca. Trang thiết bị trong mỗi lớp do học sinh tự quản gồm: 02 máy điều hòa 18.000 BTU hai chiều, 01 máy Pojecter, 18 bộ bàn ghế mới, 01 bộ loa trợ giảng, 01 máy chiếu Đa vật thể, và cá biệt có phòng học còn được trang bị TV 50 inch để phục vụ học tập. Lắp đặt 13 Camera theo dõi hoạt động chung toàn trường và Internet không dây để khai thác trực tiếp trên lớp, lập trang Web và Thư viện điện tử của trường.<br  />\r\n&nbsp; &nbsp; Cơ sở vật chất nhà trường được đầu tư khang trang xứng tầm với một nhà trường lớn được đông đảo các trường trong và ngoài tỉnh đến tham quan học tập.<br  />\r\n<strong>IV- CÁC HÌNH THỨC KHEN THƯỞNG ĐÃ ĐƯỢC GHI NHẬN</strong><br  />\r\n- Năm học 2004-2005, Nhà trường được Bộ Giáo dục và Đào tạo tặng Bằng khen về thành tích xuất sắc trong công tác TDTT và phong trào Hội khoẻ Phù Đổng giai đoạn 2000- 2004, Bằng khen của UBND tỉnh Quảng Ninh về thành tích xuất sắc trong phong trào thi đua yêu nước 5 năm 2000-2004,. Bằng khen của Liên đoàn lao động tỉnh Quảng Ninh&nbsp; năm học 2004-2005.<br  />\r\n- Năm 2004, nhà trường được Chủ tịch nước tặng thưởng Huân chương lao động hạng nhất.<br  />\r\n- Năm học 2005-2006 : Nhà trường được UBND tỉnh Quảng Ninh tặng Bằng khen về thành tích hoàn thành xuất sắc nhiệm vụ năm học 2005-2006. Bằng khen “Cơ quan giỏi năm 2005”. Bằng khen của Bảo hiểm xã hội Việt Nam về thành tích thực hiện tốt chính sách BHXH năm 2005.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Đoàn TNCS Hồ Chí Minh nhà trường được tặng thưởng Huân chương lao động hạng ba năm 2005.<br  />\r\n- Năm học 2006-2007 Nhà trường được Bộ Giáo dục và Đào tạo tặng Bằng khen về thành tích hoàn thành xuất sắc nhiệm vụ năm học 2006-2007.<br  />\r\n- Năm học 2007-2008: Nhà trường được UBND tỉnh Quảng Ninh tặng Cờ thi đua dẫn đầu khối THPT tỉnh Quảng Ninh .<br  />\r\n- Năm học 2008-2009:&nbsp; Nhà trường được Bộ Giáo dục và Đào tạo tặng Cờ thi đua cho đơn vị dẫn đầu khối THPT toàn quốc; Thủ tướng Chính phủ tặng Bằng khen.<br  />\r\n- Năm học 2009-2010:<br  />\r\n<strong>Trường được công nhận Trường chuẩn Quốc gia.</strong><br  />\r\nChủ tịch nước tặng thưởng Huân chương Độc lập hạng ba năm 2010.<br  />\r\nCông đoàn nhà trường được Chủ tịch nước tặng thưởng Huân chương Lao động hạng ba năm 2010.<br  />\r\nNhiều tập thể, cá nhân được Chủ tịch nước, Thủ tướng chính phủ, UBND tỉnh và các Bộ tặng thưởng Huân chương Lao động, danh hiệu Chiến sỹ thi đua toàn quốc, phong tặng Nhà giáo ưu tú, Bằng khen ...<br  />\r\n* Đảng bộ nhà trường nhiều năm liền đạt Đảng bộ trong sạch, vững mạnh, được Thành uỷ Hạ long, Tỉnh uỷ Quảng Ninh biểu dương và khen thưởng.', 'giới thiệu', 1, '4', '', 0, 1, 1, 1453881145, 1453881145, 1),
(2, 'Giới thiệu về Đảng bộ nhà trường', 'Gioi-thieu-ve-Dang-bo-nha-truong', '', '', '', '<div style="text-align: center;"><b>ĐẢNG BỘ TRƯỜNG THPT HÒN GAI QUA CÁC CHẶNG ĐƯỜNG PHÁT TRIỂN</b></div>\r\n\r\n<div><b>&nbsp;&nbsp;&nbsp;&nbsp; </b>Tiền thân của Đảng bộ trường THPT Hòn Gai là chi bộ Đảng Hồng Quảng, được thành lập từ năm 1959 cùng với sự thành lập trường cấp 2-3 lúc bấy giờ. Đến năm 1998 phát triển thành Đảng bộ THPT Hòn Gai. Trải qua 50 năm phấn đấu, trưởng thành, Đảng bộ THPT Hòn Gai đã vượt qua bao gian nan thử thách, làm tốt vai trò lãnh đạo các tổ chức trong trường và đã thực sự trở thành tổ chức hạt nhân, lãnh đạo nhiệm vụ chính trị.</div>\r\n\r\n<div>&nbsp; &nbsp; Thời kì chiến tranh chống Mĩ cứu nước, đặc biệt là những năm tháng giặc Mĩ leo thang bắn phá miền Bắc, điều kiện sinh hoạt khó khăn, cơ sở vật chất thiếu thốn, công việc bề bộn, vừa học, vừa sơ tán, vừa đào hào đắp lũy, tránh bom rơi đạn lạc, nhưng chi bộ Đảng đã thể hiện rõ bản chất kiên cường, năng lực lãnh đạo của mình, hoàn thành xuất sắc nhiệm vụ giáo dục phổ thông, giáo dục tư tưởng Cách mạng. Tại nơi đây, biết bao người con ưu tú sẵn sàng lên đường bảo vệ Tổ Quốc. Nhiều người đã hy sinh trên chiến trường miền Nam như: Liệt sĩ Vũ Minh Trí, Dương Trọng Chử, Nguyễn Văn Đắc, Lê Văn Bình, Nguyễn Văn Quảng, Nguyễn Văn Toàn, Lê Văn Vang, Đinh Văn Đình, Nguyễn Hữu Đương, Nguyễn Đình Quyết, Nguyễn Văn Bảo, Nguyễn Tâm, Nguyễn Dũng..... và nhiều người đã trưởng thành trong quân đội như anh hùng quân đội Đỗ Viết Cường, thiếu tướng Sóng Hồng, thiếu tướng Vũ Hiệp Bình.....</div>\r\n\r\n<div>&nbsp; &nbsp; Miền Nam giải phóng, đất nước thống nhất, trong hoàn cảnh kinh tế xã hội khó khăn, đời sống cán bộ giáo viên vất vả trăm bề, phát huy truyền thống đoàn kết vượt khó, chi bộ Đảng tiếp tục lãnh đạo nhà trường vững bước đi lên. Đến năm 1998, chi bộ Đảng đã phát triển thành đảng bộ, đây là Đảng bộ đầu tiên trong hệ thống các trường THPT, dưới sự lãnh đạo trực tiếp của Đảng bộ Thành phố và đây cũng là thời điểm quan trọng đánh dấu một bước tiến mới của Đảng bộ THPT Hòn Gai.</div>\r\n\r\n<div style="text-align: center;">&nbsp;</div>\r\n\r\n<div>&nbsp;&nbsp;&nbsp;&nbsp; Đảng bộ đã chỉ đạo các tổ chức trong trường có kế hoạch thường xuyên bồi dưỡng chuyên môn nghiệp vụ, đổi mới phương pháp dạy học, phát động các phong trào thi đua gắn&nbsp; với&nbsp; chủ đề của năm học. Với sự nỗ lực, bền bỉ vươn lên trong nhiều thập kỉ qua, nơi đây đã góp phần đào tạo lớp lớp các thế thế hệ học trò thành danh trên mọi miền đất nước như: nghệ sỹ nhân dân Lê Dung, phó giáo sư Hoàng Thọ Tu, nhạc sỹ Văn Thành Nho.... và biết bao thế hệ giáo viên, cán bộ đã trưởng thành từ mái trường này, như:</div>\r\n\r\n<div>- Đ/c Ngô Gia Phong nguyên vụ trưởng vụ THPT Bộ Giáo dục và Đào đạo.<br  />\r\n- Đ/c Trịnh Thị Tính, nguyên Tỉnh ủy viên, Hội trưởng hội Phụ nữ tỉnh Quảng Ninh.<br  />\r\n- Đ/c Lê Quang Chiểu, nguyên Tỉnh ủy viên, Giám đốc Sở Giáo dục và Đào tạo Quảng Ninh.<br  />\r\n- Đ/c Phạm Kim, nguyên Phó giám đốc Sở Giáo dục và Đào tạo Quảng Ninh, giám đốc Trung tâm giáo dục thường xuyên tỉnh Quảng Ninh.<br  />\r\n- Đ/c Đào Duy Cát, nguyên Phó giám đốc Sở Giáo dục và Đào tạo Quảng Ninh, nguyên Giám đốc Đài phát thanh truyền hình Quảng Ninh.<br  />\r\n- Đ/c Nguyễn Viết Khai, Nguyên Tổng biên tập báo Quảng Ninh, người được kết nạp Đảng khi còn là học sinh của trường.<br  />\r\n- Đ/C Lê Quang Vĩnh, Vụ trưởng Vụ văn thư lưu trữ Trung ương Đảng.<br  />\r\n- Đ/c Nguyễn Thanh Hiễn Phó giám đốc Sở Giáo dục và Đào tạo Quảng Ninh.<br  />\r\n- Đ/c Lê Thị Kim Loan, Phó giám đốc Sở nội vụ tỉnh Quảng Ninh.<br  />\r\n- Đ/c Phạm Thị Hồng Hà, Hiệu trưởng trường THPT Chuyên Hạ Long.<br  />\r\n&nbsp; &nbsp; Nhiều Đảng viên của Đảng bộ đã vinh dự được tặng danh hiệu Nhà giáo ưu tú như các đồng chí: Đinh Gia Phong, Lê Quang Chiểu, Nguyễn Thị Thận, Phạm Kim, Bùi Quốc Việt, Nguyễn Thị Kim Chi, Vũ Đình Trúc, Phạm Thị Nga, Vũ Thị Dung (Hiện là Phó bí thư Đảng ủy, Phó hiệu trưởng), Hoàng Thế Vinh (Hiện là Bí thư Đảng ủy, Hiệu trưởng).......<br  />\r\nHằng năm trường có hàng trăm học sinh giỏi cấp tỉnh, nhiều học sinh giỏi cấp quốc gia, trên 80% học sinh đỗ vào các trường Đại học. Đặc biệt 5 năm gần đây, Đảng ủy đã đổi mới cơ chế quản lí, bước đầu thực hiện thành công “Đề án thí điểm mô hình cung ứng dịch vụ giáo dục chất lượng cao trong trường THPT Hòn Gai với cơ chế tự chủ tự chịu trách nhiệm về thực hiện nhiệm vụ tổ chức bộ máy biên chế và tài chính” tạo ra một bước đột phá trong việc thực hiện nhiệm vụ chính trị của nhà trường.<br  />\r\nĐể tổ chức cơ sở Đảng thực sự vững mạnh, Đảng ủy THPT Hòn Gai đã hết sức chú trọng công tác phát triển Đảng viên, mỗi năm Đảng bộ kết nạp được từ 2-4 Đảng viên. Hiện nay Đảng bộ có 53 Đảng viên chiếm gần 50% số lượng cán bộ giáo viên của trường. Song song với sự phát triển về số lượng, Đảng bộ luôn quan tâm nâng cao chất lượng Đảng viên. Đối tượng bồi dưỡng kết nạp Đảng đều là các thầy cô giáo có năng lực chuyên môn vững vàng, say sưa với nghề, tâm huyết với học sinh. Chính vì vậy giáo viên giỏi, chiến sỹ thi đua các cấp và cán bộ quản lí của trường trên 90 % là đảng viên. 100% Đảng viên qua các kì kiểm điểm phân loại đều đạt Hoàn thành tốt nhiệm vụ. Bốn nhiệm kì qua Đảng bộ liên tục được Tỉnh ủy và Thành ủy công nhận là tổ chức cơ sở Đảng trong sạch vững mạnh. Các tổ chức trong nhà trường được bố trí một đồng chí trong BCH trực tiếp lãnh đạo, nhờ vậy đã đạt được những thành tích đáng tự hào:<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp; - Nhà trường được tặng thưởng Huân chương Độc lập hạng Ba, tặng cờ dẫn đầu khối THPT của 15&nbsp; tỉnh phía Bắc.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp; - Công đoàn được tặng cờ của Tổng liên đoàn lao động Việt Nam, và đang đề nghị được nhận Huân chương Lao động hạng Ba.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp; - Đoàn thanh niên được tặng thương Huân chương Lao động hạng Ba.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;Có được những thành tựu trên là do sự quan tâm, lãnh đạo, chỉ đạo trực tiếp của Thành ủy, Sở Giáo dục và Đào tạo, cùng sự cố gắng nỗ lực lớn của tập thể cán bộ thày cô giáo, công nhân viên nhà trường, các thế hệ học sinh, và sự ủng hộ nhiệt tình của các bậc phụ huynh.<br  />\r\n&nbsp; &nbsp; Kế thừa, phát huy những truyền thống đã đạt được trong 50 năm qua. Đảng bộ trường THPT Hòn Gai tin tưởng rằng, sẽ tiếp tục lãnh đạo Nhà trường gặt hái nhiều thành công hơn nữa, tạo ra một trang mới trong sự nghiệp giáo dục, bồi dưỡng, ươm nguồn tài năng cho đất nước. Để trường THPT Hòn Gai trở thành niềm tự hào không chỉ của cán bộ giáo viên học sinh, mà còn là niềm tự hào của ngành giáo dục Tỉnh Quảng Ninh.</div>', 'giới thiệu,đảng bộ', 1, '4', '', 0, 3, 2, 1453881167, 1454006104, 1),
(3, 'Giới thiệu tổ Toán - Tin học', 'TO-TOAN-TIN-HOC', 'anh.jpg', 'Tập thể giáo viên tổ Toán - Tin học', 'TỔ TOÁN TIN - KHỐI ĐOÀN KẾT VÀ TÂM HUYẾT NGHỀ NGHIỆP', 'Có thể nói tổ Toán Tin trường THPT Hòn Gai là một trong những tổ bộ môn thể hiện rõ nét nhất về tình đoàn kết nhất trí và sự tâm huyết nghề nghiệp. Đây là tổ bộ môn nhiều năm liền đạt danh hiệu tổ lao động xuất sắc .<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ngay từ những năm đầu thành lập trường, giáo viên Toán của trường gồm các thầy cô giáo với lòng nhiệt huyết của tuổi trẻ, say mê với nghề nghiệp, chuyên môn vững vàng và có tinh thần trách nhiệm cao như thầy Lê Biền, thầy Nguyễn Phú Mĩ, thầy Trương Công Tịnh, thầy Nguyễn Cát Tường, thầy Vũ Đình Trúc, thầy Đinh Gia Phong, thầy Đỗ Tường Chẩn, thầy Lê Đức Tình, thầy Nguyễn Văn Thắng, thầy Trịnh Hoàng Sâm, cô Lý Bích Phương, thầy Trần Văn Thấu, thầy Trần Đình Mão, thầy Nguyễn Ngọc Đàm, thầy Nguyễn Chí Viên, thầy Nguyễn Nam Sơn, cô Nguyễn Thị Thuỷ, thầy Nguyễn Văn Minh, thầy Phạm Bá Hạnh, cô Trần Thị Mĩ, cô Nguyễn Thị Thoa, thầy Đặng Mạnh Hùng, cô Lưu Thu Thuỷ, cô Lê Thị Diễn, thầy Trịnh Văn Biên, thầy Vũ Bá Nghĩa, cô Phạm Thị Hằng, cô Trịnh Thị Dung, thầy Lý Năng Luân, thầy Nguyễn Tiến Lập, thầy Lê Thế Long,v.v... Đặc biệt là thầy giáo <em>Nguyễn Cát Tường</em> - một trong những &quot; cây Đa, cây Đề&quot; của Nhà trường, thầy là giáo viên dạy giỏi có nhiều kinh nghiệm và say sưa với chuyên môn, thầy luôn tận tình kèm cặp giúp đỡ các giáo viên trẻ của tổ về chuyên môn nghiệp vụ. Một thầy giáo trong hàng ngũ &quot;cây Đa, cây Đề&quot; của Nhà trường đó là Nhà giáo ưu tú <em>Vũ Đình Trúc</em>, nguyên là Bí thư Đảng bộ, Hiệu trưởng Nhà trường, thầy là một giáo viên dạy toán kì cựu, khi thầy còn đang công tác mặc dù làm Hiệu trưởng bận rộn với rất nhiều công việc song thầy vẫn luôn quan tâm sát sao tới các hoạt động chuyên môn của tổ. Thầy <em>Nguyễn Nam Sơn</em> trước đây cũng là một giáo viên dạy Toán nổi tiếng của trường, khi khối chuyên&nbsp; thành lập riêng trường chuyên cấp III , thầy không còn dạy ở trường Hòn Gai nữa nhưng thầy vẫn nhiệt tình giúp đỡ dìu dắt các giáo viên trong tổ Toán Tin của Nhà trường. Nối tiếp thế hệ các thầy cô đi trước là đội ngũ các thầy cô rất nhiệt tình năng nổ trong chuyên môn và trong các lĩnh vực công tác khác như thầy Ngô Mạnh Khôi, cô Đặng Thị Lập, cô Bùi Bích Phương, thầy Cầm Thanh&nbsp; Hải, thầy Lê Khắc Thường, thầy Lê Văn Hân, cô Lê Thị Kim Loan, thầy Lê Quang Vĩnh, cô Lê Thị Hồng, cô Nguyễn Thanh Giang, cô Đinh Thị Thu, thầy Đỗ Tiến Dũng, cô Doãn Tô Giang, cô Vũ Thị Kim Thu, cô nguyễn Thị Tính , cô Nguyễn Thị Dung , cô Hoàng Hồng Linh, cô Nguyễn Thị Nga, cô Nguyễn Thị Hường, Thầy Nguyễn Thế Hồng Lực, thầy Đặng Thanh Dân, thầy Lê Thanh Hà, cô Đỗ Thị Hà v.v... Một số các thầy cô đã trưởng thành và đang giữ vị trí rất quan trọng trong các cơ quan của Trung ương và của Tỉnh như thầy <em>Lê Quang Vĩnh</em> -Thạc sĩ hiện đang là Vụ trưởng Vụ thư kí văn phòng Trung ương Đảng. Thầy <em>Nguyễn Thế Hồng Lực</em> - Thạc sĩ hiện là trưởng phòng Tin học của Học viện Ngoại Giao, cô <em>Lê Thị Kim Loan</em> hiện là phó giám đốc Sở nội vụ Quảng Ninh, thầy <em>Ngô Mạnh Khôi</em> hiện là trưởng phòng Tổ chức cán bộ và thầy <em>Cầm Thanh Hải</em> hiện là trưởng phòng Khảo thí và Kiểm định chất lượng giáo dục của Sở giáo dục và Đào tạo Quảng Ninh. Các thầy cô giáo đã làm tăng thêm sức mạnh cho tổ Toán Tin. Lớp giáo viên trẻ hiện nay được trưởng thành một phần cũng là nhờ sự dìu dắt của lớp các thầy cô đi trước. Kế thừa truyền thống của các thầy cô thế hệ trước, tổ Toán Tin trường THPT Hòn Gai luôn thể hiện tình đoàn kết nhất trí, sát cánh bên nhau, quyết tâm phấn đấu dạy tốt để tạo được niềm tin của học sinh và sự tin tưởng từ các bậc phụ huynh - Đây&nbsp; là một trong những <em>thành công</em> nhất của tổ Toán Tin trường THPT Hòn Gai.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;Cho đến năm học thứ 50 này tổ Toán Tin gồm 20 thầy cô giáo với tuổi đời cao nhất là 52, thấp nhất là 25. Tuổi nghề cao nhất là 30 năm và thấp nhất là 3 năm. Một cô giáo trong tổ giữ chức vụ&nbsp; Phó Bí thư Đảng bộ, Phó hiệu trưởng phụ trách chuyên môn, Chủ tịch Công đoàn Nhà trường đó là Nhà giáo ưu tú <em>Vũ Thị Dung</em>. Toàn tổ luôn là một khối đoàn kết nhất trí. Mọi thành viên trong tổ luôn thương yêu đùm bọc lẫn nhau. Mỗi khi gia đình thầy cô nào có chuyện vui, buồn&nbsp; thì các thành viên trong tổ đều có mặt đầy đủ, kịp thời chia sẻ, giúp đỡ, phân công dạy thay&nbsp; tuyệt đối không để giờ học bị bỏ trống. Mọi thành viên trong tổ cư xử với nhau như người thân trong gia đình, thông cảm và hiểu biết hoàn cảnh của nhau, giúp đỡ nhau vượt qua những khó khăn của bản thân. Trong lĩnh vực chuyên môn, tổ Toán Tin luôn được đánh giá là đội ngũ vững vàng đều tay. Các thành viên trong tổ luôn cố gắng học hỏi trau dồi chuyên môn, cập nhật công nghệ thông tin áp dụng vào giảng dạy đạt hiệu quả cao. Đại đa số các thầy cô giáo trong tổ có tay nghề vững vàng, nhiều năm đạt danh hiệu giáo viên dạy giỏi, chiến sĩ thi đua các cấp như cô&nbsp; Vũ Thị Dung, cô Vũ Thị Kim Thu, cô Nguyễn Thị Dung, cô Nguyễn Thị Tính,&nbsp; cô Nguyễn Thị Hường, cô Nguyễn Thị Nga, cô Đoàn Thị Hồng Cẩm, thầy Phạm Bắc Vinh, cô Bùi Thị Thuý Nga, thầy Bùi Văn Giang,v.v...Phát huy những thành tích của thế hệ&nbsp; các thầy cô đi trước, tổ Toán Tin trong nhiều năm gần đây đã đạt được những thành tích đáng kể trong lĩnh vực chuyên môn, góp phần rạng danh cho nhà trường : năm 2001-2002 có em <em>Phạm Quang Vinh</em> đạt giải Ba toàn quốc môn Tin học, năm học 2004-2005 có em <em>Nguyễn Xuân Hoan</em> đạt giải Khuyến Khích toàn quốc môn Tin học, năm 2008-2009 có em <em>Nguyễn Đình Hùng</em> đạt giải Khuyến Khích toàn quốc môn Máy tính Casio. Số lượng học sinh đạt giải học sinh giỏi cấp Tỉnh trong những năm gần đây cũng rất đáng tự hào, mỗi năm đạt từ 7 đến 15 giải trong đó có cả giải Nhất, Nhì, Ba ở cả&nbsp; bộ môn Toán và Tin. Bên cạnh công tác chuyên môn các thành viên của tổ còn tích cực tham gia công tác khác như công tác Đảng, Công đoàn, Đoàn thanh niên. Hơn một nửa các thành viên của Tổ tham gia công tác chủ nhiệm với nghiệp vụ vững vàng, tinh thần trách nhiệm cao được học sinh yêu mến, phụ huynh tin tưởng, nhiều đồng chí đạt danh hiệu giáo viên chủ nhiệm giỏi. Toàn tổ đã được Nhà trường, Sở Giáo dục và Đào tạo, Uỷ ban nhân dân tỉnh&nbsp; khen thưởng. Có được những thành tích trên là nhờ sự quan tâm chỉ đạo sát sao của cấp uỷ Đảng, Ban giám hiệu Nhà trường, sự giúp đỡ tận tình của thế hệ các thầy cô đi trước và sự cố gắng không ngừng của mỗi thành viên trong tổ.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Nhìn lại chặng đường 50 năm qua, tổ Toán Tin trường THPT Hòn Gai đã đạt được những thành tích đáng tự hào, góp phần xây dựng sự nghiệp giáo dục của Tỉnh Quảng Ninh nói riêng và của đất nước nói chung. Để phát triển và nhân rộng những thành tích đó, tổ Toán Tin luôn sát cánh cùng với các tổ bộ môn khác hướng tới mục tiêu đào tạo con người và nhân tài góp phần xây dựng tỉnh Quảng Ninh giàu đẹp và đất nước phồn vinh.<br  />\r\n&nbsp;', 'giới thiệu', 1, '4', '', 0, 4, 5, 1454380678, 1454381043, 1),
(4, 'tổ Song ngữ', 'to-Song-ngu', 'sngw.jpg', 'to song ngữ', '', '<div><strong><em>TỔ SONG NGỮ</em></strong><br  />\r\n&nbsp;<br  />\r\n<strong>10 NĂM HÌNH THÀNH VÀ PHÁT TRIỂN</strong><br  />\r\n<strong>(Bùi Thị Lý - Tổ trưởng)</strong><br  />\r\n&nbsp;<br  />\r\nTrong không khí sôi nổi, hào hứng, khẩn trương của các thầy cô giáo trong Ban giám hiệu, các tổ chuyên môn, các đoàn thể để chuẩn bị lễ kỉ niệm 50 năm ngày thành lập trường THPT Hòn Gai.Với sự tự hào về những thành tích hết sức to lớn mà nhà trường đã đạt được trong đó có sự đóng góp không nhỏ của tổ <em>Song ngữ</em>, chúng tôi xin được đóng góp vài dòng tư liệu phản ánh quá trình xây dựng và trưởng thành của tổ chuyên môn.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Được thành lập rất muộn so với các tổ chuyên môn khác, năm 1994 ở Quảng Ninh các lớp 1 và lớp 6 song ngữ có mặt tại trường tiểu học Bạch Đằng và trường THCS Kim Đồng và đến năm 1998 những lớp song ngữ đầu tiên có mặt tại trường THPT Hòn Gai.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Từ năm 1998 đến 2001 các giáo viên song ngữ sinh hoạt trong tổ Ngoại ngữ, các giáo viên khoa học bằng tiếng Pháp sinh hoạt trong tổ Toán, tổ Vật lý, tổ Sinh hóa. Từ năm 2001 đến nay, các giáo viên song ngữ và khoa học bằng tiếng Pháp sinh hoạt trong tổ chuyên môn mới có tên là: <strong><em>SONG NGỮ</em></strong><br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ban đầu mỗi phân môn chỉ có 01 giáo viên dạy: 01 giáo viên tiếng Pháp, 01 giáo viên lý Pháp, 01 giáo viên toán Pháp, 01 giáo viên dạy sinh Pháp. Đến nay tổ chuyên môn đã có 15 thành viên gồm 12 giáo viên tiếng Pháp và 03 giáo viên khoa học bằng tiếng Pháp.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Các giáo viên làm việc dưới sự giám sát chuyên môn rất nghiêm túc, chặt chẽ sát&nbsp; xao của các cố vấn sư phạm người nước ngoài: Canada, Bỉ, Pháp trong các giờ dạy trên lớp và trong các buổi sinh hoạt chuyên môn và hàng tháng có báo cáo gửi về chương trình song ngữ của khối Pháp ngữ tại Hà Nội. Trang thiết bị trong lớp học được phía đối tác trang bị đầy đủ: Đài cát-xét, ti vi, đầu video, máy photo, sách truyện tài liệu, giáo trình. Hàng năm trong các đợt hè, các giáo viên được tập huấn chuyên môn tại các thành phố lớn như Hà Nội, thành phố Hồ Chí Minh, Đà Nẵng, Huế ...và đặc biệt là các cuộc tập huấn chuyên môn tại Cộng hòa Pháp và Canada. Các giáo viên được đào tạo sát với thực tế nên trình độ chuyên môn rất cao.<br  />\r\nVới đặc thù bộ môn học nên học sinh học các lớp song ngữ rất năng động và hiếu học. Thành tích các em đạt được rất đáng tự hào. Khóa đầu tiên lớp 11 đi thi học sinh giỏi cấp Quốc gia đã đạt được 8 giải, một kết quả làm nức lòng cho học sinh khối song ngữ đặc biệt là các bậc phụ huynh có con theo học trong chương trình.<br  />\r\nCác năm tiếp theo thành tích càng được dày thêm. Đến nay số học sinh giỏi quốc gia đã đạt được 58&nbsp; giải trong đó có 01 giải nhất và 30 giải nhì và nhiều những giải khác. Một con số mơ ước của tất cả các tổ chuyên môn trong trường !<br  />\r\nBên cạnh thành tích đạt được trong các kì thi học sinh giỏi quốc gia, học sinh lớp 12 song ngữ đỗ vào các trường đại học với tỷ lệ cao. Hàng năm số học sinh đi du học tại Pháp và Canada tăng lên rõ rệt. Tính đến thời điểm 2010 số lượng học sinh đi du học nước ngoài là 68 em. Nhiều học sinh đang theo học thạc sĩ, tiến sĩ ở các trường đại học danh tiếng như Sorbone (Paris), Lyon, Nantes....<br  />\r\n<strong><u>Một số gương mặt học sinh&nbsp; điển hình :</u></strong><br  />\r\n<strong>1.Trần Minh Hoàng (1999 - 2002) đã bảo vệ thành công luận án tiến sĩ kinh tế tại đại học Sorbone (Paris).</strong><br  />\r\n<strong>1.Trần Hồng Nhung (1999 - 2002) đã bảo vệ thành công luận án phó tiến sĩ kinh tế tại đại học Paris 2.</strong><br  />\r\n<strong>3. Ngô Khánh Ly (2001 - 2004) đã bảo vệ thành công luận án phó tiến sĩ kinh tế tại đại học Paris 12.</strong><br  />\r\n&nbsp;<br  />\r\nNhững thành tích kể trên mới chỉ là kết quả bước đầu, trước mắt tổ <em>Song ngữ</em> còn cả một chặng đường dài phải phấn đấu. Những khó khăn về vật chất cũng như nhân lực vẫn là những thách thức không nhỏ đối với tập thể nhỏ bé này. Tuy nhiên, với tinh thần đoàn kết, nhiệt tình&nbsp; lao động sáng tạo, cùng với sự quan tâm của các cấp lãnh đạo, tổ <em>Song ngữ</em> sẽ làm hết sức mình để xứng đáng là một tổ chuyên môn điển hình mẫu mực của nhà trường. Trong những năm học tiếp theo với sự cố gắng hết mình, phấn đấu&nbsp;&nbsp; không mệt mỏi của các thành viên trong tổ, hy vọng một chặng đường mới đầy vinh quang sẽ đến với học sinh và giáo viên tổ <em>Song ngữ</em>.</div>', '', 1, '4', '', 0, 2, 8, 1454380965, 1454380965, 1),
(5, 'Giới thiệu tổ Ngoại Ngữ', 'Gioi-thieu-to-Ngoai-Ngu', '12494951_1258617394164757_3605795044239102670_n.jpg', 'Tổ Ngoại Ngữ - Thpt Hòn Gai &#40;2010-2011&#41;', 'Tổ Ngoại Ngữ - Tâm huyết và niềm tin', '&nbsp;Cũng như các môn học khác ở trường Trung học phổ thông (THPT) Hòn Gai, việc giảng dạy môn Tiếng Anh của chúng tôi cũng trải qua rất nhiểu gian khó.<br  />\r\nChúng tôi đã phải sử dụng sách giáo khoa (SGK) 3 năm, 7 năm, cải cách, phân ban, thí điểm rồi đến hiện nay là sách phân ban chuẩn và sách nâng cao. Nhìn lại chặng đường đã qua của tổ chuyên môn, chúng tôi thấy mình đã trưởng thành và vững vàng rất nhiều trong công tác giảng dạy.<br  />\r\nNgày đầu giảng dạy tại trường với cuốn SGK thí điểm 3 năm, chúng tôi đều cảm thấy rất khó truyền đạt cho học sinh của mình với lượng kiến thức ít ỏi trong sách mà các kỹ năng bị pha trộn không rõ ràng, khiến người dạy phải vừa dạy vừa thiết kế lại SGK sao cho phù hợp với sức học của học sinh.<br  />\r\nCó một lần tôi nhận được một bức thư của một em học sinh từ nước ngoài gửi về, trong thư em có nói sang Australia em phải đi học lại từ đầu môn tiếng Anh (như lớp một của Việt Nam vậy). Em có tâm sự rằng mình đã rất vất vả đánh vật với môn này để có thể được nhận vào học chính thức tại trường THPT của họ. Thời gian học tiếng là một năm với số tiền học không nhỏ. Cuối thư em có nói một câu làm khiến tôi suy nghĩ: “Giá mà ở Việt Nam em được học nghe-nói-đọc-viết tiếng Anh tốt, em đã rút ngắn được thời gian du học, tiết kiệm được tiền cho cha mẹ”.<br  />\r\nNgày ấy chúng tôi lực bất tòng tâm, người giáo viên không có điều kiện được sáng tạo bởi sự trói buộc của SGK và phân phối chương trình , phương pháp dạy truyến thống không phù hợp và trở nên lạc hậu. Trong một lớp lượng học sinh quá đông, có lớp gần 60 học sinh. Chúng tôi quản được lớp đã thấy mệt, đã thế việc thi cử cũng có tác động lớn đối với học sinh, rất ít trường đại học tuyến sinh khối D (Toán-Văn-Anh ). Vì vậy cơ hội chọn trường để thi đại học của các em cũng rất ít.<br  />\r\nSau đó chúng tôi lại sử dụng sách 7 năm (Tiếng Anh 7 năm) cho những học sinh học tiếng Anh từ cấp Trung học cơ sở. Nhưng thật buồn SGK này tuy mới mà cũng rất cũ vì dành cho các trường phía nam và được xuất bản rất nhiều năm trước. Các bài đọc khô cứng, dài dòng, không có các kỹ năng để giúp học sinh nghe, nói, viết và giao tiếp trong môi trường thực tế. Học sinh học kém môn tiếng Anh từ cấp cơ sở. Chúng tôi đã trao đổi tìm biện pháp mà chẳng mấy hiệu quả. Những ngày đó chúng tôi thực sự khâm phục các cô trong tổ chuyên môn: cô giáo Lê Thị Mão, cô giáo Dương Thị Kim. Các cô vừa chuyển từ tiếng Nga sang tiếng Anh mà phải dạy một giáo trình khó đến thế mà vẫn chuyển tải hết kiến thức cho học sinh một cách tận tình. Các cô luôn luôn học hỏi để tìm ra phương pháp tốt nhất. Trong giảng dạy, cô Nguyễn Thị Luật, cô Nguyễn Thị Tú, thầy Nguyễn Đăng Phúc, cô Trần Thị Vân là tấm gương cho chúng tôi học tập vì sự tận tuỵ, trăn trở trước từng trang giáo án. Ở các thầy,cô chúng tôi học tập được tính kiên trì, tâm huyết với học trò. Trong những lúc cam go đó, không thể không nói đến cô Vũ Thị Mận, cô Lê Thị Nhài - các tổ trưởng đã đứng mũi chịu sào lãnh đạo tổ vượt qua khó khăn …<br  />\r\nKhó khăn thế mà lớp trẻ lúc đó là cô Bùi Thị Hồng Vân, cô Trịnh Thị Hoà, thầy Phạm Ngọc Hà đều say sưa với học trò. Các thầy cô có rất nhiều sáng tạo, tự học hỏi để bắt tay vào luyện học sinh giỏi. Lúc đó có người đùa bảo chúng tôi là “Tay không bắt giặc”. Chúng tôi vẫn quyết tâm tạo ra một không khí học tập đổi mới trong nhà trường. Bước đầu giáo dục các em vể tầm quan trọng của môn tiếng Anh - đó là chìa khoá vàng để giao tiếp với các nước tiên tiến, để học tập, hội nhập, sau đó tạo hứng khởi cho các em bằng cách thay đổi phương pháp cũ. Đào tạo mũi nhọn tập trung vào các em trong đội tuyển để các các em đạt nhiểu giải, đội tuyển phải đỗ đại học 100%. Chúng tôi mạnh dạn đưa giáo trình của nước ngoài vào dạy đọc, viết cho đội tuyển. Để làm được việc này cũng rất dày công vì ngay chính bản thân chúng tôi cũng phải tự học để hiểu giáo trình của họ và truyền đạt lại cho học sinh của mình, phổ biến, chắt lọc kiến thức phù hợp với trình độ của các em, khơi gợi sự sáng tạo, tư duy cho các em.<br  />\r\nĐội tuyển của chúng tôi luôn đem lại vinh dự và niềm tự hào cho trường, bao nhiêu năm qua các em đoạt rất nhiểu giải cấp tỉnh. Có năm 15 em dự thi, 13 em đoạt giải, chưa bao giờ đội tuyển tiếng Anh chịu để trắng bảng. Đó cũng là tâm huyết của cô Liên, cô Vân, cô Hoà, thầy Hà. Các thầy cô đã không tiếc công tiếc sức cho đội tuyển của mình.<br  />\r\nSau này tổ chuyên môn của chúng tôi được bổ sung một số các thầy cô giáo trẻ. Họ thực sự đem lại niềm vui mới cho tổ chuyên môn. Cô Vũ Thu Giang, cô Lê Thị Trà Thuý, cô Bùi Thị Hạnh, cô Nguyễn Thị Vân Anh, cô Phạm Thị Huệ Linh, cô Trần Ngọc Thường, cô Nguyễn Thị Ngọc Anh là những cô giáo đầy nhiệt huyết, chúng tôi có cảm giác gánh nặng trên vai được san sẻ. Chúng tôi có dịp được học hỏi từ những bài giảng điện tử đầu tiên của cô Hạnh, tiết giảng bằng giáo án điện tử đầu tiên đó đã mở ra một sự thay đổi mới . Chúng tôi còn thấy mình cần phải biết sử dụng Công nghệ thông tin vào giảng dạy để có những giờ học thật sinh động, hấp dẫn.<br  />\r\nCác thầy cô trẻ cũng học được từ lớp các thầy cô dày kinh nghiệm nhiều phương pháp, kỹ năng khi đứng lớp. Cả tổ thực sự yêu thương, đoàn kết, giúp đỡ lẫn nhau trong cả chuyên môn lẫn trong cuộc sống. Trong cuộc sống hàng ngày thầy Nguyễn Đăng Phúc, cô Phạm Thị Hồng là những người luôn chu đáo tận tình với các thành viên trong tổ những khi có việc hiếu, hỉ, ốm đau.<br  />\r\nBộ sách mới phân ban chuẩn – nâng cao đã tạo điều kiện rất nhiều cho giáo viên chúng tôi được dạy theo bốn kỹ năng cơ bản nghe – nói - đọc - viết. Chúng tôi được sáng tạo, thiết kế bài giảng cho phù hợp với học sinh của mình,&nbsp; lấy học sinh là trung tâm. Các khoá học của hội đồng Anh của chương trình VTTN đã làm thực sự thay đổi việc giảng dạy tiếng Anh trong trường THPT. Đó thực sự là một luồng gió mới mát lành. Dạy theo phương pháp giao tiếp, các em học sinh của chúng tôi hào hứng đón nhận những giờ dạy hấp dẫn và sinh động. Các em thực sự được sáng tạo, được là trung tâm trong mỗi tiết học. Các hoạt động theo nhóm theo cặp giúp các em học sinh vốn nhút nhát trở nên tự tin và được chia sẻ.<br  />\r\nTrước đây khi mới bước chân vào nghề tôi chỉ hiểu đơn giản nếu chúng tôi hết lòng tận tụy với học sinh, tự học tự bồi dưỡng chuyên môn là đủ. Qua các cuộc tập huấn, tôi mới nghiệm ra rằng không phải vô cớ mà trong các cuộc tập huấn họ hướng dẫn cho chúng tôi từ classroom language (ngôn ngữ trong lớp) đến clear instrustions (hướng dẫn rõ ràng), motivation (tạo hứng thú trong giờ học)….<br  />\r\nViệc giảng dạy trong trường của chúng tôi ngày càng tốt đẹp vì chúng tôi được sự hỗ trợ của các phương tiện dạy học hiện đại. Nhà trường đã không tiếc công tiếc của để đầu tư thiết bị hiện đại nhất phục vụ giảng dạy và học tập, giờ dạy có hình ảnh, âm thanh hấp dẫn vô cùng…<br  />\r\nChúng tôi còn vui hơn khi nhận được những thông tin tốt đẹp từ phía các em học sinh của mình, tỉ lệ đỗ đại học của các lớp ban D rất cao. Rất nhiều học sinh của trường đã đỗ vào các trường đại học thuộc top đầu như: Đại học Quốc gia Hà Nội, Đại học Ngoại thương, Đại học Bách khoa…những trường mà trước đây rất ít học sinh của trường thi đỗ. Người vui hơn chúng tôi là cha mẹ các em. Họ đã đặt trọn niềm tin vào các thầy cô, gửi gắm con em mình cho nhà trường và họ hạnh phúc khi con em mình thành đạt. Mới đây có một em học sinh – trong số các em đỗ Đại học với điểm số rất cao đã gọi điện thoại cho tôi và nói: “ Cô ạ, khi em viết bài luận văn bằng tiếng Anh, em được điểm cao thứ hai trong cuộc thi và được xếp vào lớp ngoại ngữ thứ 6 của trung tâm ngoại ngữ Australia (lớp thứ 7 là lớp cao nhất của trung tâm). Họ hỏi em đã học tại trung tâm của người nước ngoài nào mà bài viết tiếng Anh rất tốt. Em nói chưa từng học ở đâu chỉ học thầy cô em ở trường THPT&nbsp; Hòn Gai thôi cô ạ..” Lời tâm sự của em học sinh làm tôi rất vui và nghĩ rằng chúng tôi đã góp một phần vào sự thành công của các em. Các em đã không phụ công dạy dỗ của mình.<br  />\r\nChặng đường ngần ấy năm chúng tôi đã cùng nhau đi qua, chúng tôi biết phía trước còn khó khăn, nhưng chúng tôi tin rằng chúng tôi sẽ vượt qua.', 'giới thiệu', 1, '4', '', 0, 5, 6, 1454381123, 1454381435, 1),
(6, 'Thành tích tổ Sử- Địa - GDCD năm 2015- 2016', 'Thanh-tich-to-Su-Dia-GDCD-nam-2015-2016', '', '', 'Thành tích kì thi học sinh giỏi tỉnh năm học 2015- 2016', 'Năm học 2015- 2015 , tổ Sử - Địa - GDCD đã đạt thành tích xuất sắc trong kì thi học sinh giỏi tỉnh. Với hơn 40 giải, chiếm gần 1/2 số giải toàn trường, tổ đã góp phần nâng cao thành tích của trường, đưa trường đứng vị trí số 2 trong tỉnh (Không kể trường Chuyên). Trong số có nhiều giải cao, nhất nhì, ba. Đặc biệt là môn Địa Lí với 2 học sinh đạt giải nhất. Hi vọng những năm kế tiếp thành tích của tổ sẽ lại ngày 1 cao hơn.', '', 1, '4', '', 0, 6, 9, 1454381338, 1454381338, 1),
(7, 'Tổ Thể Dục - Nhạc Họa', 'To-The-Duc-Nhac-Hoa', '616604_580892198720951_3403248310021076647_o.jpg', 'Tập Thể Tổ Thể Dục - Nhạc Họa', 'TỔ THỂ DỤC - NHẠC, HỌA<br /> 50 NĂM PHÁT TRIỂN VÀ TRƯỞNG THÀNH<br />(Nguyễn Thanh Hiền - Tổ trưởng)', 'Trải qua 50 năm, trường THPT Hòn Gai đã không ngừng phát triển và vươn tới tầm cao mới. Để có được ngày hôm nay không thể không kể đến 8 tổ chuyên môn của trường, trong đó có tổ Thể dục-Nhạc- Hoạ.<br  />\r\nLịch sử của tổ Thể dục gắn liền với bề dày 50 năm của nhà trường. Ngay từ những ngày mới khai sinh trường cấp 2-3 khu Hồng Quảng, nhóm Thể dục đã được thành lập với vẻn vẹn hai thầy giáo. Qua năm tháng phát triển với những thăng trầm, môn học Thể dục có thời kì được ghép với các môn: Sinh vật, Kĩ thuật Nông nghiệp. Đến nay tổ đã phát triển và trở thành tổ Thể dục - Nhạc- Họa với tổng số 9 thầy cô giáo. Ngoài công tác giảng dạy bộ môn Thể dục - Nhạc - Họa, tổ còn chịu trách nhiệm tổ chức dạy và học môn Giáo dục quốc phòng - An ninh. Nếu những ngày đầu, sân bãi, dụng cụ tập luyện còn rất đơn giản thì nay các phương tiện tập luyện đã trở nên khá chuyên nghiệp, cơ bản đã đáp ứng được yêu cầu dạy và học của bộ môn. Tin vui đến với các thầy cô giáo và các em học sinh cũng là món quà kỉ niệm&nbsp; 50 năm ngày thành lập trường là ngày 15/3/2010 nhà trường đã khánh thành và đi vào hoạt động một nhà tập đa năng hiện đại tạo điều kiện tốt cho việc thực hiện các yêu cầu chuyên môn.<br  />\r\nTổ Thể dục-Nhạc-Họa luôn là một tập thể trẻ và đoàn kết, các thành viên của tổ luôn hăng hái trong công tác chuyên môn cũng như đoàn thể, chung tay giúp sức cùng nhà trường đạt nhiều danh hiệu cao quý. Nhiều năm liền tổ đạt danh hiệu tổ lao động tiên tiến, góp phần đưa trường THPT Hòn Gai luôn là đơn vị tiên tiến xuất sắc trong lĩnh vực TDTT, được nhận cờ, bằng khen của Tỉnh, của Ủy ban TDTT Nhà nước… Những năm gần đây tổ luôn có từ 4 đến 6 đồng chí đạt danh hiệu giáo viên giỏi cấp tỉnh và cấp cơ sở. Như thầy giáo Nguyễn Công Đoàn, Nguyễn Thanh Hiền đã nhiều năm đạt danh hiệu chiến sĩ thi đua,&nbsp; giáo viên giỏi cấp tỉnh. Giáo viên giỏi cấp cơ sở có các thầy cô: Trần Văn Toàn, Phạm Thu Huyền, Phạm Thúy Lương, Nguyễn Bảo Chi. Các thầy cô trẻ luôn hăng say phấn đấu vì sự nghiệp giáo dục chung, đó là cô: Nguyễn Ánh Tuyết, Vũ Thị Thu Hường và thầy Đoàn Quân Hùng. Cũng từ đây biết bao thế hệ thầy giáo đã trưởng thành như: thầy Nguyễn Hoàng Quân hiện là chuyên viên Sở Giáo dục và Đào tạo, thầy Bùi Đức Đoàn trưởng phòng Thể thao Văn hóa Thông tin thành phố…tổ hiện có 4 cô giáo nguyên là học sinh cũ của trường .<br  />\r\nBên cạnh những danh hiệu cao quý ấy, tổ Thể dục-Nhạc- Họa còn là một tổ chuyên môn có bề dày truyền thống trong công tác giáo dục thể chất, đóng góp một phần công sức chung vào mục tiêu giáo dục con người toàn diện. Ngoài công tác giảng dạy bộ môn, tổ còn có một trách nhiệm không nhỏ đó là: Phát hiện và bồi dưỡng nhân tài TDTT. Có thể nói trong mỗi giai đoạn lịch sử của nhà trường, cùng với những vẻ vang chung thì tổ Thể dục luôn tự hào về những thế hệ học trò đã làm rạng danh cho mái trường, cho Tỉnh và cho đất nước. Đã có không ít những tài năng trong lĩnh vực TDTT được cả nước biết đến, đó là các danh thủ bóng đá nổi tiếng một thời như Nguyễn Trọng Giáp, Nguyễn Đình Hùng A, Nguyễn Đình Hùng B...cuối những năm 70 đầu 80 của thế kỉ trước. Hay các vận động viên (VĐV) Điền kinh từng đạt danh hiệu cấp kiện tướng, nhiều năm liền độc tôn trên đường chạy những năm 80 - 90 như: Nguyễn Thị Vinh, Vũ Thị Hoa, Nguyễn Thị Dung, Vũ Thị Tươi, Đỗ Thị Diệp... Trong giai đoạn mới này có các VĐV như: Trần Thị Hiền tay công không thể thay thế trong đội hình tuyển bóng chuyền nữ Quốc gia. Năm học 2002-2003 có em: Cao Văn Hoàng lập kỉ lục Tỉnh môn đẩy tạ, giành&nbsp; Huy chương vàng (HCV) tại giải Điền kinh học sinh toàn quốc tháng 8/ 2003. Em Trần Thị Thanh Thương (2007-2009) với các thành tích: huy chương Bạc tại giải Điền kinh học sinh Đông Nam Á và 1 HCV, 1 HCĐ tại HKPĐ toàn quốc lần thứ VII... Trong lĩnh vực Âm nhạc không thể không nhắc đến các ca sĩ lừng danh như: cố nghệ sĩ Nhân dân Lê Dung, nữ ca sĩ Hồ Quỳnh Hương hay nam ca sĩ Tuấn Anh... những người con từng lớn lên dưới mái trường THPT Hòn Gai.<br  />\r\nCó thể nói rằng trường THPT Hòn Gai luôn là ngọn cờ đầu của ngành giáo dục trong lĩnh vực giáo dục thể chất. Thầy cô trong tổ bộ môn luôn là những nhân tố chính cho việc tổ chức các hoạt động ngoại khoá của nhà trường, của thành phố và của tỉnh nhà trong các ngày hội thể thao, những ngày lễ lớn ...<br  />\r\nCòn rất nhiều những thành tích đáng tự hào mà các thế hệ thầy trò nhà trường đã đạt được trong những năm qua. Dù không thể kể hết song chúng tôi tin rằng những thành tích đó mãi mãi là niềm vinh dự, là những kỉ niệm đẹp trong tâm trí các thế hệ thầy cô và học trò trường THPT Hòn Gai nói chung và tổ Thể dục – Nhạc, Họa nói riêng. Ngày nay, trong điều kiện đất nước còn khó khăn, môn học, ngành học chưa thật sự chiếm được cảm tình của đa số người dân thì việc phát huy những truyền thống quý báu mà các thế hệ đàn anh đi trước quả không dễ dàng gì. Tuy nhiên với trách nhiệm của những người thầy đã và đang làm công tác Giáo dục thể chất ở trường THPT Hòn Gai, các thành viên tổ Thể dục – Nhạc, Họa vẫn luôn tâm huyết với nghề, với con đường mà mình đã chọn, quyết tâm thực hiện theo đúng phương châm: <strong><em>“TDTT trường học không chỉ là phương tiện nâng cao sức khỏe, phát triển thể chất mà còn góp phần rèn luyện nhân cách, đạo đức, ý chí, kỉ luật và lối sống lành mạnh cho thế hệ học sinh, sinh viên Việt Nam”.</em></strong><br  />\r\n<em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</em><br  />\r\n<img alt="" height="188" src="file:///C:\\Users\\TVC\\AppData\\Local\\Temp\\msohtml1\\01\\clip_image002.jpg" width="294" /><br  />\r\nNguyễn Thị Vinh, giải nhất Marathon quốc gia năm 1993.<br  />\r\n<img alt="" height="218" src="file:///C:\\Users\\TVC\\AppData\\Local\\Temp\\msohtml1\\01\\clip_image004.jpg" width="324" /><br  />\r\n<strong>Vũ Thị Hoa, vận động viên cấp kiện tướng, giải nhất Marathon toàn quốc.</strong><br  />\r\n<img alt="" height="221" src="file:///C:\\Users\\TVC\\AppData\\Local\\Temp\\msohtml1\\01\\clip_image006.jpg" width="329" /><br  />\r\n&nbsp;&nbsp; Em Cao Văn&nbsp; Hoàng (đứng giữa) lập kỷ lục Tỉnh môn đẩy tạ, giành huy chương Vàng (HCV) tại giải Điền kinh học sinh Toàn quốc tháng 8 - 2004.\r\n<div style="clear:both;">&nbsp;</div>', 'thể dục', 1, '4', '', 0, 7, 7, 1454381431, 1454381506, 1);
INSERT INTO `pacorp_vi_about` (`id`, `title`, `alias`, `image`, `imagealt`, `description`, `bodytext`, `keywords`, `socialbutton`, `activecomm`, `layout_func`, `gid`, `weight`, `admin_id`, `add_time`, `edit_time`, `status`) VALUES
(8, 'Tổ Sử Địa GDCD 50 năm một chặng đường', 'To-Su-Dia-GDCD-50-nam-mot-chang-duong', 'to-sdgdcd.jpg', 'Tập thể tổ Sử địa GDCD trường THPT Hòn Gai năm 2010', '', 'Nhìn lại chặng đường 50 năm xây dựng và trưởng thành của tổ Sử - Địa - Giáo dục công dân, chúng tôi rất tự hào với những thành tích mà tổ đã đạt được và biết ơn các thế hệ thầy cô giáo đã tạo dựng nên những truyền thống của tổ sau này.<br  />\r\nKhi mới thành lập, tổ mang tên là tổ Xã hội (1959 - 1970), sau đổi thành tổ Sử - Địa – Chính trị (1971 – 1985), từ năm 1985 đến nay là: Tổ Sử - Địa - Giáo dục công dân ( tổ ghép của 3 bộ môn: Lịch sử, Địa lý, Giáo dục công dân).<br  />\r\nNhững thầy cô là lớp người đi trước đặt nền móng cho tổ: Cô Nguyễn Thị Thận, thầy Trần Quang Bàn, thầy Nguyễn Bá Quát, thầy Đặng Văn Luyến, thầy Nguyễn Đỗ Lục, thầy Nguyễn Kiên, cô Vi Thị Hải Ngọc. Tổ chính là một cái nôi cung cấp rất nhiều cán bộ cho tỉnh và ngành như:&nbsp;<br  />\r\nCô giáo Nguyễn Thị Thận (Hiệu trưởng nhà trường từ năm 1959 đến năm 1961), thầy Trần Quang Bàn (Hiệu trưởng nhà trường từ năm 1961 đến năm 1962), thầy Hoàng Nga (Phó Hiệu trưởng nhà trường từ năm 1974 đến năm 1978), thầy Vũ Huy Tường (Phó Hiệu trưởng nhà trường từ 1976 đến 1988), thầy Nguyễn Kiên cán bộ Ban Tuyên Giáo tỉnh Quảng Ninh, cô Đào Thị Hảo (Phó Hiệu trưởng nhà trường từ 1980 đến năm 1985), cô Trịnh Thị Tính (Chủ tịch Hội Liên hiệp phụ nữ Tỉnh Quảng Ninh), thầy Nguyễn Thanh Hiễn ( hiện là phó giám đốc Sở GD - ĐT Quảng Ninh), thầy Nguyễn Ngọc Lưu (phó hiệu trưởng trường THPT Vũ Văn Hiếu nay đã nghỉ hưu), cô giáo Nguyễn Thị Hoa ( Hiệu phó trường Chuyên Hạ Long), thầy Hà Duy Thành ( Phòng Tổ chức Cán bộ Sở GD - ĐT Quảng Ninh), thầy Nguyễn Minh Tân (hiện là chuyên viên của Sở GD - ĐT Quảng Ninh). Các thầy, các cô đã làm rạng rỡ cho tổ Sử - Địa - Giáo dục công dân.<br  />\r\n&nbsp;Khi tôi mới về nhận công tác ở trường, tổ Sử - Địa - Giáo dục công dân do cô Lê Thị Ninh làm tổ trưởng (1979 - 1986), sau là thầy Nguyễn Ngọc Lưu (1986 - 1990), cô Đỗ Thị Hồng (1994-1996), từ 1996 đến 2004 cô Ninh lại tiếp tục lãnh đạo tổ. Các thầy cô đã xây dựng được khối đoàn kết nhất trí, tinh thần cộng đồng trách nhiệm, thương yêu giúp đỡ nhau trong công việc cũng như trong cuộc sống. Các thầy cô có bề dày chuyên môn như: Cô Nguyễn Thị Sánh, cô Đỗ Thị Hồng, cô Lê Thị Ninh, thầy Nguyễn Ngọc Lưu, thầy Nguyễn Minh Tân,...luôn là những tấm gương tận tuỵ trong giảng dạy, có nhiều đóng góp trong việc xây dựng tổ đạt danh hiệu Tổ Lao Động Xã hội chủ nghĩa. Các thầy cô luôn là những tấm gương mẫu mực trong chuyên môn, có nhiều kinh nghiệm trong giảng dạy, nhiệt tình hướng dẫn cho thế hệ chúng tôi mỗi khi có giám định giáo viên giỏi các cấp; các thầy cô chính là những nòng cốt trong sinh hoạt Công đoàn của tổ, truyền đạt kinh nghiệm nuôi dạy con ngoan, nữ công gia chánh giỏi cho những giáo viên trẻ mới ra trường. Tổ đã có 3 thầy đạt danh hiệu Chiến sĩ thi đua (thầy Hoàng Nga, thầy Vũ Huy Tường, thầy Nguyễn Ngọc Lưu), 14 thầy cô đạt danh hiệu giáo viên dạy giỏi. Tổ 2 lần đạt danh hiệu Tổ Lao Động Xã hội chủ nghĩa.<br  />\r\n&nbsp;Trong thời kì đổi mới, nhất là những năm 1997 đến 2004, tổ đạt nhiều thành tích trong ôn luyện thi học sinh giỏi: Tổng số giải học sinh giỏi cấp Tỉnh trong 7 năm học đạt: 47 giải (môn Sử, Địa) và 6 giải học sinh giỏi cấp Quốc gia ( môn Lịch sử).<br  />\r\n&nbsp;Từ năm 2004 đến nay, cơ cấu tổ chức của tổ Sử - Địa - Giáo dục công dân đã có nhiều thay đổi. Lớp người giàu kinh nghiệm giảng dạy đã lần lượt nghỉ hưu như: Cô Lê Thị Ninh, cô Nguyễn Thị Sánh, cô Vũ Thuý Quỳnh, cô Phạm Thị Luận; cô Lê Thị Bích chuyển công tác về nhà xuất bản ĐHSP Hà Nội; thầy Nguyễn Đức Quế chuyển công tác về trường Cao đẳng sư phạm Uông Bí. Tổ lại đón nhận một loạt các thầy cô mới: Cô Đặng Thị Hải, cô Đặng Thị Quyên (dạy địa); cô Phạm Hồng Hạnh, cô Vũ Bảo Yến (dạy sử); cô Nguyễn Quỳnh Trang, cô Phạm Lệ Quyên (dạy GDCD). Các cô giáo mới về tổ là những người yêu nghề, thành thạo công nghệ thông tin, có định hướng phấn đấu chuyên môn rõ rệt.<br  />\r\n&nbsp;Noi gương các thế hệ thầy cô đi trước, phát huy những truyền thống của tổ - một tổ đã đạt nhiều thành tích trong ôn luyện thi học sinh giỏi, trách nhiệm của chúng tôi phải duy trì được những thành tựu đó. Trước những yêu cầu đổi mới về phương pháp dạy học của ngành, đặc biệt trường xây dựng mô hình mới “ Cung ứng dịch vụ chất lượng giáo dục cao”, mỗi thành viên trong tổ từ chị cả như cô Phạm Hồng Cúc, đến em út của tổ Vũ Thị Bảo Yến, tất cả chúng tôi đều sử dụng thành thạo công nghệ thông tin phục vụ có hiệu quả cho giảng dạy. Nguyên tắc làm việc của tổ là: Dân chủ, bình đẳng, có tổ chức - kỷ luật. Với tâm huyết nghề nghiệp và tiếp thu những kinh nghiệm giảng dạy của các bậc tiền bối, tổ vẫn duy trì được thành tích ôn luyện thi học sinh giỏi. Từ năm 2004 - 2010: tổ đã có 53 em đạt giải học sinh giỏi cấp Tỉnh (môn lịch sử và môn địa lý); 3 em đạt giải học sinh giỏi cấp Quốc gia (môn lịch sử)<br  />\r\nTổ liên tục đạt danh hiệu tổ lao động xuất sắc, được Bộ Giáo dục, được Tỉnh, Sở giáo dục Quảng Ninh cấp giấy khen. Đặc biệt ngày 1-12-2009, tổ được Ban Chấp hành Đảng bộ thành phố Hạ Long tặng giấy khen: Tổ có thành tích tiêu biểu trong <em>“Học tập và làm theo tấm gương đạo đức Hồ Chí Minh”. </em><br  />\r\n&nbsp;&nbsp; Năm thập kỉ đã đi qua, tổ Sử - Địa - Giáo dục công dân đã không ngừng trưởng thành cùng với sự đi lên của Nhà trường. Hướng tới kỷ niệm 50 năm ngày thành lập trường THPT Hòn Gai, các thế hệ thầy cô giáo của tổ Sử - Địa - Giáo dục công dân đều rất phấn khởi, tự hào vì những gì mình đã làm được cho sự nghiệp 50 năm nở hoa trồng người của Nhà trường. Chúng tôi sẽ tiếp tục tích luỹ nhiều hơn nữa những kinh nghiệm trong giảng dạy, xây dựng một đội ngũ vững vàng về chuyên môn, nghiệp vụ và phẩm chất chính trị để xứng đáng là giáo viên trường THPT Hòn Gai.\r\n<div style="clear:both;">&nbsp;</div>', 'năm một', 1, '4', '', 0, 8, 11, 1454382332, 1454384128, 1),
(9, 'giới thiệu về Tổ Văn', 'gioi-thieu-ve-To-Van', 'to-van.jpg', 'Tổ Văn 2010', '', '<strong><em>“... Giáo viên là nhân tố quyết định chất lượng của giáo dục và được xã hội tôn vinh...”</em></strong><br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Trích nghị quyết II BCH Trung ương Đảng)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br  />\r\n&nbsp;<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>TỔ VĂN</strong><strong>- MỘT CHẶNG ĐƯỜNG</strong><br  />\r\n<em>(Nguyễn Minh Dân - Tổ trưởng)</em><br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 50 năm một chặng đường dài, năm mươi năm nhịp cùng thời gian làm nên một bề dày truyền thống. Năm mươi năm với biết bao gương mặt, biết bao thế hệ các thầy cô giáo của tổ Văn miệt mài, cần mẫn với những chuyến đò, lặng lẽ ươm cho đời những mầm xanh hữu ích. Năm mươi năm- đó cũng là dịp để ta nhìn lại, tự hào, tiếp nối!<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tổ Văn tự hào bởi các bậc tiền bối xứng đáng là những cây cao bóng cả, góp phần làm nên bề dày truyền thống của nhà trường. Trên mỗi chặng hành trình phát triển đi lên của trường cấp 2-3 Hồng Quảng xưa, nay là THPT Hòn Gai, đều ghi dấu những gương mặt thầy cô giáo dạy Văn đã để lại những ấn tượng đẹp trong lòng các thế hệ học trò. Nhớ khi xưa&nbsp; thầy Trần Tăng Bí với những bài giảng rất hay về Lí luận văn học; như vẫn còn đây thầy Nguyễn Thanh Dân thâm trầm, sâu sắc, rất giỏi về Hán-Nôm. Thầy Nguyễn Đình Sô – một tâm hồn nghệ sĩ, vừa có thơ hay lại vừa có lời giảng mượt mà, truyền cảm; thầy&nbsp; Lê Tuấn Đãng hóm hỉnh mà tài hoa. Cô Đào Thị Minh say sưa, đầy cuốn hút; cô Trần Thị Quế với lời giảng điềm tĩnh như kể, như bình mà giàu sức thuyết phục; cô Giang Thị Báu lãng mạn mà tinh tế; cô Hoàng Thị Thanh lời giảng nhẹ nhàng, dí dỏm mà sâu lắng; cô Nguyễn Thị Sự, cô Đinh Thị Quý, cô Nguyễn Thị Quy say sưa, miệt mài; cô Vũ Chi Ngân tươi tắn, luôn truyền được sự trẻ trung, sôi nổi qua mỗi lời giảng; cô Lê Bích Hồng lời giảng chau chuốt, mượt mà, bay bổng; cô giáo Lê Minh Hiền, cô giáo Nguyễn Thị Phương, những hoa khôi một thời của tổ Văn, sôi nổi và đầy nhiệt huyết luôn được học sinh mến mộ…<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cũng từ lòng yêu nghề ấy, thầy giáo Nguyễn Đình Sô, nguyên là tổ trưởng tổ Văn đã từng nói vui:<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Dạy văn: “vặn dậy” tâm linh</em><br  />\r\n<em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cho đời thêm đẹp, thấy&nbsp; mình yêu hơn!</em><br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Thật tâm huyết mà thấm thía! Lòng yêu nghề, say nghề của các thầy cô đã chắp cánh cho lời giảng, truyền sức nóng cho tâm hồn học trò yêu văn chương, để rồi từ mái trường này đã xuất hiện những gương mặt học trò xưa nay đã thành danh trên khắp mọi miền đất nước. Đó là nhà văn Nguyễn Khắc Phục- thế hệ học sinh khóa đầu tiên của trường, nhà báo Nguyễn Viết Khai- nguyên tổng biên tập báo Quảng Ninh, thầy giáo Trương Quốc Trung- chuyên viên cao cấp, nguyên Trưởng phòng Giáo dục trung hoc Sở Giáo dục- Đào tạo Quảng Ninh, tiến sĩ Văn học Lê Thị Bích Hồng- Phó vụ trưởng Vụ Văn hóa- Văn nghệ ban Tuyên giáo Trung ương...<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Noi gương các thế hệ thầy cô đi trước, tổ Văn hôm nay đang vững bước trưởng thành với những gương mặt phần đông còn rất trẻ, năng động, linh hoạt và nhạy bén với sự đổi mới, tiếp tục đào tạo những thế hệ học trò yêu văn chương, những công dân có ích cho xã hội. Đội tuyển HSG Văn của trường đã nhiều năm liền có học sinh đạt giải Tỉnh, trong đó có học sinh đã tham gia đội tuyển HSG Quốc gia.Thật cảm động khi có những em học sinh yêu quý môn Văn và thầy cô dạy mình đã quyết tâm thi đỗ vào Đại học sư phạm để được tiếp nối sự nghiệp của thầy cô. Đó là các em học sinh khóa 45 (lớp cô Thu Hạnh chủ nhiệm): Nguyễn Thị Loan A- thạc sĩ Ngữ văn, Nguyễn Thị Loan B hiện đang theo học Cao học tại Đại học sư phạm I Hà Nội, Nguyễn Thanh Thủy- giáo viên THPT. Đó còn là em Bùi Kim Oanh, học sinh khóa 49 (lớp cô Nguyễn Hồng chủ nhiệm), giải Nhì môn Văn cấp Tỉnh năm học 2009-2010, luôn quyết tâm giành điểm cao trong các kì thi để làm vui lòng thầy cô và đã thi đỗ vào ĐH Sư phạm I Hà Nội với số điểm là 24,5…Đặc biệt, những năm gần đây có những học sinh giỏi Văn của trường đã thi đỗ Đại học đạt vị trí thủ khoa, á khoa: em Bùi Thị Minh Ngọc- thủ khoa Đại học KHXH &amp; NV năm 2008, em Trần Anh Phương á khoa Đại học KHXH &amp; NV năm 2009… Đó cũng là món quà vô giá, là động lực để thế hệ các thầy cô giáo tổ Văn hôm nay tăng thêm nhiệt huyết với nghề, yêu nghề, yêu người hơn.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Theo thời gian năm tháng, tổ Văn đã đi qua chiều dài của thời gian vô tận, chiều rộng của cuộc sống mỗi ngày, chiều cao của cống hiến tri thức, khát vọng, chiều sâu của lòng người, tình người. Nửa thế kỉ đã trôi qua, thấm đẫm một trang văn, trang đời. Tổ Văn- một đại gia đình văn chương, thế hệ này nối tiếp thế hệ kia như “<strong><em>tứ đại đồng đường</em></strong>”. Ôn cũ, nhớ xưa, thấy nay để hướng tới tương lai!<br  />\r\n&nbsp;', 'giới thiệu', 1, '4', '', 0, 9, 10, 1454383059, 1454383059, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_about_config`
--

CREATE TABLE `pacorp_vi_about_config` (
  `config_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_about_config`
--

INSERT INTO `pacorp_vi_about_config` (`config_name`, `config_value`) VALUES
('viewtype', '0'),
('facebookapi', ''),
('per_page', '20'),
('news_first', '0'),
('related_articles', '5');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_blocks_groups`
--

CREATE TABLE `pacorp_vi_blocks_groups` (
  `bid` mediumint(8) UNSIGNED NOT NULL,
  `theme` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `act` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `groups_view` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text COLLATE utf8mb4_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_blocks_groups`
--

INSERT INTO `pacorp_vi_blocks_groups` (`bid`, `theme`, `module`, `file_name`, `title`, `link`, `template`, `position`, `exp_time`, `active`, `act`, `groups_view`, `all_func`, `weight`, `config`) VALUES
(1, 'default', 'news', 'module.block_newscenter.php', 'Tin mới nhất', '', 'no_title', '[TOP]', 0, '1', 1, '6', 0, 1, 'a:9:{s:6:"numrow";i:6;s:11:"showtooltip";i:1;s:16:"tooltip_position";s:6:"bottom";s:14:"tooltip_length";s:3:"150";s:12:"length_title";i:400;s:15:"length_hometext";i:0;s:5:"width";i:500;s:6:"height";i:0;s:7:"nocatid";a:0:{}}'),
(3, 'default', 'news', 'global.block_category.php', 'Chủ đề', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 1, 'a:2:{s:5:"catid";i:0;s:12:"title_length";i:25;}'),
(4, 'default', 'theme', 'global.module_menu.php', 'Module Menu', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 2, ''),
(6, 'default', 'statistics', 'global.counter.php', 'Thống kê truy cập', '', 'primary', '[LEFT]', 0, '1', 1, '6', 1, 5, ''),
(8, 'default', 'xep-hang-thi-dua', 'global.xephang.php', 'Xếp hạng thi đua', '', 'no_title', '[RIGHT]', 0, '1', 1, '6', 1, 1, ''),
(10, 'default', 'news', 'global.block_tophits.php', 'Tin xem nhiều', '', '', '[RIGHT]', 0, '1', 1, '6', 1, 2, 'a:6:{s:10:"number_day";i:3650;s:6:"numrow";i:10;s:11:"showtooltip";i:1;s:16:"tooltip_position";s:6:"bottom";s:14:"tooltip_length";s:3:"150";s:7:"nocatid";a:2:{i:0;i:10;i:1;i:11;}}'),
(11, 'default', 'theme', 'global.copyright.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 1, 'a:5:{s:12:"copyright_by";s:0:"";s:13:"copyright_url";s:0:"";s:9:"design_by";s:12:"VINADES.,JSC";s:10:"design_url";s:18:"http://vinades.vn/";s:13:"siteterms_url";s:39:"/index.php?language=vi&amp;nv=siteterms";}'),
(12, 'default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 2, ''),
(15, 'default', 'users', 'global.user_button.php', 'Đăng nhập thành viên', '', 'no_title', '[PERSONALAREA]', 0, '1', 1, '6', 1, 1, ''),
(16, 'default', 'theme', 'global.company_info.php', 'CÔNG TY TNHH PACORP', '', 'simple', '[COMPANY_INFO]', 0, '1', 1, '6', 1, 1, 'a:17:{s:12:"company_name";s:0:"";s:16:"company_sortname";s:0:"";s:15:"company_regcode";s:0:"";s:16:"company_regplace";s:0:"";s:21:"company_licensenumber";s:0:"";s:22:"company_responsibility";s:0:"";s:15:"company_address";s:57:"124/6/12, Võ Văn Hát, Long Trường, quận 9, TP.HCM";s:15:"company_showmap";i:1;s:20:"company_mapcenterlat";d:20.982196983985108573733668890781700611114501953125;s:20:"company_mapcenterlng";d:105.8029476343177748276502825319766998291015625;s:14:"company_maplat";d:20.9845159999999992805896908976137638092041015625;s:14:"company_maplng";d:105.7954750000000103682396002113819122314453125;s:15:"company_mapzoom";i:15;s:13:"company_phone";s:12:"0904.9999.55";s:11:"company_fax";s:0:"";s:13:"company_email";s:17:"contact@pacorp.vn";s:15:"company_website";s:16:"http://pacorp.vn";}'),
(37, 'default', 'menu', 'global.slimmenu.php', 'Thông tin chung', '', 'simple', '[BLOCK_FOOTER1]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:"menuid";i:3;s:12:"title_length";i:40;}'),
(32, 'default', 'support', 'global.support.php', 'Hỗ trợ trực tuyến', '', '', '[LEFT]', 0, '1', 1, '6', 1, 4, 'a:2:{s:6:"menuid";i:1;s:12:"title_length";i:20;}'),
(17, 'default', 'menu', 'global.bootstrap.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:"menuid";i:1;s:12:"title_length";i:0;}'),
(18, 'default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[CONTACT_DEFAULT]', 0, '1', 1, '6', 1, 1, ''),
(19, 'default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[FOOTER SOTIONS]', 0, '1', 1, '6', 1, 1, 'a:4:{s:8:"facebook";s:32:"http://www.facebook.com/nukeviet";s:11:"google_plus";s:32:"https://www.google.com/+nukeviet";s:7:"youtube";s:37:"https://www.youtube.com/user/nukeviet";s:7:"twitter";s:28:"https://twitter.com/nukeviet";}'),
(20, 'default', 'theme', 'global.menu_footer.php', 'Các chuyên mục chính', '', 'simple', '[MENU_FOOTER]', 0, '1', 1, '6', 1, 1, 'a:1:{s:14:"module_in_menu";a:8:{i:0;s:5:"about";i:1;s:4:"news";i:2;s:5:"users";i:3;s:7:"contact";i:4;s:6:"voting";i:5;s:7:"banners";i:6;s:4:"seek";i:7;s:5:"feeds";}}'),
(22, 'mobile_default', 'menu', 'global.metismenu.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:"menuid";i:1;s:12:"title_length";i:0;}'),
(23, 'mobile_default', 'users', 'global.user_button.php', 'Sign In', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 2, ''),
(24, 'mobile_default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 1, ''),
(25, 'mobile_default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 2, ''),
(26, 'mobile_default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 3, 'a:4:{s:8:"facebook";s:32:"http://www.facebook.com/nukeviet";s:11:"google_plus";s:32:"https://www.google.com/+nukeviet";s:7:"youtube";s:37:"https://www.youtube.com/user/nukeviet";s:7:"twitter";s:28:"https://twitter.com/nukeviet";}'),
(27, 'mobile_default', 'theme', 'global.QR_code.php', 'QR code', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 4, 'a:3:{s:5:"level";s:1:"L";s:15:"pixel_per_point";i:4;s:11:"outer_frame";i:1;}'),
(28, 'mobile_default', 'theme', 'global.copyright.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 1, 'a:5:{s:12:"copyright_by";s:0:"";s:13:"copyright_url";s:0:"";s:9:"design_by";s:12:"VINADES.,JSC";s:10:"design_url";s:18:"http://vinades.vn/";s:13:"siteterms_url";s:35:"/index.php?language=vi&nv=siteterms";}'),
(29, 'mobile_default', 'theme', 'global.menu_footer.php', 'Các chuyên mục chính', '', 'primary', '[MENU_FOOTER]', 0, '1', 1, '6', 1, 1, 'a:1:{s:14:"module_in_menu";a:9:{i:0;s:5:"about";i:1;s:4:"news";i:2;s:5:"users";i:3;s:7:"contact";i:4;s:6:"voting";i:5;s:7:"banners";i:6;s:4:"seek";i:7;s:5:"feeds";i:8;s:9:"siteterms";}}'),
(30, 'mobile_default', 'theme', 'global.company_info.php', 'Công ty chủ quản', '', 'primary', '[COMPANY_INFO]', 0, '1', 1, '6', 1, 1, 'a:17:{s:12:"company_name";s:58:"Công ty cổ phần phát triển nguồn mở Việt Nam";s:16:"company_sortname";s:12:"VINADES.,JSC";s:15:"company_regcode";s:0:"";s:16:"company_regplace";s:0:"";s:21:"company_licensenumber";s:0:"";s:22:"company_responsibility";s:0:"";s:15:"company_address";s:72:"Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội";s:15:"company_showmap";i:1;s:20:"company_mapcenterlat";d:20.9845159999999992805896908976137638092041015625;s:20:"company_mapcenterlng";d:105.7954749999999961573848850093781948089599609375;s:14:"company_maplat";d:20.9845159999999992805896908976137638092041015625;s:14:"company_maplng";d:105.7954750000000103682396002113819122314453125;s:15:"company_mapzoom";i:17;s:13:"company_phone";s:56:"+84-4-85872007[+84485872007]|+84-904762534[+84904762534]";s:11:"company_fax";s:14:"+84-4-35500914";s:13:"company_email";s:18:"contact@vinades.vn";s:15:"company_website";s:17:"http://vinades.vn";}'),
(33, 'default', 'laws', 'global.block_newlaws.php', 'Văn bản mới', '', '', '[LEFT]', 0, '1', 1, '6', 1, 3, 'a:2:{s:6:"numrow";i:10;s:6:"height";i:100;}'),
(35, 'default', 'theme', 'global.block_facebook_like_box.php', 'Mạng xã hội', '', '', '[RIGHT]', 0, '1', 1, '6', 1, 3, 'a:7:{s:3:"url";s:31:"https://www.facebook.com/PA.JSC";s:5:"width";i:280;s:6:"height";i:220;s:6:"scheme";s:5:"light";s:5:"faces";i:1;s:6:"stream";i:0;s:6:"header";i:1;}'),
(36, 'default', 'menu', 'global.slimmenu.php', 'Thành viên', '', 'simple', '[BLOCK_FOOTER3]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:"menuid";i:2;s:12:"title_length";i:30;}'),
(38, 'default', 'menu', 'global.slimmenu.php', 'Tiện ích website', '', 'simple', '[BLOCK_FOOTER2]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:"menuid";i:4;s:12:"title_length";i:30;}'),
(39, 'default', 'videos', 'global.block_groups.php', 'Video clip', '', '', '[LEFT]', 0, '1', 1, '6', 1, 6, 'a:5:{s:7:"blockid";i:1;s:6:"numrow";i:5;s:11:"showtooltip";i:1;s:16:"tooltip_position";s:6:"bottom";s:14:"tooltip_length";s:3:"150";}');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_blocks_weight`
--

CREATE TABLE `pacorp_vi_blocks_weight` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `func_id` mediumint(8) NOT NULL DEFAULT '0',
  `weight` mediumint(8) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_blocks_weight`
--

INSERT INTO `pacorp_vi_blocks_weight` (`bid`, `func_id`, `weight`) VALUES
(32, 26, 3),
(16, 36, 1),
(16, 37, 1),
(16, 38, 1),
(16, 39, 1),
(16, 45, 1),
(16, 46, 1),
(16, 47, 1),
(16, 48, 1),
(16, 55, 1),
(16, 58, 1),
(16, 4, 1),
(16, 5, 1),
(16, 6, 1),
(16, 7, 1),
(16, 8, 1),
(16, 9, 1),
(16, 10, 1),
(16, 11, 1),
(16, 12, 1),
(16, 49, 1),
(16, 57, 1),
(32, 25, 3),
(32, 24, 3),
(16, 29, 1),
(16, 30, 1),
(16, 31, 1),
(16, 32, 1),
(16, 33, 1),
(16, 34, 1),
(16, 35, 1),
(16, 18, 1),
(16, 19, 1),
(16, 20, 1),
(16, 21, 1),
(16, 22, 1),
(16, 23, 1),
(16, 24, 1),
(16, 25, 1),
(16, 26, 1),
(16, 27, 1),
(32, 23, 3),
(18, 1, 1),
(18, 36, 1),
(18, 37, 1),
(18, 38, 1),
(18, 39, 1),
(18, 45, 1),
(18, 46, 1),
(18, 47, 1),
(18, 48, 1),
(18, 55, 1),
(18, 58, 1),
(18, 4, 1),
(18, 5, 1),
(18, 6, 1),
(18, 7, 1),
(18, 8, 1),
(18, 9, 1),
(18, 10, 1),
(18, 11, 1),
(18, 12, 1),
(18, 49, 1),
(18, 57, 1),
(18, 52, 1),
(18, 53, 1),
(18, 29, 1),
(18, 30, 1),
(18, 31, 1),
(18, 32, 1),
(18, 33, 1),
(18, 34, 1),
(18, 35, 1),
(18, 18, 1),
(18, 19, 1),
(18, 20, 1),
(18, 21, 1),
(18, 22, 1),
(18, 23, 1),
(18, 24, 1),
(18, 25, 1),
(18, 26, 1),
(18, 27, 1),
(18, 56, 1),
(32, 128, 2),
(32, 127, 2),
(32, 72, 2),
(32, 74, 2),
(32, 73, 2),
(32, 69, 2),
(32, 71, 2),
(32, 70, 2),
(32, 66, 2),
(32, 59, 2),
(32, 64, 2),
(32, 60, 2),
(32, 48, 2),
(32, 47, 2),
(32, 46, 2),
(32, 45, 2),
(32, 49, 2),
(32, 58, 2),
(32, 57, 2),
(32, 39, 2),
(32, 38, 2),
(32, 37, 2),
(32, 36, 2),
(32, 35, 3),
(32, 34, 3),
(27, 128, 4),
(27, 127, 4),
(26, 128, 3),
(26, 127, 3),
(25, 128, 2),
(11, 1, 1),
(11, 36, 1),
(11, 37, 1),
(11, 38, 1),
(11, 39, 1),
(11, 45, 1),
(11, 46, 1),
(11, 47, 1),
(11, 48, 1),
(11, 55, 1),
(11, 58, 1),
(11, 4, 1),
(11, 5, 1),
(11, 6, 1),
(11, 7, 1),
(11, 8, 1),
(11, 9, 1),
(11, 10, 1),
(11, 11, 1),
(11, 12, 1),
(11, 49, 1),
(11, 57, 1),
(11, 52, 1),
(11, 53, 1),
(11, 29, 1),
(11, 30, 1),
(11, 31, 1),
(11, 32, 1),
(11, 33, 1),
(11, 34, 1),
(11, 35, 1),
(11, 18, 1),
(11, 19, 1),
(11, 20, 1),
(11, 21, 1),
(11, 22, 1),
(11, 23, 1),
(11, 24, 1),
(11, 25, 1),
(11, 26, 1),
(11, 27, 1),
(11, 56, 1),
(12, 1, 2),
(12, 36, 2),
(12, 37, 2),
(12, 38, 2),
(12, 39, 2),
(12, 45, 2),
(12, 46, 2),
(12, 47, 2),
(12, 48, 2),
(12, 55, 2),
(12, 58, 2),
(12, 4, 2),
(12, 5, 2),
(12, 6, 2),
(12, 7, 2),
(12, 8, 2),
(12, 9, 2),
(12, 10, 2),
(12, 11, 2),
(12, 12, 2),
(12, 49, 2),
(12, 57, 2),
(12, 52, 2),
(12, 53, 2),
(12, 29, 2),
(12, 30, 2),
(12, 31, 2),
(12, 32, 2),
(12, 33, 2),
(12, 34, 2),
(12, 35, 2),
(12, 18, 2),
(12, 19, 2),
(12, 20, 2),
(12, 21, 2),
(12, 22, 2),
(12, 23, 2),
(12, 24, 2),
(12, 25, 2),
(12, 26, 2),
(12, 27, 2),
(12, 56, 2),
(3, 4, 1),
(3, 5, 1),
(3, 6, 1),
(3, 7, 1),
(3, 8, 1),
(3, 9, 1),
(3, 10, 1),
(3, 11, 1),
(3, 12, 1),
(4, 18, 1),
(4, 19, 1),
(4, 20, 1),
(4, 21, 1),
(4, 22, 1),
(4, 23, 1),
(4, 24, 1),
(4, 25, 1),
(4, 26, 1),
(4, 27, 1),
(4, 29, 1),
(4, 30, 1),
(4, 31, 1),
(4, 32, 1),
(4, 33, 1),
(4, 34, 1),
(4, 35, 1),
(6, 1, 1),
(6, 36, 3),
(6, 37, 3),
(6, 38, 3),
(6, 39, 3),
(6, 45, 3),
(6, 46, 3),
(6, 47, 3),
(6, 48, 3),
(6, 55, 3),
(6, 58, 3),
(6, 4, 5),
(6, 5, 4),
(6, 6, 4),
(6, 7, 4),
(6, 8, 4),
(6, 9, 4),
(6, 10, 4),
(6, 11, 4),
(6, 12, 4),
(6, 49, 3),
(6, 57, 3),
(6, 52, 1),
(6, 53, 1),
(6, 29, 4),
(6, 30, 4),
(6, 31, 4),
(6, 32, 4),
(6, 33, 4),
(6, 34, 4),
(6, 35, 4),
(6, 18, 4),
(6, 19, 4),
(6, 20, 4),
(6, 21, 4),
(6, 22, 4),
(6, 23, 4),
(6, 24, 4),
(6, 25, 4),
(6, 26, 4),
(6, 27, 4),
(6, 56, 1),
(20, 1, 1),
(20, 36, 1),
(20, 37, 1),
(20, 38, 1),
(20, 39, 1),
(20, 45, 1),
(20, 46, 1),
(20, 47, 1),
(20, 48, 1),
(20, 55, 1),
(20, 58, 1),
(20, 4, 1),
(20, 5, 1),
(20, 6, 1),
(20, 7, 1),
(20, 8, 1),
(20, 9, 1),
(20, 10, 1),
(20, 11, 1),
(20, 12, 1),
(20, 49, 1),
(20, 57, 1),
(20, 52, 1),
(20, 53, 1),
(20, 29, 1),
(20, 30, 1),
(20, 31, 1),
(20, 32, 1),
(20, 33, 1),
(20, 34, 1),
(20, 35, 1),
(20, 18, 1),
(20, 19, 1),
(20, 20, 1),
(20, 21, 1),
(20, 22, 1),
(20, 23, 1),
(20, 24, 1),
(20, 25, 1),
(20, 26, 1),
(20, 27, 1),
(20, 56, 1),
(17, 1, 1),
(17, 36, 1),
(17, 37, 1),
(17, 38, 1),
(17, 39, 1),
(17, 45, 1),
(17, 46, 1),
(17, 47, 1),
(17, 48, 1),
(17, 55, 1),
(17, 58, 1),
(17, 4, 1),
(17, 5, 1),
(17, 6, 1),
(17, 7, 1),
(17, 8, 1),
(17, 9, 1),
(17, 10, 1),
(17, 11, 1),
(17, 12, 1),
(17, 49, 1),
(17, 57, 1),
(17, 52, 1),
(17, 53, 1),
(17, 29, 1),
(17, 30, 1),
(17, 31, 1),
(17, 32, 1),
(17, 33, 1),
(17, 34, 1),
(17, 35, 1),
(17, 18, 1),
(17, 19, 1),
(17, 20, 1),
(17, 21, 1),
(17, 22, 1),
(17, 23, 1),
(17, 24, 1),
(17, 25, 1),
(17, 26, 1),
(17, 27, 1),
(17, 56, 1),
(15, 1, 1),
(15, 36, 1),
(15, 37, 1),
(15, 38, 1),
(15, 39, 1),
(15, 45, 1),
(15, 46, 1),
(15, 47, 1),
(15, 48, 1),
(15, 55, 1),
(15, 58, 1),
(15, 4, 1),
(15, 5, 1),
(15, 6, 1),
(15, 7, 1),
(15, 8, 1),
(15, 9, 1),
(15, 10, 1),
(15, 11, 1),
(15, 12, 1),
(15, 49, 1),
(15, 57, 1),
(15, 52, 1),
(15, 53, 1),
(15, 29, 1),
(15, 30, 1),
(15, 31, 1),
(15, 32, 1),
(15, 33, 1),
(15, 34, 1),
(15, 35, 1),
(15, 18, 1),
(15, 19, 1),
(15, 20, 1),
(15, 21, 1),
(15, 22, 1),
(15, 23, 1),
(15, 24, 1),
(15, 25, 1),
(15, 26, 1),
(15, 27, 1),
(15, 56, 1),
(27, 125, 4),
(27, 124, 4),
(26, 125, 3),
(26, 124, 3),
(25, 125, 2),
(25, 124, 2),
(24, 125, 1),
(24, 124, 1),
(23, 125, 2),
(32, 33, 3),
(8, 36, 1),
(8, 37, 1),
(8, 38, 1),
(8, 39, 1),
(8, 45, 1),
(8, 46, 1),
(8, 47, 1),
(8, 48, 1),
(8, 55, 1),
(8, 58, 1),
(8, 4, 1),
(8, 5, 1),
(8, 6, 1),
(8, 7, 1),
(8, 8, 1),
(8, 9, 1),
(8, 10, 1),
(8, 11, 1),
(8, 12, 1),
(8, 49, 1),
(8, 57, 1),
(32, 32, 3),
(32, 31, 3),
(8, 29, 1),
(8, 30, 1),
(8, 31, 1),
(8, 32, 1),
(8, 33, 1),
(8, 34, 1),
(8, 35, 1),
(8, 18, 1),
(8, 19, 1),
(8, 20, 1),
(8, 21, 1),
(8, 22, 1),
(8, 23, 1),
(8, 24, 1),
(8, 25, 1),
(8, 26, 1),
(8, 27, 1),
(32, 30, 3),
(39, 119, 4),
(10, 36, 2),
(10, 37, 2),
(10, 38, 2),
(10, 39, 2),
(10, 45, 2),
(10, 46, 2),
(10, 47, 2),
(10, 48, 2),
(10, 55, 2),
(10, 58, 2),
(10, 4, 2),
(10, 5, 2),
(10, 6, 2),
(10, 7, 2),
(10, 8, 2),
(10, 9, 2),
(10, 10, 2),
(10, 11, 2),
(10, 12, 2),
(10, 49, 2),
(10, 57, 2),
(39, 118, 4),
(39, 120, 4),
(10, 29, 2),
(10, 30, 2),
(10, 31, 2),
(10, 32, 2),
(10, 33, 2),
(10, 34, 2),
(10, 35, 2),
(10, 18, 2),
(10, 19, 2),
(10, 20, 2),
(10, 21, 2),
(10, 22, 2),
(10, 23, 2),
(10, 24, 2),
(10, 25, 2),
(10, 26, 2),
(10, 27, 2),
(39, 117, 4),
(19, 1, 1),
(19, 36, 1),
(19, 37, 1),
(19, 38, 1),
(19, 39, 1),
(19, 45, 1),
(19, 46, 1),
(19, 47, 1),
(19, 48, 1),
(19, 55, 1),
(19, 58, 1),
(19, 4, 1),
(19, 5, 1),
(19, 6, 1),
(19, 7, 1),
(19, 8, 1),
(19, 9, 1),
(19, 10, 1),
(19, 11, 1),
(19, 12, 1),
(19, 49, 1),
(19, 57, 1),
(19, 52, 1),
(19, 53, 1),
(19, 29, 1),
(19, 30, 1),
(19, 31, 1),
(19, 32, 1),
(19, 33, 1),
(19, 34, 1),
(19, 35, 1),
(19, 18, 1),
(19, 19, 1),
(19, 20, 1),
(19, 21, 1),
(19, 22, 1),
(19, 23, 1),
(19, 24, 1),
(19, 25, 1),
(19, 26, 1),
(19, 27, 1),
(19, 56, 1),
(1, 4, 1),
(30, 1, 1),
(30, 36, 1),
(30, 37, 1),
(30, 38, 1),
(30, 39, 1),
(30, 45, 1),
(30, 46, 1),
(30, 47, 1),
(30, 48, 1),
(30, 55, 1),
(30, 58, 1),
(30, 4, 1),
(30, 5, 1),
(30, 6, 1),
(30, 7, 1),
(30, 8, 1),
(30, 9, 1),
(30, 10, 1),
(30, 11, 1),
(30, 12, 1),
(30, 49, 1),
(30, 57, 1),
(30, 52, 1),
(30, 53, 1),
(30, 29, 1),
(30, 30, 1),
(30, 31, 1),
(30, 32, 1),
(30, 33, 1),
(30, 34, 1),
(30, 35, 1),
(30, 18, 1),
(30, 19, 1),
(30, 20, 1),
(30, 21, 1),
(30, 22, 1),
(30, 23, 1),
(30, 24, 1),
(30, 25, 1),
(30, 26, 1),
(30, 27, 1),
(30, 56, 1),
(28, 1, 1),
(28, 36, 1),
(28, 37, 1),
(28, 38, 1),
(28, 39, 1),
(28, 45, 1),
(28, 46, 1),
(28, 47, 1),
(28, 48, 1),
(28, 55, 1),
(28, 58, 1),
(28, 4, 1),
(28, 5, 1),
(28, 6, 1),
(28, 7, 1),
(28, 8, 1),
(28, 9, 1),
(28, 10, 1),
(28, 11, 1),
(28, 12, 1),
(28, 49, 1),
(28, 57, 1),
(28, 52, 1),
(28, 53, 1),
(28, 29, 1),
(28, 30, 1),
(28, 31, 1),
(28, 32, 1),
(28, 33, 1),
(28, 34, 1),
(28, 35, 1),
(28, 18, 1),
(28, 19, 1),
(28, 20, 1),
(28, 21, 1),
(28, 22, 1),
(28, 23, 1),
(28, 24, 1),
(28, 25, 1),
(28, 26, 1),
(28, 27, 1),
(28, 56, 1),
(29, 1, 1),
(29, 36, 1),
(29, 37, 1),
(29, 38, 1),
(29, 39, 1),
(29, 45, 1),
(29, 46, 1),
(29, 47, 1),
(29, 48, 1),
(29, 55, 1),
(29, 58, 1),
(29, 4, 1),
(29, 5, 1),
(29, 6, 1),
(29, 7, 1),
(29, 8, 1),
(29, 9, 1),
(29, 10, 1),
(29, 11, 1),
(29, 12, 1),
(29, 49, 1),
(29, 57, 1),
(29, 52, 1),
(29, 53, 1),
(29, 29, 1),
(29, 30, 1),
(29, 31, 1),
(29, 32, 1),
(29, 33, 1),
(29, 34, 1),
(29, 35, 1),
(29, 18, 1),
(29, 19, 1),
(29, 20, 1),
(29, 21, 1),
(29, 22, 1),
(29, 23, 1),
(29, 24, 1),
(29, 25, 1),
(29, 26, 1),
(29, 27, 1),
(29, 56, 1),
(22, 1, 1),
(22, 36, 1),
(22, 37, 1),
(22, 38, 1),
(22, 39, 1),
(22, 45, 1),
(22, 46, 1),
(22, 47, 1),
(22, 48, 1),
(22, 55, 1),
(22, 58, 1),
(22, 4, 1),
(22, 5, 1),
(22, 6, 1),
(22, 7, 1),
(22, 8, 1),
(22, 9, 1),
(22, 10, 1),
(22, 11, 1),
(22, 12, 1),
(22, 49, 1),
(22, 57, 1),
(22, 52, 1),
(22, 53, 1),
(22, 29, 1),
(22, 30, 1),
(22, 31, 1),
(22, 32, 1),
(22, 33, 1),
(22, 34, 1),
(22, 35, 1),
(22, 18, 1),
(22, 19, 1),
(22, 20, 1),
(22, 21, 1),
(22, 22, 1),
(22, 23, 1),
(22, 24, 1),
(22, 25, 1),
(22, 26, 1),
(22, 27, 1),
(22, 56, 1),
(23, 1, 2),
(23, 36, 2),
(23, 37, 2),
(23, 38, 2),
(23, 39, 2),
(23, 45, 2),
(23, 46, 2),
(23, 47, 2),
(23, 48, 2),
(23, 55, 2),
(23, 58, 2),
(23, 4, 2),
(23, 5, 2),
(23, 6, 2),
(23, 7, 2),
(23, 8, 2),
(23, 9, 2),
(23, 10, 2),
(23, 11, 2),
(23, 12, 2),
(23, 49, 2),
(23, 57, 2),
(23, 52, 2),
(23, 53, 2),
(23, 29, 2),
(23, 30, 2),
(23, 31, 2),
(23, 32, 2),
(23, 33, 2),
(23, 34, 2),
(23, 35, 2),
(23, 18, 2),
(23, 19, 2),
(23, 20, 2),
(23, 21, 2),
(23, 22, 2),
(23, 23, 2),
(23, 24, 2),
(23, 25, 2),
(23, 26, 2),
(23, 27, 2),
(23, 56, 2),
(24, 1, 1),
(24, 36, 1),
(24, 37, 1),
(24, 38, 1),
(24, 39, 1),
(24, 45, 1),
(24, 46, 1),
(24, 47, 1),
(24, 48, 1),
(24, 55, 1),
(24, 58, 1),
(24, 4, 1),
(24, 5, 1),
(24, 6, 1),
(24, 7, 1),
(24, 8, 1),
(24, 9, 1),
(24, 10, 1),
(24, 11, 1),
(24, 12, 1),
(24, 49, 1),
(24, 57, 1),
(24, 52, 1),
(24, 53, 1),
(24, 29, 1),
(24, 30, 1),
(24, 31, 1),
(24, 32, 1),
(24, 33, 1),
(24, 34, 1),
(24, 35, 1),
(24, 18, 1),
(24, 19, 1),
(24, 20, 1),
(24, 21, 1),
(24, 22, 1),
(24, 23, 1),
(24, 24, 1),
(24, 25, 1),
(24, 26, 1),
(24, 27, 1),
(24, 56, 1),
(25, 1, 2),
(25, 36, 2),
(25, 37, 2),
(25, 38, 2),
(25, 39, 2),
(25, 45, 2),
(25, 46, 2),
(25, 47, 2),
(25, 48, 2),
(25, 55, 2),
(25, 58, 2),
(25, 4, 2),
(25, 5, 2),
(25, 6, 2),
(25, 7, 2),
(25, 8, 2),
(25, 9, 2),
(25, 10, 2),
(25, 11, 2),
(25, 12, 2),
(25, 49, 2),
(25, 57, 2),
(25, 52, 2),
(25, 53, 2),
(25, 29, 2),
(25, 30, 2),
(25, 31, 2),
(25, 32, 2),
(25, 33, 2),
(25, 34, 2),
(25, 35, 2),
(25, 18, 2),
(25, 19, 2),
(25, 20, 2),
(25, 21, 2),
(25, 22, 2),
(25, 23, 2),
(25, 24, 2),
(25, 25, 2),
(25, 26, 2),
(25, 27, 2),
(25, 56, 2),
(26, 1, 3),
(26, 36, 3),
(26, 37, 3),
(26, 38, 3),
(26, 39, 3),
(26, 45, 3),
(26, 46, 3),
(26, 47, 3),
(26, 48, 3),
(26, 55, 3),
(26, 58, 3),
(26, 4, 3),
(26, 5, 3),
(26, 6, 3),
(26, 7, 3),
(26, 8, 3),
(26, 9, 3),
(26, 10, 3),
(26, 11, 3),
(26, 12, 3),
(26, 49, 3),
(26, 57, 3),
(26, 52, 3),
(26, 53, 3),
(26, 29, 3),
(26, 30, 3),
(26, 31, 3),
(26, 32, 3),
(26, 33, 3),
(26, 34, 3),
(26, 35, 3),
(26, 18, 3),
(26, 19, 3),
(26, 20, 3),
(26, 21, 3),
(26, 22, 3),
(26, 23, 3),
(26, 24, 3),
(26, 25, 3),
(26, 26, 3),
(26, 27, 3),
(26, 56, 3),
(27, 1, 4),
(27, 36, 4),
(27, 37, 4),
(27, 38, 4),
(27, 39, 4),
(27, 45, 4),
(27, 46, 4),
(27, 47, 4),
(27, 48, 4),
(27, 55, 4),
(27, 58, 4),
(27, 4, 4),
(27, 5, 4),
(27, 6, 4),
(27, 7, 4),
(27, 8, 4),
(27, 9, 4),
(27, 10, 4),
(27, 11, 4),
(27, 12, 4),
(27, 49, 4),
(27, 57, 4),
(27, 52, 4),
(27, 53, 4),
(27, 29, 4),
(27, 30, 4),
(27, 31, 4),
(27, 32, 4),
(27, 33, 4),
(27, 34, 4),
(27, 35, 4),
(27, 18, 4),
(27, 19, 4),
(27, 20, 4),
(27, 21, 4),
(27, 22, 4),
(27, 23, 4),
(27, 24, 4),
(27, 25, 4),
(27, 26, 4),
(27, 27, 4),
(27, 56, 4),
(16, 60, 1),
(16, 64, 1),
(16, 59, 1),
(18, 60, 1),
(18, 64, 1),
(18, 59, 1),
(25, 127, 2),
(24, 128, 1),
(24, 127, 1),
(11, 60, 1),
(11, 64, 1),
(11, 59, 1),
(12, 60, 2),
(12, 64, 2),
(12, 59, 2),
(6, 60, 3),
(6, 64, 3),
(6, 59, 3),
(20, 60, 1),
(20, 64, 1),
(20, 59, 1),
(17, 60, 1),
(17, 64, 1),
(17, 59, 1),
(15, 60, 1),
(15, 64, 1),
(15, 59, 1),
(23, 124, 2),
(22, 125, 1),
(22, 124, 1),
(8, 60, 1),
(8, 64, 1),
(8, 59, 1),
(10, 60, 2),
(10, 64, 2),
(10, 59, 2),
(19, 60, 1),
(19, 64, 1),
(19, 59, 1),
(30, 60, 1),
(30, 64, 1),
(30, 59, 1),
(28, 60, 1),
(28, 64, 1),
(28, 59, 1),
(29, 60, 1),
(29, 64, 1),
(29, 59, 1),
(22, 60, 1),
(22, 64, 1),
(22, 59, 1),
(23, 60, 2),
(23, 64, 2),
(23, 59, 2),
(24, 60, 1),
(24, 64, 1),
(24, 59, 1),
(25, 60, 2),
(25, 64, 2),
(25, 59, 2),
(26, 60, 3),
(26, 64, 3),
(26, 59, 3),
(27, 60, 4),
(27, 64, 4),
(27, 59, 4),
(16, 66, 1),
(18, 66, 1),
(23, 128, 2),
(11, 66, 1),
(12, 66, 2),
(6, 66, 3),
(20, 66, 1),
(17, 66, 1),
(15, 66, 1),
(29, 125, 1),
(8, 66, 1),
(10, 66, 2),
(19, 66, 1),
(30, 66, 1),
(28, 66, 1),
(29, 66, 1),
(22, 66, 1),
(23, 66, 2),
(24, 66, 1),
(25, 66, 2),
(26, 66, 3),
(27, 66, 4),
(18, 70, 1),
(18, 71, 1),
(18, 69, 1),
(18, 73, 1),
(18, 74, 1),
(18, 72, 1),
(23, 127, 2),
(22, 128, 1),
(22, 127, 1),
(29, 128, 1),
(29, 127, 1),
(28, 128, 1),
(11, 70, 1),
(11, 71, 1),
(11, 69, 1),
(11, 73, 1),
(11, 74, 1),
(11, 72, 1),
(12, 70, 2),
(12, 71, 2),
(12, 69, 2),
(12, 73, 2),
(12, 74, 2),
(12, 72, 2),
(6, 70, 3),
(6, 71, 3),
(6, 69, 3),
(6, 73, 3),
(6, 74, 3),
(6, 72, 3),
(20, 70, 1),
(20, 71, 1),
(20, 69, 1),
(20, 73, 1),
(20, 74, 1),
(20, 72, 1),
(17, 70, 1),
(17, 71, 1),
(17, 69, 1),
(17, 73, 1),
(17, 74, 1),
(17, 72, 1),
(15, 70, 1),
(15, 71, 1),
(15, 69, 1),
(15, 73, 1),
(15, 74, 1),
(15, 72, 1),
(29, 124, 1),
(28, 125, 1),
(28, 124, 1),
(30, 125, 1),
(30, 124, 1),
(19, 125, 1),
(8, 70, 1),
(8, 71, 1),
(8, 69, 1),
(8, 73, 1),
(8, 74, 1),
(8, 72, 1),
(39, 114, 4),
(39, 27, 5),
(39, 116, 4),
(39, 25, 5),
(39, 24, 5),
(39, 26, 5),
(19, 70, 1),
(19, 71, 1),
(19, 69, 1),
(19, 73, 1),
(19, 74, 1),
(19, 72, 1),
(30, 70, 1),
(30, 71, 1),
(30, 69, 1),
(30, 73, 1),
(30, 74, 1),
(30, 72, 1),
(28, 70, 1),
(28, 71, 1),
(28, 69, 1),
(28, 73, 1),
(28, 74, 1),
(28, 72, 1),
(29, 70, 1),
(29, 71, 1),
(29, 69, 1),
(29, 73, 1),
(29, 74, 1),
(29, 72, 1),
(22, 70, 1),
(22, 71, 1),
(22, 69, 1),
(22, 73, 1),
(22, 74, 1),
(22, 72, 1),
(23, 70, 2),
(23, 71, 2),
(23, 69, 2),
(23, 73, 2),
(23, 74, 2),
(23, 72, 2),
(24, 70, 1),
(24, 71, 1),
(24, 69, 1),
(24, 73, 1),
(24, 74, 1),
(24, 72, 1),
(25, 70, 2),
(25, 71, 2),
(25, 69, 2),
(25, 73, 2),
(25, 74, 2),
(25, 72, 2),
(26, 70, 3),
(26, 71, 3),
(26, 69, 3),
(26, 73, 3),
(26, 74, 3),
(26, 72, 3),
(27, 70, 4),
(27, 71, 4),
(27, 69, 4),
(27, 73, 4),
(27, 74, 4),
(27, 72, 4),
(32, 22, 3),
(18, 76, 1),
(28, 127, 1),
(11, 76, 1),
(12, 76, 2),
(6, 76, 1),
(20, 76, 1),
(17, 76, 1),
(15, 76, 1),
(19, 124, 1),
(32, 29, 3),
(39, 23, 5),
(19, 76, 1),
(30, 76, 1),
(28, 76, 1),
(29, 76, 1),
(22, 76, 1),
(23, 76, 2),
(24, 76, 1),
(25, 76, 2),
(26, 76, 3),
(27, 76, 4),
(32, 21, 3),
(18, 77, 1),
(30, 128, 1),
(11, 77, 1),
(12, 77, 2),
(6, 77, 1),
(20, 77, 1),
(17, 77, 1),
(15, 77, 1),
(10, 125, 2),
(32, 55, 2),
(39, 22, 5),
(19, 77, 1),
(30, 77, 1),
(28, 77, 1),
(29, 77, 1),
(22, 77, 1),
(23, 77, 2),
(24, 77, 1),
(25, 77, 2),
(26, 77, 3),
(27, 77, 4),
(32, 19, 3),
(32, 18, 3),
(32, 20, 3),
(18, 79, 1),
(18, 83, 1),
(18, 78, 1),
(30, 127, 1),
(19, 128, 1),
(19, 127, 1),
(11, 79, 1),
(11, 83, 1),
(11, 78, 1),
(12, 79, 2),
(12, 83, 2),
(12, 78, 2),
(6, 79, 1),
(6, 83, 1),
(6, 78, 1),
(20, 79, 1),
(20, 83, 1),
(20, 78, 1),
(17, 79, 1),
(17, 83, 1),
(17, 78, 1),
(15, 79, 1),
(15, 83, 1),
(15, 78, 1),
(10, 124, 2),
(8, 125, 1),
(8, 124, 1),
(32, 100, 2),
(32, 101, 2),
(32, 123, 2),
(39, 20, 5),
(39, 19, 5),
(39, 21, 5),
(19, 79, 1),
(19, 83, 1),
(19, 78, 1),
(30, 79, 1),
(30, 83, 1),
(30, 78, 1),
(28, 79, 1),
(28, 83, 1),
(28, 78, 1),
(29, 79, 1),
(29, 83, 1),
(29, 78, 1),
(22, 79, 1),
(22, 83, 1),
(22, 78, 1),
(23, 79, 2),
(23, 83, 2),
(23, 78, 2),
(24, 79, 1),
(24, 83, 1),
(24, 78, 1),
(25, 79, 2),
(25, 83, 2),
(25, 78, 2),
(26, 79, 3),
(26, 83, 3),
(26, 78, 3),
(27, 79, 4),
(27, 83, 4),
(27, 78, 4),
(32, 11, 3),
(32, 4, 4),
(32, 5, 3),
(32, 7, 3),
(32, 9, 3),
(32, 12, 3),
(32, 10, 3),
(32, 6, 3),
(32, 8, 3),
(18, 88, 1),
(18, 98, 1),
(18, 97, 1),
(18, 87, 1),
(18, 86, 1),
(18, 93, 1),
(18, 85, 1),
(18, 96, 1),
(18, 91, 1),
(10, 128, 2),
(10, 127, 2),
(8, 128, 1),
(8, 127, 1),
(15, 128, 1),
(11, 88, 1),
(11, 98, 1),
(11, 97, 1),
(11, 87, 1),
(11, 86, 1),
(11, 93, 1),
(11, 85, 1),
(11, 96, 1),
(11, 91, 1),
(12, 88, 2),
(12, 98, 2),
(12, 97, 2),
(12, 87, 2),
(12, 86, 2),
(12, 93, 2),
(12, 85, 2),
(12, 96, 2),
(12, 91, 2),
(6, 88, 1),
(6, 98, 1),
(6, 97, 1),
(6, 87, 1),
(6, 86, 1),
(6, 93, 1),
(6, 85, 1),
(6, 96, 1),
(6, 91, 1),
(20, 88, 1),
(20, 98, 1),
(20, 97, 1),
(20, 87, 1),
(20, 86, 1),
(20, 93, 1),
(20, 85, 1),
(20, 96, 1),
(20, 91, 1),
(17, 88, 1),
(17, 98, 1),
(17, 97, 1),
(17, 87, 1),
(17, 86, 1),
(17, 93, 1),
(17, 85, 1),
(17, 96, 1),
(17, 91, 1),
(15, 88, 1),
(15, 98, 1),
(15, 97, 1),
(15, 87, 1),
(15, 86, 1),
(15, 93, 1),
(15, 85, 1),
(15, 96, 1),
(15, 91, 1),
(15, 125, 1),
(15, 124, 1),
(17, 125, 1),
(17, 124, 1),
(20, 125, 1),
(32, 115, 2),
(32, 116, 2),
(32, 117, 2),
(32, 112, 2),
(32, 113, 2),
(32, 118, 2),
(32, 102, 2),
(32, 120, 2),
(32, 119, 2),
(39, 7, 5),
(39, 5, 5),
(39, 6, 5),
(39, 9, 5),
(39, 10, 5),
(39, 8, 5),
(39, 18, 5),
(39, 12, 5),
(39, 11, 5),
(19, 88, 1),
(19, 98, 1),
(19, 97, 1),
(19, 87, 1),
(19, 86, 1),
(19, 93, 1),
(19, 85, 1),
(19, 96, 1),
(19, 91, 1),
(30, 88, 1),
(30, 98, 1),
(30, 97, 1),
(30, 87, 1),
(30, 86, 1),
(30, 93, 1),
(30, 85, 1),
(30, 96, 1),
(30, 91, 1),
(28, 88, 1),
(28, 98, 1),
(28, 97, 1),
(28, 87, 1),
(28, 86, 1),
(28, 93, 1),
(28, 85, 1),
(28, 96, 1),
(28, 91, 1),
(29, 88, 1),
(29, 98, 1),
(29, 97, 1),
(29, 87, 1),
(29, 86, 1),
(29, 93, 1),
(29, 85, 1),
(29, 96, 1),
(29, 91, 1),
(22, 88, 1),
(22, 98, 1),
(22, 97, 1),
(22, 87, 1),
(22, 86, 1),
(22, 93, 1),
(22, 85, 1),
(22, 96, 1),
(22, 91, 1),
(23, 88, 2),
(23, 98, 2),
(23, 97, 2),
(23, 87, 2),
(23, 86, 2),
(23, 93, 2),
(23, 85, 2),
(23, 96, 2),
(23, 91, 2),
(24, 88, 1),
(24, 98, 1),
(24, 97, 1),
(24, 87, 1),
(24, 86, 1),
(24, 93, 1),
(24, 85, 1),
(24, 96, 1),
(24, 91, 1),
(25, 88, 2),
(25, 98, 2),
(25, 97, 2),
(25, 87, 2),
(25, 86, 2),
(25, 93, 2),
(25, 85, 2),
(25, 96, 2),
(25, 91, 2),
(26, 88, 3),
(26, 98, 3),
(26, 97, 3),
(26, 87, 3),
(26, 86, 3),
(26, 93, 3),
(26, 85, 3),
(26, 96, 3),
(26, 91, 3),
(27, 88, 4),
(27, 98, 4),
(27, 97, 4),
(27, 87, 4),
(27, 86, 4),
(27, 93, 4),
(27, 85, 4),
(27, 96, 4),
(27, 91, 4),
(16, 100, 1),
(18, 100, 1),
(15, 127, 1),
(11, 100, 1),
(12, 100, 2),
(6, 100, 3),
(20, 100, 1),
(17, 100, 1),
(15, 100, 1),
(20, 124, 1),
(8, 100, 1),
(10, 100, 2),
(19, 100, 1),
(30, 100, 1),
(28, 100, 1),
(29, 100, 1),
(22, 100, 1),
(23, 100, 2),
(24, 100, 1),
(25, 100, 2),
(26, 100, 3),
(27, 100, 4),
(16, 102, 1),
(16, 101, 1),
(18, 102, 1),
(18, 101, 1),
(17, 128, 1),
(17, 127, 1),
(11, 102, 1),
(11, 101, 1),
(12, 102, 2),
(12, 101, 2),
(6, 102, 3),
(6, 101, 3),
(20, 102, 1),
(20, 101, 1),
(17, 102, 1),
(17, 101, 1),
(15, 102, 1),
(15, 101, 1),
(6, 125, 3),
(6, 124, 3),
(8, 102, 1),
(8, 101, 1),
(10, 102, 2),
(10, 101, 2),
(19, 102, 1),
(19, 101, 1),
(30, 102, 1),
(30, 101, 1),
(28, 102, 1),
(28, 101, 1),
(29, 102, 1),
(29, 101, 1),
(22, 102, 1),
(22, 101, 1),
(23, 102, 2),
(23, 101, 2),
(24, 102, 1),
(24, 101, 1),
(25, 102, 2),
(25, 101, 2),
(26, 102, 3),
(26, 101, 3),
(27, 102, 4),
(27, 101, 4),
(16, 114, 1),
(16, 116, 1),
(16, 117, 1),
(16, 120, 1),
(16, 118, 1),
(16, 119, 1),
(16, 115, 1),
(16, 112, 1),
(16, 113, 1),
(18, 114, 1),
(18, 116, 1),
(18, 117, 1),
(18, 120, 1),
(18, 118, 1),
(18, 119, 1),
(18, 115, 1),
(18, 112, 1),
(18, 113, 1),
(20, 128, 1),
(20, 127, 1),
(6, 128, 3),
(6, 127, 3),
(12, 128, 2),
(12, 127, 2),
(11, 128, 1),
(11, 114, 1),
(11, 116, 1),
(11, 117, 1),
(11, 120, 1),
(11, 118, 1),
(11, 119, 1),
(11, 115, 1),
(11, 112, 1),
(11, 113, 1),
(12, 114, 2),
(12, 116, 2),
(12, 117, 2),
(12, 120, 2),
(12, 118, 2),
(12, 119, 2),
(12, 115, 2),
(12, 112, 2),
(12, 113, 2),
(6, 114, 3),
(6, 116, 3),
(6, 117, 3),
(6, 120, 3),
(6, 118, 3),
(6, 119, 3),
(6, 115, 3),
(6, 112, 3),
(6, 113, 3),
(20, 114, 1),
(20, 116, 1),
(20, 117, 1),
(20, 120, 1),
(20, 118, 1),
(20, 119, 1),
(20, 115, 1),
(20, 112, 1),
(20, 113, 1),
(17, 114, 1),
(17, 116, 1),
(17, 117, 1),
(17, 120, 1),
(17, 118, 1),
(17, 119, 1),
(17, 115, 1),
(17, 112, 1),
(17, 113, 1),
(15, 114, 1),
(15, 116, 1),
(15, 117, 1),
(15, 120, 1),
(15, 118, 1),
(15, 119, 1),
(15, 115, 1),
(15, 112, 1),
(15, 113, 1),
(12, 125, 2),
(12, 124, 2),
(11, 125, 1),
(11, 124, 1),
(11, 127, 1),
(18, 128, 1),
(18, 125, 1),
(8, 114, 1),
(8, 116, 1),
(8, 117, 1),
(8, 120, 1),
(8, 118, 1),
(8, 119, 1),
(8, 115, 1),
(8, 112, 1),
(8, 113, 1),
(10, 114, 2),
(10, 116, 2),
(10, 117, 2),
(10, 120, 2),
(10, 118, 2),
(10, 119, 2),
(10, 115, 2),
(10, 112, 2),
(10, 113, 2),
(19, 114, 1),
(19, 116, 1),
(19, 117, 1),
(19, 120, 1),
(19, 118, 1),
(19, 119, 1),
(19, 115, 1),
(19, 112, 1),
(19, 113, 1),
(30, 114, 1),
(30, 116, 1),
(30, 117, 1),
(30, 120, 1),
(30, 118, 1),
(30, 119, 1),
(30, 115, 1),
(30, 112, 1),
(30, 113, 1),
(28, 114, 1),
(28, 116, 1),
(28, 117, 1),
(28, 120, 1),
(28, 118, 1),
(28, 119, 1),
(28, 115, 1),
(28, 112, 1),
(28, 113, 1),
(29, 114, 1),
(29, 116, 1),
(29, 117, 1),
(29, 120, 1),
(29, 118, 1),
(29, 119, 1),
(29, 115, 1),
(29, 112, 1),
(29, 113, 1),
(22, 114, 1),
(22, 116, 1),
(22, 117, 1),
(22, 120, 1),
(22, 118, 1),
(22, 119, 1),
(22, 115, 1),
(22, 112, 1),
(22, 113, 1),
(23, 114, 2),
(23, 116, 2),
(23, 117, 2),
(23, 120, 2),
(23, 118, 2),
(23, 119, 2),
(23, 115, 2),
(23, 112, 2),
(23, 113, 2),
(24, 114, 1),
(24, 116, 1),
(24, 117, 1),
(24, 120, 1),
(24, 118, 1),
(24, 119, 1),
(24, 115, 1),
(24, 112, 1),
(24, 113, 1),
(25, 114, 2),
(25, 116, 2),
(25, 117, 2),
(25, 120, 2),
(25, 118, 2),
(25, 119, 2),
(25, 115, 2),
(25, 112, 2),
(25, 113, 2),
(26, 114, 3),
(26, 116, 3),
(26, 117, 3),
(26, 120, 3),
(26, 118, 3),
(26, 119, 3),
(26, 115, 3),
(26, 112, 3),
(26, 113, 3),
(27, 114, 4),
(27, 116, 4),
(27, 117, 4),
(27, 120, 4),
(27, 118, 4),
(27, 119, 4),
(27, 115, 4),
(27, 112, 4),
(27, 113, 4),
(32, 125, 2),
(32, 124, 2),
(18, 121, 1),
(18, 122, 1),
(18, 127, 1),
(16, 128, 1),
(11, 121, 1),
(11, 122, 1),
(12, 121, 2),
(12, 122, 2),
(6, 121, 1),
(6, 122, 1),
(20, 121, 1),
(20, 122, 1),
(17, 121, 1),
(17, 122, 1),
(15, 121, 1),
(15, 122, 1),
(18, 124, 1),
(16, 125, 1),
(32, 114, 2),
(32, 27, 3),
(39, 4, 3),
(39, 125, 4),
(19, 121, 1),
(19, 122, 1),
(30, 121, 1),
(30, 122, 1),
(28, 121, 1),
(28, 122, 1),
(29, 121, 1),
(29, 122, 1),
(22, 121, 1),
(22, 122, 1),
(23, 121, 2),
(23, 122, 2),
(24, 121, 1),
(24, 122, 1),
(25, 121, 2),
(25, 122, 2),
(26, 121, 3),
(26, 122, 3),
(27, 121, 4),
(27, 122, 4),
(18, 123, 1),
(16, 127, 1),
(11, 123, 1),
(12, 123, 2),
(6, 123, 3),
(20, 123, 1),
(17, 123, 1),
(15, 123, 1),
(16, 124, 1),
(8, 123, 1),
(39, 124, 4),
(19, 123, 1),
(30, 123, 1),
(28, 123, 1),
(29, 123, 1),
(22, 123, 1),
(23, 123, 2),
(24, 123, 1),
(25, 123, 2),
(26, 123, 3),
(27, 123, 4),
(33, 124, 1),
(33, 125, 1),
(33, 4, 2),
(33, 5, 2),
(33, 6, 2),
(33, 12, 2),
(33, 8, 2),
(33, 11, 2),
(33, 7, 2),
(33, 9, 2),
(33, 10, 2),
(33, 18, 2),
(33, 19, 2),
(33, 20, 2),
(33, 21, 2),
(33, 22, 2),
(33, 23, 2),
(33, 24, 2),
(33, 25, 2),
(33, 26, 2),
(33, 27, 2),
(33, 114, 1),
(33, 116, 1),
(33, 117, 1),
(33, 120, 1),
(33, 118, 1),
(33, 119, 1),
(33, 115, 1),
(33, 112, 1),
(33, 113, 1),
(33, 102, 1),
(33, 101, 1),
(33, 100, 1),
(33, 123, 1),
(33, 55, 1),
(33, 29, 2),
(33, 30, 2),
(33, 31, 2),
(33, 32, 2),
(33, 33, 2),
(33, 34, 2),
(33, 35, 2),
(33, 36, 1),
(33, 37, 1),
(33, 38, 1),
(33, 39, 1),
(33, 57, 1),
(33, 58, 1),
(33, 49, 1),
(33, 45, 1),
(33, 46, 1),
(33, 47, 1),
(33, 48, 1),
(33, 60, 1),
(33, 64, 1),
(33, 59, 1),
(33, 66, 1),
(33, 70, 1),
(33, 71, 1),
(33, 69, 1),
(33, 73, 1),
(33, 74, 1),
(33, 72, 1),
(33, 127, 1),
(33, 128, 1),
(35, 124, 3),
(35, 125, 3),
(35, 4, 3),
(35, 5, 3),
(35, 6, 3),
(35, 12, 3),
(35, 8, 3),
(35, 11, 3),
(35, 7, 3),
(35, 9, 3),
(35, 10, 3),
(35, 18, 3),
(35, 19, 3),
(35, 20, 3),
(35, 21, 3),
(35, 22, 3),
(35, 23, 3),
(35, 24, 3),
(35, 25, 3),
(35, 26, 3),
(35, 27, 3),
(35, 114, 3),
(35, 116, 3),
(35, 117, 3),
(35, 120, 3),
(35, 118, 3),
(35, 119, 3),
(35, 115, 3),
(35, 112, 3),
(35, 113, 3),
(35, 102, 3),
(35, 101, 3),
(35, 100, 3),
(39, 115, 4),
(35, 55, 3),
(35, 29, 3),
(35, 30, 3),
(35, 31, 3),
(35, 32, 3),
(35, 33, 3),
(35, 34, 3),
(35, 35, 3),
(35, 36, 3),
(35, 37, 3),
(35, 38, 3),
(35, 39, 3),
(35, 57, 3),
(35, 58, 3),
(35, 49, 3),
(35, 45, 3),
(35, 46, 3),
(35, 47, 3),
(35, 48, 3),
(35, 60, 3),
(35, 64, 3),
(35, 59, 3),
(35, 66, 3),
(39, 100, 4),
(39, 101, 4),
(39, 55, 4),
(39, 113, 4),
(39, 112, 4),
(39, 102, 4),
(35, 127, 3),
(35, 128, 3),
(36, 124, 1),
(36, 125, 1),
(36, 4, 1),
(36, 5, 1),
(36, 6, 1),
(36, 12, 1),
(36, 8, 1),
(36, 11, 1),
(36, 7, 1),
(36, 9, 1),
(36, 10, 1),
(36, 18, 1),
(36, 19, 1),
(36, 20, 1),
(36, 21, 1),
(36, 22, 1),
(36, 23, 1),
(36, 24, 1),
(36, 25, 1),
(36, 26, 1),
(36, 27, 1),
(36, 114, 1),
(36, 116, 1),
(36, 117, 1),
(36, 120, 1),
(36, 118, 1),
(36, 119, 1),
(36, 115, 1),
(36, 112, 1),
(36, 113, 1),
(36, 102, 1),
(36, 101, 1),
(36, 100, 1),
(36, 123, 1),
(36, 55, 1),
(36, 29, 1),
(36, 30, 1),
(36, 31, 1),
(36, 32, 1),
(36, 33, 1),
(36, 34, 1),
(36, 35, 1),
(36, 36, 1),
(36, 37, 1),
(36, 38, 1),
(36, 39, 1),
(36, 57, 1),
(36, 58, 1),
(36, 49, 1),
(36, 45, 1),
(36, 46, 1),
(36, 47, 1),
(36, 48, 1),
(36, 60, 1),
(36, 64, 1),
(36, 59, 1),
(36, 66, 1),
(36, 70, 1),
(36, 71, 1),
(36, 69, 1),
(36, 73, 1),
(36, 74, 1),
(36, 72, 1),
(36, 127, 1),
(36, 128, 1),
(37, 124, 1),
(37, 125, 1),
(37, 4, 1),
(37, 5, 1),
(37, 6, 1),
(37, 12, 1),
(37, 8, 1),
(37, 11, 1),
(37, 7, 1),
(37, 9, 1),
(37, 10, 1),
(37, 18, 1),
(37, 19, 1),
(37, 20, 1),
(37, 21, 1),
(37, 22, 1),
(37, 23, 1),
(37, 24, 1),
(37, 25, 1),
(37, 26, 1),
(37, 27, 1),
(37, 114, 1),
(37, 116, 1),
(37, 117, 1),
(37, 120, 1),
(37, 118, 1),
(37, 119, 1),
(37, 115, 1),
(37, 112, 1),
(37, 113, 1),
(37, 102, 1),
(37, 101, 1),
(37, 100, 1),
(37, 123, 1),
(37, 55, 1),
(37, 29, 1),
(37, 30, 1),
(37, 31, 1),
(37, 32, 1),
(37, 33, 1),
(37, 34, 1),
(37, 35, 1),
(37, 36, 1),
(37, 37, 1),
(37, 38, 1),
(37, 39, 1),
(37, 57, 1),
(37, 58, 1),
(37, 49, 1),
(37, 45, 1),
(37, 46, 1),
(37, 47, 1),
(37, 48, 1),
(37, 60, 1),
(37, 64, 1),
(37, 59, 1),
(37, 66, 1),
(37, 70, 1),
(37, 71, 1),
(37, 69, 1),
(37, 73, 1),
(37, 74, 1),
(37, 72, 1),
(37, 127, 1),
(37, 128, 1),
(38, 124, 1),
(38, 125, 1),
(38, 4, 1),
(38, 5, 1),
(38, 6, 1),
(38, 12, 1),
(38, 8, 1),
(38, 11, 1),
(38, 7, 1),
(38, 9, 1),
(38, 10, 1),
(38, 18, 1),
(38, 19, 1),
(38, 20, 1),
(38, 21, 1),
(38, 22, 1),
(38, 23, 1),
(38, 24, 1),
(38, 25, 1),
(38, 26, 1),
(38, 27, 1),
(38, 114, 1),
(38, 116, 1),
(38, 117, 1),
(38, 120, 1),
(38, 118, 1),
(38, 119, 1),
(38, 115, 1),
(38, 112, 1),
(38, 113, 1),
(38, 102, 1),
(38, 101, 1),
(38, 100, 1),
(38, 123, 1),
(38, 55, 1),
(38, 29, 1),
(38, 30, 1),
(38, 31, 1),
(38, 32, 1),
(38, 33, 1),
(38, 34, 1),
(38, 35, 1),
(38, 36, 1),
(38, 37, 1),
(38, 38, 1),
(38, 39, 1),
(38, 57, 1),
(38, 58, 1),
(38, 49, 1),
(38, 45, 1),
(38, 46, 1),
(38, 47, 1),
(38, 48, 1),
(38, 60, 1),
(38, 64, 1),
(38, 59, 1),
(38, 66, 1),
(38, 70, 1),
(38, 71, 1),
(38, 69, 1),
(38, 73, 1),
(38, 74, 1),
(38, 72, 1),
(38, 127, 1),
(38, 128, 1),
(37, 134, 1),
(37, 143, 1),
(37, 132, 1),
(37, 131, 1),
(37, 133, 1),
(37, 139, 1),
(38, 134, 1),
(38, 143, 1),
(38, 132, 1),
(38, 131, 1),
(38, 133, 1),
(38, 139, 1),
(36, 134, 1),
(36, 143, 1),
(36, 132, 1),
(36, 131, 1),
(36, 133, 1),
(36, 139, 1),
(16, 134, 1),
(16, 143, 1),
(16, 132, 1),
(16, 131, 1),
(16, 133, 1),
(16, 139, 1),
(18, 134, 1),
(18, 143, 1),
(18, 132, 1),
(18, 131, 1),
(18, 133, 1),
(18, 139, 1),
(19, 134, 1),
(19, 143, 1),
(19, 132, 1),
(19, 131, 1),
(19, 133, 1),
(19, 139, 1),
(11, 134, 1),
(11, 143, 1),
(11, 132, 1),
(11, 131, 1),
(11, 133, 1),
(11, 139, 1),
(12, 134, 2),
(12, 143, 2),
(12, 132, 2),
(12, 131, 2),
(12, 133, 2),
(12, 139, 2),
(33, 134, 1),
(33, 143, 1),
(33, 132, 1),
(33, 131, 1),
(33, 133, 1),
(33, 139, 1),
(32, 134, 2),
(32, 143, 2),
(32, 132, 2),
(32, 131, 2),
(32, 133, 2),
(32, 139, 2),
(6, 134, 3),
(6, 143, 3),
(6, 132, 3),
(6, 131, 3),
(6, 133, 3),
(6, 139, 3),
(20, 134, 1),
(20, 143, 1),
(20, 132, 1),
(20, 131, 1),
(20, 133, 1),
(20, 139, 1),
(17, 134, 1),
(17, 143, 1),
(17, 132, 1),
(17, 131, 1),
(17, 133, 1),
(17, 139, 1),
(15, 134, 1),
(15, 143, 1),
(15, 132, 1),
(15, 131, 1),
(15, 133, 1),
(15, 139, 1),
(8, 134, 1),
(8, 143, 1),
(8, 132, 1),
(8, 131, 1),
(8, 133, 1),
(8, 139, 1),
(10, 134, 2),
(10, 143, 2),
(10, 132, 2),
(10, 131, 2),
(10, 133, 2),
(10, 139, 2),
(35, 134, 3),
(35, 143, 3),
(35, 132, 3),
(35, 131, 3),
(35, 133, 3),
(35, 139, 3),
(30, 134, 1),
(30, 143, 1),
(30, 132, 1),
(30, 131, 1),
(30, 133, 1),
(30, 139, 1),
(28, 134, 1),
(28, 143, 1),
(28, 132, 1),
(28, 131, 1),
(28, 133, 1),
(28, 139, 1),
(29, 134, 1),
(29, 143, 1),
(29, 132, 1),
(29, 131, 1),
(29, 133, 1),
(29, 139, 1),
(22, 134, 1),
(22, 143, 1),
(22, 132, 1),
(22, 131, 1),
(22, 133, 1),
(22, 139, 1),
(23, 134, 2),
(23, 143, 2),
(23, 132, 2),
(23, 131, 2),
(23, 133, 2),
(23, 139, 2),
(24, 134, 1),
(24, 143, 1),
(24, 132, 1),
(24, 131, 1),
(24, 133, 1),
(24, 139, 1),
(25, 134, 2),
(25, 143, 2),
(25, 132, 2),
(25, 131, 2),
(25, 133, 2),
(25, 139, 2),
(26, 134, 3),
(26, 143, 3),
(26, 132, 3),
(26, 131, 3),
(26, 133, 3),
(26, 139, 3),
(27, 134, 4),
(27, 143, 4),
(27, 132, 4),
(27, 131, 4),
(27, 133, 4),
(27, 139, 4),
(37, 147, 1),
(37, 154, 1),
(37, 155, 1),
(37, 146, 1),
(37, 153, 1),
(37, 148, 1),
(37, 150, 1),
(37, 152, 1),
(38, 147, 1),
(38, 154, 1),
(38, 155, 1),
(38, 146, 1),
(38, 153, 1),
(38, 148, 1),
(38, 150, 1),
(38, 152, 1),
(36, 147, 1),
(36, 154, 1),
(36, 155, 1),
(36, 146, 1),
(36, 153, 1),
(36, 148, 1),
(36, 150, 1),
(36, 152, 1),
(16, 147, 1),
(16, 154, 1),
(16, 155, 1),
(16, 146, 1),
(16, 153, 1),
(16, 148, 1),
(16, 150, 1),
(16, 152, 1),
(18, 147, 1),
(18, 154, 1),
(18, 155, 1),
(18, 146, 1),
(18, 153, 1),
(18, 148, 1),
(18, 150, 1),
(18, 152, 1),
(19, 147, 1),
(19, 154, 1),
(19, 155, 1),
(19, 146, 1),
(19, 153, 1),
(19, 148, 1),
(19, 150, 1),
(19, 152, 1),
(11, 147, 1),
(11, 154, 1),
(11, 155, 1),
(11, 146, 1),
(11, 153, 1),
(11, 148, 1),
(11, 150, 1),
(11, 152, 1),
(12, 147, 2),
(12, 154, 2),
(12, 155, 2),
(12, 146, 2),
(12, 153, 2),
(12, 148, 2),
(12, 150, 2),
(12, 152, 2),
(33, 147, 1),
(33, 154, 1),
(33, 155, 1),
(33, 146, 1),
(33, 153, 1),
(33, 148, 1),
(33, 150, 1),
(33, 152, 1),
(32, 147, 2),
(32, 154, 2),
(32, 155, 2),
(32, 146, 2),
(32, 153, 2),
(32, 148, 2),
(32, 150, 2),
(32, 152, 2),
(6, 147, 3),
(6, 154, 3),
(6, 155, 3),
(6, 146, 3),
(6, 153, 3),
(6, 148, 3),
(6, 150, 3),
(6, 152, 3),
(20, 147, 1),
(20, 154, 1),
(20, 155, 1),
(20, 146, 1),
(20, 153, 1),
(20, 148, 1),
(20, 150, 1),
(20, 152, 1),
(17, 147, 1),
(17, 154, 1),
(17, 155, 1),
(17, 146, 1),
(17, 153, 1),
(17, 148, 1),
(17, 150, 1),
(17, 152, 1),
(15, 147, 1),
(15, 154, 1),
(15, 155, 1),
(15, 146, 1),
(15, 153, 1),
(15, 148, 1),
(15, 150, 1),
(15, 152, 1),
(8, 147, 1),
(8, 154, 1),
(8, 155, 1),
(8, 146, 1),
(8, 153, 1),
(8, 148, 1),
(8, 150, 1),
(8, 152, 1),
(10, 147, 2),
(10, 154, 2),
(10, 155, 2),
(10, 146, 2),
(10, 153, 2),
(10, 148, 2),
(10, 150, 2),
(10, 152, 2),
(35, 147, 3),
(35, 154, 3),
(35, 155, 3),
(35, 146, 3),
(35, 153, 3),
(35, 148, 3),
(35, 150, 3),
(35, 152, 3),
(30, 147, 1),
(30, 154, 1),
(30, 155, 1),
(30, 146, 1),
(30, 153, 1),
(30, 148, 1),
(30, 150, 1),
(30, 152, 1),
(28, 147, 1),
(28, 154, 1),
(28, 155, 1),
(28, 146, 1),
(28, 153, 1),
(28, 148, 1),
(28, 150, 1),
(28, 152, 1),
(29, 147, 1),
(29, 154, 1),
(29, 155, 1),
(29, 146, 1),
(29, 153, 1),
(29, 148, 1),
(29, 150, 1),
(29, 152, 1),
(22, 147, 1),
(22, 154, 1),
(22, 155, 1),
(22, 146, 1),
(22, 153, 1),
(22, 148, 1),
(22, 150, 1),
(22, 152, 1),
(23, 147, 2),
(23, 154, 2),
(23, 155, 2),
(23, 146, 2),
(23, 153, 2),
(23, 148, 2),
(23, 150, 2),
(23, 152, 2),
(24, 147, 1),
(24, 154, 1),
(24, 155, 1),
(24, 146, 1),
(24, 153, 1),
(24, 148, 1),
(24, 150, 1),
(24, 152, 1),
(25, 147, 2),
(25, 154, 2),
(25, 155, 2),
(25, 146, 2),
(25, 153, 2),
(25, 148, 2),
(25, 150, 2),
(25, 152, 2),
(26, 147, 3),
(26, 154, 3),
(26, 155, 3),
(26, 146, 3),
(26, 153, 3),
(26, 148, 3),
(26, 150, 3),
(26, 152, 3),
(27, 147, 4),
(27, 154, 4),
(27, 155, 4),
(27, 146, 4),
(27, 153, 4),
(27, 148, 4),
(27, 150, 4),
(27, 152, 4),
(39, 29, 5),
(39, 30, 5),
(39, 31, 5),
(39, 32, 5),
(39, 33, 5),
(39, 34, 5),
(39, 35, 5),
(39, 36, 4),
(39, 37, 4),
(39, 38, 4),
(39, 39, 4),
(39, 57, 4),
(39, 58, 4),
(39, 49, 4),
(39, 45, 4),
(39, 46, 4),
(39, 47, 4),
(39, 48, 4),
(39, 60, 4),
(39, 64, 4),
(39, 59, 4),
(39, 66, 4),
(39, 127, 4),
(39, 128, 4),
(39, 134, 4),
(39, 143, 4),
(39, 132, 4),
(39, 131, 4),
(39, 133, 4),
(39, 139, 4),
(39, 147, 4),
(39, 154, 4),
(39, 155, 4),
(39, 146, 4),
(39, 153, 4),
(39, 148, 4),
(39, 150, 4),
(39, 152, 4),
(37, 176, 1),
(37, 189, 1),
(37, 178, 1),
(37, 186, 1),
(37, 177, 1),
(37, 173, 1),
(37, 172, 1),
(37, 182, 1),
(37, 187, 1),
(37, 188, 1),
(37, 174, 1),
(37, 175, 1),
(37, 185, 1),
(37, 180, 1),
(38, 176, 1),
(38, 189, 1),
(38, 178, 1),
(38, 186, 1),
(38, 177, 1),
(38, 173, 1),
(38, 172, 1),
(38, 182, 1),
(38, 187, 1),
(38, 188, 1),
(38, 174, 1),
(38, 175, 1),
(38, 185, 1),
(38, 180, 1),
(36, 176, 1),
(36, 189, 1),
(36, 178, 1),
(36, 186, 1),
(36, 177, 1),
(36, 173, 1),
(36, 172, 1),
(36, 182, 1),
(36, 187, 1),
(36, 188, 1),
(36, 174, 1),
(36, 175, 1),
(36, 185, 1),
(36, 180, 1),
(16, 176, 1),
(16, 189, 1),
(16, 178, 1),
(16, 186, 1),
(16, 177, 1),
(16, 173, 1),
(16, 172, 1),
(16, 182, 1),
(16, 187, 1),
(16, 188, 1),
(16, 174, 1),
(16, 175, 1),
(16, 185, 1),
(16, 180, 1),
(18, 176, 1),
(18, 189, 1),
(18, 178, 1),
(18, 186, 1),
(18, 177, 1),
(18, 173, 1),
(18, 172, 1),
(18, 182, 1),
(18, 187, 1),
(18, 188, 1),
(18, 174, 1),
(18, 175, 1),
(18, 185, 1),
(18, 180, 1),
(19, 176, 1),
(19, 189, 1),
(19, 178, 1),
(19, 186, 1),
(19, 177, 1),
(19, 173, 1),
(19, 172, 1),
(19, 182, 1),
(19, 187, 1),
(19, 188, 1),
(19, 174, 1),
(19, 175, 1),
(19, 185, 1),
(19, 180, 1),
(11, 176, 1),
(11, 189, 1),
(11, 178, 1),
(11, 186, 1),
(11, 177, 1),
(11, 173, 1),
(11, 172, 1),
(11, 182, 1),
(11, 187, 1),
(11, 188, 1),
(11, 174, 1),
(11, 175, 1),
(11, 185, 1),
(11, 180, 1),
(12, 176, 2),
(12, 189, 2),
(12, 178, 2),
(12, 186, 2),
(12, 177, 2),
(12, 173, 2),
(12, 172, 2),
(12, 182, 2),
(12, 187, 2),
(12, 188, 2),
(12, 174, 2),
(12, 175, 2),
(12, 185, 2),
(12, 180, 2),
(33, 176, 1),
(33, 189, 1),
(33, 178, 1),
(33, 186, 1),
(33, 177, 1),
(33, 173, 1),
(33, 172, 1),
(33, 182, 1),
(33, 187, 1),
(33, 188, 1),
(33, 174, 1),
(33, 175, 1),
(33, 185, 1),
(33, 180, 1),
(32, 176, 2),
(32, 189, 2),
(32, 178, 2),
(32, 186, 2),
(32, 177, 2),
(32, 173, 2),
(32, 172, 2),
(32, 182, 2),
(32, 187, 2),
(32, 188, 2),
(32, 174, 2),
(32, 175, 2),
(32, 185, 2),
(32, 180, 2),
(6, 176, 3),
(6, 189, 3),
(6, 178, 3),
(6, 186, 3),
(6, 177, 3),
(6, 173, 3),
(6, 172, 3),
(6, 182, 3),
(6, 187, 3),
(6, 188, 3),
(6, 174, 3),
(6, 175, 3),
(6, 185, 3),
(6, 180, 3),
(39, 176, 4),
(39, 189, 4),
(39, 178, 4),
(39, 186, 4),
(39, 177, 4),
(39, 173, 4),
(39, 172, 4),
(39, 182, 4),
(39, 187, 4),
(39, 188, 4),
(39, 174, 4),
(39, 175, 4),
(39, 185, 4),
(39, 180, 4),
(20, 176, 1),
(20, 189, 1),
(20, 178, 1),
(20, 186, 1),
(20, 177, 1),
(20, 173, 1),
(20, 172, 1),
(20, 182, 1),
(20, 187, 1),
(20, 188, 1),
(20, 174, 1),
(20, 175, 1),
(20, 185, 1),
(20, 180, 1),
(17, 176, 1),
(17, 189, 1),
(17, 178, 1),
(17, 186, 1),
(17, 177, 1),
(17, 173, 1),
(17, 172, 1),
(17, 182, 1),
(17, 187, 1),
(17, 188, 1),
(17, 174, 1),
(17, 175, 1),
(17, 185, 1),
(17, 180, 1),
(15, 176, 1),
(15, 189, 1),
(15, 178, 1),
(15, 186, 1),
(15, 177, 1),
(15, 173, 1),
(15, 172, 1),
(15, 182, 1),
(15, 187, 1),
(15, 188, 1),
(15, 174, 1),
(15, 175, 1),
(15, 185, 1),
(15, 180, 1),
(8, 176, 1),
(8, 189, 1),
(8, 178, 1),
(8, 186, 1),
(8, 177, 1),
(8, 173, 1),
(8, 172, 1),
(8, 182, 1),
(8, 187, 1),
(8, 188, 1),
(8, 174, 1),
(8, 175, 1),
(8, 185, 1),
(8, 180, 1),
(10, 176, 2),
(10, 189, 2),
(10, 178, 2),
(10, 186, 2),
(10, 177, 2),
(10, 173, 2),
(10, 172, 2),
(10, 182, 2),
(10, 187, 2),
(10, 188, 2),
(10, 174, 2),
(10, 175, 2),
(10, 185, 2),
(10, 180, 2),
(35, 176, 3),
(35, 189, 3),
(35, 178, 3),
(35, 186, 3),
(35, 177, 3),
(35, 173, 3),
(35, 172, 3),
(35, 182, 3),
(35, 187, 3),
(35, 188, 3),
(35, 174, 3),
(35, 175, 3),
(35, 185, 3),
(35, 180, 3),
(30, 176, 1),
(30, 189, 1),
(30, 178, 1),
(30, 186, 1),
(30, 177, 1),
(30, 173, 1),
(30, 172, 1),
(30, 182, 1),
(30, 187, 1),
(30, 188, 1),
(30, 174, 1),
(30, 175, 1),
(30, 185, 1),
(30, 180, 1),
(28, 176, 1),
(28, 189, 1),
(28, 178, 1),
(28, 186, 1),
(28, 177, 1),
(28, 173, 1),
(28, 172, 1),
(28, 182, 1),
(28, 187, 1),
(28, 188, 1),
(28, 174, 1),
(28, 175, 1),
(28, 185, 1),
(28, 180, 1),
(29, 176, 1),
(29, 189, 1),
(29, 178, 1),
(29, 186, 1),
(29, 177, 1),
(29, 173, 1),
(29, 172, 1),
(29, 182, 1),
(29, 187, 1),
(29, 188, 1),
(29, 174, 1),
(29, 175, 1),
(29, 185, 1),
(29, 180, 1),
(22, 176, 1),
(22, 189, 1),
(22, 178, 1),
(22, 186, 1),
(22, 177, 1),
(22, 173, 1),
(22, 172, 1),
(22, 182, 1),
(22, 187, 1),
(22, 188, 1),
(22, 174, 1),
(22, 175, 1),
(22, 185, 1),
(22, 180, 1),
(23, 176, 2),
(23, 189, 2),
(23, 178, 2),
(23, 186, 2),
(23, 177, 2),
(23, 173, 2),
(23, 172, 2),
(23, 182, 2),
(23, 187, 2),
(23, 188, 2),
(23, 174, 2),
(23, 175, 2),
(23, 185, 2),
(23, 180, 2),
(24, 176, 1),
(24, 189, 1),
(24, 178, 1),
(24, 186, 1),
(24, 177, 1),
(24, 173, 1),
(24, 172, 1),
(24, 182, 1),
(24, 187, 1),
(24, 188, 1),
(24, 174, 1),
(24, 175, 1),
(24, 185, 1),
(24, 180, 1),
(25, 176, 2),
(25, 189, 2),
(25, 178, 2),
(25, 186, 2),
(25, 177, 2),
(25, 173, 2),
(25, 172, 2),
(25, 182, 2),
(25, 187, 2),
(25, 188, 2),
(25, 174, 2),
(25, 175, 2),
(25, 185, 2),
(25, 180, 2),
(26, 176, 3),
(26, 189, 3),
(26, 178, 3),
(26, 186, 3),
(26, 177, 3),
(26, 173, 3),
(26, 172, 3),
(26, 182, 3),
(26, 187, 3),
(26, 188, 3),
(26, 174, 3),
(26, 175, 3),
(26, 185, 3),
(26, 180, 3),
(27, 176, 4),
(27, 189, 4),
(27, 178, 4),
(27, 186, 4),
(27, 177, 4),
(27, 173, 4),
(27, 172, 4),
(27, 182, 4),
(27, 187, 4),
(27, 188, 4),
(27, 174, 4),
(27, 175, 4),
(27, 185, 4),
(27, 180, 4),
(37, 190, 1),
(38, 190, 1),
(36, 190, 1),
(16, 190, 1),
(18, 190, 1),
(19, 190, 1),
(11, 190, 1),
(12, 190, 2),
(33, 190, 1),
(32, 190, 2),
(6, 190, 3),
(39, 190, 4),
(20, 190, 1),
(17, 190, 1),
(15, 190, 1),
(8, 190, 1),
(10, 190, 2),
(35, 190, 3),
(30, 190, 1),
(28, 190, 1),
(29, 190, 1),
(22, 190, 1),
(23, 190, 2),
(24, 190, 1),
(25, 190, 2),
(26, 190, 3),
(27, 190, 4);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_cbdoan`
--

CREATE TABLE `pacorp_vi_cbdoan` (
  `id` int(3) NOT NULL,
  `hoten` varchar(40) NOT NULL,
  `ngsinh` varchar(10) NOT NULL,
  `gtinh` int(1) DEFAULT '1',
  `avt` varchar(255) DEFAULT NULL,
  `nvdoan` varchar(10) DEFAULT NULL,
  `dang` int(1) DEFAULT '0',
  `nvdang` varchar(10) DEFAULT NULL,
  `quequan` varchar(255) DEFAULT NULL,
  `diachi` varchar(255) DEFAULT NULL,
  `madvi` int(3) NOT NULL,
  `macvu1` int(3) NOT NULL,
  `macvu2` int(3) NOT NULL,
  `macvu3` int(3) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `yahoo` varchar(50) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `phone` varchar(12) DEFAULT NULL,
  `website` varchar(50) DEFAULT NULL,
  `tomtat` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_cbdoan`
--

INSERT INTO `pacorp_vi_cbdoan` (`id`, `hoten`, `ngsinh`, `gtinh`, `avt`, `nvdoan`, `dang`, `nvdang`, `quequan`, `diachi`, `madvi`, `macvu1`, `macvu2`, `macvu3`, `email`, `yahoo`, `skype`, `phone`, `website`, `tomtat`) VALUES
(1, 'Nguyễn Linh', '-284022000', 1, '/uploads/cbdoan/nguyen-linh.gif', '1457110800', 1, '0', 'Quảng Ninh', 'P. Hồng Hải - TP. Hạ Long', 2, 1, 0, 0, 'nguyenlinh.c3hongai@quangninh.edu.vn', '', '', '0913396150', '', '- Trình độ chuyên môn: Thạc sĩ&nbsp;<br  />\r\n- Trình độ LLCT: cao cấp LLCT'),
(2, 'Vũ Thị Phượng', '63046800', 0, '/uploads/cbdoan/c3hongai-dothiphuong.jpg', '0', 1, '0', '', '', 2, 2, 0, 0, 'vuthiphuong.c3hongai@quangninh.edu.vn', '', '', '0904823344', '', '- Trình độ chuyên môn: Đại học Sư phạm Địa lí<br  />\r\n- Trình độ LLCT: Trung cấp<br  />\r\n- Trình độ QLGD: Đang học<br  />\r\n- Điện thoại văn phòng: 0333825289<br  />\r\n&nbsp;'),
(3, 'Bùi Thị Hồng Vân', '-253090800', 1, '', '0', 1, '0', '', '', 4, 3, 0, 0, 'van6161@gmail.com', '', '', '0902055766', '', ''),
(4, 'Đặng Thị Quyên', '449341200', 1, '', '0', 0, '0', 'Ân Thi, Hưng Yên', 'T8, K3, P Hồng Hà, TP Hạ Long', 5, 8, 0, 0, 'dangthiquyen.c3hongai@quangninh.edu.vn', '', '', '01686379146', '', ''),
(5, 'Trần Ngọc Thường', '229366800', 1, '', '0', 1, '0', '', '', 4, 5, 0, 0, '', '', '', '', '', ''),
(6, 'Mai Hoài Thu', '503082000', 1, '', '0', 0, '0', 'Quảng Ninh', 'Tổ 7 Khu 4 phường Hồng Hà-tp Hạ Long', 6, 8, 0, 0, 'maihoaithu.c3hongai@quangninh.edu.vn', '', '', '0902044357', '', ''),
(7, 'Vũ Thị Thu Giang', '106246800', 1, '', '0', 1, '0', '', '', 4, 4, 0, 0, '', '', '', '', '', ''),
(8, 'Đào Duy Hảo', '300819600', 1, '', '0', 0, '0', '', '', 9, 3, 0, 0, '', '', '', '0985052468', '', ''),
(9, 'Trịnh Thị Hòa', '-219999600', 1, '', '0', 1, '0', '', '', 4, 8, 0, 0, '', '', '', '', '', ''),
(10, 'Trần Thúy Vinh', '253472400', 1, '', '0', 1, '0', 'Hải Lăng-quảng Trị', 'Hồng Hải-Hạ Long-Quảng Ninh', 7, 8, 0, 0, 'buithuyvinh.c3hongai@quangninh.edu.vn', '', '', '0914569215', '', 'Là thành viên của tổ Văn trường THPT Hòn Gai.tự nhận thấy là người yêu nghề, mến trẻ, yêu đồng nghiệp...'),
(11, 'Đặng Thị Hải', '-159778800', 1, '', '0', 1, '0', 'Hưng Hà, Thái Bình', 'Phường Hồng Hải, TP Hạ Long', 6, 3, 0, 0, 'dangthihai.c3hongai@quangninh.edu.vn', '', '', '01679386438', '', ''),
(12, 'Nguyễn Đăng Phúc', '-311842800', 1, '', '0', 0, '0', '', '', 4, 8, 0, 0, '', '', '', '', '', ''),
(13, 'Vũ Thị Thu Hường', '443206800', 1, '', '0', 0, '0', '', '', 8, 8, 0, 0, '', '', '', '', '', ''),
(14, 'Nguyễn Thị Dung B', '-244623600', 1, '', '0', 0, '0', '', '', 9, 8, 0, 0, '', '', '', '', '', ''),
(15, 'Phạm Bắc Vinh', '-265359600', 1, '', '0', 0, '0', '', '', 9, 8, 0, 0, '', '', '', '', '', ''),
(16, 'Phạm Ngọc Hà', '107802000', 1, '', '0', 0, '0', '', '', 4, 8, 0, 0, '', '', '', '', '', ''),
(17, 'Nguyễn Thị Hồng Thuý', '-230799600', 1, '', '0', 0, '0', '', '', 9, 8, 0, 0, '', '', '', '', '', ''),
(18, 'Vũ Mạnh Việt', '0', 1, '', '0', 1, '0', '', '', 4, 8, 0, 0, '', '', '', '', '', ''),
(19, 'Lê Thị Thu', '38509200', 1, '', '0', 0, '0', '', '', 9, 8, 0, 0, '', '', '', '', '', ''),
(20, 'Giang Thị Thúy', '230230800', 1, '', '0', 1, '0', '', '', 4, 8, 0, 0, '', '', '', '', '', ''),
(21, 'Đoàn Thị Hồng Cẩm', '0', 1, '', '0', 0, '0', '', '', 9, 5, 0, 0, '', '', '', '', '', ''),
(22, 'Lê Thị Trà Thúy', '318099600', 1, '', '0', 0, '0', '', '', 4, 8, 0, 0, '', '', '', '', '', ''),
(23, 'Vũ Thị Liễu', '204310800', 1, '', '0', 0, '0', '', '', 9, 8, 0, 0, '', '', '', '', '', ''),
(24, 'Trần Thị Thu Hiền', '279133200', 1, '', '0', 0, '0', '', '', 9, 8, 0, 0, '', '', '', '', '', ''),
(25, 'Lê Thị Trà Thúy', '0', 1, '', '0', 0, '0', '', '', 4, 8, 0, 0, '', '', '', '', '', ''),
(26, 'Nguyễn Thu Giang', '292352400', 1, '', '0', 0, '0', '', '', 9, 8, 0, 0, '', '', '', '', '', ''),
(27, 'Phùng Danh Tú', '315853200', 1, '', '0', 0, '0', '', '', 9, 8, 0, 0, '', '', '', '', '', ''),
(28, 'Bùi Thị Hạnh', '367779600', 1, '', '0', 0, '0', '', '', 4, 8, 0, 0, '', '', '', '', '', ''),
(29, 'Nguyễn Thuý Hằng', '396118800', 1, '', '0', 0, '0', '', '', 9, 8, 0, 0, '', '', '', '', '', ''),
(30, 'Nguyễn Thuý Hằng', '396118800', 1, '', '0', 0, '0', '', '', 9, 8, 0, 0, '', '', '', '', '', ''),
(31, 'Bùi Thị Hạnh', '367779600', 1, '', '0', 0, '0', '', '', 4, 8, 0, 0, '', '', '', '', '', ''),
(32, 'Quách Hồng Hiệp', '393872400', 1, '', '0', 0, '0', '', '', 9, 8, 0, 0, '', '', '', '', '', ''),
(33, 'Vũ Thị Bảo Yến', '505933200', 1, '', '0', 0, '0', 'Yên Hưng-Quảng Ninh', 'Phường Hồng Hải-tp Hạ Long', 6, 4, 0, 0, 'vuthibaoyen.c3hongai@quangninh.edu.vn', '', '', '0946639588', '', ''),
(34, 'Vũ Thị Bảo Yến', '536432400', 1, '', '0', 0, '0', 'Yên Hưng-Quảng Ninh', 'Phường Hồng Hải-tp Hạ Long', 6, 4, 0, 0, 'vuthibaoyen.c3hongai@quangninh.edu.vn', '', '', '0946639588', '', ''),
(35, 'Phạm Thị Hồng Hạnh', '378666000', 1, '', '0', 0, '0', 'Quảng Ninh', 'phường Hồng Hải-tp Hạ Long', 6, 5, 0, 0, 'phamthihonghanh.c3hongai@quangninh.edu.v', '', '', '0983565988', '', ''),
(36, 'Nguyễn Thanh Hiền', '-30265200', 1, '', '0', 1, '0', '', '', 8, 3, 0, 0, '', '', '', '', '', ''),
(37, 'Nguyễn Thanh Hiền', '-30265200', 1, '', '0', 1, '0', '', '', 8, 3, 0, 0, '', '', '', '', '', ''),
(38, 'Phạm Xuân Hòa', '-360226800', 1, '', '0', 0, '0', 'Hà Tĩnh', 'Tổ 3 khu 3 phường Hồng Hải Hạ Long Quảng Ninh', 6, 8, 0, 0, 'phamxuanhoa.c3hongai@quangninh.vn', '', '', '', '', ''),
(39, 'Đoàn Quân Hùng', '537814800', 1, '', '0', 0, '0', '', '', 8, 8, 0, 0, '', '', '', '', '', ''),
(40, 'Nguyễn Quỳnh Trang', '225997200', 1, '', '0', 0, '0', 'Thái Bình', 'Hồng Hải-Hạ Long-Quảng Ninh', 6, 8, 0, 0, 'nguyenquynhtrang.c3hongai@quangninh.edu.', '', '', '', '', ''),
(41, 'Nguyễn Bảo Chi', '364669200', 1, '', '0', 0, '0', '', '', 8, 8, 0, 0, '', '', '', '', '', ''),
(42, 'Nguyễn Công Đoàn', '-28450800', 1, '', '0', 1, '0', '', '', 8, 5, 0, 0, '', '', '', '', '', ''),
(43, 'Nguyễn Thị Ngát', '-112604400', 1, '', '0', 0, '0', 'Hải Dương', 'Cao Xanh- Hạ Long', 6, 8, 0, 0, 'nguyenthingat.c3hongai@quangninh.edu.vn', '', '', '', '', ''),
(44, 'Phạm Xuân Hòa', '-360226800', 1, '', '0', 1, '0', 'Hà Tĩnh', 'T3, K3, P Hồng Hải, TP HajnLong', 5, 8, 0, 0, '', '', '', '0982882916', '', ''),
(45, 'Đoàn Quân Hùng', '537814800', 1, '', '0', 0, '0', '', '', 8, 8, 0, 0, '', '', '', '', '', ''),
(46, 'Nguyễn Bảo Chi', '364669200', 1, '', '0', 0, '0', '', '', 8, 8, 0, 0, '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_cbdoan_chucvu`
--

CREATE TABLE `pacorp_vi_cbdoan_chucvu` (
  `macvu` int(3) NOT NULL,
  `tenchucvu` varchar(100) NOT NULL,
  `gt_cv` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_cbdoan_chucvu`
--

INSERT INTO `pacorp_vi_cbdoan_chucvu` (`macvu`, `tenchucvu`, `gt_cv`) VALUES
(1, 'Hiệu trưởng', 'Hiệu trưởng'),
(2, 'Phó hiệu trưởng', 'Phó hiệu trưởng'),
(3, 'Tổ trưởng', 'Tổ trưởng'),
(4, 'Tổ trưởng công đoàn', 'Tổ trưởng công đoàn'),
(5, 'Tổ phó', 'Tổ phó'),
(6, 'Chủ tịch công đoàn', 'Chủ tịch công đoàn'),
(7, 'Phó Chủ tịch công đoàn', 'Phó Chủ tịch công đoàn'),
(8, 'Giáo viên', 'Giáo viên nhà trường');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_cbdoan_donvi`
--

CREATE TABLE `pacorp_vi_cbdoan_donvi` (
  `madvi` int(3) NOT NULL,
  `tendonvi` varchar(100) NOT NULL,
  `gt_dv` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_cbdoan_donvi`
--

INSERT INTO `pacorp_vi_cbdoan_donvi` (`madvi`, `tendonvi`, `gt_dv`) VALUES
(2, 'Ban giám hiệu', 'Ban giám hiệu nhà trường'),
(3, 'BCH Công đoàn', 'BCH Công đoàn'),
(4, 'Tổ Ngoại Ngữ', ''),
(5, 'Nhóm Địa lí', 'Nhóm Địa lí có tất cả 5 thành viên.'),
(6, 'Tổ sử địa gdcd', 'Tổ sử địa gdcd'),
(7, 'tổ ngữ văn', ''),
(8, 'Tổ Thể dục-Nhạc-Họa', ''),
(9, 'Tổ Toán - Tin học', '');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_comment`
--

CREATE TABLE `pacorp_vi_comment` (
  `cid` mediumint(8) UNSIGNED NOT NULL,
  `module` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` int(11) NOT NULL DEFAULT '0',
  `id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `pid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `userid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `post_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_ip` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `likes` mediumint(9) NOT NULL DEFAULT '0',
  `dislikes` mediumint(9) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_contact_department`
--

CREATE TABLE `pacorp_vi_contact_department` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `full_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `others` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cats` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `admins` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `act` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `weight` smallint(5) NOT NULL,
  `is_default` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_contact_department`
--

INSERT INTO `pacorp_vi_contact_department` (`id`, `full_name`, `alias`, `image`, `phone`, `fax`, `email`, `address`, `note`, `others`, `cats`, `admins`, `act`, `weight`, `is_default`) VALUES
(1, 'Văn phòng', 'Van-phong', '', '&#40;033&#41; 3.000.000&#91;+84333.000.000&#93;', '0333.000.000', 'admin@thpthongai.edu.vn', '', 'Bộ phận tiếp nhận và giải quyết các yêu cầu, đề nghị, ý kiến liên quan đến hoạt động chính của nhà trường.', '[]', 'Liên hệ công tác|Khiếu nại, phản ánh|Đề nghị hợp tác', '1/1/1/0', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_contact_reply`
--

CREATE TABLE `pacorp_vi_contact_reply` (
  `rid` mediumint(8) UNSIGNED NOT NULL,
  `id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `reply_content` text COLLATE utf8mb4_unicode_ci,
  `reply_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_contact_send`
--

CREATE TABLE `pacorp_vi_contact_send` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `cid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `cat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `send_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `sender_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sender_ip` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_download`
--

CREATE TABLE `pacorp_vi_download` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `introtext` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploadtime` int(11) UNSIGNED NOT NULL,
  `updatetime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` mediumint(8) UNSIGNED NOT NULL,
  `user_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_email` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileupload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `linkdirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filesize` int(11) NOT NULL DEFAULT '0',
  `fileimage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `copyright` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_hits` int(11) NOT NULL DEFAULT '0',
  `download_hits` int(11) NOT NULL DEFAULT '0',
  `groups_comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `groups_view` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `groups_download` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_hits` int(11) NOT NULL DEFAULT '0',
  `rating_detail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_download`
--

INSERT INTO `pacorp_vi_download` (`id`, `catid`, `title`, `alias`, `description`, `introtext`, `uploadtime`, `updatetime`, `user_id`, `user_name`, `author_name`, `author_email`, `author_url`, `fileupload`, `linkdirect`, `version`, `filesize`, `fileimage`, `status`, `copyright`, `view_hits`, `download_hits`, `groups_comment`, `groups_view`, `groups_download`, `comment_hits`, `rating_detail`) VALUES
(1, 2, 'Speaking topics-g10 &#40;2015-2016&#41;', 'Speaking-topics-g10-2015-2016', '1.&nbsp;&nbsp; &nbsp;Talk about your daily routine.<br  />\r\n2.&nbsp;&nbsp; &nbsp;Talk about your school work. (subjects, classes, tests, examinations, homework, ect.Suggestion-P47)<br  />\r\n3.&nbsp;&nbsp; &nbsp;Talk about the background of a person you know well.<br  />\r\n4.&nbsp;&nbsp; &nbsp;Talk about one of the mass media you like.(suggestion-p76)<br  />\r\n5.&nbsp;&nbsp; &nbsp;Talk about the picnic you enjoyed most.(suggesstion-p68)', 'SPEAKING TOPICS - Grade 10', 1454383435, 1454383435, 6, 'english-hhg', 'Tổng hợp', '', '', '/download/files/speaking-topics10cb2015.doc', '', '', 24064, '', 1, '', 23, 4, '4', '6', '6', 0, ''),
(2, 5, 'Đề thi thử THPTQG lần 1 &amp; Đáp án năm học 2015 - 2016', 'De-thi-thu-dai-hoc-lan-1-Dap-an-nam-hoc-2015-2016', '<img alt="1 DE" height="1008" src="/uploads/about/1-de.jpg" width="674" /><br  />\r\n<img alt="2 DA" height="972" src="/uploads/download/2-da.jpg" width="752" /><br  />\r\n<img alt="3 DA" height="1084" src="/uploads/download/3-da.jpg" width="764" /><br  />\r\n<img alt="4 DA" src="/uploads/download/4-da.jpg" /><br  />\r\n<img alt="5 DA" height="1090" src="/uploads/download/5-da.jpg" width="734" /><br  />\r\n<img alt="6 DA" height="804" src="/uploads/download/6-da.jpg" width="776" /><br  />\r\n<img alt="7 DA" height="952" src="/uploads/download/7-da.jpg" width="752" />', '', 1454383736, 1454383916, 5, 'daongan1991', 'Tổ Toán - Tin &#40;THPT Hòn Gai&#41;', '', '', '/download/files/thi-thu-dh-lan-1c3-hg-15-16-1.doc', '', 'Đề thi file doc', 2193920, '', 1, '', 21, 4, '4', '6', '6', 0, ''),
(3, 5, 'ĐỀ THI THỬ THPT QG LẦN 1 MÔN VẬT LÍ', 'DE-THI-THU-THPT-QG-LAN-1-MON-VAT-LI', '', '', 1454383840, 1454383840, 14, 'vatlihg', 'GV CHU THẾ NAM', 'chuthenam.c3hongai@quangninh.edu.vn', '', '/download/files/de-thi-thu-lan-1-2016.rar', '', '', 273590, '', 1, '', 27, 3, '4', '6', '6', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_download_categories`
--

CREATE TABLE `pacorp_vi_download_categories` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `parentid` smallint(5) UNSIGNED NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `groups_view` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `groups_download` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `viewcat` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'viewcat_list_new',
  `numlink` smallint(4) DEFAULT '3',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `weight` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_download_categories`
--

INSERT INTO `pacorp_vi_download_categories` (`id`, `parentid`, `title`, `alias`, `description`, `groups_view`, `groups_download`, `numsubcat`, `subcatid`, `viewcat`, `numlink`, `sort`, `lev`, `weight`, `status`) VALUES
(1, 0, 'Giáo án', 'Giao-an', 'Giáo án', '6', '6', 0, '', 'viewcat_list_new', 3, 1, 0, 1, 1),
(2, 0, 'Tài liệu chuyên môn', 'Tai-lieu-chuyen-mon', 'Tài liệu chuyên môn', '6', '6', 0, '', 'viewcat_list_new', 3, 2, 0, 2, 1),
(3, 0, 'Phần mềm giáo dục', 'Phan-mem-giao-duc', 'Phần mềm giáo dục', '6', '6', 0, '', 'viewcat_list_new', 3, 3, 0, 3, 1),
(4, 0, 'Phần mềm tiện ích', 'Phan-mem-tien-ich', 'Phần mềm tiện ích', '6', '6', 0, '', 'viewcat_list_new', 3, 4, 0, 4, 1),
(5, 0, 'Đề thi &amp; Đáp án', 'De-thi-Dap-an', 'Tổng hợp các đề thi - đáp án', '6', '6', 0, '', 'viewcat_list_new', 3, 5, 0, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_download_config`
--

CREATE TABLE `pacorp_vi_download_config` (
  `config_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_download_config`
--

INSERT INTO `pacorp_vi_download_config` (`config_name`, `config_value`) VALUES
('indexfile', 'viewcat_main_bottom'),
('viewlist_type', 'list'),
('per_page_home', '20'),
('per_page_child', '20'),
('is_addfile', '1'),
('groups_upload', '4'),
('maxfilesize', '8388608'),
('upload_filetype', 'adobe,archives,audio,documents,flash,images,real,video'),
('groups_addfile', '4'),
('tags_alias', '0'),
('is_zip', '0'),
('is_resume', '1'),
('max_speed', '0');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_download_report`
--

CREATE TABLE `pacorp_vi_download_report` (
  `fid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `post_ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_download_report`
--

INSERT INTO `pacorp_vi_download_report` (`fid`, `post_ip`, `post_time`) VALUES
(3, '14.169.34.188', 1455255130);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_download_tags`
--

CREATE TABLE `pacorp_vi_download_tags` (
  `did` mediumint(8) UNSIGNED NOT NULL,
  `numdownload` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_download_tags_id`
--

CREATE TABLE `pacorp_vi_download_tags_id` (
  `id` int(11) NOT NULL,
  `did` mediumint(9) NOT NULL,
  `keyword` varchar(65) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_download_tmp`
--

CREATE TABLE `pacorp_vi_download_tmp` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `catid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `introtext` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploadtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `user_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_email` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileupload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `linkdirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filesize` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileimage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `copyright` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_faq`
--

CREATE TABLE `pacorp_vi_faq` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `catid` mediumint(8) UNSIGNED NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_faq_categories`
--

CREATE TABLE `pacorp_vi_faq_categories` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `parentid` mediumint(8) UNSIGNED NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `groups_view` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `keywords` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_faq_config`
--

CREATE TABLE `pacorp_vi_faq_config` (
  `config_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_faq_config`
--

INSERT INTO `pacorp_vi_faq_config` (`config_name`, `config_value`) VALUES
('type_main', '0');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_laws_cat`
--

CREATE TABLE `pacorp_vi_laws_cat` (
  `catid` mediumint(8) UNSIGNED NOT NULL,
  `parentid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `thumbnail` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `orders` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) UNSIGNED NOT NULL DEFAULT '3',
  `keywords` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `admins` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edit_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `del_cache_time` int(11) NOT NULL DEFAULT '0',
  `who_view` tinyint(2) UNSIGNED NOT NULL DEFAULT '0',
  `groups_view` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `numrow` int(8) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_laws_cat`
--

INSERT INTO `pacorp_vi_laws_cat` (`catid`, `parentid`, `title`, `alias`, `description`, `image`, `thumbnail`, `weight`, `orders`, `lev`, `viewcat`, `numsubcat`, `subcatid`, `inhome`, `numlinks`, `keywords`, `admins`, `add_time`, `edit_time`, `del_cache_time`, `who_view`, `groups_view`, `numrow`) VALUES
(1, 0, 'Công văn', 'Cong-van', '', '', '', 1, 1, 0, 'viewcat_list', 0, '', 1, 3, '', '', 1453914369, 1453914369, 1479914369, 0, '', 1),
(2, 0, 'Quy chế', 'Quy-che', 'Quy chế', '', '', 2, 2, 0, 'viewcat_list', 0, '', 1, 3, 'Quy chế', '', 1454009639, 1454009639, 1480009639, 0, '', 1),
(3, 0, 'Thông tư', 'Thong-tu', 'Thông tư', '', '', 3, 3, 0, 'viewcat_list', 0, '', 1, 3, 'Thông tư', '', 1454009651, 1454009651, 1480009651, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_laws_field`
--

CREATE TABLE `pacorp_vi_laws_field` (
  `fieldid` mediumint(8) UNSIGNED NOT NULL,
  `parentid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `orders` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `numsubfield` int(11) NOT NULL DEFAULT '0',
  `subfieldid` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `keywords` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `admins` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edit_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_laws_field`
--

INSERT INTO `pacorp_vi_laws_field` (`fieldid`, `parentid`, `title`, `alias`, `description`, `weight`, `orders`, `lev`, `numsubfield`, `subfieldid`, `keywords`, `admins`, `add_time`, `edit_time`) VALUES
(1, 0, 'Giáo dục', 'Giao-duc', 'Giáo dục', 1, 1, 0, 0, '', 'Giáo dục', '', 1454009311, 1454009311),
(2, 0, 'Công đoàn', 'Cong-doan', 'Công đoàn', 2, 2, 0, 0, '', 'Công đoàn', '', 1454009323, 1454009323),
(3, 0, 'Công tác đảng', 'Cong-tac-dang', 'Công tác đảng', 4, 4, 0, 0, '', 'Công tác đảng', '', 1454009340, 1454009340),
(4, 0, 'Công tác cán bộ', 'Cong-tac-can-bo', 'Công tác cán bộ', 3, 3, 0, 0, '', 'Công tác cán bộ', '', 1454009358, 1454009358);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_laws_organ`
--

CREATE TABLE `pacorp_vi_laws_organ` (
  `organid` mediumint(8) UNSIGNED NOT NULL,
  `parentid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `orders` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `numsuborgan` int(11) NOT NULL DEFAULT '0',
  `suborganid` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `keywords` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `admins` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edit_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_laws_organ`
--

INSERT INTO `pacorp_vi_laws_organ` (`organid`, `parentid`, `title`, `alias`, `description`, `weight`, `orders`, `lev`, `numsuborgan`, `suborganid`, `keywords`, `admins`, `add_time`, `edit_time`) VALUES
(1, 0, 'Nhà trường', 'Nha-truong', 'Nhà trường', 1, 1, 0, 0, '', 'Nhà trường', '', 1454009371, 1454009371),
(2, 0, 'Sở GD&ĐT', 'So-GD-DT', 'Sở GD&amp;ĐT', 2, 2, 0, 0, '', 'Sở GD&ĐT', '', 1454009391, 1454009391),
(3, 0, 'Bộ GD&ĐT', 'Bo-GD-DT', 'Bộ GD&amp;ĐT', 4, 4, 0, 0, '', 'Bộ GD&ĐT', '', 1454009406, 1454009406),
(4, 0, 'Công đoàn ngành', 'Cong-doan-nganh', 'Công đoàn ngành', 3, 3, 0, 0, '', 'Công đoàn ngành', '', 1454009419, 1454009419);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_laws_room`
--

CREATE TABLE `pacorp_vi_laws_room` (
  `roomid` mediumint(8) UNSIGNED NOT NULL,
  `parentid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(4) UNSIGNED NOT NULL DEFAULT '0',
  `orders` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `numsubroom` int(11) NOT NULL DEFAULT '0',
  `subroomid` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `keywords` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `admins` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edit_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_laws_room`
--

INSERT INTO `pacorp_vi_laws_room` (`roomid`, `parentid`, `title`, `alias`, `description`, `weight`, `orders`, `lev`, `numsubroom`, `subroomid`, `keywords`, `admins`, `add_time`, `edit_time`) VALUES
(1, 0, 'Sở GD&ĐT', 'So-GD-DT', 'Sở GD&amp;ĐT', 1, 1, 0, 3, '2,3,4', 'Sở GD&ĐT', '', 1454009454, 1454009454),
(2, 1, 'Phòng GDTrH', 'Phong-GDTrH', 'Phòng GDTrH', 1, 2, 1, 0, '', 'Phòng GDTrH', '', 1454009473, 1454009473),
(3, 1, 'Phòng KT&KĐCL', 'Phong-KT-KDCL', 'Phòng KT&amp;KĐCL', 2, 3, 1, 0, '', 'Phòng KT&KĐCL', '', 1454009494, 1454009494),
(4, 1, 'Văn phòng Sở', 'Van-phong-So', 'Văn phòng Sở', 3, 4, 1, 0, '', 'Văn phòng Sở', '', 1454009510, 1454009510),
(5, 0, 'Nhà trường', 'Nha-truong', 'Nhà trường', 2, 5, 0, 0, '', 'Nhà trường', '', 1454009529, 1454009529),
(6, 0, 'Công đoàn trường', 'Cong-doan-truong', 'Công đoàn trường', 5, 10, 0, 0, '', 'Công đoàn trường', '', 1454009547, 1454009547),
(7, 0, 'Đoàn thanh niên', 'Doan-thanh-nien', 'Đoàn thanh niên', 4, 9, 0, 0, '', 'Đoàn thanh niên', '', 1454009559, 1454009559),
(8, 0, 'Bộ GD&ĐT', 'Bo-GD-DT', 'Bộ GD&amp;ĐT', 3, 6, 0, 2, '9,10', 'Bộ GD&ĐT', '', 1454041562, 1454041562),
(9, 8, 'Vụ GDTrH', 'Vu-GDTrH', 'Vụ GDTrH', 1, 7, 1, 0, '', 'Vụ GDTrH', '', 1454041588, 1454041600),
(10, 8, 'Cục nhà giáo', 'Cuc-nha-giao', 'Cục nhà giáo', 2, 8, 1, 0, '', 'Cục nhà giáo', '', 1454041615, 1454041615);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_laws_rows`
--

CREATE TABLE `pacorp_vi_laws_rows` (
  `id` int(11) NOT NULL,
  `catid` int(11) NOT NULL DEFAULT '0',
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hometext` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `bodytext` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `filepath` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `otherpath` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `roomid` int(11) NOT NULL DEFAULT '0',
  `fieldid` int(11) NOT NULL DEFAULT '0',
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `down` int(8) NOT NULL DEFAULT '0',
  `view` int(8) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT '0',
  `type` int(2) NOT NULL DEFAULT '0',
  `sign` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `signtime` int(11) NOT NULL DEFAULT '0',
  `organid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_laws_rows`
--

INSERT INTO `pacorp_vi_laws_rows` (`id`, `catid`, `title`, `alias`, `hometext`, `bodytext`, `keywords`, `filepath`, `otherpath`, `roomid`, `fieldid`, `addtime`, `edittime`, `down`, `view`, `userid`, `status`, `type`, `sign`, `signtime`, `organid`) VALUES
(1, 1, 'Tiêu chí chấm GVST trên nền tảng CNTT', 'Tieu-chi-cham-GVST-tren-nen-tang-CNTT', 'QUYẾT  ĐỊNHBan hành Tiêu chí chấm thi cuộc thi  “Giáo viên sáng tạo trên nền tảng công nghệ thông tin năm 2016”', '<table align="center" border="0" cellpadding="0" cellspacing="0" style="width:650px;" width="650">	<tbody>		<tr>			<td style="width:272px;">BỘ GIÁO DỤC VÀ ĐÀO TẠO<br  />			<strong>CỤC NHÀ GIÁO VÀ CÁN BỘ QUẢN LÝ CƠ SỞ GIÁO DỤC</strong><br  />			<br  />			Số: 15/QĐ-NGCBQLCSGD</td>			<td style="width:378px;"><strong>CỘNG HOÀ XÃ HỘI CHỦ NGHĨA VIỆT NAM</strong><br  />			<strong>Độc lập - Tự do – Hạnh phúc</strong><br  />			<br  />			<br clear="ALL" />			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<em>Hà Nội, ngày 06 &nbsp;tháng 1 năm 2016</em></td>		</tr>	</tbody></table><div style="clear:both;">&nbsp;</div><div style="text-align: center;"><strong>QUYẾT&nbsp; ĐỊNH</strong><br  /><strong>Ban hành Tiêu chí chấm thi cuộc thi</strong><br  /><strong>&nbsp;“Giáo viên sáng tạo trên nền tảng công nghệ thông tin năm 2016”</strong></div><div style="text-align: center;"><strong>CỤC</strong><strong> TRƯỞNG </strong><strong>CỤC NHÀ GIÁO </strong><br  /><strong>VÀ CÁN BỘ QUẢN LÝ CƠ SỞ GIÁO DỤC</strong></div>Căn cứ Quyết định số 3535/QĐ-BGDĐT ngày 09 tháng 9 năm 2014 của Bộ trưởng Bộ Giáo dục và Đào tạo quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của các đơn vị giúp Bộ trưởng thực hiện chức năng quản lý nhà nước thuộc Bộ Giáo dục và Đào tạo;<br  />Căn cứ Kế hoạch số 1122/KH-BGDĐT ngày 17 tháng 11 năm 2015 của Bộ Giáo dục và Đào tạo về việc thực hiện các nhiệm vụ hợp tác với Microsoft Việt Nam năm 2016;<br  />Căn cứ Quyết định số 5707/QĐ – BGDĐT ngày 17 tháng 11 năm 2015 của Bộ trưởng Bộ Giáo dục và Đào tạo ban hành “thể lệ cuộc thi giáo viên sáng tạo trên nền tảng công nghệ thông tin năm 2016”;<br  />Xét đề nghị của Trưởng phòng Nhà giáo,<br  />&nbsp;<div style="text-align: center;"><strong>QUYẾT ĐỊNH:</strong></div><strong>Điều 1</strong>. Ban hành kèm theo Quyết định này&nbsp; Tiêu chí chấm thi cuộc thi “Giáo viên sáng tạo trên nền tảng công nghệ thông tin năm 2016”<br  /><strong>Điều 2.</strong> Tiêu chí này được dùng để đánh giá các bài thi trong cuộc thi “Giáo viên sáng tạo trên nền tảng công nghệ thông tin năm 2016”<br  /><strong>Điều 3.</strong> Quyết định này có hiệu lực kể từ ngày ký. Chánh Văn phòng, Trưởng phòng Nhà giáo, Thủ trưởng các đơn vị có liên quan chịu trách nhiệm thi hành Quyết định này./.<br  />&nbsp;<table align="center" border="0" cellpadding="0" cellspacing="0">	<tbody>		<tr>			<td style="width:327px;"><strong><em>Nơi nhận:</em></strong><br  />			&nbsp;<br  />			- Bộ trưởng (để báo cáo);<br  />			- TT Nguyễn Vinh Hiển (để b/cáo);<br  />			- Microsoft Việt Nam (để phối hợp);<br  />			- Tr. Tâm NC &amp; SX HL – ĐHSPHN (để thực hiện);<br  />			- Như điều 3 (để thực hiện);<br  />			- Lưu: VT, NG.<br  />			&nbsp;</td>			<td style="width:270px;"><strong>CỤC TRƯỞNG</strong><br  />			&nbsp;<br  />			&nbsp;<br  />			&nbsp;<br  />			&nbsp;<br  />			&nbsp;<br  />			<strong>Hoàng Đức Minh</strong></td>		</tr>	</tbody></table><div style="clear:both;">&nbsp;</div>&nbsp;<br  />&nbsp;<div style="text-align: center;"><strong>TIÊU CHÍ CHẤM THI</strong><br  /><strong>Cuộc thi giáo viên sáng tạo trên nền tảng công nghệ thông tin năm 2016</strong><br  /><br clear="ALL" /><em>(Ban hành kèm theo Quyết định số&nbsp; 15/QĐ-NGCBQLCSGD</em><br  /><em>&nbsp;ngày 06 tháng 1 năm 2016 của Cục trưởng Cục Nhà giáo và Cán bộ quản lý cơ sở giáo dục)</em></div>&nbsp;<br  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Sản phẩm dự thi của giáo viên tham gia cuộc thi “Giáo viên sáng tạo trên nền tảng công nghệ thông tin năm 2016” (sau đây gọi chung là sản phẩm dự thi) sẽ được chấm qua 3 vòng, bao gồm chấm vòng 1, chấm vòng 2 và chấm chung khảo để chọn ra các sản phẩm đạt giải.<br  /><strong>I. Hình thức chấm thi</strong><br  /><em>Chấm vòng 1</em><br  />Tại vòng chấm này, tất cả các sản phẩm dự thi được chấm tại nơi làm việc của Hội đồng chấm thi để chọn ra tối đa 200 sản phẩm dự thi vào chấm vòng 2.<br  /><em>Chấm vòng 2</em><br  />Tại vòng chấm này, các sản phẩm dự thi được chọn từ vòng 1 được chấm tại nơi làm việc của Hội đồng chấm thi để chọn ra tối đa 80 sản phẩm vào chấm chung khảo.<br  /><em>Chấm chung khảo</em><br  />Tại vòng chấm này, các sản phẩm được chọn ra từ vòng 2 được chấm theo hai công đoạn như sau:<br  />- Công đoạn 1: Sản phẩm dự thi được chấm tại nơi làm việc của Hội đồng chấm thi theo tiêu chí chấm quy định tại mục 1 phần II.<br  />- Công đoạn 2: Sản phẩm dự thi được chấm trực tiếp tại địa điểm tổ chức tổng kết cuộc thi theo tiêu chí chấm thi trực tiếp được quy định tại mục 2 phần II. Giáo viên có sản phẩm dự thi được mời đến địa điểm tổ chức tổng kết cuộc thi để trình bày, thuyết minh về sản phẩm dự thi. Nội dung thuyết minh trình bày trên 1 tờ giấy khổ A0 và máy tính xách tay kèm theo các minh họa cần thiết cho sản phẩm dự thi.<br  /><strong>II. Tiêu chí chấm thi</strong><br  /><strong>1. Tiêu chí chấm chung cho cả 3 vòng </strong><br  />Sản phẩm dự thi của giáo viên được chấm theo thang điểm 100 và được đánh giá theo các tiêu chí sau đây:<br  /><em>1. Tiêu chí 1:&nbsp; Lập kế hoạch và thiết kế môi trường học tập (1-12 điểm).</em><br  />&nbsp;Sản phẩm dự thi sẽ được đánh giá dựa trên các thành tố sau: Cách lập kế hoạch của hoạt động học tập (HĐHT); Mục tiêu và đầu ra của HĐHT; Học sinh có tham gia lập kế hoạch, đánh giá và chỉnh sửa công việc của mình; Việc lập kế hoạch HĐHT có tạo điều kiện cho sự phát triển các kỹ năng thế kỷ 21 của học sinh (ví dụ: xây dựng tri thức, sử dụng CNTT vào học tập, giải quyết vấn đề, tự kỷ luật, kỹ năng hợp tác và giao tiếp...).<br  />Yêu cầu: Đưa ra được bản kế hoạch chung, thể hiện được tính sáng tạo, sự đổi mới trong phương pháp giảng dạy và các HĐHT cho học sinh.<br  /><em>2. Tiêu chí 2: Bài trình bày của HĐHT &nbsp;–&nbsp; Bằng chứng cụ thể của việc học tập (1-8 điểm)</em>.<br  />&nbsp;Sản phẩm dự thi sẽ được đánh giá dựa trên các thành tố sau: &nbsp;Những hoạt động của học sinh chứng minh được việc lập kế hoạch học tập; Hoạt động học tập của học sinh thể hiện được các khía cạnh của kỹ năng thế kỷ 21 ( ví dụ: xây dựng tri thức, sử dụng CNTT vào học tập, giải quyết vấn đề, tự kỷ luật, kỹ năng hợp tác và giao tiếp...).<br  />Yêu cầu: Trình bày được sản phẩm và đầu ra của học sinh, có bằng chứng cụ thể của việc học sinh được tham gia trong suốt quá trình làm sản phẩm bao gồm cả việc sử dụng CNTT một cách đột phá.<br  /><em>3. Tiêu chí 3:&nbsp; Hợp tác (1-16 điểm).</em><br  />Sản phẩm dự thi sẽ được đánh giá dựa trên các thành tố sau: &nbsp;HĐHT thể hiện năng lực học sinh trong hợp tác, thương lượng với người học khác và đưa ra những quyết định độc lập để hình thành nội dung, quy trình hay sản phẩm của chính các em; Học sinh được làm việc cùng nhau trong HĐHT.<br  />Yêu cầu: HĐHT đòi hỏi học sinh làm việc hợp tác, đồng thời đưa ra các quyết định độc lập để phát triển sản phẩm chung để tạo nên sự thành công của nhóm. Học sinh có thể hợp tác với các bạn trong lớp hoặc những người lớn ngoài lớp học.<br  /><em>4. Tiêu chí 4: Xây dựng tri thức và khả năng tư duy phản biện (1-16 điểm).</em><br  />Sản phẩm dự thi sẽ được đánh giá dựa trên các thành tố sau: HĐHT kích thích khả năng xây dựng và áp dụng kiến thức của học sinh ở mức độ nào? và những kiến thức đó có phải là kiến thức liên môn không?&nbsp;<br  />Yêu cầu: Học sinh vượt lên khỏi việc lặp lại những gì các em được học trong lớp để xây dựng tri thức thông qua việc hiểu sâu, phân tích, tổng hợp, đánh giá. Những HĐHT này đòi hỏi học sinh tạo ra ý tưởng hoặc những hiểu biết mới để ứng dụng những kiến thức đã học vào các bối cảnh khác nhau và có sự liên kết thông tin, ý tưởng từ hai hay nhiều môn học với nhau.<br  /><em>5. Tiêu chí 5: Mở rộng học tập ra bên ngoài lớp học (1 -16 điểm).</em><br  />Sản phẩm dự thi sẽ được đánh giá dựa trên các thành tố sau: HĐHT đòi hỏi kỹ năng giải quyết vấn đề ở mức độ nào? Những giải pháp của học sinh có được áp dụng trong đời thực không?&nbsp; &nbsp;<br  />Yêu cầu: HĐHT không chỉ gói gọn trong 4 bức tường lớp học, trong thời lượng học của những tiết học truyền thống, theo các môn học chuẩn mực mà mở rộng ra phạm vi ngoài lớp học, gắn với đời sống thật. Ý tưởng, thiết kế, giải pháp của học sinh được đưa vào thực hành với đối tượng ngoài lớp học và có tác động tích cực tới cộng đồng địa phương hoặc thế giới .<br  /><em>6. Tiêu chí 6:&nbsp; Sử dụng CNTT vào giảng dạy và học tập một cách đột phá (1-16 điểm).</em><br  />Sản phẩm dự thi sẽ được đánh giá dựa trên các thành tố sau: Sử dụng CNTT theo hướng hỗ trợ xây dựng tri thức, hợp tác, học tập bên ngoài lớp học; Việc sử dụng CNTT tạo điều kiện cho xây dựng tri thức mới, mở rộng cơ hội học tập ra ngoài lớp học; Các công cụ CNTT được sử dụng một cách sáng tạo, đột phá để hỗ trợ quá trình học tập; Học sinh là đối tượng sử dụng CNTT một cách chủ động và tích cực, là người thiết kế các sản phẩm CNTT phục vụ vào HĐHT.<br  />Yêu cầu: HĐHT lôi kéo học sinh tham gia sử dụng CNTT – CNTT giúp học sinh xây dựng tri thức, mở rộng học tập ra bên ngoài lớp học; Học sinh sẽ gặp khó khăn khi xây dựng tri thức, mở rộng học tập bên ngoài lớp học ở mức độ đó nếu không sử dụng CNTT.<br  /><em>7. Tiêu chí 7: Giáo viên là người sáng tạo, là nhân tố tạo thay đổi (1-16 điểm).</em><br  />Sản phẩm dự thi sẽ được đánh giá dựa trên các thành tố sau: Giáo viên thay đổi quy trình học tập giảng dạy một cách đáng kể bằng việc sử dụng CNTT; Giáo viên tạo nên sự khác biệt vượt ra khỏi môi trường lớp học truyền thống.<br  />Yêu cầu: Trong những môi trường mà việc đổi mới dạy học là một thử thách, những thực hành giảng dạy sáng tạo và các công cụ CNTT được sử dụng một cách thực tế để thay đổi việc học tập của học sinh. Giáo viên thể hiện được những bằng chứng về sự liên tục cải thiện trong công tác chuyên môn, tạo hình mẫu về việc học tập suốt đời&nbsp; và sự tiên phong đi đầu của mình trong cộng đồng chuyên môn bằng cách hỗ trợ sự phát triển của các giáo viên khác và thúc đẩy sự hiểu biết của đồng nghiệp về tác động tích cực của sử dụng CNTT hiệu quả lên việc giảng dạy và học tập.<br  /><strong>2. Tiêu chí chấm thi trực tiếp vòng chung khảo</strong><br  />Ngoài các tiêu chí chung được áp dụng cho cả 3 vòng như trên, vòng chung khảo được chấm thêm các tiêu chí sau đây cho công đoạn chấm trực tiếp theo thang điểm 100.<br  /><em>1. Chuẩn bị (1-10 điểm)</em><br  />Giáo viên tự chuẩn bị đầy đủ các điều kiện cần thiết theo yêu cầu để tham gia trình bày sản phẩm dự thi của mình. Cụ thể:<br  />- 1 tờ giấy khổ A0: ghi rõ tiêu đề sản phẩm dự thi, trình bày các thuyết minh, hình ảnh, minh họa sản phẩm dự thi của mình trên đó.<br  />- Một máy tính xách tay: có lưu sẵn bài trình bày, video (không quá 5 phút) và các phần mềm, tài liệu liên quan đến sản phẩm dự thi.<br  />- Các sản phẩm (nếu có) để dẫn chứng cụ thể hơn cho kết quả của sản phẩm dự thi.<br  /><em>2. Trình bày (1 - 40&nbsp; điểm)</em><br  />Giáo viên giới thiệu về sản phẩm dự thi của mình. Thời gian trình bày không quá 10 phút (bao gồm cả trình chiếu video nếu cần thiết).<br  /><em>3. Trả lời câu hỏi (1-30 điểm)</em><br  />Giáo viên trả lời các câu hỏi do Hội đồng chấm thi đưa ra. Phần hỏi đáp không quá 5 phút.<br  /><em>4. Tiếng Anh (1-20 điểm)</em><br  />Giáo viên trả lời một hoặc một số câu hỏi bằng Tiếng Anh do Hội đồng chấm thi đặt ra (<em>để giáo viên có cơ hội được chọn tham gia quốc tế trình bày sản phẩm, tiếng Anh là một tiêu chí để đánh giá.) </em>Phần hỏi đáp tiếng Anh không quá 5 phút.<br  />Hội đồng chấm thi sẽ nghe trình bày của từng thí sinh theo thứ tự và chấm điểm.<br  />Thời gian dành cho phần thi của mỗi giáo viên tối đa không quá 20 phút.<br  />&nbsp;<table border="0" cellpadding="0" cellspacing="0">	<tbody>		<tr>			<td style="width:313px;">&nbsp;</td>			<td style="width:313px;"><strong>CỤC TRƯỞNG</strong><br  />			&nbsp;<br  />			&nbsp;<br  />			&nbsp;<br  />			&nbsp;<br  />			<strong>Hoàng Đức Minh</strong><br  />			&nbsp;</td>		</tr>	</tbody></table>', 'thi GVST,GVST trên nền tảng CNTT, giáo viên sáng tạo 2016', '2016_01/tieu-chi-cham-thi-gvst-2016.doc', '', 10, 1, 1453914383, 1454041698, 20, 45, 1, 1, 2, 'Hoàng Đức Minh', 1453955280, 3),
(2, 2, 'Quy chế thực hiện dân chủ', 'Quy-che-thuc-hien-dan-chu', 'QUY CHẾ THỰC HIỆN DÂN CHỦ TRONG HOẠT ĐỘNG CỦA NHÀ TRƯỜNG', '<div style="text-align: center;"><strong>CHƯƠNG I:&nbsp;</strong><strong>NHỮNG QUY ĐỊNH CHUNG</strong></div>&nbsp;<strong><u>Điều 1</u></strong><strong>: Mục đích thực hiện dân chủ trong nhà trường.</strong><br  />1. Thực hiện có hiệu quả những điều trong Luật giáo dục và quyết định số 04/2000/QĐ BGD&amp;ĐT ngày 01/03/2000 của Bộ trưởng Bộ GD&amp;ĐT về việc &quot;Ban hành Quy chế dân chủ trong hoạt động của nhà trường&quot; theo phương châm &quot;Dân biết, dân bàn, dân làm, dân kiểm tra&quot;.<br  />2. Phát huy quyền làm chủ và tiềm năng, trí tuệ của tập thể cán bộ viên chức, xây dựng nhà trường trong sạch, vững mạnh góp phần tích cực vào việc đấu tranh, ngăn chặn nạn tham nhũng, lãng phí, quan liêu, phiền hà sách nhiễu dân.<br  /><strong><u>Điều 2</u></strong><strong>: Nguyên tắc thực hiện dân chủ trong nhà trường.</strong><br  />1. Đảm bảo sự lãnh đạo của Đảng bộ nhà trường theo nguyên tắc tập trung dân chủ, thực hiện trách nhiệm của Hiệu trưởng và phát huy vai trò của tổ chức đoàn thể quần chúng, nhất là Công đoàn. Đồng thời kiên quyết xử lý những hành vi lợi dụng dân chủ, vi phạm pháp luật, cản trở người thi hành công vụ ở cơ quan, gây rối mất đoàn kết trong nội bộ.<br  />2. Mỗi cán bộ, viên chức trong nhà trường cần nghiên cứu nắm vững quy chế thực hiện dân chủ trong hoạt động của nhà trường, nhận thức rõ trách nhiệm, quyền hạn của mình trong việc thực hiện Quy chế dân chủ.<br  />3. Việc thực hiện Quy chế dân chủ trong nhà trường phải phù hợp với Hiến pháp và Pháp luật; quyền phải đi đôi với nghĩa vụ và trách nhiệm; dân chủ phải gắn liền với kỷ luật, kỷ cương trong nhà trường.<br  />&nbsp;<div style="text-align: center;"><strong>CHƯƠNG II:&nbsp;</strong><strong>NỘI DUNG CỤ THỂ VỀ THỰC HIỆN DÂN CHỦ T</strong><strong>RONG HOẠT ĐỘNG NHÀ TRƯỜNG</strong></div><strong>MỤC I: TRÁCH NHIỆM CỦA HIỆU TRƯỞNG.</strong><br  /><strong><u>Điều 3</u></strong><strong>: Hiệu trưởng có trách nhiệm.</strong><br  />1. Quản lý điều hành mọi hoạt động của nhà trường, đảm bảo sự lãnh đạo của Đảng, chịu trách nhiệm trước Pháp luật và cấp trên về toàn bộ hoạt động của nhà trường.<br  />2. Phân công nhiệm vụ cụ thể cho các Phó hiệu trưởng, giao trách nhiệm cho các Tổ chuyên môn và đôn đốc việc thực hiện những quy định về quyền hạn, trách nhiệm của BGH, tổ chuyên môn và cán bộ, công chức.<br  />3. Quản lý cán bộ, viên chức nhà trường về các mặt phẩm chất đạo đức, sử dụng đào tạo thực hiện các chính sách để xây dựng đội ngũ cán bộ viên chức có phẩm chất năng lực công tác, đoàn kết thống nhất.<br  />4. Lắng nghe và tiếp thu những ý kiến của cá nhân, tổ chức, đoàn thể trong nhà trường có biện pháp giải quyế theo đúng chế độ chính sách hiện hành của Nhà nước, đúng thẩm quyền, trách nhiệm được giao của Hiệu trưởng. Trong trường hợp vượt quá thẩm quyền giải quyết của Hiệu trưởng thì phải thông báo cho cá nhân, tổ chức đoàn thể trong cơ quan được biết và thông báo cấp trên.<br  />5. Thực hiện chế độ họp đúng định kỳ: Họp BGH, Ban chấp hành Đảng uỷ, họp giao ban cơ quan, Hội nghị viên chức hàng năm.<br  />6. Thực hiện chế độ công khai tài chính theo đúng quy định của Nhà nước; công khai quyền lợi, chế độ, chính sách và đánh giá định kỳ đối với cán bộ, viên chức của nhà trường về việc thực hiện nhiệm vụ được giao. Chăm lo xây dựng tu bổ cơ sở vật chất nhà trường, tạo điều kiện động viên về tinh thần, vật chất cho cán bộ, viên chức.<br  />7. Thực hiện nghiêm túc nguyên tắc tập trung dân chủ trong quản lý nhà trường; phối hợp chặt chẽ với các tổ chức, đoàn thể, cá nhân, phát huy dân chủ trong tổ chức hoạt động của nhà trường. Định kỳ hàng quý họp với BCH Đảng ủy, nghe đại diện công đoàn, Đoàn thanh niên và Thanh tra nhân dân của trường phản ánh tình hình, giải quyết các kiến nghị.<br  />8. Gương mẫu đi đầu trong việc đấu tranh chống những biểu hiện thiếu dân chủ trong nhà trường, như: Cửa quyền, sách nhiễu, thành kiến, trù dập, bưng bít, làm sai sự thật, làm trái nguyên tắc và những biểu hiện thiếu dân chủ khác. Bảo vệ và giữ gìn uy tín của nhà trường.<br  />9. Hướng dẫn, đôn tốc kiểm tra hoạt động của cấp dưới, trực tiếp trong việc thực hiện dân chủ trong nhà trường và giải quyết kịp thời những kiến nghị của cấp dưới theo thẩm quyền được giao.<br  />10. Phối hợp với tổ chức Công đoàn và Đoàn thanh niên tổ chức Hội nghị cán bộ viên chức mỗi năm một lần vào đầu năm học theo quy định của nhà nước.<br  />11. Giải quyết các đơn thư khiếu nại, tố cáo liên quan tới cán bộ, công chức của nhà trường theo quy định của Luật khiếu nại tố cáo.<br  /><strong><u>Điều 4</u></strong><strong>: Những việc Hiệu trưởng lấy ý kiến tham gia của cán bộ viên chức, các tổ chức đoàn thể trong nhà trường trước khi quyết định:</strong><br  />1. Kế hoạch phát triển nghiên cứu giáo dục; nghiên cứu khoa học và các giải pháp lớn trong việc quản lý chỉ đạo chuyên môn nhằm nâng cao chất lượng giáo dục, đào tạo.<br  />2. Quy trình quản lý đào tạo, các vấn đề chức năng, nhiệm vụ của các bộ máy tổ chức trong nhà trường.<br  />3. Kế hoạch đào tạo bồi dưỡng chuyên môn nghiệp vụ của cán bộ viên chức.<br  />4. Kế hoạch xây dựng cơ sở vật chất, trang thiết bị phục vụ cho nhiệm vụ hoạt động của nhà trường.<br  />5. Các biện pháp tổ chức phong trào thi đua, khen thưởng hàng năm, xây dựng lề lối làm việc, nội quy trong nhà trường.<br  />6. Báo cáo theo định kỳ về sơ kết, tổng kết năm học, các báo cáo gửi cấp trên theo quy định của Nhà nước.<br  /><strong>MỤC II: TRÁCH NHIỆM CỦA CÁC PHÓ HIỆU TRƯỞNG VÀ KHỐI TRƯỞNG.</strong><br  />1. Phó hiệu trưởng phụ trách chuyên môn: Đ/c Vũ Thị Phượng<br  />- Giúp Hiệu trưởng quản lý chuyên môn.<br  />- Tham gia cùng lãnh đạo trực trong tuần.<br  />2. Phó hiệu trưởng phụ trách cơ sở vật chất: Đ/c Đỗ Thị Thu.<br  />- Giúp hiệu trưởng quản lý cơ sở vật chất của nhà trường.<br  />- Tham gia cùng lãnh đạo trực trong tuần.<br  />3. Phó hiệu trưởng phụ trách hoạt động ngoài giờ lên lớp, GDHN, GD Nghề PT: &nbsp;Đ/c Nguyễn Thị Tuyết Hồng.<br  />- Tham gia trực trong tuần.<br  />- Trực tiếp quản lý đạo đức học sinh.<br  /><strong>MỤC III: QUYỀN, NGHĨA VỤ CỦA LÃNH ĐẠO NHÀ TRƯỜNG.</strong><br  />1. Đảm bảo đủ giờ tiêu chuẩn.<br  />2. Nếu chưa đủ giờ phải trực tiếp giảng dạy hoặc làm công tác khác kiêm nhiệm được tính giờ như giờ tiêu chuẩn.<br  /><strong>MỤC IV: TRÁCH NHIỆM CỦA CÁN BỘ VIÊN CHỨC.</strong><br  /><strong><u>Điều 5</u></strong><strong>: Cán bộ, viên chức trong nhà trường phải có trách nhiệm.</strong><br  />1. Thực hiện các nhiệm vụ và quyền hạn theo quy định của Luật giáo dục. Thực hiện đúng các quy định của Pháp lệnh cán bộ, công chức; Pháp lệnh chống tham nhũng; Pháp lệnh thực hành tiết kiệm. Tích cực hưởng ứng cuộc vận động &quot;Hai không&quot;.<br  />2. Tham gia đóng góp ý kiến với Hiệu trưởng.<br  />3. Kiên quyết đấu tranh chống những hiện tượng cửa quyền, bè phái, mất đoàn kết và những việc làm vi phạm dân chủ, kỷ cương, nền nếp trong nhà trường.<br  />4. Giữ gìn phẩm chất, danh dự, uy tín của nhà giáo, cán bộ viên chức; Tôn trọng đồng nghiệp; có trách nhiệm và hòan thành tốt công việc được giao.<br  />5. Tự nhận xét đánh giá về quá trình công tác của mình theo định kỳ. Không tổ chức dạy thêm dưới bất kỳ hình thức nào, nếu chưa được cấp có thẩm quyền cho phép.<br  />6. Tiếp thu có chọn lọc ý kiến của cơ sở phản ánh để báo cáo với Hiệu trưởng. Giữ gìn bí mật những điều chưa được nhà trường cho công bố rộng rãi.<br  />7. Bảo vệ uy tín của nhà trường.<br  /><strong>MỤC IV: NHỮNG CÔNG VIỆC CÁN BỘ VIÊN CHỨC ĐƯỢC BIẾT.</strong><br  /><strong><u>Điều 6</u></strong><strong>: Tham gia ý kiến, giám sát kiểm tra thông qua dân chủ trực tiếp hoặc thông qua các tổ chức, đoàn thể trong nhà trường.</strong><br  />1. Những chủ trương, chính sách, chế độ của Đảng và Nhà nước đối với nhà giáo, cán bộ, viên chức.<br  />2. Các quy định về sử dụng tài sản, cơ sở vật chất của nhà trường.<br  />3. Công khai các khoản đóng góp của cán bộ viên chức, việc sử dụng kinh phí và chấp hành chế độ thu chi, quyết toán theo quy định hiện hành của Nhà nước.<br  />4. Việc giải quyết đơn thư khiếu nại, tố cáo liên quan đến cán bộ viên chức nhà trường theo quy định của luật khiếu nại tố cáo.<br  />5. Việc giải quyết các chế độ, quyền lợi về đời sống vật chất, tinh thần cho cán bộ viên chức.<br  />6. Việc thực hiện thi tuyển dụng, thi nâng ngạch viên chức, nâng bậc lương, thuyên chuyển, điều động, đề bạt, khen thưởng, kỉ luật.<br  />7. Tăng cường công tác tự kiểm tra tại nhà trường. Ban thanh tra nhân dan phát huy tích cực vai trò trách nhiệm được giao.<br  />8. Báo cáo sơ kết, tổng kết, nhận xét, đánh giá cán bộ viên chức hàng năm.<br  /><strong>MỤC V: TRÁCH NHIỆM CỦA CÁC ĐƠN VỊ, CÁC ĐOÀN THỂ, TỔ CHỨC TRONG NHÀ TRƯỜNG.</strong><br  /><strong><u>Điều 7</u></strong><strong>: Trách nhiệm các tổ chuyên môn.</strong><br  />Tổ trưởng chuyên môn trong nhà trường là người đại diện cho các tổ, có trách nhiệm.<br  />1. Chấp hành và tổ chức thực hiện đúng chức năng, nhiệm vụ, các hoạt động dân chủ trong đơn vị tổ mình phụ trách.<br  />2. Thực hiện ngiêm túc lề lối làm việc của tổ, giữa các tổ với nhau; thực hiện đầy đủ chức năng, nhiẹm vụ của tổ do Hiệu trưởng quy định và những quy định của Luật giáo dục đã ban hành; Tích cực thực hiện đổi mới phương pháp dạy học.<br  />3. Thường xuyên theo dõi đôn đốc việc thực hiện các yêu cầu của nhà trường về soạn bàn trên máy tính và sử dụng có hiệu quả các phương tiện dạy học hiện đại.<br  /><strong><u>Điều 8</u></strong><strong>: Trách nhiệm của các đoàn thể, các tổ chức trong nhà trườg.</strong><br  />Người đứng đầu các đoàn thể, các tổ chức trong cơ quan là người đại diện cho đoàn thể, tổ chức đó có trách nhiệm.<br  />1. Phối hợp với Tổ chuyên môn và các tổ chức khác trong việc tổ chức, thực hiện Quy chế dân chủ trong hoạt động nhà trường.<br  />2. Nâng cao chất lượng hoạt động của các đoàn thể, các tổ chức, dân chủ bàn bạc các chủ trương, biện pháp thực hiện của nhà trường.<br  />3. Ban Thanh tra nhân dân có nhiệm vụ thực hiện chức năng giám sát, kiểm tra việc thực hiện Quy chế dân chủ trong nhà trường, lắng nghe ý kiến của cán bộ, công chức, phát hiện kịp thời những biểu hiện vi phạm quy chế dân chủ trong các nhà trường để đề nghị với Hiệu trưởng giải quyết.<br  /><strong>MỤC VI: TRÁCH NHIỆM GIẢI QUYẾT CÔNG VIỆC CỦA CƠ QUAN VỚI CƠ QUAN QUẢN LÝ CẤP TRÊN, VỚI CHÍNH QUYỀN ĐỊA PHƯƠNG.</strong><br  /><strong><u>Điều 9:</u></strong><strong> Cơ quan với cơ quan quản lý cấp trên.</strong><br  />1. Phục tùng sự chỉ đạo của Sở giáo dục đào tạo Quảng Ninh, Thành ủy Hạ Long và UBND thành phố, thực hiện nghiêm túc chế độ báo cáo định kỳ kịp thời, nghiêm túc, đúng quy định.<br  />2. Kịp thời phản ánh với cấp trên những khó khăn, vướng mắc của nhà trường và kiến nghị những biện pháp khắc phục để cấp trên xem xét giải quyết. Phản ánh những vấn đề chưa rõ trong việc quản lý, chỉ đạo của cấp trên, góp ý với cơ quan quản lý cấp trên bằng văn bản. Trong khi ý kiến phản ánh chưa được giải quyết, nhà trường vẫn phải thực hiện nghiêm túc, chấp hành sự chỉ đạo của cấp trên.<br  /><strong><u>Điều 10</u></strong><strong>: Cơ quan chính quyền địa phương.</strong><br  />- Hiệu trưởng có trách niệm đảm bảo mối quan hệ, phối hợp chặt chẽ với các cơ quan, chính quyền địa phương để giải quyết những công việc có liên quan đến công tác của nhà trường.<br  />&nbsp;<div style="text-align: center;"><strong>CHƯƠNG III:&nbsp;</strong><strong>TỔ CHỨC THỰC HIỆN</strong></div>&nbsp;- Quy chế này được xem xét, sửa đổi bổ sung theo Nghị định của Hội nghị cán bộ, viên chức hàng năm.<br  />- Mọi cán nhân, tổ chức đoàn thể trong nhà trường phải nghiêm túc thực hiện quy chế này. Nếu vi phạm, tùy theo mức độ sẽ bị xử lý theo Pháp lệnh cán bộ viên chức.<br  />- Trong quá trình thực hiện, nếu có vướng mắc, cần báo kịp thời để điều chỉnh và bổ sung cho phù hợp.<br  />&nbsp;', 'QUY CHẾ THỰC HIỆN DÂN CHỦ,', '2016_01/2013_11-quy-che-thuc-hien-dan-chu.doc', '', 5, 2, 1454009824, 1454009824, 22, 39, 2, 1, 1, 'Nguyễn Linh', 1385667420, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_lichct`
--

CREATE TABLE `pacorp_vi_lichct` (
  `nid` int(4) NOT NULL,
  `idpart` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `week` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `begtime` int(11) NOT NULL DEFAULT '0',
  `endtime` int(11) NOT NULL DEFAULT '0',
  `monam` mediumtext COLLATE utf8mb4_unicode_ci,
  `monpm` mediumtext COLLATE utf8mb4_unicode_ci,
  `tueam` mediumtext COLLATE utf8mb4_unicode_ci,
  `tuepm` mediumtext COLLATE utf8mb4_unicode_ci,
  `wedam` mediumtext COLLATE utf8mb4_unicode_ci,
  `wedpm` mediumtext COLLATE utf8mb4_unicode_ci,
  `thuam` mediumtext COLLATE utf8mb4_unicode_ci,
  `thupm` mediumtext COLLATE utf8mb4_unicode_ci,
  `friam` mediumtext COLLATE utf8mb4_unicode_ci,
  `fripm` mediumtext COLLATE utf8mb4_unicode_ci,
  `satam` mediumtext COLLATE utf8mb4_unicode_ci,
  `satpm` mediumtext COLLATE utf8mb4_unicode_ci,
  `sunam` mediumtext COLLATE utf8mb4_unicode_ci,
  `sunpm` mediumtext COLLATE utf8mb4_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_lichct`
--

INSERT INTO `pacorp_vi_lichct` (`nid`, `idpart`, `week`, `begtime`, `endtime`, `monam`, `monpm`, `tueam`, `tuepm`, `wedam`, `wedpm`, `thuam`, `thupm`, `friam`, `fripm`, `satam`, `satpm`, `sunam`, `sunpm`) VALUES
(1, '1', '1', 1297011600, 1297616399, 'Làm bình thường', 'Làm bình thường', 'Làm bình thường', 'Làm bình thường', 'Làm bình thường', 'Làm bình thường', 'Làm bình thường', 'Làm bình thường', 'Làm bình thường', 'Làm bình thường', 'Làm bình thường', 'Làm bình thường', 'Nghỉ', 'Nghỉ');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_lichct_config`
--

CREATE TABLE `pacorp_vi_lichct_config` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `notice` mediumtext COLLATE utf8mb4_unicode_ci,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_lichct_config`
--

INSERT INTO `pacorp_vi_lichct_config` (`id`, `title`, `notice`, `active`) VALUES
(1, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_lichct_part`
--

CREATE TABLE `pacorp_vi_lichct_part` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `full_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_lichct_part`
--

INSERT INTO `pacorp_vi_lichct_part` (`id`, `full_name`, `phone`, `email`, `note`, `weight`) VALUES
(1, 'BGH', '0363.840. 035', 'hoang.nguyen@webvang.vn', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_menu`
--

CREATE TABLE `pacorp_vi_menu` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_menu`
--

INSERT INTO `pacorp_vi_menu` (`id`, `title`) VALUES
(1, 'Top Menu'),
(2, 'Thành viên'),
(3, 'Thông tin chung'),
(4, 'Tiện ích');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_menu_rows`
--

CREATE TABLE `pacorp_vi_menu_rows` (
  `id` mediumint(5) NOT NULL,
  `parentid` mediumint(5) UNSIGNED NOT NULL,
  `mid` smallint(5) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` text COLLATE utf8mb4_unicode_ci,
  `groups_view` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `module_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `op` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `target` tinyint(4) DEFAULT '0',
  `css` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `active_type` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_menu_rows`
--

INSERT INTO `pacorp_vi_menu_rows` (`id`, `parentid`, `mid`, `title`, `link`, `icon`, `note`, `weight`, `sort`, `lev`, `subitem`, `groups_view`, `module_name`, `op`, `target`, `css`, `active_type`, `status`) VALUES
(165, 32, 1, 'Trường xưa', '/index.php?language=vi&nv=news&amp;op=truong-xua', '', '', 5, 24, 1, '166,167,168', '6', 'news', 'truong-xua', 1, '', 1, 1),
(166, 165, 1, 'Cựu học sinh', '/index.php?language=vi&nv=news&amp;op=cuu-hoc-sinh', '', '', 1, 25, 2, '', '6', 'news', 'cuu-hoc-sinh', 1, '', 1, 1),
(167, 165, 1, 'Lưu bút học trò', '/index.php?language=vi&nv=news&amp;op=luu-but-hoc-tro', '', '', 2, 26, 2, '', '6', 'news', 'luu-but-hoc-tro', 1, '', 1, 1),
(32, 0, 1, 'Tin Tức', '/index.php?language=vi&nv=news', '', '', 2, 11, 0, '153,154,157,161,165,169,170', '6', 'news', '', 1, '', 1, 1),
(164, 161, 1, 'Công tác đội', '/index.php?language=vi&nv=news&amp;op=cong-tac-doi', '', '', 3, 23, 2, '', '6', 'news', 'cong-tac-doi', 1, '', 1, 1),
(145, 23, 1, 'tổ Song ngữ', '/index.php?language=vi&nv=about&amp;op=to-Song-ngu.html', '', '', 2, 3, 1, '', '6', 'about', 'to-Song-ngu.html', 1, '', 1, 1),
(144, 23, 1, 'Giới thiệu về nhà trường', '/index.php?language=vi&nv=about&amp;op=Gioi-thieu-ve-nha-truong.html', '', '', 1, 2, 1, '', '6', 'about', 'Gioi-thieu-ve-nha-truong.html', 1, '', 1, 1),
(139, 77, 1, 'Phần mềm giáo dục', '/index.php?language=vi&nv=download&amp;op=Phan-mem-giao-duc', '', '', 4, 39, 1, '', '6', 'download', 'Phan-mem-giao-duc', 1, '', 1, 1),
(138, 77, 1, 'Tài liệu chuyên môn', '/index.php?language=vi&nv=download&amp;op=Tai-lieu-chuyen-mon', '', '', 3, 38, 1, '', '6', 'download', 'Tai-lieu-chuyen-mon', 1, '', 1, 1),
(137, 77, 1, 'Giáo án', '/index.php?language=vi&nv=download&amp;op=Giao-an', '', '', 1, 36, 1, '', '6', 'download', 'Giao-an', 1, '', 1, 1),
(23, 0, 1, 'Giới thiệu', '/index.php?language=vi&nv=about', '', '', 1, 1, 0, '144,145,146,147,148,149,150,151,152', '6', 'about', '', 1, '', 1, 1),
(168, 165, 1, 'Ký ức học trò', '/index.php?language=vi&nv=news&amp;op=ky-uc-hoc-tro', '', '', 3, 27, 2, '', '6', 'news', 'ky-uc-hoc-tro', 1, '', 1, 1),
(169, 32, 1, 'Hợp tác Quốc tế', '/index.php?language=vi&nv=news&amp;op=hop-tac-quoc-te', '', '', 6, 28, 1, '', '6', 'news', 'hop-tac-quoc-te', 1, '', 1, 1),
(170, 32, 1, 'Gương mặt tiêu biểu', '/index.php?language=vi&nv=news&amp;op=guong-mat-tieu-bieu', '', '', 7, 29, 1, '171,172', '6', 'news', 'guong-mat-tieu-bieu', 1, '', 1, 1),
(50, 0, 1, 'Liên hệ', '/index.php?language=vi&nv=contact', '', '', 9, 43, 0, '', '6', 'contact', '', 1, '', 1, 1),
(99, 0, 2, 'Đăng nhập', '/index.php?language=vi&nv=users&op=login', '', '', 1, 1, 0, '', '6', 'users', 'login', 1, 'fa fa-sign-out', 1, 1),
(100, 0, 2, 'Đăng ký', '/index.php?language=vi&nv=users&op=register', '', '', 2, 2, 0, '', '6', 'users', 'register', 1, 'fa fa-eyedropper', 1, 1),
(97, 0, 1, 'Tổ chức', '/index.php?language=vi&nv=cbdoan', '', '', 3, 32, 0, '', '6', 'cbdoan', '', 1, '', 0, 1),
(101, 0, 2, 'Quên mật khẩu', '/index.php?language=vi&nv=users&op=lostpass', '', '', 3, 3, 0, '', '6', 'users', 'lostpass', 1, 'fa fa-refresh', 1, 1),
(102, 0, 2, 'Thiếp lập tài khoản', '/index.php?language=vi&nv=users&op=editinfo', '', '', 4, 4, 0, '', '6', 'users', 'editinfo', 1, 'fa fa-toggle-off', 1, 1),
(104, 0, 2, 'Thoát', '/index.php?language=vi&nv=users&op=logout', '', '', 6, 6, 0, '', '6', 'users', 'logout', 1, 'fa fa-outdent', 1, 1),
(103, 0, 2, 'Danh sách thành viên', '/index.php?language=vi&nv=users&op=memberlist', '', '', 5, 5, 0, '', '6', 'users', 'memberlist', 1, 'fa fa-exchange', 1, 1),
(77, 0, 1, 'Tài liệu', '/index.php?language=vi&nv=download', '', '', 6, 35, 0, '139,138,137,140,143', '6', 'download', '', 1, '', 1, 1),
(173, 0, 1, 'Lịch công tac', '/index.php?language=vi&nv=lichct', '', '', 4, 33, 0, '', '6', 'lichct', '', 1, '', 0, 1),
(115, 0, 4, 'Hình ảnh hoạt động', '/index.php?language=vi&nv=photos', '', '', 4, 4, 0, '', '6', 'photos', '', 1, 'fa fa-file-image-o', 0, 1),
(81, 0, 1, 'Công văn', '/index.php?language=vi&nv=laws', '', '', 5, 34, 0, '', '6', 'laws', '', 1, '', 1, 1),
(105, 0, 3, 'Giới thiệu', '/index.php?language=vi&nv=about', '', '', 1, 1, 0, '', '6', 'about', '', 1, 'fa fa-check-square-o', 0, 1),
(106, 0, 3, 'Cơ cấu tổ chức', '/index.php?language=vi&nv=cbdoan', '', '', 2, 2, 0, '', '6', 'cbdoan', '', 1, 'fa fa-life-ring', 0, 1),
(107, 0, 3, 'Liên hệ', '/index.php?language=vi&nv=contact', '', '', 6, 6, 0, '', '6', 'contact', '', 1, 'fa fa-envelope-o', 0, 1),
(108, 0, 0, 'Xếp hạng thi đua', '/index.php?language=vi&nv=xep-hang-thi-dua', '', '', 1, 1, 0, '', '6', 'xep-hang-thi-dua', '', 1, 'fa fa-graduation-cap', 0, 1),
(112, 0, 4, 'Xếp hạng thi đua', '/index.php?language=vi&nv=xep-hang-thi-dua', '', '', 3, 3, 0, '', '6', 'xep-hang-thi-dua', '', 1, 'fa fa-graduation-cap', 0, 1),
(109, 0, 3, 'Công văn', '/index.php?language=vi&nv=laws', '', '', 4, 4, 0, '', '6', 'laws', '', 1, 'fa fa-gavel', 0, 1),
(113, 0, 3, 'Lịch công tác', '/index.php?language=vi&nv=lichcongtac', '', '', 3, 3, 0, '', '6', 'lichcongtac', '', 1, 'fa fa-hourglass-end', 0, 1),
(110, 0, 4, 'Tài liệu', '/index.php?language=vi&nv=download', '', '', 1, 1, 0, '', '6', 'download', '', 1, 'fa fa-download', 0, 1),
(111, 0, 4, 'Thời khóa biểu lớp', '/index.php?language=vi&nv=tkblop', '', '', 2, 2, 0, '', '6', 'tkblop', '', 1, 'fa fa-keyboard-o', 0, 1),
(114, 0, 3, 'Tin tức - Sự kiện', '/index.php?language=vi&nv=news', '', '', 5, 5, 0, '', '6', 'news', '', 1, 'fa fa-bars', 0, 1),
(116, 0, 4, 'Video clip', '/index.php?language=vi&nv=videos', '', '', 5, 5, 0, '', '6', 'videos', '', 1, 'fa fa-youtube', 0, 1),
(163, 161, 1, 'Hoạt động công đoàn', '/index.php?language=vi&nv=news&amp;op=hoat-dong-cong-doan', '', '', 2, 22, 2, '', '6', 'news', 'hoat-dong-cong-doan', 1, '', 1, 1),
(162, 161, 1, 'Công tác đoàn', '/index.php?language=vi&nv=news&amp;op=cong-tac-doan', '', '', 1, 21, 2, '', '6', 'news', 'cong-tac-doan', 1, '', 1, 1),
(161, 32, 1, 'Hoạt động phong trào', '/index.php?language=vi&nv=news&amp;op=hoat-dong-phong-trao', '', '', 4, 20, 1, '162,163,164', '6', 'news', 'hoat-dong-phong-trao', 1, '', 1, 1),
(160, 157, 1, 'Đội tuyển HSG', '/index.php?language=vi&nv=news&amp;op=doi-tuyen-hsg', '', '', 3, 19, 2, '', '6', 'news', 'doi-tuyen-hsg', 1, '', 1, 1),
(159, 157, 1, 'Hoạt động tổ CM', '/index.php?language=vi&nv=news&amp;op=hoat-dong-to-cm', '', '', 2, 18, 2, '', '6', 'news', 'hoat-dong-to-cm', 1, '', 1, 1),
(158, 157, 1, 'Chỉ đạo chuyên môn', '/index.php?language=vi&nv=news&amp;op=chi-dao-chuyen-mon', '', '', 1, 17, 2, '', '6', 'news', 'chi-dao-chuyen-mon', 1, '', 1, 1),
(157, 32, 1, 'Hoạt động chuyên môn', '/index.php?language=vi&nv=news&amp;op=hoat-dong-chuyen-mon', '', '', 3, 16, 1, '158,159,160', '6', 'news', 'hoat-dong-chuyen-mon', 1, '', 1, 1),
(156, 154, 1, 'Thông báo', '/index.php?language=vi&nv=news&amp;op=thong-bao-27', '', '', 2, 15, 2, '', '6', 'news', 'thong-bao-27', 1, '', 1, 1),
(155, 154, 1, 'Thông tin công khai', '/index.php?language=vi&nv=news&amp;op=thong-tin-cong-khai', '', '', 1, 14, 2, '', '6', 'news', 'thong-tin-cong-khai', 1, '', 1, 1),
(154, 32, 1, 'Thông báo', '/index.php?language=vi&nv=news&amp;op=thong-bao', '', '', 2, 13, 1, '155,156', '6', 'news', 'thong-bao', 1, '', 1, 1),
(153, 32, 1, 'Tin tức - Sự kiện', '/index.php?language=vi&nv=news&amp;op=tin-tuc-su-kien', '', '', 1, 12, 1, '', '6', 'news', 'tin-tuc-su-kien', 1, '', 1, 1),
(140, 77, 1, 'Phần mềm tiện ích', '/index.php?language=vi&nv=download&amp;op=Phan-mem-tien-ich', '', '', 5, 40, 1, '', '6', 'download', 'Phan-mem-tien-ich', 1, '', 1, 1),
(141, 0, 1, 'Hình ảnh', '/index.php?language=vi&nv=photos', '', '', 7, 41, 0, '', '6', 'photos', '', 1, '', 0, 1),
(143, 77, 1, 'Đề thi &amp; Đáp án', '/index.php?language=vi&nv=download&op=De-thi-Dap-an', '', '', 2, 37, 1, '', '6', 'download', 'De-thi-Dap-an', 1, '', 0, 1),
(142, 0, 1, 'Video clip', '/index.php?language=vi&nv=videos', '', '', 8, 42, 0, '', '6', 'videos', '', 1, '', 0, 1),
(146, 23, 1, 'Giới thiệu về Đảng bộ nhà trường', '/index.php?language=vi&nv=about&amp;op=Gioi-thieu-ve-Dang-bo-nha-truong.html', '', '', 3, 4, 1, '', '6', 'about', 'Gioi-thieu-ve-Dang-bo-nha-truong.html', 1, '', 1, 1),
(147, 23, 1, 'Giới thiệu tổ Toán - Tin học', '/index.php?language=vi&nv=about&amp;op=TO-TOAN-TIN-HOC.html', '', '', 4, 5, 1, '', '6', 'about', 'TO-TOAN-TIN-HOC.html', 1, '', 1, 1),
(148, 23, 1, 'Giới thiệu tổ Ngoại Ngữ', '/index.php?language=vi&nv=about&amp;op=Gioi-thieu-to-Ngoai-Ngu.html', '', '', 5, 6, 1, '', '6', 'about', 'Gioi-thieu-to-Ngoai-Ngu.html', 1, '', 1, 1),
(149, 23, 1, 'Thành tích tổ Sử- Địa - GDCD năm 2015- 2016', '/index.php?language=vi&nv=about&amp;op=Thanh-tich-to-Su-Dia-GDCD-nam-2015-2016.html', '', '', 6, 7, 1, '', '6', 'about', 'Thanh-tich-to-Su-Dia-GDCD-nam-2015-2016.html', 1, '', 1, 1),
(150, 23, 1, 'Tổ Thể Dục - Nhạc Họa', '/index.php?language=vi&nv=about&amp;op=To-The-Duc-Nhac-Hoa.html', '', '', 7, 8, 1, '', '6', 'about', 'To-The-Duc-Nhac-Hoa.html', 1, '', 1, 1),
(151, 23, 1, 'Tổ Sử Địa GDCD 50 năm một chặng đường', '/index.php?language=vi&nv=about&amp;op=To-Su-Dia-GDCD-50-nam-mot-chang-duong.html', '', '', 8, 9, 1, '', '6', 'about', 'To-Su-Dia-GDCD-50-nam-mot-chang-duong.html', 1, '', 1, 1),
(152, 23, 1, 'giới thiệu về Tổ Văn', '/index.php?language=vi&nv=about&amp;op=gioi-thieu-ve-To-Van.html', '', '', 9, 10, 1, '', '6', 'about', 'gioi-thieu-ve-To-Van.html', 1, '', 1, 1),
(171, 170, 1, 'Học sinh tiêu biểu', '/index.php?language=vi&nv=news&amp;op=hoc-sinh-tieu-bieu', '', '', 1, 30, 2, '', '6', 'news', 'hoc-sinh-tieu-bieu', 1, '', 1, 1),
(172, 170, 1, 'Giáo viên tiêu biểu', '/index.php?language=vi&nv=news&amp;op=giao-vien-tieu-bieu', '', '', 2, 31, 2, '', '6', 'news', 'giao-vien-tieu-bieu', 1, '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_modfuncs`
--

CREATE TABLE `pacorp_vi_modfuncs` (
  `func_id` mediumint(8) UNSIGNED NOT NULL,
  `func_name` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `func_custom_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `in_module` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `subweight` smallint(2) UNSIGNED NOT NULL DEFAULT '1',
  `setting` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_modfuncs`
--

INSERT INTO `pacorp_vi_modfuncs` (`func_id`, `func_name`, `alias`, `func_custom_name`, `in_module`, `show_func`, `in_submenu`, `subweight`, `setting`) VALUES
(125, 'rss', 'rss', 'Rss', 'about', 1, 0, 2, ''),
(124, 'main', 'main', 'Main', 'about', 1, 0, 1, ''),
(4, 'main', 'main', 'Main', 'news', 1, 0, 1, ''),
(5, 'viewcat', 'viewcat', 'Viewcat', 'news', 1, 0, 2, ''),
(6, 'topic', 'topic', 'Topic', 'news', 1, 0, 3, ''),
(7, 'content', 'content', 'Content', 'news', 1, 0, 7, ''),
(8, 'detail', 'detail', 'Detail', 'news', 1, 0, 5, ''),
(9, 'tag', 'tag', 'Tag', 'news', 1, 0, 8, ''),
(10, 'rss', 'rss', 'Rss', 'news', 1, 0, 9, ''),
(11, 'search', 'search', 'Search', 'news', 1, 0, 6, ''),
(12, 'groups', 'groups', 'Groups', 'news', 1, 0, 4, ''),
(13, 'sitemap', 'sitemap', 'Sitemap', 'news', 0, 0, 0, ''),
(14, 'print', 'print', 'Print', 'news', 0, 0, 0, ''),
(15, 'rating', 'rating', 'Rating', 'news', 0, 0, 0, ''),
(16, 'savefile', 'savefile', 'Savefile', 'news', 0, 0, 0, ''),
(17, 'sendmail', 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''),
(18, 'main', 'main', 'Main', 'users', 1, 0, 1, ''),
(19, 'login', 'login', 'Đăng nhập', 'users', 1, 1, 2, ''),
(20, 'register', 'register', 'Đăng ký', 'users', 1, 1, 3, ''),
(21, 'lostpass', 'lostpass', 'Quên mật khẩu', 'users', 1, 1, 4, ''),
(22, 'active', 'active', 'Kích hoạt', 'users', 1, 0, 5, ''),
(23, 'lostactivelink', 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 6, ''),
(24, 'editinfo', 'editinfo', 'Thiếp lập tài khoản', 'users', 1, 1, 7, ''),
(25, 'memberlist', 'memberlist', 'Danh sách thành viên', 'users', 1, 1, 8, ''),
(26, 'avatar', 'avatar', 'Avatar', 'users', 1, 0, 9, ''),
(27, 'logout', 'logout', 'Thoát', 'users', 1, 1, 10, ''),
(28, 'oauth', 'oauth', 'Oauth', 'users', 0, 0, 0, ''),
(29, 'main', 'main', 'Main', 'statistics', 1, 0, 1, ''),
(30, 'allreferers', 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, ''),
(31, 'allcountries', 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, ''),
(32, 'allbrowsers', 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, ''),
(33, 'allos', 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, ''),
(34, 'allbots', 'allbots', 'Máy chủ tìm kiếm', 'statistics', 1, 1, 6, ''),
(35, 'referer', 'referer', 'Đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, ''),
(36, 'main', 'main', 'Main', 'banners', 1, 0, 1, ''),
(37, 'addads', 'addads', 'Addads', 'banners', 1, 0, 2, ''),
(38, 'clientinfo', 'clientinfo', 'Clientinfo', 'banners', 1, 0, 3, ''),
(39, 'stats', 'stats', 'Stats', 'banners', 1, 0, 4, ''),
(40, 'cledit', 'cledit', 'Cledit', 'banners', 0, 0, 0, ''),
(41, 'click', 'click', 'Click', 'banners', 0, 0, 0, ''),
(42, 'clinfo', 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''),
(43, 'logininfo', 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''),
(44, 'viewmap', 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''),
(45, 'main', 'main', 'main', 'comment', 1, 0, 1, ''),
(46, 'post', 'post', 'post', 'comment', 1, 0, 2, ''),
(47, 'like', 'like', 'Like', 'comment', 1, 0, 3, ''),
(48, 'delete', 'delete', 'Delete', 'comment', 1, 0, 4, ''),
(49, 'main', 'main', 'Main', 'page', 1, 0, 1, ''),
(50, 'sitemap', 'sitemap', 'Sitemap', 'page', 0, 0, 0, ''),
(51, 'rss', 'rss', 'Rss', 'page', 0, 0, 0, ''),
(128, 'rss', 'rss', 'Rss', 'xep-hang-thi-dua', 1, 0, 2, ''),
(127, 'main', 'main', 'Main', 'xep-hang-thi-dua', 1, 0, 1, ''),
(55, 'main', 'main', 'Main', 'contact', 1, 0, 1, ''),
(126, 'sitemap', 'sitemap', 'Sitemap', 'about', 0, 0, 0, ''),
(57, 'main', 'main', 'Main', 'seek', 1, 0, 1, ''),
(58, 'main', 'main', 'Main', 'feeds', 1, 0, 1, ''),
(59, 'detail', 'detail', 'Detail', 'weblinks', 1, 0, 3, ''),
(60, 'main', 'main', 'Main', 'weblinks', 1, 0, 1, ''),
(61, 'reportlink', 'reportlink', 'Reportlink', 'weblinks', 0, 0, 0, ''),
(62, 'rss', 'rss', 'Rss', 'weblinks', 0, 0, 0, ''),
(63, 'sitemap', 'sitemap', 'Sitemap', 'weblinks', 0, 0, 0, ''),
(64, 'viewcat', 'viewcat', 'Viewcat', 'weblinks', 1, 0, 2, ''),
(65, 'visitlink', 'visitlink', 'Visitlink', 'weblinks', 0, 0, 0, ''),
(66, 'main', 'main', 'Main', 'faq', 1, 0, 1, ''),
(67, 'rss', 'rss', 'Rss', 'faq', 0, 0, 0, ''),
(68, 'sitemap', 'sitemap', 'Sitemap', 'faq', 0, 0, 0, ''),
(186, 'uploader', 'uploader', 'Uploader', 'videos', 1, 0, 4, ''),
(185, 'tag', 'tag', 'Tag', 'videos', 1, 0, 13, ''),
(184, 'sitemap', 'sitemap', 'Sitemap', 'videos', 0, 0, 0, ''),
(183, 'sendmail', 'sendmail', 'Sendmail', 'videos', 0, 0, 0, ''),
(102, 'main', 'main', 'Main', 'cbdoan', 1, 1, 1, ''),
(129, 'sitemap', 'sitemap', 'Sitemap', 'xep-hang-thi-dua', 0, 0, 0, ''),
(130, 'main', 'main', 'Main', 'support', 0, 0, 0, ''),
(116, 'view', 'view', 'View', 'laws', 1, 1, 2, ''),
(117, 'viewcat', 'viewcat', 'Viewcat', 'laws', 1, 1, 3, ''),
(118, 'viewfield', 'viewfield', 'Viewfield', 'laws', 1, 1, 5, ''),
(119, 'vieworgan', 'vieworgan', 'Vieworgan', 'laws', 1, 1, 6, ''),
(120, 'viewroom', 'viewroom', 'Viewroom', 'laws', 1, 1, 4, ''),
(115, 'search', 'search', 'Search', 'laws', 1, 1, 7, ''),
(114, 'main', 'main', 'Main', 'laws', 1, 1, 1, ''),
(113, 'down', 'down', 'Down', 'laws', 1, 1, 9, ''),
(112, 'content', 'content', 'Content', 'laws', 1, 1, 8, ''),
(101, 'detail', 'detail', 'Detail', 'cbdoan', 1, 0, 2, ''),
(100, 'main', 'main', 'Main', 'tkblop', 1, 0, 1, ''),
(131, 'detail', 'detail', 'Detail', 'photos', 1, 0, 4, ''),
(132, 'detail_album', 'detail_album', 'Detail_album', 'photos', 1, 0, 3, ''),
(133, 'detail_viewer', 'detail_viewer', 'Detail_viewer', 'photos', 1, 0, 5, ''),
(134, 'main', 'main', 'Main', 'photos', 1, 0, 1, ''),
(135, 'pagemap', 'pagemap', 'Pagemap', 'photos', 0, 0, 0, ''),
(136, 'process', 'process', 'Process', 'photos', 0, 0, 0, ''),
(137, 'rating', 'rating', 'Rating', 'photos', 0, 0, 0, ''),
(138, 'rss', 'rss', 'Rss', 'photos', 0, 1, 0, ''),
(139, 'search', 'search', 'Search', 'photos', 1, 1, 6, ''),
(140, 'sitemap-image', 'sitemap-image', 'Sitemap-image', 'photos', 0, 0, 0, ''),
(141, 'sitemap', 'sitemap', 'Sitemap', 'photos', 0, 0, 0, ''),
(142, 'upload', 'upload', 'Upload', 'photos', 0, 0, 0, ''),
(143, 'viewcat', 'viewcat', 'Viewcat', 'photos', 1, 0, 2, ''),
(182, 'search', 'search', 'Search', 'videos', 1, 1, 8, ''),
(146, 'down', 'down', 'Down', 'download', 1, 0, 4, ''),
(147, 'main', 'main', 'Main', 'download', 1, 0, 1, ''),
(148, 'report', 'report', 'Report', 'download', 1, 0, 6, ''),
(149, 'rss', 'rss', 'Rss', 'download', 0, 0, 0, ''),
(150, 'search', 'search', 'Search', 'download', 1, 0, 7, ''),
(151, 'sitemap', 'sitemap', 'Sitemap', 'download', 0, 0, 0, ''),
(152, 'tag', 'tag', 'Tag', 'download', 1, 0, 8, ''),
(153, 'upload', 'upload', 'Upload', 'download', 1, 0, 5, ''),
(154, 'viewcat', 'viewcat', 'Viewcat', 'download', 1, 0, 2, ''),
(155, 'viewfile', 'viewfile', 'Viewfile', 'download', 1, 0, 3, ''),
(181, 'savefile', 'savefile', 'Savefile', 'videos', 0, 0, 0, ''),
(180, 'rss', 'rss', 'Rss', 'videos', 1, 1, 14, ''),
(179, 'rating', 'rating', 'Rating', 'videos', 0, 0, 0, ''),
(178, 'playlists', 'playlists', 'Playlists', 'videos', 1, 0, 3, ''),
(177, 'player', 'player', 'Player', 'videos', 1, 0, 5, ''),
(175, 'list_playlist_cat', 'list_playlist_cat', 'List_playlist_cat', 'videos', 1, 0, 12, ''),
(174, 'list_playlist', 'list_playlist', 'List_playlist', 'videos', 1, 0, 11, ''),
(173, 'groups', 'groups', 'Groups', 'videos', 1, 0, 6, ''),
(172, 'detail', 'detail', 'Detail', 'videos', 1, 0, 7, ''),
(176, 'main', 'main', 'Main', 'videos', 1, 0, 1, ''),
(187, 'user-playlist', 'user-playlist', 'User-playlist', 'videos', 1, 1, 9, ''),
(188, 'user-video', 'user-video', 'User-video', 'videos', 1, 1, 10, ''),
(189, 'viewcat', 'viewcat', 'Viewcat', 'videos', 1, 0, 2, ''),
(190, 'main', 'main', 'Main', 'lichct', 1, 0, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_modthemes`
--

CREATE TABLE `pacorp_vi_modthemes` (
  `func_id` mediumint(8) DEFAULT NULL,
  `layout` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_modthemes`
--

INSERT INTO `pacorp_vi_modthemes` (`func_id`, `layout`, `theme`) VALUES
(0, 'body', 'mobile_default'),
(0, 'left-body-right', 'default'),
(4, 'body', 'mobile_default'),
(4, 'left-body-right', 'default'),
(5, 'body', 'mobile_default'),
(5, 'body-right', 'default'),
(6, 'body', 'mobile_default'),
(6, 'body-right', 'default'),
(7, 'body', 'mobile_default'),
(7, 'body-right', 'default'),
(8, 'body', 'mobile_default'),
(8, 'body-right', 'default'),
(9, 'body', 'mobile_default'),
(9, 'body-right', 'default'),
(10, 'body-right', 'default'),
(11, 'body', 'mobile_default'),
(11, 'body-right', 'default'),
(12, 'body', 'mobile_default'),
(12, 'body-right', 'default'),
(18, 'body', 'mobile_default'),
(18, 'body-right', 'default'),
(19, 'body', 'mobile_default'),
(19, 'body-right', 'default'),
(20, 'body', 'mobile_default'),
(20, 'body-right', 'default'),
(21, 'body', 'mobile_default'),
(21, 'body-right', 'default'),
(22, 'body', 'mobile_default'),
(22, 'body-right', 'default'),
(23, 'body', 'mobile_default'),
(23, 'body-right', 'default'),
(24, 'body', 'mobile_default'),
(24, 'body-right', 'default'),
(25, 'body', 'mobile_default'),
(25, 'body-right', 'default'),
(26, 'body-right', 'default'),
(27, 'body', 'mobile_default'),
(27, 'body-right', 'default'),
(29, 'body', 'mobile_default'),
(29, 'body-right', 'default'),
(30, 'body', 'mobile_default'),
(30, 'body-right', 'default'),
(31, 'body', 'mobile_default'),
(31, 'body-right', 'default'),
(32, 'body', 'mobile_default'),
(32, 'body-right', 'default'),
(33, 'body', 'mobile_default'),
(33, 'body-right', 'default'),
(34, 'body', 'mobile_default'),
(34, 'body-right', 'default'),
(35, 'body', 'mobile_default'),
(35, 'body-right', 'default'),
(36, 'body', 'mobile_default'),
(36, 'body-right', 'default'),
(37, 'body', 'mobile_default'),
(37, 'body-right', 'default'),
(38, 'body', 'mobile_default'),
(38, 'body-right', 'default'),
(39, 'body', 'mobile_default'),
(39, 'body-right', 'default'),
(45, 'body', 'mobile_default'),
(45, 'body-right', 'default'),
(46, 'body', 'mobile_default'),
(46, 'body-right', 'default'),
(47, 'body', 'mobile_default'),
(47, 'body-right', 'default'),
(48, 'body', 'mobile_default'),
(48, 'body-right', 'default'),
(49, 'body', 'mobile_default'),
(49, 'body-right', 'default'),
(55, 'body', 'mobile_default'),
(55, 'left-body-right', 'default'),
(57, 'body', 'mobile_default'),
(57, 'body-right', 'default'),
(58, 'body', 'mobile_default'),
(58, 'body-right', 'default'),
(59, 'body', 'mobile_default'),
(59, 'body-right', 'default'),
(60, 'body', 'mobile_default'),
(60, 'body-right', 'default'),
(61, 'left-body-right', 'default'),
(62, 'left-body-right', 'default'),
(63, 'left-body-right', 'default'),
(64, 'body', 'mobile_default'),
(64, 'body-right', 'default'),
(65, 'left-body-right', 'default'),
(66, 'body', 'mobile_default'),
(66, 'body-right', 'default'),
(67, 'left-body-right', 'default'),
(68, 'left-body-right', 'default'),
(100, 'body-right', 'default'),
(101, 'left-body-right', 'default'),
(102, 'left-body-right', 'default'),
(112, 'body-right', 'default'),
(113, 'body-right', 'default'),
(114, 'body-right', 'default'),
(115, 'body-right', 'default'),
(116, 'body-right', 'default'),
(117, 'body-right', 'default'),
(118, 'body-right', 'default'),
(119, 'body-right', 'default'),
(120, 'body-right', 'default'),
(124, 'body-right', 'default'),
(125, 'body-right', 'default'),
(126, 'left-body-right', 'default'),
(127, 'left-body-right', 'default'),
(128, 'left-body-right', 'default'),
(129, 'left-body-right', 'default'),
(130, 'left-body-right', 'default'),
(131, 'left-body-right', 'default'),
(132, 'left-body-right', 'default'),
(133, 'left-body-right', 'default'),
(134, 'left-body-right', 'default'),
(135, 'left-body-right', 'default'),
(136, 'left-body-right', 'default'),
(137, 'left-body-right', 'default'),
(138, 'left-body-right', 'default'),
(139, 'left-body-right', 'default'),
(140, 'left-body-right', 'default'),
(141, 'left-body-right', 'default'),
(142, 'left-body-right', 'default'),
(143, 'left-body-right', 'default'),
(146, 'left-body-right', 'default'),
(147, 'left-body-right', 'default'),
(148, 'left-body-right', 'default'),
(149, 'left-body-right', 'default'),
(150, 'left-body-right', 'default'),
(151, 'left-body-right', 'default'),
(152, 'left-body-right', 'default'),
(153, 'left-body-right', 'default'),
(154, 'left-body-right', 'default'),
(155, 'left-body-right', 'default'),
(172, 'left-body-right', 'default'),
(173, 'left-body-right', 'default'),
(174, 'left-body-right', 'default'),
(175, 'left-body-right', 'default'),
(176, 'left-body-right', 'default'),
(177, 'left-body-right', 'default'),
(178, 'left-body-right', 'default'),
(179, 'left-body-right', 'default'),
(180, 'left-body-right', 'default'),
(181, 'left-body-right', 'default'),
(182, 'left-body-right', 'default'),
(183, 'left-body-right', 'default'),
(184, 'left-body-right', 'default'),
(185, 'left-body-right', 'default'),
(186, 'left-body-right', 'default'),
(187, 'left-body-right', 'default'),
(188, 'left-body-right', 'default'),
(189, 'left-body-right', 'default'),
(190, 'left-body-right', 'default');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_modules`
--

CREATE TABLE `pacorp_vi_modules` (
  `title` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_file` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module_data` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module_upload` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `custom_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `set_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `main_file` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `theme` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `mobile` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `keywords` text COLLATE utf8mb4_unicode_ci,
  `groups_view` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `act` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `admins` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  `gid` smallint(5) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_modules`
--

INSERT INTO `pacorp_vi_modules` (`title`, `module_file`, `module_data`, `module_upload`, `custom_title`, `admin_title`, `set_time`, `main_file`, `admin_file`, `theme`, `mobile`, `description`, `keywords`, `groups_view`, `weight`, `act`, `admins`, `rss`, `gid`) VALUES
('about', 'about', 'about', 'about', 'Giới thiệu', '', 1453879458, 1, 1, '', '', '', '', '6', 1, 1, '6,5,7,8,9,10,11,12,14', 1, 0),
('news', 'news', 'news', 'news', 'Tin Tức', '', 1453703239, 1, 1, '', '', '', '', '6', 2, 1, '6,5,7,8,9,10,11,12,14', 1, 0),
('users', 'users', 'users', 'users', 'Thành viên', 'Tài khoản', 1453703239, 1, 1, '', '', '', '', '6', 3, 1, '5,7,8,9,10,11,6,12,14', 0, 0),
('contact', 'contact', 'contact', 'contact', 'Liên hệ', '', 1453703239, 1, 1, '', '', '', '', '6', 7, 1, '7,8,9,10,11,6,5,12,14', 0, 0),
('statistics', 'statistics', 'statistics', 'statistics', 'Thống kê', '', 1453703239, 1, 1, '', '', '', 'truy cập, online, statistics', '6', 19, 1, '', 0, 0),
('banners', 'banners', 'banners', 'banners', 'Quảng cáo', '', 1453703239, 1, 1, '', '', '', '', '6', 21, 1, '', 0, 0),
('seek', 'seek', 'seek', 'seek', 'Tìm kiếm', '', 1453703239, 1, 0, '', '', '', '', '6', 9, 1, '', 0, 0),
('menu', 'menu', 'menu', 'menu', 'Menu Site', '', 1453703239, 0, 1, '', '', '', '', '6', 10, 1, '', 0, 0),
('feeds', 'feeds', 'feeds', 'feeds', 'Rss Feeds', '', 1453703239, 1, 1, '', '', '', '', '6', 14, 1, '', 0, 0),
('page', 'page', 'page', 'page', 'Page', '', 1453703239, 1, 1, '', '', '', '', '6', 15, 1, '', 1, 0),
('comment', 'comment', 'comment', 'comment', 'Bình luận', 'Quản lý bình luận', 1453703239, 0, 1, '', '', '', '', '6', 16, 1, '', 0, 0),
('xep-hang-thi-dua', 'xep-hang-thi-dua', 'xep_hang_thi_dua', 'xep-hang-thi-dua', 'Xếp hạng thi đua', '', 1453887536, 1, 1, '', '', '', '', '6', 11, 1, '5,8,10,11,6,12,14,15', 1, 0),
('support', 'support', 'support', 'support', 'Support', '', 1453913563, 1, 1, '', '', '', '', '6', 20, 1, '15', 0, 0),
('weblinks', 'weblinks', 'weblinks', 'weblinks', 'Giới thiệu web', '', 1453703404, 1, 1, '', '', '', '', '6', 17, 1, '', 1, 0),
('faq', 'faq', 'faq', 'faq', 'Hỏi đáp', '', 1453703418, 1, 1, '', '', '', '', '6', 18, 1, '', 1, 0),
('download', 'download', 'download', 'download', 'Tài liệu', '', 1453918250, 1, 1, '', '', '', '', '6', 8, 1, '6,5,7,8,9,10,11,12,14', 1, 0),
('cbdoan', 'cbdoan', 'cbdoan', 'cbdoan', 'Cơ cấu tổ chức', '', 1453729371, 1, 1, '', '', '', '', '6', 5, 1, '8,9,10,11,6,7,5,12,14', 0, 0),
('laws', 'laws', 'laws', 'laws', 'Công văn', '', 1453733962, 1, 1, '', '', '', '', '6', 4, 1, '7,8,9,10,11,6,5,12,14', 0, 0),
('tkblop', 'tkblop', 'tkblop', 'tkblop', 'Thời khóa biểu lớp', '', 1453728321, 1, 1, '', '', '', '', '6', 6, 1, '11,6,7,5,12,14', 0, 0),
('photos', 'photos', 'photos', 'photos', 'Hình ảnh hoạt động', '', 1453917743, 1, 1, '', '', '', '', '6', 12, 1, '6,5,7,8,9,10,11,12,14', 1, 0),
('videos', 'videos', 'videos', 'videos', 'Video clip', '', 1454234628, 1, 1, '', '', '', '', '6', 13, 1, '6,5,7,8,9,10,11,12,14', 1, 0),
('lichct', 'lichct', 'lichct', 'lichct', 'Lịch công tac', '', 1457537789, 1, 1, '', '', '', '', '6', 22, 1, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_8`
--

CREATE TABLE `pacorp_vi_news_8` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_news_8`
--

INSERT INTO `pacorp_vi_news_8` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(85, 8, '8', 0, 1, '', 3, 1450820291, 1450820866, 1, 1450819860, 0, 2, 'Giải Đẩy gậy Hội khỏe Phù Đổng tỉnh Quảng Ninh lần thứ IX - 2016', 'giai-day-gay-hoi-khoe-phu-dong-tinh-quang-ninh-lan-thu-ix-2016', 'Sáng 10/12/2015, tại Nhà Luyện tập và Thi đấu Thể dục thể thao tỉnh Quảng Ninh, Ban Tổ chức Hội khỏe Phù Đổng Tỉnh tổ chức Lễ khai mạc Giải Đẩy gậy Hội khỏe Phù Đổng tỉnh Quảng Ninh lần thứ IX.', '2015_12/day-gay-cap-tinh.jpg', 'Đẩy gậy cấp tỉnh', 1, 1, '6', 1, 226, 0, 0, 0),
(88, 8, '8,12', 1, 1, 'PDT', 5, 1451316832, 1453918545, 1, 1451315820, 0, 2, 'Trường THPT đạt thành tích cao trong kỳ thi chọn HSG cấp tỉnh năm 2015', 'truong-thpt-dat-thanh-tich-cao-trong-ky-thi-chon-hsg-cap-tinh-nam-2015', 'Trong kỳ thi chọn HSG cấp tỉnh THPT năm 2015 diễn ra ngày 8/12/2015, trường THPT Hòn Gai có 213 em tham gia dự thi ở 10 môn thi và đã đạt 107 giải, đứng thứ 3 toàn tỉnh.', '2015_12/bui-thu-thuy-giai-3-asean-2008.jpg', 'Bùi Thu Thủy &#40;trái&#41; đạt giải Ba ASEAN năm 2008', 1, 1, '6', 1, 293, 0, 0, 0),
(87, 8, '8', 0, 1, 'PDT', 5, 1451237022, 1451238598, 1, 1451235840, 0, 2, 'Trường THPT Hòn Gai tham gia cuộc thi KHKT cấp tỉnh dành cho học sinh trung học năm học 2015-2016', 'truong-thpt-tham-gia-cuoc-thi-khkt-cap-tinh-danh-cho-hoc-sinh-trung-hoc-nam-hoc-2015-2016', 'Trong các ngày 24, 25, 26/12/2015, tại trường trung học phổ thông Cẩm Phả, Sở Giáo dục và Đào tạo đã tổ chức Cuộc thi Khoa học kỹ thuật cấp tỉnh dành cho học sinh trung học năm học 2015-2016. Trường THPT Hòn Gai tham gia với 2 sản phẩm dự thi: Máy tập thể dục Power Plus và phần mềm Mê cung hóa học.', '2015_12/thi-khkt-2015-cap-tinh-1_1.jpg', 'Đại diện các thí sinh tham gia cuộc thi nhận cờ của Ban tổ chức', 1, 1, '6', 1, 246, 0, 0, 0),
(92, 8, '8', 0, 3, 'Nguyễn Khoa', 10, 1454032624, 1454033376, 1, 1454032440, 0, 2, 'HỌC SINH TRƯỜNG THPT HÒN GAI HƯỞNG ỨNG TUẦN LỄ HỘI HOA ANH ĐÀO HẠ LONG NĂM 2015', 'hoc-sinh-truong-thpt-hon-gai-huong-ung-tuan-le-hoi-hoa-anh-dao-ha-long-nam-2015', 'Thực hiện công văn số 1214/UBND của Thành phố Hạ Long ngày 31/3/2015, công văn số 633/SGD&ĐT-VP ngày 31/3/2015 của Sở GD Quảng Ninh về việc phối hợp phối hợp hỗ trợ lực lượng tham gia Lễ hội Hoa anh đào Hạ Long năm 2015, sáng ngày 3/4/2015, học sinh các lớp 8A2; 10A3; 10B1; 10B2 và đội Thanh niên xung kích trường THPT Hòn Gai đã tham gia một số hoạt động của Lễ hội Hoa anh đào năm Hạ Long năm 2015, như chơi các trò chơi dân gian và tham gia Hội nghị giới thiệu du học Nhật Bản.', '2016_01/img20150403105313.jpg', 'Học sinh trường THPT Hòn Gai tham gia lễ hội Hoa anh đào 2015', 1, 1, '4', 1, 124, 0, 0, 0),
(93, 8, '8', 0, 3, 'Nguyễn Khoa', 11, 1454033304, 1454033304, 1, 1454032860, 0, 2, 'LỄ KỶ NIỆM 70 NĂM THÀNH LẬP QUÂN ĐỘI NHÂN DÂN VIỆT NAM &#40;22&#x002F;12&#x002F;1944 - 22&#x002F;12&#x002F;2014&#41;', 'le-ky-niem-70-nam-thanh-lap-quan-doi-nhan-dan-viet-nam-22-12-1944-22-12-2014', 'Nhân dịp kỷ niệm 70 năm ngày thành lập Quân đội nhân dân Việt Nam và 25 năm ngày hội Quốc phòng toàn dân, giờ chào cờ đầu tuần sáng ngày 22/12/2014, trường THPT Hòn Gai tổ chức buổi lễ “Kỷ niệm 70 năm ngày thành lập quân đội nhân dân Việt Nam”.', '2016_01/20141222_075648.jpg', 'Văn nghệ chào mừng 70 năm ngày thành lập Quân đội nhân dân Việt Nam', 1, 1, '4', 1, 118, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_9`
--

CREATE TABLE `pacorp_vi_news_9` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_news_9`
--

INSERT INTO `pacorp_vi_news_9` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(91, 11, '9,11', 2, 2, 'Nguyễn Thị Tuyết Anh', 9, 1454010143, 1454010143, 1, 1454009880, 0, 2, 'TRƯỜNG THPT HÒN GAI THÀNH LẬP CÂU LẠC BỘ TIẾNG ANH', 'truong-thpt-hon-gai-thanh-lap-cau-lac-bo-tieng-anh', 'Dưới sự chỉ đạo của Ban Giám Hiệu,tổ Ngoại ngữ đã thành lập câu lạc bộ Tiếng Anh lấy tên là Hon Gai English Club. Câu lạc bộ sẽ được tổ chức 1 lần/tháng cho mỗi khối của học sinh cấp THPT. Lần đầu tiên CLB đã ra mắt vào thứ Tư ngày 31 tháng 12 năm 2014 với sự háo hức của cả thầy và trò trường THPT Hòn Gai.', '2016_01/1.jpg', 'Thành lập CLB tiếng Anh', 1, 1, '6', 1, 173, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_10`
--

CREATE TABLE `pacorp_vi_news_10` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_11`
--

CREATE TABLE `pacorp_vi_news_11` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_news_11`
--

INSERT INTO `pacorp_vi_news_11` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(91, 11, '9,11', 2, 2, 'Nguyễn Thị Tuyết Anh', 9, 1454010143, 1454010143, 1, 1454009880, 0, 2, 'TRƯỜNG THPT HÒN GAI THÀNH LẬP CÂU LẠC BỘ TIẾNG ANH', 'truong-thpt-hon-gai-thanh-lap-cau-lac-bo-tieng-anh', 'Dưới sự chỉ đạo của Ban Giám Hiệu,tổ Ngoại ngữ đã thành lập câu lạc bộ Tiếng Anh lấy tên là Hon Gai English Club. Câu lạc bộ sẽ được tổ chức 1 lần/tháng cho mỗi khối của học sinh cấp THPT. Lần đầu tiên CLB đã ra mắt vào thứ Tư ngày 31 tháng 12 năm 2014 với sự háo hức của cả thầy và trò trường THPT Hòn Gai.', '2016_01/1.jpg', 'Thành lập CLB tiếng Anh', 1, 1, '6', 1, 173, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_12`
--

CREATE TABLE `pacorp_vi_news_12` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_news_12`
--

INSERT INTO `pacorp_vi_news_12` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(88, 8, '8,12', 1, 1, 'PDT', 5, 1451316832, 1453918545, 1, 1451315820, 0, 2, 'Trường THPT đạt thành tích cao trong kỳ thi chọn HSG cấp tỉnh năm 2015', 'truong-thpt-dat-thanh-tich-cao-trong-ky-thi-chon-hsg-cap-tinh-nam-2015', 'Trong kỳ thi chọn HSG cấp tỉnh THPT năm 2015 diễn ra ngày 8/12/2015, trường THPT Hòn Gai có 213 em tham gia dự thi ở 10 môn thi và đã đạt 107 giải, đứng thứ 3 toàn tỉnh.', '2015_12/bui-thu-thuy-giai-3-asean-2008.jpg', 'Bùi Thu Thủy &#40;trái&#41; đạt giải Ba ASEAN năm 2008', 1, 1, '6', 1, 293, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_13`
--

CREATE TABLE `pacorp_vi_news_13` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_news_13`
--

INSERT INTO `pacorp_vi_news_13` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(89, 27, '13,27', 0, 5, 'Admin', 7, 1453359849, 1454010226, 1, 1453359540, 0, 2, 'Thông báo về việc mặc đồng phục', 'thong-bao-ve-viec-mac-dong-phuc', 'Nhà trường thông báo:  từ ngày 21/1/2016, vì thời tiết lạnh, hs tạm thời không phải mặc đồng phục cho đến khi nghỉ tết nguyên đán.', '2015_12/images730419_dsc_1945.jpg', '', 1, 1, '6', 1, 198, 0, 0, 0),
(84, 27, '13,27', 0, 1, 'Admin', 6, 1450819406, 1454010239, 1, 1450819020, 0, 2, 'Thời khóa biểu mới &#40;22&#x002F;12&#x002F;2015&#41;', 'thoi-khoa-bieu-moi-22-12-2015', 'Nhà trường thông báo thời khóa biểu Học kỳ 2 năm học 2015-2106 thực hiện từ ngày 22/12/2015', '2015_12/tkb.jpg', 'Thời khóa biểu', 1, 1, '6', 1, 401, 0, 0, 0),
(94, 13, '13,27', 0, 2, 'Admin', 7, 1454128409, 1454132740, 1, 1454128080, 0, 2, 'Thông Báo KHẨN  về lịch tuần từ 01&#x002F;02-04&#x002F;02&#x002F;2016', 'thong-bao-khan-ve-lich-tuan-tu-01-02-04-02-2016', 'Theo dự báo thời tiết thứ 2 có mưa nhỏ, nhà trường đổi Lễ sơ kết HK1 vào ngày thứ 4. Kế hoạch cụ thể như sau:', '2016_01/thong-bao-khan.jpg', 'Thông báo khẩn', 1, 1, '6', 1, 202, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_14`
--

CREATE TABLE `pacorp_vi_news_14` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_15`
--

CREATE TABLE `pacorp_vi_news_15` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_16`
--

CREATE TABLE `pacorp_vi_news_16` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_17`
--

CREATE TABLE `pacorp_vi_news_17` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_18`
--

CREATE TABLE `pacorp_vi_news_18` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_news_18`
--

INSERT INTO `pacorp_vi_news_18` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(86, 25, '18,25', 0, 1, '', 4, 1450882922, 1450882922, 1, 1450882020, 0, 2, 'Bịn rịn lúc chia tay mái trường', 'bin-rin-luc-chia-tay-mai-truong', 'Những ngày này, nhiều trường THPT trên địa bàn TP Hạ Long tổ chức tổng kết năm học 2013-2014 và chia tay khối 12. Trong tà áo dài trắng tinh khôi, các nữ sinh Trường THPT Hòn Gai bịn rịn chia tay bạn bè, mái trường thân yêu. Những dòng lưu bút, những cái ôm thật chặt và cả những lời chúc thi tốt được gửi trao trong ngày chia xa.', '2015_12/images730386_dsc_1002.jpg', 'Bịn rịn lúc chia tay', 1, 1, '4', 1, 280, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_19`
--

CREATE TABLE `pacorp_vi_news_19` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_20`
--

CREATE TABLE `pacorp_vi_news_20` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_21`
--

CREATE TABLE `pacorp_vi_news_21` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_22`
--

CREATE TABLE `pacorp_vi_news_22` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_news_22`
--

INSERT INTO `pacorp_vi_news_22` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(90, 23, '22,23', 0, 2, 'Admin', 8, 1454008983, 1454038548, 1, 1454008560, 0, 2, 'HAI HỌC SINH ƯU TÚ TRƯỜNG THPT HÒN GAI XUẤT SẮC ĐƯỢC NHẬN VÀO HỌC VIỆN DANH TIẾNG TẠI ÚC', 'hai-hoc-sinh-uu-tu-truong-thpt-hon-gai-xuat-sac-duoc-nhan-vao-hoc-vien-danh-tieng-tai-uc', 'Kết thúc khóa học 2013-2014 vừa qua trường THPT Hòn Gai vinh dự có 2 học sinh được nhận vào học viện Le Cordon Bleu, một trong những trường đào tạo chuyên về ngành Quản trị khách sạn du lịch tại Úc. Đó là em Mai Tuấn Linh lớp 12A5 và em Tạ Quang Hoàng lớp 12B1.', '2016_01/mai-tuan-linh.png', 'Mai Tuấn Linh', 1, 1, '4', 1, 205, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_23`
--

CREATE TABLE `pacorp_vi_news_23` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_news_23`
--

INSERT INTO `pacorp_vi_news_23` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(90, 23, '22,23', 0, 2, 'Admin', 8, 1454008983, 1454038548, 1, 1454008560, 0, 2, 'HAI HỌC SINH ƯU TÚ TRƯỜNG THPT HÒN GAI XUẤT SẮC ĐƯỢC NHẬN VÀO HỌC VIỆN DANH TIẾNG TẠI ÚC', 'hai-hoc-sinh-uu-tu-truong-thpt-hon-gai-xuat-sac-duoc-nhan-vao-hoc-vien-danh-tieng-tai-uc', 'Kết thúc khóa học 2013-2014 vừa qua trường THPT Hòn Gai vinh dự có 2 học sinh được nhận vào học viện Le Cordon Bleu, một trong những trường đào tạo chuyên về ngành Quản trị khách sạn du lịch tại Úc. Đó là em Mai Tuấn Linh lớp 12A5 và em Tạ Quang Hoàng lớp 12B1.', '2016_01/mai-tuan-linh.png', 'Mai Tuấn Linh', 1, 1, '4', 1, 205, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_24`
--

CREATE TABLE `pacorp_vi_news_24` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_25`
--

CREATE TABLE `pacorp_vi_news_25` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_news_25`
--

INSERT INTO `pacorp_vi_news_25` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(86, 25, '18,25', 0, 1, '', 4, 1450882922, 1450882922, 1, 1450882020, 0, 2, 'Bịn rịn lúc chia tay mái trường', 'bin-rin-luc-chia-tay-mai-truong', 'Những ngày này, nhiều trường THPT trên địa bàn TP Hạ Long tổ chức tổng kết năm học 2013-2014 và chia tay khối 12. Trong tà áo dài trắng tinh khôi, các nữ sinh Trường THPT Hòn Gai bịn rịn chia tay bạn bè, mái trường thân yêu. Những dòng lưu bút, những cái ôm thật chặt và cả những lời chúc thi tốt được gửi trao trong ngày chia xa.', '2015_12/images730386_dsc_1002.jpg', 'Bịn rịn lúc chia tay', 1, 1, '4', 1, 280, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_26`
--

CREATE TABLE `pacorp_vi_news_26` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_27`
--

CREATE TABLE `pacorp_vi_news_27` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_news_27`
--

INSERT INTO `pacorp_vi_news_27` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(84, 27, '13,27', 0, 1, 'Admin', 6, 1450819406, 1454010239, 1, 1450819020, 0, 2, 'Thời khóa biểu mới &#40;22&#x002F;12&#x002F;2015&#41;', 'thoi-khoa-bieu-moi-22-12-2015', 'Nhà trường thông báo thời khóa biểu Học kỳ 2 năm học 2015-2106 thực hiện từ ngày 22/12/2015', '2015_12/tkb.jpg', 'Thời khóa biểu', 1, 1, '6', 1, 401, 0, 0, 0),
(89, 27, '13,27', 0, 5, 'Admin', 7, 1453359849, 1454010226, 1, 1453359540, 0, 2, 'Thông báo về việc mặc đồng phục', 'thong-bao-ve-viec-mac-dong-phuc', 'Nhà trường thông báo:  từ ngày 21/1/2016, vì thời tiết lạnh, hs tạm thời không phải mặc đồng phục cho đến khi nghỉ tết nguyên đán.', '2015_12/images730419_dsc_1945.jpg', '', 1, 1, '6', 1, 198, 0, 0, 0),
(94, 13, '13,27', 0, 2, 'Admin', 7, 1454128409, 1454132740, 1, 1454128080, 0, 2, 'Thông Báo KHẨN  về lịch tuần từ 01&#x002F;02-04&#x002F;02&#x002F;2016', 'thong-bao-khan-ve-lich-tuan-tu-01-02-04-02-2016', 'Theo dự báo thời tiết thứ 2 có mưa nhỏ, nhà trường đổi Lễ sơ kết HK1 vào ngày thứ 4. Kế hoạch cụ thể như sau:', '2016_01/thong-bao-khan.jpg', 'Thông báo khẩn', 1, 1, '6', 1, 202, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_admins`
--

CREATE TABLE `pacorp_vi_news_admins` (
  `userid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_news_admins`
--

INSERT INTO `pacorp_vi_news_admins` (`userid`, `catid`, `admin`, `add_content`, `pub_content`, `edit_content`, `del_content`, `app_content`) VALUES
(6, 0, 1, 1, 1, 1, 1, 0),
(5, 0, 1, 1, 1, 1, 1, 0),
(7, 0, 1, 1, 1, 1, 1, 0),
(8, 0, 1, 1, 1, 1, 1, 0),
(9, 0, 1, 1, 1, 1, 1, 0),
(10, 0, 1, 1, 1, 1, 1, 0),
(11, 0, 1, 1, 1, 1, 1, 0),
(12, 0, 1, 1, 1, 1, 1, 0),
(14, 0, 1, 1, 1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_block`
--

CREATE TABLE `pacorp_vi_news_block` (
  `bid` smallint(5) UNSIGNED NOT NULL,
  `id` int(11) UNSIGNED NOT NULL,
  `weight` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_news_block`
--

INSERT INTO `pacorp_vi_news_block` (`bid`, `id`, `weight`) VALUES
(1, 85, 10),
(1, 84, 11),
(1, 86, 9),
(1, 89, 6),
(1, 88, 7),
(1, 87, 8),
(1, 90, 5),
(1, 91, 4),
(1, 92, 3),
(1, 93, 2),
(1, 94, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_block_cat`
--

CREATE TABLE `pacorp_vi_news_block_cat` (
  `bid` smallint(5) UNSIGNED NOT NULL,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_news_block_cat`
--

INSERT INTO `pacorp_vi_news_block_cat` (`bid`, `adddefault`, `numbers`, `title`, `alias`, `image`, `description`, `weight`, `keywords`, `add_time`, `edit_time`) VALUES
(1, 1, 4, 'Tin mới', 'Tin-moi', '', '', 1, '', 1430433561, 1430433561),
(2, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', '', 2, '', 1430433568, 1430433568);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_bodyhtml_1`
--

CREATE TABLE `pacorp_vi_news_bodyhtml_1` (
  `id` int(11) UNSIGNED NOT NULL,
  `bodyhtml` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourcetext` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_news_bodyhtml_1`
--

INSERT INTO `pacorp_vi_news_bodyhtml_1` (`id`, `bodyhtml`, `sourcetext`, `imgposition`, `copyright`, `allowed_send`, `allowed_print`, `allowed_save`, `gid`) VALUES
(89, 'Nhà trường thông báo: &nbsp;từ ngày 21/1/2016, vì thời tiết lạnh, hs tạm thời không phải mặc đồng phục cho đến khi nghỉ tết nguyên đán.', 'BGH', 2, 1, 1, 1, 1, 0),
(84, 'Nội dung mời xem tại bảng thông báo ở các phòng chờ giáo viên hoặc văn phòng.<br  />\r\nXem trực tuyến tại địa chỉ <a href="http://thpthongai.edu.vn/tkb" target="_blank" type="http://thpthongai.edu.vn/tkb">http://thpthongai.edu.vn/tkb</a>\r\n<div style="text-align: right;">Chuyên môn</div>', 'Bộ phận TKB.', 2, 1, 1, 1, 1, 0),
(85, '<div style="text-align: center;"><img alt="image001" height="296" src="/uploads/news/2015_12/image001.jpg" width="444" /></div><div>&nbsp; Tham dự Lễ khai mạc Giải có các đồng chí: Vũ Liên Oanh, Tỉnh ủy viên, Giám đốc Sở GD&amp;ĐT, Trưởng Ban Tổ chức HKPĐ tỉnh Quảng Ninh lần thứ IX, Phạm Mạnh Sơn, Phó Giám đốc Sở VH, TT&amp;DL, Phó Trưởng Ban Tổ chức HKPĐ Tỉnh; các đại biểu đại diện các phòng, ban Sở GD&amp;ĐT, Sở VH, TT&amp;DL, Công an tỉnh, phòng GD&amp;ĐT, phòng VHTT, lãnh đạo các trường THPT trên địa bàn thành phố Hạ Long và hơn 700 cán bộ, giáo viên, học sinh trường THPT Ngô Quyền, TP Hạ Long.</div><div align="center">&nbsp;<br  /><img alt="image001" height="296" src="/uploads/news/2015_12/image001.jpg" style="border:0px;" width="444" /></div><div><span style="line-height: 20.8px;">Đẩy gậy là môn thể thao mang đậm nét văn hóa của các dân tộc tỉnh Quảng Ninh, là môn thể thao dễ tổ chức trong các nhà trường, nhưng lại hết sức hấp dẫn với học sinh, nó là công cụ hữu hiệu để rèn luyện thể lực, sức khỏe nói chung, và đặc biệt là rèn luyện phát triển sức mạnh tĩnh cho người tập. Về tham dự Giải Đẩy gậy HKPĐ tỉnh Quảng Ninh lần thứ IX năm 2016 có 332 học sinh-nam, nữ vận động viên đến từ 14 huyện, TX, TP trong tỉnh (là Giải có số lượng VĐV đông nhất so với các các Giải đã tổ chức từ tháng 9/2015 đến nay), các em là những gương mặt tiêu biểu đại diện cho học sinh THCS và THPT của ngành GD&amp;ĐT Quảng Ninh về tham dự Giải.&nbsp;Giải Đẩy gậy sẽ được diễn ra trong 3 ngày, từ 10-12/12/2015, với 08 hạng cân đối với nam, nữ học sinh THCS và THPT. Vận động viên giành thành tích Nhất, Nhì, Ba sẽ được trao huy chương Vàng, Bạc, Đồng và được tuyển chọn để tập huấn, chuẩn bị thi đấu HKPĐ toàn quốc tổ chức tháng 8/2016, tại TP Vinh, tỉnh Nghệ An ./. &nbsp;</span></div>', 'Công thông tin SGD', 2, 0, 1, 1, 1, 0),
(86, '<div>&nbsp;</div><div><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730378 DSC 1000" height="306" src="/uploads/news/2015_12/images730378_dsc_1000.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Ngày 26-5, Trường THPT Hòn Gai tổ chức tổng kết năm học 2013-2014...</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730417 DSC 1905" height="306" src="/uploads/news/2015_12/images730417_dsc_1905.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">...và chia tay khối 12.</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730410 DSC 1854" height="333" src="/uploads/news/2015_12/images730410_dsc_1854.jpg" style="max-width: 480px; height: 333px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Buổi tổng kết được nhiều bạn chuẩn bị công phu, đem cả những chùm bóng bay đến trường.</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 410px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="400">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730411 DSC 1845" height="644" src="/uploads/news/2015_12/images730411_dsc_1845.jpg" style="max-width: 480px; height: 644px; width: 400px;" width="400" /></a></td>		</tr>		<tr>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 410px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="400">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730414 DSC 1886" height="461" src="/uploads/news/2015_12/images730414_dsc_1886.jpg" style="max-width: 480px; height: 461px; width: 400px;" width="400" /></a></td>		</tr>		<tr>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730412 DSC 1875" height="316" src="/uploads/news/2015_12/images730412_dsc_1875.jpg" style="max-width: 480px; height: 316px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Rạng ngời nữ sinh lớp 12.</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730420 DSC 1923" height="303" src="/uploads/news/2015_12/images730420_dsc_1923.jpg" style="max-width: 480px; height: 303px; width: 460px;" width="460" /></a></td>		</tr>		<tr>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730396 DSC 1165" height="306" src="/uploads/news/2015_12/images730396_dsc_1165.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730381 DSC 1025" height="306" src="/uploads/news/2015_12/images730381_dsc_1025.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">&nbsp;</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730413 DSC 1884" height="290" src="/uploads/news/2015_12/images730413_dsc_1884.jpg" style="max-width: 480px; height: 290px; width: 460px;" width="460" /></a></td>		</tr>		<tr>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730415 a" height="303" src="/uploads/news/2015_12/images730415_a.jpg" style="max-width: 480px; height: 303px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Trao nhau những dòng lưu bút.</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730385 DSC 1023" height="306" src="/uploads/news/2015_12/images730385_dsc_1023.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">&nbsp;</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730386 DSC 1002" height="306" src="/uploads/news/2015_12/images730386_dsc_1002_1.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Cùng những cái ôm thật chặt.</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730401 DSC 1129" height="306" src="/uploads/news/2015_12/images730401_dsc_1129.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">&nbsp;</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730387 DSC 1006" height="306" src="/uploads/news/2015_12/images730387_dsc_1006.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Những giọt nước mắt lăn dài trên má.</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730403 DSC 1058" height="306" src="/uploads/news/2015_12/images730403_dsc_1058.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Cô trò cùng bùi ngùi.</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730416 DSC 1893" height="330" src="/uploads/news/2015_12/images730416_dsc_1893.jpg" style="max-width: 480px; height: 330px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Tranh thủ lên lớp lần cuối trước giờ chia xa.</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730418 DSC 1925" height="370" src="/uploads/news/2015_12/images730418_dsc_1925.jpg" style="max-width: 480px; height: 370px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Chụp những bức ảnh kỷ niệm.</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730419 DSC 1945" height="378" src="/uploads/news/2015_12/images730419_dsc_1945.jpg" style="max-width: 480px; height: 378px; width: 460px;" width="460" /></a></td>		</tr>		<tr>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730390 DSC 1013" height="306" src="/uploads/news/2015_12/images730390_dsc_1013.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">&nbsp;</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730384 DSC 1016" height="306" src="/uploads/news/2015_12/images730384_dsc_1016.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Phút đùa nghịch cùng bạn bè.</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730388 DSC 1030" height="306" src="/uploads/news/2015_12/images730388_dsc_1030.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730391 DSC 1018" height="306" src="/uploads/news/2015_12/images730391_dsc_1018.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730393 DSC 1048" height="306" src="/uploads/news/2015_12/images730393_dsc_1048.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Cô trò chụp ảnh kỷ niệm ngày chia xa.</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730397 DSC 1080" height="306" src="/uploads/news/2015_12/images730397_dsc_1080.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Tạm biệt mái trường.</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730398 DSC 1087" height="391" src="/uploads/news/2015_12/images730398_dsc_1087.jpg" style="max-width: 480px; height: 391px; width: 460px;" width="460" /></a></td>		</tr>		<tr>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730402 DSC 1070" height="306" src="/uploads/news/2015_12/images730402_dsc_1070.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Bâng khuâng ngày chia xa...</td>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="text-decoration: none; color: rgb(43, 97, 151); cursor: pointer; display: block; position: relative;"><img alt="images730421 DSC 1966" height="306" src="/uploads/news/2015_12/images730421_dsc_1966.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /></a></td>		</tr>		<tr>		</tr>	</tbody></table><table align="center" class="image center" style="border-collapse: collapse; width: 470px; color: rgb(19, 94, 185); margin-bottom: 10px; font-family: Arial; line-height: normal; background: rgb(233, 233, 233);" width="460">	<tbody>		<tr>			<td style="text-align: center; padding: 5px;"><a class="iframe cboxElement" href="http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html" style="color: rgb(43, 97, 151); outline: none; cursor: pointer; display: block; position: relative;"><img alt="images730422 DSC 1930" height="306" src="/uploads/news/2015_12/images730422_dsc_1930.jpg" style="max-width: 480px; height: 306px; width: 460px;" width="460" /><span class="icon-hover" style="position: absolute; top: 137.688px; left: 207px;"><img alt="" src="http://www.baoquangninh.com.vn/common/v2/image/kinhnup.png" style="border: none; max-width: 480px; height: auto !important;" /></span></a></td>		</tr>		<tr>			<td class="image_desc" style="text-align: center; padding: 5px;">Mong ước kỷ niệm xưa...</td>		</tr>	</tbody></table><p style="padding: 0px 0px 10px; margin: 0px; list-style-type: none; border: 0px; text-align: right; line-height: 17px; color: rgb(0, 0, 0); font-family: Arial;"><strong>&nbsp;Thái Bình – Nghĩa Hiếu (báo QN)</strong></p></div>', 'Báo Quảng Ninh', 2, 0, 1, 1, 1, 0),
(87, '<div style="text-align: center;"><div style="text-align:center"><img alt="Khai mạc cuộc thi KHKT 2015" height="400" src="/uploads/news/2015_12/khai-mac.jpg" width="600" /></div><span style="color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &#039;Trebuchet MS&#039;; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 1; word-spacing: 0px; -webkit-text-stroke-width: 0px; line-height: 23.1111px;"><strong><em>Đồng chí Ngô Văn Hợi phát biểu khai mạc cuộc thi</em></strong></span></div><span style="color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &#039;Trebuchet MS&#039;; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 1; word-spacing: 0px; -webkit-text-stroke-width: 0px; line-height: 23.1111px;">Tham dự Cuộc thi có 31 trường trung học phổ thông và 21 trường trung học cơ sở trong tỉnh với tổng số 69 dự án thuộc 16 lĩnh vực của Cuộc thi, trong đó có 19 dự án cá nhân (của một học sinh) và 50 dự án tập thể (của 2 học sinh); 36 dự án của học sinh trung học phổ thông và 33 dự án của học sinh trung học cơ sở; có 119 học sinh trường trung học cơ sở, trường trung học phổ thông là tác giả của 69 dự án tham gia Cuộc thi. Ngoài ra Cuộc thi còn có sự tham gia góp mặt, động viên của nhiều thầy cô giáo và học sinh các trường trung học cơ sở và trung học phổ thông trong tỉnh.</span><div style="text-align:center"><img alt="Các học sinh tham gia sản phẩm dự thi" height="400" src="/uploads/news/2015_12/thi-khkt-2015-cap-tinh-3.jpg" width="600" /></div><div style="text-align: center;"><em><strong>Học sinh và các thầy cô tham dự cuộc thi năm 2015</strong></em><br  />&nbsp;</div><span style="color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &#039;Trebuchet MS&#039;; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 1; word-spacing: 0px; -webkit-text-stroke-width: 0px; line-height: 23.1111px;">Cuộc thi đã được tổ chức an toàn, nghiêm túc, đảm bảo chính xác, khoa học, khách quan, công bằng.</span><br style="color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &#039;Trebuchet MS&#039;; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 1; word-spacing: 0px; -webkit-text-stroke-width: 0px; line-height: 23.1111px;" /><span style="color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &#039;Trebuchet MS&#039;; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 1; word-spacing: 0px; -webkit-text-stroke-width: 0px; line-height: 23.1111px;">So với năm học 2014-2015, số đơn vị dự thi và số dự án tham gia cuộc thi đều tăng. Các giáo viên hướng dẫn và các học sinh đã có sự đầu tư, nghiên cứu công phu, nghiêm túc. Phần lớn các dự án, đề tài dự thi đều có ý tưởng tốt, giải quyết nhiều vấn đề đặt ra trong thực tiễn học tập và sinh hoạt ở các địa phương trong tỉnh. Một số sản phẩm của dự án có thể được đưa và sử dụng trong thực tiễn. Nhìn chung các học sinh dự thi đã quan tâm tới tiến trình, phương pháp nghiên cứu, nhờ đó kết quả nghiên cứu có độ tin cậy và giá trị khoa học. </span>Trường THPT Hòn Gai tham gia với 2 sản phẩm dự thi: Máy tập thể dục Power Plus và phần mềm Mê cung hóa học và đều đạt giải Ba của cuộc thi. Sản phẩm phần mềm Mê cung Hóa học chạy trên mobile là một trong 13 sản phẩm được tham gia thi chọn vòng thứ hai.<div style="text-align:center"><img alt="Em Nguyễn Anh Tú thuyết trình tại cuộc thi" height="400" src="/uploads/news/2015_12/thi-khkt-2015-cap-tinh-2.jpg" width="600" /></div><div style="text-align: center;"><strong><em>Em Nguyễn Anh Tú thuyết trình tại cuộc thi​</em></strong></div><span style="color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &#039;Trebuchet MS&#039;; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 1; word-spacing: 0px; -webkit-text-stroke-width: 0px; line-height: 23.1111px;">Kết thúc Cuộc thi, có 4 dự án đạt giải Nhất, 11 dự án đạt giải Nhì, 17 dự án đạt giải Ba và 28 dự án đạt giải khuyến khích. Ngoài ra, có 9 dự án được Hội Khuyến học tỉnh và Tỉnh đoàn thanh niên Cộng sản Hồ Chí Minh trao giải ý tưởng, giải triển vọng kèm theo các phần thưởng. </span><br  />Ban tổ chức Cuộc thi cũng đã chọn được 6 dự án xuất sắc nhất của 12 học sinh (2 học sinh trung học cơ sở và 10 học sinh trung học phổ thông), đại diện cho học sinh trung học Quảng Ninh tham gia Cuộc thi Khoa học kỹ thuật cấp quốc gia năm 2016 sẽ được tổ chức tại thành phố Hải Phòng vào tháng 3 năm 2016.<div style="text-align:center"><img alt="Tham gia QG2016" height="379" src="/uploads/news/2015_12/tham-gia-qg2016.jpg" width="600" /></div><div style="text-align: center;"><em><strong>Đồng chí Vũ Liên Oanh – Tỉnh ủy viên, Giám đốc Sở Giáo dục và Đào tạo cùng các đồng chí lãnh đạo Hội Khuyến học tỉnh, Tỉnh đoàn thanh niên Cộng sản Hồ Chí Minh và một số Sở, Ngành cùng tham dự lễ bế mạc và trao Giấy chứng nhận kèm&nbsp; giải thưởng cho các học sinh đạt giải. &nbsp;&nbsp;</strong></em></div>Thông qua cuộc thi năm nay, các học sinh trung học đã có cơ cơ hội được giới thiệu kết quả nghiên cứu khoa học, kỹ thuật của mình đồng thời các thầy cô giáo và các học sinh được tăng cường trao đổi kiến thức, giao lưu văn hóa, giáo dục giữa các vùng miền trong tỉnh.<br  />&nbsp;', 'Admin', 2, 1, 1, 1, 1, 0);
INSERT INTO `pacorp_vi_news_bodyhtml_1` (`id`, `bodyhtml`, `sourcetext`, `imgposition`, `copyright`, `allowed_send`, `allowed_print`, `allowed_save`, `gid`) VALUES
(88, 'Với sự cố gắng không ngừng nghỉ, thầy và trò nhà trường đã đạt được những thành tích to lớn, vượt thành tích so với năm học trước 20 giải, đứng thứ 3 toàn tỉnh sau trường THPT Chuyên Hạ Long và THPT Cẩm Phả. Trong đó các bộ môn Tiếng Pháp, Lịch Sử, Địa Lý, GDCD, Toán là những bộ môn có thành tích cao.<br  />\r\n​Thay mặt nhà trường, thầy giáo Nguyễn Linh - Hiệu trưởng nhà trường - đã tuyên dương và ghi nhận những thành tích đạt được của thầy và trò các đội tuyển. ​Hiện nay nhà trường có đội tuyển tiếng Pháp đang tích cực ôn tập cho kỳ thi HSG cấp quốc gia sắp tới.<br  />\r\n​Dưới đây là danh sách các học sinh đạt giải ở các bộ môn. Một lần nữa chúc mừng thành tích của các em.\r\n<div style="text-align:center">\r\n<figure class="image" style="display:inline-block"><img alt="Số lượng HSG cấp tỉnh năm 2015" height="309" src="/uploads/news/2015_12/hsg2015-2016.jpg" width="598" />\r\n<figcaption><strong><em>Số lượng HSG cấp tỉnh năm 2015</em></strong></figcaption>\r\n</figure>\r\n</div>\r\n&nbsp;\r\n\r\n<table border="0" cellpadding="0" cellspacing="0" style="width:505px;" width="505">\r\n	<tbody>\r\n		<tr>\r\n			<td rowspan="2" style="width: 39px; height: 21px; text-align: center;"><strong>TT</strong></td>\r\n			<td rowspan="2" style="width: 190px; height: 21px; text-align: center;"><strong>Họ và tên</strong></td>\r\n			<td rowspan="2" style="width: 51px; height: 21px; text-align: center;"><strong>Lớp</strong></td>\r\n			<td rowspan="2" style="width: 131px; height: 21px; text-align: center;"><strong>Giải</strong></td>\r\n			<td rowspan="2" style="width: 95px; height: 21px; text-align: center;"><strong>Môn thi</strong></td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td height="29" style="height: 29px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">1</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Phạm Thị Thanh Huyền</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B3</td>\r\n			<td nowrap="nowrap" style="width: 131px; height: 21px; text-align: center;">Nhất</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Địa Lí</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">2</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Thị Quỳnh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B3</td>\r\n			<td nowrap="nowrap" style="width: 131px; height: 21px; text-align: center;">Nhất</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Địa Lí</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">3</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Vũ Thị Ánh Ngọc</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11A3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Địa Lí</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">4</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Giáp Thị Mỹ Linh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Địa Lí</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">5</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Đặng Ái Vân</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Địa Lí</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">6</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Thùy Linh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12A3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Địa Lí</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">7</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Võ Thị Trang Nhung</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12A3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Địa Lí</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">8</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Trương Thị Thu Hà</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11A3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Địa Lí</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">9</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Trần Huyền Trang</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11A3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Địa Lí</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">10</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Lê Thị Ngọc Anh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Địa Lí</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">11</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Vũ Thị Huyền Trang</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12A3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Địa Lí</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">12</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Lưu Tiến Đạt</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11B3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Địa Lí</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 26px; text-align: center;">13</td>\r\n			<td style="width: 190px; height: 26px; text-align: center;">Ngô Hương Thảo</td>\r\n			<td style="width: 51px; height: 26px; text-align: center;">11A3</td>\r\n			<td style="width: 131px; height: 26px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 26px; text-align: center;">Địa Lí</td>\r\n			<td height="26" style="height: 26px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">14</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Trần Anh Tuấn</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11A3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Địa Lí</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">15</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Phan Như Ngọc</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11B6</td>\r\n			<td nowrap="nowrap" style="width: 131px; height: 21px; text-align: center;">Nhất</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">GDCD</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">16</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Đỗ Thùy Trang</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11A1</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">GDCD</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">17</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Lương Kỳ Duyên</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11B6</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">GDCD</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">18</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Ngọc Lan</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11B4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">GDCD</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">19</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Hoàng Thị Thu Hằng</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">10A3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">GDCD</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">20</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Lê Thị Vân Hoài</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11A1</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">GDCD</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">21</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Đinh Thị Thu Vân</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11B6</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">GDCD</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">22</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Linh Thu Trang</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11B4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">GDCD</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">23</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Cao Thị Minh Ánh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11B4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">GDCD</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">24</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Khiếu Thị Huyền Thanh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11B4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">GDCD</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">25</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Vũ Đỗ Khánh Linh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11B4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">GDCD</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">26</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Hà My</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">GDCD</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">27</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Phan Văn Thắng</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12A1</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Hóa học</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">28</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Phạm Thị Trà My</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B1</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Hóa học</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">29</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Hoàng Bích Thủy</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B1</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Hóa học</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">30</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Lê Tùng Dương</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Hóa học</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">31</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Bùi Anh Tuấn</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12A4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Hóa học</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">32</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Vũ Thu Huyền</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12A4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Hóa học</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">33</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Vũ Thùy Trang</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B6</td>\r\n			<td nowrap="nowrap" style="width: 131px; height: 21px; text-align: center;">Nhất</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">34</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Hoàng Quỳnh Anh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B6</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">35</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Thị Ánh Chi</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B6</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">36</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Huỳnh Ngọc Mai</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">37</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Lê Thị Nhung</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B6</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">38</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Ngô Quang Anh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B6</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">39</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nghiêm Thị Tú Chi</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B6</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">40</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Trần Thu Huyền</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B6</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">41</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Phạm Thanh Ngân</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11A3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">42</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Như Quỳnh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11A3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">43</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Lê Anh Đào</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">44</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Mạc Ngọc Hoài</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B6</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">45</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Thùy Linh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B6</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">46</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Trần Thúy Hải Linh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11A3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">47</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Thị Hồng Nhung</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B6</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">48</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Ngọc Oánh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B6</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">49</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Hoàng Quỳnh Trang</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11A3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Lịch sử</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">50</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Vũ Minh Ngọc</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12A3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Ngữ Văn</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">51</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Đoàn Thu Hoài</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Ngữ Văn</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">52</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Lê Ngọc Mai</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B1</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Sinh học</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">53</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Thị Kim Trinh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12A2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Sinh học</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">54</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Chu Thị Ngọc Mai</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11a2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Sinh học</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">55</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Phương Oanh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11b2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Sinh học</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">56</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Bùi Ngọc Anh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng Anh</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">57</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Đinh Nguyễn Bảo Phúc</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12A4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng Anh</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">58</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Phạm Thị Hoài</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng Anh</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">59</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Trần Thị Kim Khánh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng Anh</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">60</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Tuấn Hưng</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11B4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng Anh</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 20px; text-align: center;">61</td>\r\n			<td style="width: 190px; height: 20px; text-align: center;">Vũ Thị Hoàng Ngân</td>\r\n			<td style="width: 51px; height: 20px; text-align: center;">12B3</td>\r\n			<td style="width: 131px; height: 20px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 20px; text-align: center;">Tiếng Anh</td>\r\n			<td height="20" style="height: 20px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">62</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Hoàng Phương Minh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng Anh</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">63</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Quốc Huy</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11B4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng Anh</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">64</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Đoàn Mai Huyền</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B6</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng Anh</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">65</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Ngọc Linh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12B3</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng Anh</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">66</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Bùi Hoài Linh</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11B5</td>\r\n			<td nowrap="nowrap" style="width: 131px; height: 21px; text-align: center;">Nhất</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">67</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Phạm Thu Hà</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11A5</td>\r\n			<td nowrap="nowrap" style="width: 131px; height: 21px; text-align: center;">Nhất</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">68</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Lê Thị Ngọc Linh</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11A5</td>\r\n			<td nowrap="nowrap" style="width: 131px; height: 21px; text-align: center;">Nhất</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">69</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Từ Quang Tùng</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11A5</td>\r\n			<td nowrap="nowrap" style="width: 131px; height: 21px; text-align: center;">Nhất</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">70</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Tạ Mai An</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11B5</td>\r\n			<td nowrap="nowrap" style="width: 131px; height: 21px; text-align: center;">Nhất</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">71</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Tạ Đức Sơn</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11B5</td>\r\n			<td nowrap="nowrap" style="width: 131px; height: 21px; text-align: center;">Nhất</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">72</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Vũ Thị Thanh Xuân</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11B5</td>\r\n			<td nowrap="nowrap" style="width: 131px; height: 21px; text-align: center;">Nhất</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">73</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Trần Thị Quỳnh Anh</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">12A5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">74</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Đức Hiếu</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11A5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">75</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Hoàng Quỳnh Mai</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11A5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">76</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Bùi Thị Linh Chi</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11B5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">77</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Song Hào</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">12A5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">78</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Trịnh Linh Chi</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11A5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">79</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Anh Tú</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11A5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">80</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Bạch Cúc</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11B5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">81</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Bùi Phương Linh</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">11B5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">82</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Hoàng Văn Dũng</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">10B5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">83</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Hoàng Minh Đạt</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">10B5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">84</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Khánh My</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">10B5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">85</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Hoàng Minh Thoa</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">10B5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">86</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Bùi Hải Yến</td>\r\n			<td nowrap="nowrap" style="width: 51px; height: 21px; text-align: center;">12A5</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Tiếng pháp</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">87</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Đình Minh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12b2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Toán</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 23px; text-align: center;">88</td>\r\n			<td style="width: 190px; height: 23px; text-align: center;">Đỗ Thế Mạnh</td>\r\n			<td style="width: 51px; height: 23px; text-align: center;">11a2</td>\r\n			<td style="width: 131px; height: 23px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 23px; text-align: center;">Toán</td>\r\n			<td height="23" style="height: 23px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">89</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Trung Hiếu</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12b1</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Toán</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">90</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Đỗ Thúy An</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12a2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Toán</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">91</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Trần Hoàng Anh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12b2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Toán</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">92</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Phạm Văn Nam</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12b2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Toán</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">93</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Thùy Linh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12a4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Toán</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">94</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Phạm Trung Hiếu</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12a4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Toán</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">95</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Lưu Trọng Toàn</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12b2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Toán</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">96</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Khải Hà</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12b2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Toán</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">97</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Dương Thị Hằng</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12b2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Toán</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">98</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Bùi thị thu Trang</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12b2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Toán</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">99</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Mạc Văn Nam</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11a2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Toán</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">100</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Dương Đức Thắng</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12a4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Nhì</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Vật lý</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">101</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Trần Hiền</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12b2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Ba</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Vật lý</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">102</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Thị Hồng Hạnh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12b2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Vật lý</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 24px; text-align: center;">103</td>\r\n			<td style="width: 190px; height: 24px; text-align: center;">Nguyễn Thị Thu Huyền</td>\r\n			<td style="width: 51px; height: 24px; text-align: center;">12b2</td>\r\n			<td style="width: 131px; height: 24px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 24px; text-align: center;">Vật lý</td>\r\n			<td height="24" style="height: 24px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">104</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Lại Thuỳ Linh</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">11a4</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Vật lý</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">105</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Bùi Thanh Ngọc Nam</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12b2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Vật lý</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">106</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Nguyễn Quỳnh Trang</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12b2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Vật lý</td>\r\n			<td height="21" style="height: 21px; text-align: center;">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="width: 39px; height: 21px; text-align: center;">107</td>\r\n			<td style="width: 190px; height: 21px; text-align: center;">Đoàn Thị Hải Yến</td>\r\n			<td style="width: 51px; height: 21px; text-align: center;">12b2</td>\r\n			<td style="width: 131px; height: 21px; text-align: center;">Khuyến Khích</td>\r\n			<td style="width: 95px; height: 21px; text-align: center;">Vật lý</td>\r\n			<td height="21" style="height:21px;">&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<br  />\r\n&nbsp;', 'Admin', 2, 1, 1, 1, 1, 0);
INSERT INTO `pacorp_vi_news_bodyhtml_1` (`id`, `bodyhtml`, `sourcetext`, `imgposition`, `copyright`, `allowed_send`, `allowed_print`, `allowed_save`, `gid`) VALUES
(90, 'Mai Tuấn Linh là học sinh lớp chuyên Pháp, em được biết đến là một học sinh với thành tích học tập tốt đều các môn, thường xuyên có mặt trong các kỳ thi tiếng Pháp của thành phố, của tỉnh, và luôn đạt giải cao. Thầy cô nhắc đến em luôn là một học sinh ưu tú, thông minh và có kỷ luật. Bạn bè quý mến Linh bởi sự hòa đồng, nhiệt tình . Người thân luôn tự hào về em bởi sự hiếu thảo và lòng trắc ẩn sâu sắc với những hoàn cảnh khó khăn.<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Với vốn tiếng Pháp thuộc loại ưu, em lựa chọn Le Cordon Bleu làm điểm đến cho con đường học tập tiếp theo của mình. Trường nổi tiếng về đào tạo Nhà Hàng – Khách Sạn, Du Lịch - Ẩm Thực. Được thành lập năm 1895 tại Paris – Pháp, có trụ sở trên 28 quốc gia. Tại Úc, trường có 2 cơ sở học nằm tại Adelaide và Sydney. Linh đã chọn học tại cơ sở Sydney, em chia sẻ ước mơ lớn nhất của em là được học tập tại Pháp và em cũng đã có trải nghiệm đáng quý 2 tháng tại đất nước này, càng vững hơn quyết định của mình là sẽ gắn bó lâu dài với Pháp quốc. Tuy nhiên điều kiện hiện tại chưa cho phép nên em lựa chọn Úc như một đòn bẩy cần thiết cho kế hoạch tương lai lâu dài của mình. Với thành tích học tập tốt Linh không khó để được trường Le Cordon Bleu lựa chọn.\r\n<div>\r\n<div style="text-align:center"><img alt="untitled" height="800" src="/uploads/news/2016_01/untitled.png" style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; width: 500px; height: 667px; background: transparent;" width="600" /></div>\r\n&nbsp;\r\n\r\n<div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;Linh chia sẻ, để có được tiền đề tốt như ngày hôm nay em đã được nhận sự dạy dỗ tận tình của thầy chủ nhiệm Quốc Đạt cùng các thầy cô giáo bộ môn cũng như sự động viên khích lệ từ bạn bè. Bên cạnh đó trong suốt quá trình học tập và lựa chọn hướng đi cho tương lai của mình em luôn nhận được sự hậu thuẫn từ gia đình, đặc biệt là ông bà ngoại, Linh nói: “Ông rất thương em, với em ông còn như một người bạn tri kỉ, ông là động lực rất lớn với em”. Để thực hiện được giấc mơ du học Linh còn nhận được sự trợ giúp từ phía Trung tâm tư vấn du học Panda, một trung tâm có uy tín tại thành phố Hạ Long. Em nói<br  />\r\n“Phía trước của em còn rất nhiều khó khăn, thử thách, em còn phải nỗ lực rất nhiều mới mong có thành tích tốt để không phụ lòng thầy cô, gia đình”.</div>\r\n\r\n<div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cùng sang với em còn có bạn Tạ Quang Hoàng, học sinh lớp 12B1 do cô Nguyễn Thúy Hằng làm chủ nhiệm. Hoàng là một học sinh năng động và rất vui nhộn. Môn học sở trường của em là toán và hóa. Em rất yêu thích thể thao đặc biệt là môn bóng rổ nên được giao trọng trách làm đội phó câu lạc bộ bóng rổ của trường kiêm đảm nhiệm việc dạy cho các thành viên mới. Em cùng đội của mình thường xuyên tham gia các giải thi đấu thể thao của Tỉnh và Thành phố và luôn dành được các giải cao về cho trường.&nbsp;<br  />\r\n&nbsp;</div>\r\n</div>\r\n\r\n<div>\r\n<div style="text-align:center">\r\n<figure class="image" style="display:inline-block"><img alt="Hoàng ngồi thứ 2 hàng thứ 1 từ phải sang" height="632" src="/uploads/news/2016_01/untitled_2.png" style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; width: 500px; height: 329px; background: transparent;" width="960" />\r\n<figcaption>(<em>Hoàng ngồi thứ 2 hàng thứ 1 từ phải sang)</em></figcaption>\r\n</figure>\r\n</div>\r\n</div>\r\n\r\n<div style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 16.8px; orphans: auto; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 1; word-spacing: 0px; -webkit-text-stroke-width: 0px; background: rgb(255, 255, 255);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cũng với niềm đam mê chuyên ngành Quản trị du lịch - khách sạn , Hoàng đã lựa chọn Le Cordon Bleu làm điểm đến tiếp theo cho mình trên con đường phát triển sự nghiệp.Vốn là một câu học sinh năng động và dễ gần , Hoàng nhanh chóng hòa nhập với môi trường mới cũng như các bạn ở đây. Em chia sẻ rất thích thời tiết của Úc và môi trường học tập ở đây, việc học rất thoải mái và lớp học luôn sôi nổi.</div>\r\n\r\n<div style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 16.8px; orphans: auto; text-indent: 0px; text-transform: none; white-space: normal; widows: 1; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-align: center; background: rgb(255, 255, 255);">&nbsp;\r\n<div style="text-align:center">\r\n<figure class="image" style="display:inline-block"><img alt="( Lớp học của Hoàng tại Úc )" height="656" src="/uploads/news/2016_01/untitled_3.png" style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; width: 500px; height: 342px; background: transparent;" width="960" />\r\n<figcaption>( Lớp học của Hoàng tại Úc )</figcaption>\r\n</figure>\r\n</div>\r\n</div>\r\n\r\n<div style="background: rgb(255, 255, 255); font: 12px/16.8px Arial,Helvetica,sans-serif; margin: 0px; padding: 0px; outline: 0px; border: 0px; border-image: none; color: rgb(0, 0, 0); text-transform: none; text-indent: 0px; letter-spacing: normal; word-spacing: 0px; vertical-align: baseline; white-space: normal; widows: 1;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; “Em mong muốn được gửi lời tri ân sâu sắc tới toàn thể thầy cô trường THPT Hòn Gai đặc biệt là cô&nbsp; giáo chủ nhiệm Nguyễn Thúy Hằng, cô luôn tâm lý với học sinh và tạo ra các giờ học cực kỳ thoải mái. Em cũng trân trọng tình bạn của tập thể 12B1 luôn dành cho em. Riêng với bố mẹ Hoàng có nói <em style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; background: transparent;">“Em sẽ học tập và sống tốt để không phụ long bố mẹ”.</em> Em cũng cảm ơn các chị tư vấn viên của Trung tâm du học Panda đã đồng hành cùng em trong cuộc chinh phục đỉnh cao mới lần này, kết quả đến với em rất mỹ mãn, em đã là sinh viên trường Le Cordon Bleu “</div>\r\n\r\n<div style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 16.8px; orphans: auto; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 1; word-spacing: 0px; -webkit-text-stroke-width: 0px; background: rgb(255, 255, 255);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cả Linh và Hoàng, 2 cậu học trò thông minh, năng động đã góp phần tạo nên hình ảnh ngôi trường THPT Hòn Gai đẹp đẽ hơn bằng chính cái tài và cái đức của các em. Hoàng và Linh đều muốn nhắn nhủ tới các học sinh khóa tiếp theo của trường “<em style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; background: transparent;">hãy nỗ lực không ngừng và dám theo đuổi ước mơ của mình, nhất định các bạn sẽ đạt được điều mình mong muốn</em>”.</div>', 'Quangninh.edu.vn', 2, 1, 1, 1, 1, 0),
(94, '<b>- Thứ Hai:&nbsp;</b>\r\n<div style="margin-left: 40px;">+ Sáng: Các lớp THPT Khối A tập quân sự từ 7h15 đến 10h00. Khối THCS đẩy giờ học từ tiết 1 đến tiết 4.&nbsp;</div>\r\n\r\n<div style="margin-left: 40px;">+ Chiều: Các lớp THPT Khối B tập quân sự từ 13h30. Khối THCS học từ tiết 2 đến tiết 5.&nbsp;</div>\r\n<b>- Thứ 3:&nbsp;</b>\r\n\r\n<div style="margin-left: 40px;">+ Sáng: Các lớp THPT Khối A tập quân sự từ 7h15. Khối THCS học bình thường theo TKB.&nbsp;</div>\r\n\r\n<div style="margin-left: 40px;">+ Sáng: Từ 7h30 tập huấn về đưa bài viết và tài liệu lên trang web của trường (Mỗi tổ CM cử 1 GV tham gia tập huấn).</div>\r\n\r\n<div style="margin-left: 40px;">+ Chiều: Các lớp THPT Khối B tập quân sự từ 13h30. Khối THCS học bình thường theo TKB.&nbsp;</div>\r\n<b>- Thứ 4:</b>&nbsp;\r\n\r\n<div style="margin-left: 40px;">+ Sáng : Sơ kết trong học sinh từ 7h15.&nbsp;</div>\r\n\r\n<div style="margin-left: 40px;">+ Chiều : Sơ kết trong giáo viên từ 14h00.</div>\r\n\r\n<div style="text-align: right;">Hiệu trưởng<br  />\r\n<b>Nguyễn Linh</b></div>', 'BGH', 2, 1, 1, 1, 1, 0),
(91, '<div style="text-align: center;"><strong>SPEAKING ENGLISH IS&nbsp; QUITE INTERSETING</strong></div>\r\n&nbsp; &nbsp; &nbsp;Trường THPT Hòn Gai được lựa chọn là 1 trường điển hình về dạy và học ngoại ngữ cấp THPT của tỉnh Quảng Ninh. Ngoài việc thực hiện tốt công tác dạy và học tiếng Anh theo chương trình của Bộ GD&amp;ĐT thì việc tổ chức các hoạt động ngoài giờ lên lớp có sử dụng tiếng Anh là một việc làm hết sức cần thiết trong việc đổi mới cách dạy và cách học tiếng Anh hiệu quả.<br  />\r\n&nbsp; &nbsp; Chính vì vậy, tổ ngoại ngữ dưới sự chỉ đạo của Ban Giám Hiệu đã thành lập câu lạc bộ Tiếng Anh lấy tên là&nbsp;<strong><em>Hon Gai English Club</em></strong>. Câu lạc bộ sẽ được tổ chức 1 lần/tháng cho mỗi khối của học sinh cấp THPT. Lần đầu tiên CLB đã &nbsp;ra mắt vào thứ Tư ngày 31 tháng 12 năm 2014 với sự háo hức của cả thầy và trò trường THPT Hòn Gai.<br  />\r\n&nbsp; &nbsp; &nbsp; &nbsp;Đến tham dự với buổi sinh hoạt đầu tiên có hơn 80 học sinh tham gia. Đền dự và chỉ đạo các hoạt động của CLB có đại diện Tỉnh Đoàn Quảng Ninh, Thành Đoàn Hạ Long, Giáo viên người nước ngoài của trung tâm Ngoại Ngữ Shelton cùng Ban Giám Hiệu và các thầy cô trong tổ Ngoại Ngữ.\r\n<div style="text-align:center"><img alt="2" height="338" src="/uploads/news/2016_01/2.jpg" width="446" /></div>\r\n<br  />\r\nVới lối dẫn chương trình dí dỏm, hấp dẫn và cách thể hiện ngôn ngữ chuẩn xác, thành thục của hai MC đã lôi cuốn và thuyết phục cả đại biểu và học sinh từ đầu tới cuối.<br  />\r\nCác bạn học sinh tham gia nhiệt tình, mạnh dạn bàn luận, thể hiễn diễn thuyết bằng tiếng Anh thông qua các hoạt động đa dạng như: nhảy, hát, diễn kịch, thuyết trình, và chơi các trò chơi. Ngôn ngữ sử trong các hoạt động này đều bằng tiếng Anh và chủ yếu là hoạt động nhóm và các bạn đã thể hiện hào hứng và sôi động.\r\n<div style="text-align:center"><img alt="3" height="351" src="/uploads/news/2016_01/3.jpg" width="624" /></div>\r\n<br  />\r\nCâu lạc bộ Tiếng Anh của trường cũng là nơi để học sinh giao lưu học hỏi lẫn nhau và dần cải thiện khả năng nghe, nói Tiếng Anh. Qua đây, học sinh cảm thấy tự tin hơn khi giao tiếp trước đám đông.\r\n<div style="text-align:center"><img alt="4" height="351" src="/uploads/news/2016_01/4.jpg" width="624" /></div>\r\n<br  />\r\nBuổi sinh hoạt được dẫn dắt bởi hai MC do chính các em học sinh tự đảm trách. Điều này khiến các thành viên trong câu lạc bộ cảm thấy gần gũi và thoải mái hơn trong việc bày tỏ quan điểm, thái độ cùng phong thái khi tham gia các hoạt động do MC hướng dẫn.\r\n<div style="text-align:center"><img alt="5" height="468" src="/uploads/news/2016_01/5.jpg" width="624" /></div>\r\n<br  />\r\nBuổi ra mắt đầu tiên đã diễn ra rất thành công khi số lượng học sinh đến tham gia vượt qua dự kiến. Các em tham gia với thái độ hào hứng, cởi mở. Điều làm nên sự thành công cho buổi ra mắt đầu tiên này chính nằm ở sự chuẩn bị kỹ lưỡng giữa thầy và trò trong quá trình lên kế hoạch. Không thể không kể đến đó là sự nhiệt tình của các em học sinh khi tham gia hoạt động.\r\n<div style="text-align:center"><img alt="bietthuhiendai3" height="461" src="/uploads/news/2016_01/bietthuhiendai3.jpg" width="344" /></div>\r\n<br  />\r\nĐối với loại hình không mới này nhưng là lần đầu tiên được áp dụng vào một trường THPT, mong rằng câu lạc bộ Tiếng Anh trường THPT Hòn Gai sẽ còn phát triển hơn nữa với nhiều hoạt động giúp các em học sinh nâng cao khả năng tiếng Anh.', 'Tổ Ngoại ngữ', 2, 1, 1, 1, 1, 0),
(92, 'Tại quảng trường 30/10, các em học sinh của các lớp 8A2; 10A3 và đội Thanh niên xung kích trường THPT Hòn Gai cùng với các em học sinh của các trường trên địa bàn Thành phố đã nhiệt tình tham gia hưởng ứng tuần Lễ hội Hoa anh đào Hạ Long năm 2015. Các em học sinh đã được tham gia các trò chơi dân gian vô cùng độc đáo và thú vị như: kéo có, bắt trạch, đập niêu, đẩy gậy…<br  />\r\n&nbsp; &nbsp; &nbsp; Thông qua các trò chơi dân gian, các em đã hiểu biết thêm truyền thông văn hóa dân tộc và quảng bá các trò chơi này đến với các bạn bè quốc tế. Các em học sinh đã tham gia nhiệt tình, vô tư và đã cống hiến cho khán giả những giây phút vui vẻ, thoải mái.<br  />\r\n&nbsp; &nbsp; &nbsp; Buổi giao lưu hưởng ứng tuần Lễ hội Hoa anh đào Hạ Long năm 2015 với chủ đề Hòa bình - Hợp tác – Thịnh vượng đã kết thúc trong không khí vui tươi, hào hứng và tổng hợp các trò chơi thì đội các học sinh trường THPT Hòn Gai đã xuất sắc đạt giải ba toàn đoàn.<br  />\r\n&nbsp; &nbsp; &nbsp; Cũng vào sáng ngày 3/4/2015, tại Trung tâm tổ chức Hội nghị Thành phố, các em học sinh của hai lớp 10B1; 10B2 đã tham dự Hội nghị giới thiệu du học Nhật Bản với chủ để Chắp cánh ước mơ, kết nối thế giới. Qua tham dự Hội nghị, các em học sinh đã có thêm các thông tin về đất nước và con người Nhật Bản cũng như môi trường học tập bên nước bạn, các em học sinh cũng được hướng dẫn các điều kiện và thủ tục để có thể học tập và nghiên cứu tại một đất nước có nền giáo dục phát triển hàng đầu thế giới.<br  />\r\n&nbsp; &nbsp; &nbsp; Một số hình ảnh tham gia của các em học sinh.\r\n<div style="text-align:center"><img alt="" src="http://quangninh.edu.vn/c3hongai/uploads/news/2015_04/img20150403081058.jpg" /></div>\r\n\r\n<div style="text-align: center;">Các em học sinh lớp 8A2</div>\r\n&nbsp;\r\n\r\n<div style="text-align:center"><img alt="" src="http://quangninh.edu.vn/c3hongai/uploads/news/2015_04/img20150403103112.jpg" /></div>\r\n\r\n<div style="text-align: center;">Các đội chơi hào hứng tham gia các trò chơi dân gian vui nhộn.</div>\r\n&nbsp;\r\n\r\n<div style="text-align:center"><img alt="" src="http://quangninh.edu.vn/c3hongai/uploads/news/2015_04/img20150403105313.jpg" /></div>\r\n\r\n<div style="text-align: center;">Những người chiến thắng trong trò chơi &quot;dừng hình&quot;</div>\r\n&nbsp;\r\n\r\n<div style="text-align:center"><img alt="" src="http://quangninh.edu.vn/c3hongai/uploads/news/2015_04/img20150403105959.jpg" /></div>\r\n\r\n<div style="text-align: center;">Khi các trò chơi kết thúc, các đội đều có phần thưởng.</div>', 'Đoàn trường THPT Hòn Gai', 2, 1, 1, 1, 1, 0),
(93, '&nbsp;Mở đầu chương trình là các tiết mục văn nghệ của các em học sinh trong đội văn nghệ xung kích của Đoàn trường.<br  />\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Cũng trong buổi lễ, đồng chí Đỗ Thị Thu đã có bài phát biểu ôn lại chặng đường 70 năm lịch sử hào hùng, vẻ vang của Quân đội nhân dân Việt Nam và có những lời căn dặn đối với thầy và trò Nhà trường cần phải cố gắng giảng dạy và học tập thật tốt xây dựng đất nước.<br  />\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Kết thúc buổi lễ, thay mặt các thầy cô giáo và các em học sinh, đồng chí Hiệu trưởng Nguyễn Linh đã có bó hoa tươi thắm tặng đồng chí Nguyễn Mạnh Hòa – nguyên là một người lính cụ Hồ và bây giờ là một chiến sĩ trên mặt trận văn hóa giảng dạy môn Vật lý tại trường. Với niềm hân hoan chào đón ngày kỷ niệm, đồng chí Nguyễn Mạnh Hòa cũng đã hát dành tặng các thầy cô giáo và các em học sinh những bài hát cách mạng “đi cùng năm tháng và không thể nào quên” hết sức ý nghĩa.<br  />\r\n<br  />\r\nMột số hình ảnh của buổi lễ:<br  />\r\n&nbsp;\r\n<div style="text-align:center"><img alt="" height="421" src="http://quangninh.edu.vn/c3hongai/uploads/news/2014_12/20141222_073148.jpg" width="700" /></div>\r\n&nbsp;\r\n\r\n<div style="text-align: center;">Tiết mục văn nghệ của các em học sinh trong đội văn nghệ xung kích của Đoàn trường<br  />\r\n(Thục Trinh - lớp 12A5)</div>\r\n&nbsp;\r\n\r\n<div style="text-align:center"><img alt="" height="421" src="http://quangninh.edu.vn/c3hongai/uploads/news/2014_12/20141222_075648.jpg" width="700" /></div>\r\n&nbsp;\r\n\r\n<div style="text-align: center;">Tiết mục văn nghệ của các em học sinh trong đội văn nghệ xung kích của Đoàn trường</div>\r\n&nbsp;\r\n\r\n<div style="text-align:center"><img alt="" height="421" src="http://quangninh.edu.vn/c3hongai/uploads/news/2014_12/20141222_073423.jpg" width="700" /></div>\r\n&nbsp;\r\n\r\n<div style="text-align: center;">Đ/c Đỗ Thị Thu - P. Hiệu trưởng Nhà trường ôn lại chặng đường 70 năm lịch sử hào hùng, vẻ vang<br  />\r\ncủa Quân đội nhân dân Việt Nam.</div>\r\n&nbsp;\r\n\r\n<div style="text-align:center"><img alt="" height="421" src="http://quangninh.edu.vn/c3hongai/uploads/news/2014_12/20141222_074129_1.jpg" width="700" /></div>\r\n&nbsp;\r\n\r\n<div style="text-align: center;">Đ/c Hiệu trưởng Nguyễn Linh đã có bó hoa tươi thắm tặng đồng chí Nguyễn Mạnh Hòa.</div>\r\n&nbsp;\r\n\r\n<div style="text-align:center"><img alt="" height="421" src="http://quangninh.edu.vn/c3hongai/uploads/news/2014_12/20141222_074415.jpg" width="700" /></div>\r\n\r\n<div style="text-align: center;">Phút ngẫu hứng của thầy Nguyễn Mạnh Hòa.</div>\r\n\r\n<div style="text-align: center;"><br  />\r\n<strong>BÀI PHÁT BIỂU CỦA ĐỒNG CHÍ ĐỖ THỊ THU - P. HIỆU TRƯỞNG</strong></div>\r\n\r\n<div style="text-align: center;"><strong>Diễn văn chào mừng kỉ niệm ngày 22 – 12</strong></div>\r\n<strong>&nbsp; &nbsp; &nbsp; Kính thưa:&nbsp; - &nbsp;Các Thầy giáo, Cô giáo!</strong><br  />\r\n<strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;- Các em học sinh thân mến!</strong><br  />\r\n&nbsp; &nbsp; &nbsp; Ngày 22 – 12 – 1944, theo chỉ thị của Hồ Chí Minh, Đại tướng Võ Nguyên Giáp đọc lệnh thành lập Quân đội Nhân dân Việt Nam, đến nay đã tròn 70 năm. Hằng năm cứ đến ngày này, toàn thể quân và dân ta lại tổ chức trọng thể lễ kỉ niệm ngày ra đời của Quân đội nhân dân Việt Nam và ngày Quốc phòng toàn dân. Để biểu dương truyền thống chiến đấu kiên cường của quân và dân ta trong sự nghiệp chiến đấu, bảo vệ và xây dựng Đất nước. Quân đội nhân dân Việt Nam, từ nhân dân mà ra và chiến đấu vì nhân dân, vì độc lập tự do của Tổ quốc và dân tộc. Với vũ khí thô sơ chỉ là gậy gộc, giáo mác, trang bị thiếu thốn, quân đội ta đã nêu cao tinh thần yêu nước thương nhà, lòng căm thù giặc sâu sắc. Ngay từ những năm đầu, quân ta đã đánh cho thực dân Pháp thất bại phải rút về nước.<br  />\r\n&nbsp; &nbsp; &nbsp; Người lính Việt Nam trong kháng chiến chống Pháp với tên gọi bình dị mà đáng yêu như &quot;Anh vệ quốc quân&quot;, &quot;Anh bộ đội cụ Hồ&quot;, &quot;Những con người áo vải, chân không đi tìm giặc đánh&quot; đã vượt qua gian khổ, hi sinh tạo nên, hết &quot;chiến công này, đến chiến công khác mà đỉnh cao là chiến dịch Điện Biên Phủ lừng lẫy năm châu, chấn động địa cầu&quot;, buộc thực dân Pháp phải kí Hiệp định Giơ-ne-vơ năm 1954 và rút quân ra khỏi Đất nước ta, phải công nhận nước Việt Nam là nước độc lập tự do, có chủ quyền: Như nhà thơ Tố Hữu đã ca ngợi<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &quot;Chín năm làm một Điện Biên<br  />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Nên vành hoa đỏ, nên thiên sử vàng&quot;<br  />\r\n&nbsp; &nbsp; &nbsp;Vinh quang đó trước hết thuộc về Quân đội Việt Nam anh hùng, dưới sự lãnh đạo của Đảng Cộng sản Việt Nam.<br  />\r\n&nbsp; &nbsp; &nbsp;Sau khi thực dân Pháp thất bại, đế quốc Mĩ lại xâm lược nước ta. Nhân dân ta và Quân đội ta, lại phải tiến hành cuộc kháng chiến chống Mĩ cứu nước với quy mô ác liệt nhất trong lịch sử dân tộc và nhân loại. Kẻ thù đế quốc Mĩ là kẻ thù nham hiểm, hung ác nhất, tàn bạo nhất. Nhưng với truyền thống anh hùng bốn nghìn năm dựng nước và giữ nước, với sự lãnh đạo sáng suốt của Đảng, với tinh thần đoàn kết quân dân một ý chí thực hiện lời dạy của Bác Hồ: &quot;Không có gì quý hơn độc lập tự do&quot;, quân dân ta đã bách chiến, bách thắng viết lên nhiều trang sử vàng chói lọi.<br  />\r\nLớp lớp các thế hệ con cháu, cầm súng lên đường tiếp bước các thế hệ cha anh đã tạo thành đội quân trùng trùng, điệp điệp:<br  />\r\n&quot;Lớp cha trước, lớp con sau<br  />\r\nĐã thành đồng chí chung câu quân hành&quot;<br  />\r\n&nbsp; &nbsp; &nbsp;Với bao binh chủng xuất hiện như: Lục quân, Hải quân, Không quân, Đội quân tóc dài, đấu tranh binh vận, chính trị rồi đấu tranh vũ trang...Thật chưa bao giờ lại sáng tạo, phong phú tràn đầy dũng khí, ý chí kiên cường với trận lịch sử “ Điện biên phủ trên không” 12 ngày đêm trên bầu trời Hà Nội và kết tinh là đỉnh là cao chiến dịch Hồ Chí Minh lịch sử.<br  />\r\n&nbsp; &nbsp; &nbsp;Đế quốc Mĩ và bọn tay sai thất trận, lại đạp lên nhau xéo chạy khỏi đất nước Việt Nam, buộc phải kí Hiệp định Pari thừa nhận chủ quyền thống nhất, độc lập toàn vẹn lãnh thổ Việt Nam.<br  />\r\n<strong><em>&nbsp; &nbsp; &nbsp;Kính thưa các Thầy giáo, Cô giáo và toàn thể các em!</em></strong><br  />\r\n&nbsp; &nbsp; &nbsp;Trong kháng chiến chống Mĩ cứu nước, mái trường thân yêu của chúng ta đã trở thành pháo đài trên mặt trận văn hoá và có những đóng góp rất đáng tự hào.<br  />\r\n&nbsp; &nbsp; &nbsp;Nhiều Thầy giáo, Cô giáo và hàng trăm học sinh trường ta đãtừ bỏ ước mơ vào đại học, xếp bút nghiên tình nguyện lên đường đi chiến đấu. Các chiến sĩ &nbsp;trường ta dù ở binh chủng nào cũng chiến đấu anh hùng, lập nhiều chiến công. Có đồng chí đã trở thành anh hùng như đồng chí Đỗ Viết Cường có các đ/c đã hi sinh mãi mãi không bao giờ trở về, đó là các liệt sỹ: Vũ Minh Trí,Nguyễn văn Quang, Trần mạnh Dũng,Vũ Thành Tâm, Nguyễn văn Thuận, Nguyễn Văn Toàn, Đào tiến Lộc, Nguyễn Văn Thanh và nhiều liệt sỹ khác. Có những Thầy giáo sau khi hoàn thành nhiệm vụ chiến đấu, lại trở về với nhiệm vụ trồng&nbsp; người Như thầy giáo Nguyễn Mạnh Hòa giáo viên trường ta.<br  />\r\n<strong><em>&nbsp; &nbsp; &nbsp; Kinh thưa các Thầy giáo, Cô giáo và các em!</em></strong><br  />\r\n&nbsp; &nbsp; &nbsp; Tự hào về Quân đội Việt Nam anh hùng, Thầy trò chúng ta càng phải tìm ra những bài học sâu sắc cho mình để vận dụng sáng tạo trong sự nghiệp giáo dục, khoa học, xây dựng con người mới trong sự nghiệp công nghiệp hoá, hiện đại hoá hôm nay.<br  />\r\n&nbsp; &nbsp; &nbsp; Trước hết, Thầy trò chúng ta phải học tập phẩm chất anh hùng, lý tưởng cao cả vì Nhân dân, vì Đất nước mà chiến đấu của người chiến sĩ Việt Nam. Sự lười biếng trong học tập, lao động, sự thiếu ý chí quyết tâm vươn lên trong nghiên cứu khoa học, trong tu dưỡng đạo đức, tài năng; rồi những tệ nạn xã hội như: Ma tuý, HIV/AIDS đang ngày đêm phá hoại cuộc sống của chúng ta còn ác liệt, tệ hại hơn cả bom đạn - đó là những kẻ thù giấu mặt, rất âm thầm nhưng lại có sức công phá, xói mòn chân lý, đạo lý đến mức ghê sợ. Vậy! chúng ta phải tỉnh táo, cảnh giác, học tập tinh thần người lính chiến đấu với những tệ nạn ấy, quyết không đầu hàng, khuất phục.<br  />\r\n<strong><em>&nbsp; &nbsp; &nbsp; Kính thưa các Thầy giáo, Cô giáo và các em!</em></strong><br  />\r\n&nbsp; &nbsp; &nbsp; Kỉ niệm ngày thành lập Quân đội Nhân dân Việt Nam – ngày Quốc phòng toàn dân, năm nay, trường ta đang chuyển mình với vị thế, tầm vóc mới rất đáng phấn khởi, thành phố Hạ Long tỉnh Quảng Ninh cũng như bối cảnh chung của Đất nước đang chuyển biến tốt đẹp có nhiều hứa hẹn.<br  />\r\nQuê hương, Đất nước, tương lai cuộc sống đang cần đến các em. Các em phải sống, học tập, rèn luyện để đền đáp lại sự hi sinh xương máu của những chiến sĩ quân đội cho cuộc sống hoà bình, hạnh phúc hôm nay; để không khỏi hổ thẹn trước những mong mỏi, chờ đợi của Đất nước, của Nhân dân. Tương lai tươi sáng của thế kỉ 21 đang đón chào các em!<br  />\r\n<strong><em>&nbsp; &nbsp; &nbsp; Thay mặt các Thầy giáo, Cô giáo, tôi xin cảm ơn và chúc các Thầy giáo, Cô giáo, các em học sinh những lời chúc mừng tốt đẹp nhất.Trân trọng cảm ơn!( vỗ tay)</em></strong><br  />\r\n<strong>&nbsp;<em>Kính thưa các Thầy giáo, Cô giáo và các em!</em></strong><br  />\r\n&nbsp; &nbsp; &nbsp; Trong niềm vui hân hoàn tự hào về người lính cụ Hồ, có những Thầy giáo, cô giáo sau khi hoàn thành nhiệm vụ chiến đấu lại trở về với nhiệm vụ trồng&nbsp; người ở trường ta. Tôi xin trân trọng giới thiệu và kính mời lên sân khấu cựu chiến binh: Đó là:Thầy Nguyễn Mạnh Hòa giáo viên môn Vật Lý.<br  />\r\n&nbsp;', 'Nguyễn Trọng Nghĩa - Bí thư Đoàn trường', 2, 1, 1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_bodytext`
--

CREATE TABLE `pacorp_vi_news_bodytext` (
  `id` int(11) UNSIGNED NOT NULL,
  `bodytext` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_news_bodytext`
--

INSERT INTO `pacorp_vi_news_bodytext` (`id`, `bodytext`) VALUES
(84, 'Nội dung mời xem tại bảng thông báo ở các phòng chờ giáo viên hoặc văn phòng.\r\nXem trực tuyến tại địa chỉ http://thpthongai.edu.vn/tkb http://thpthongai.edu.vn/tkb\r\nChuyên môn'),
(85, ' /uploads/news/2015_12/image001.jpg image001   Tham dự Lễ khai mạc Giải có các đồng chí: Vũ Liên Oanh, Tỉnh ủy viên, Giám đốc Sở GD&amp;ĐT, Trưởng Ban Tổ chức HKPĐ tỉnh Quảng Ninh lần thứ IX, Phạm Mạnh Sơn, Phó Giám đốc Sở VH, TT&amp;DL, Phó Trưởng Ban Tổ chức HKPĐ Tỉnh; các đại biểu đại diện các phòng, ban Sở GD&amp;ĐT, Sở VH, TT&amp;DL, Công an tỉnh, phòng GD&amp;ĐT, phòng VHTT, lãnh đạo các trường THPT trên địa bàn thành phố Hạ Long và hơn 700 cán bộ, giáo viên, học sinh trường THPT Ngô Quyền, TP Hạ Long.     /uploads/news/2015_12/image001.jpg image001  Đẩy gậy là môn thể thao mang đậm nét văn hóa của các dân tộc tỉnh Quảng Ninh, là môn thể thao dễ tổ chức trong các nhà trường, nhưng lại hết sức hấp dẫn với học sinh, nó là công cụ hữu hiệu để rèn luyện thể lực, sức khỏe nói chung, và đặc biệt là rèn luyện phát triển sức mạnh tĩnh cho người tập. Về tham dự Giải Đẩy gậy HKPĐ tỉnh Quảng Ninh lần thứ IX năm 2016 có 332 học sinh-nam, nữ vận động viên đến từ 14 huyện, TX, TP trong tỉnh (là Giải có số lượng VĐV đông nhất so với các các Giải đã tổ chức từ tháng 9/2015 đến nay), các em là những gương mặt tiêu biểu đại diện cho học sinh THCS và THPT của ngành GD&amp;ĐT Quảng Ninh về tham dự Giải. Giải Đẩy gậy sẽ được diễn ra trong 3 ngày, từ 10-12/12/2015, với 08 hạng cân đối với nam, nữ học sinh THCS và THPT. Vận động viên giành thành tích Nhất, Nhì, Ba sẽ được trao huy chương Vàng, Bạc, Đồng và được tuyển chọn để tập huấn, chuẩn bị thi đấu HKPĐ toàn quốc tổ chức tháng 8/2016, tại TP Vinh, tỉnh Nghệ An ./. '),
(86, '     	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730378_dsc_1000.jpg images730378 DSC 1000 		 		 			Ngày 26-5, Trường THPT Hòn Gai tổ chức tổng kết năm học 2013-2014... 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730417_dsc_1905.jpg images730417 DSC 1905 		 		 			...và chia tay khối 12. 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730410_dsc_1854.jpg images730410 DSC 1854 		 		 			Buổi tổng kết được nhiều bạn chuẩn bị công phu, đem cả những chùm bóng bay đến trường. 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730411_dsc_1845.jpg images730411 DSC 1845 		 		 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730414_dsc_1886.jpg images730414 DSC 1886 		 		 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730412_dsc_1875.jpg images730412 DSC 1875 		 		 			Rạng ngời nữ sinh lớp 12. 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730420_dsc_1923.jpg images730420 DSC 1923 		 		 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730396_dsc_1165.jpg images730396 DSC 1165 		 		 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730381_dsc_1025.jpg images730381 DSC 1025 		 		 			  		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730413_dsc_1884.jpg images730413 DSC 1884 		 		 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730415_a.jpg images730415 a 		 		 			Trao nhau những dòng lưu bút. 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730385_dsc_1023.jpg images730385 DSC 1023 		 		 			  		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730386_dsc_1002_1.jpg images730386 DSC 1002 		 		 			Cùng những cái ôm thật chặt. 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730401_dsc_1129.jpg images730401 DSC 1129 		 		 			  		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730387_dsc_1006.jpg images730387 DSC 1006 		 		 			Những giọt nước mắt lăn dài trên má. 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730403_dsc_1058.jpg images730403 DSC 1058 		 		 			Cô trò cùng bùi ngùi. 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730416_dsc_1893.jpg images730416 DSC 1893 		 		 			Tranh thủ lên lớp lần cuối trước giờ chia xa. 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730418_dsc_1925.jpg images730418 DSC 1925 		 		 			Chụp những bức ảnh kỷ niệm. 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730419_dsc_1945.jpg images730419 DSC 1945 		 		 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730390_dsc_1013.jpg images730390 DSC 1013 		 		 			  		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730384_dsc_1016.jpg images730384 DSC 1016 		 		 			Phút đùa nghịch cùng bạn bè. 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730388_dsc_1030.jpg images730388 DSC 1030 		 		 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730391_dsc_1018.jpg images730391 DSC 1018 		 		 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730393_dsc_1048.jpg images730393 DSC 1048 		 		 			Cô trò chụp ảnh kỷ niệm ngày chia xa. 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730397_dsc_1080.jpg images730397 DSC 1080 		 		 			Tạm biệt mái trường. 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730398_dsc_1087.jpg images730398 DSC 1087 		 		 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730402_dsc_1070.jpg images730402 DSC 1070 		 		 			Bâng khuâng ngày chia xa... 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730421_dsc_1966.jpg images730421 DSC 1966 		 		 		 	    	 		 			http://www.baoquangninh.com.vn/xa-hoi/201405/teen-thpt-hon-gai-bin-rin-chia-tay-mai-truong-2230892/index.photo.html /uploads/news/2015_12/images730422_dsc_1930.jpg images730422 DSC 1930 http://www.baoquangninh.com.vn/common/v2/image/kinhnup.png 		 		 			Mong ước kỷ niệm xưa... 		 	    Thái Bình – Nghĩa Hiếu (báo QN) '),
(87, '  /uploads/news/2015_12/khai-mac.jpg Khai mạc cuộc thi KHKT 2015 Đồng chí Ngô Văn Hợi phát biểu khai mạc cuộc thi Tham dự Cuộc thi có 31 trường trung học phổ thông và 21 trường trung học cơ sở trong tỉnh với tổng số 69 dự án thuộc 16 lĩnh vực của Cuộc thi, trong đó có 19 dự án cá nhân (của một học sinh) và 50 dự án tập thể (của 2 học sinh); 36 dự án của học sinh trung học phổ thông và 33 dự án của học sinh trung học cơ sở; có 119 học sinh trường trung học cơ sở, trường trung học phổ thông là tác giả của 69 dự án tham gia Cuộc thi. Ngoài ra Cuộc thi còn có sự tham gia góp mặt, động viên của nhiều thầy cô giáo và học sinh các trường trung học cơ sở và trung học phổ thông trong tỉnh.   /uploads/news/2015_12/thi-khkt-2015-cap-tinh-3.jpg Các học sinh tham gia sản phẩm dự thi  Học sinh và các thầy cô tham dự cuộc thi năm 2015   Cuộc thi đã được tổ chức an toàn, nghiêm túc, đảm bảo chính xác, khoa học, khách quan, công bằng. So với năm học 2014-2015, số đơn vị dự thi và số dự án tham gia cuộc thi đều tăng. Các giáo viên hướng dẫn và các học sinh đã có sự đầu tư, nghiên cứu công phu, nghiêm túc. Phần lớn các dự án, đề tài dự thi đều có ý tưởng tốt, giải quyết nhiều vấn đề đặt ra trong thực tiễn học tập và sinh hoạt ở các địa phương trong tỉnh. Một số sản phẩm của dự án có thể được đưa và sử dụng trong thực tiễn. Nhìn chung các học sinh dự thi đã quan tâm tới tiến trình, phương pháp nghiên cứu, nhờ đó kết quả nghiên cứu có độ tin cậy và giá trị khoa học. Trường THPT Hòn Gai tham gia với 2 sản phẩm dự thi: Máy tập thể dục Power Plus và phần mềm Mê cung hóa học và đều đạt giải Ba của cuộc thi. Sản phẩm phần mềm Mê cung Hóa học chạy trên mobile là một trong 13 sản phẩm được tham gia thi chọn vòng thứ hai.   /uploads/news/2015_12/thi-khkt-2015-cap-tinh-2.jpg Em Nguyễn Anh Tú thuyết trình tại cuộc thi  Em Nguyễn Anh Tú thuyết trình tại cuộc thi​ Kết thúc Cuộc thi, có 4 dự án đạt giải Nhất, 11 dự án đạt giải Nhì, 17 dự án đạt giải Ba và 28 dự án đạt giải khuyến khích. Ngoài ra, có 9 dự án được Hội Khuyến học tỉnh và Tỉnh đoàn thanh niên Cộng sản Hồ Chí Minh trao giải ý tưởng, giải triển vọng kèm theo các phần thưởng.  Ban tổ chức Cuộc thi cũng đã chọn được 6 dự án xuất sắc nhất của 12 học sinh (2 học sinh trung học cơ sở và 10 học sinh trung học phổ thông), đại diện cho học sinh trung học Quảng Ninh tham gia Cuộc thi Khoa học kỹ thuật cấp quốc gia năm 2016 sẽ được tổ chức tại thành phố Hải Phòng vào tháng 3 năm 2016.  /uploads/news/2015_12/tham-gia-qg2016.jpg Tham gia QG2016  Đồng chí Vũ Liên Oanh – Tỉnh ủy viên, Giám đốc Sở Giáo dục và Đào tạo cùng các đồng chí lãnh đạo Hội Khuyến học tỉnh, Tỉnh đoàn thanh niên Cộng sản Hồ Chí Minh và một số Sở, Ngành cùng tham dự lễ bế mạc và trao Giấy chứng nhận kèm giải thưởng cho các học sinh đạt giải.  Thông qua cuộc thi năm nay, các học sinh trung học đã có cơ cơ hội được giới thiệu kết quả nghiên cứu khoa học, kỹ thuật của mình đồng thời các thầy cô giáo và các học sinh được tăng cường trao đổi kiến thức, giao lưu văn hóa, giáo dục giữa các vùng miền trong tỉnh.  '),
(88, 'Với sự cố gắng không ngừng nghỉ, thầy và trò nhà trường đã đạt được những thành tích to lớn, vượt thành tích so với năm học trước 20 giải, đứng thứ 3 toàn tỉnh sau trường THPT Chuyên Hạ Long và THPT Cẩm Phả. Trong đó các bộ môn Tiếng Pháp, Lịch Sử, Địa Lý, GDCD, Toán là những bộ môn có thành tích cao.\r\n​Thay mặt nhà trường, thầy giáo Nguyễn Linh - Hiệu trưởng nhà trường - đã tuyên dương và ghi nhận những thành tích đạt được của thầy và trò các đội tuyển. ​Hiện nay nhà trường có đội tuyển tiếng Pháp đang tích cực ôn tập cho kỳ thi HSG cấp quốc gia sắp tới.\r\n​Dưới đây là danh sách các học sinh đạt giải ở các bộ môn. Một lần nữa chúc mừng thành tích của các em.\r\n\r\n /uploads/news/2015_12/hsg2015-2016.jpg Số lượng HSG cấp tỉnh năm 2015\r\nSố lượng HSG cấp tỉnh năm 2015\r\n\r\n\r\n \r\n\r\n\r\n	\r\n		\r\n			TT\r\n			Họ và tên\r\n			Lớp\r\n			Giải\r\n			Môn thi\r\n			 \r\n		\r\n		\r\n			 \r\n		\r\n		\r\n			1\r\n			Phạm Thị Thanh Huyền\r\n			12B3\r\n			Nhất\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			2\r\n			Nguyễn Thị Quỳnh\r\n			12B3\r\n			Nhất\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			3\r\n			Vũ Thị Ánh Ngọc\r\n			11A3\r\n			Nhì\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			4\r\n			Giáp Thị Mỹ Linh\r\n			12B3\r\n			Ba\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			5\r\n			Đặng Ái Vân\r\n			12B3\r\n			Ba\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			6\r\n			Nguyễn Thùy Linh\r\n			12A3\r\n			Ba\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			7\r\n			Võ Thị Trang Nhung\r\n			12A3\r\n			Ba\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			8\r\n			Trương Thị Thu Hà\r\n			11A3\r\n			Ba\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			9\r\n			Trần Huyền Trang\r\n			11A3\r\n			Ba\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			10\r\n			Lê Thị Ngọc Anh\r\n			12B3\r\n			Khuyến Khích\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			11\r\n			Vũ Thị Huyền Trang\r\n			12A3\r\n			Khuyến Khích\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			12\r\n			Lưu Tiến Đạt\r\n			11B3\r\n			Khuyến Khích\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			13\r\n			Ngô Hương Thảo\r\n			11A3\r\n			Khuyến Khích\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			14\r\n			Trần Anh Tuấn\r\n			11A3\r\n			Khuyến Khích\r\n			Địa Lí\r\n			 \r\n		\r\n		\r\n			15\r\n			Phan Như Ngọc\r\n			11B6\r\n			Nhất\r\n			GDCD\r\n			 \r\n		\r\n		\r\n			16\r\n			Đỗ Thùy Trang\r\n			11A1\r\n			Nhì\r\n			GDCD\r\n			 \r\n		\r\n		\r\n			17\r\n			Nguyễn Lương Kỳ Duyên\r\n			11B6\r\n			Nhì\r\n			GDCD\r\n			 \r\n		\r\n		\r\n			18\r\n			Nguyễn Ngọc Lan\r\n			11B4\r\n			Nhì\r\n			GDCD\r\n			 \r\n		\r\n		\r\n			19\r\n			Hoàng Thị Thu Hằng\r\n			10A3\r\n			Ba\r\n			GDCD\r\n			 \r\n		\r\n		\r\n			20\r\n			Lê Thị Vân Hoài\r\n			11A1\r\n			Ba\r\n			GDCD\r\n			 \r\n		\r\n		\r\n			21\r\n			Đinh Thị Thu Vân\r\n			11B6\r\n			Ba\r\n			GDCD\r\n			 \r\n		\r\n		\r\n			22\r\n			Linh Thu Trang\r\n			11B4\r\n			Ba\r\n			GDCD\r\n			 \r\n		\r\n		\r\n			23\r\n			Cao Thị Minh Ánh\r\n			11B4\r\n			Ba\r\n			GDCD\r\n			 \r\n		\r\n		\r\n			24\r\n			Khiếu Thị Huyền Thanh\r\n			11B4\r\n			Ba\r\n			GDCD\r\n			 \r\n		\r\n		\r\n			25\r\n			Vũ Đỗ Khánh Linh\r\n			11B4\r\n			Khuyến Khích\r\n			GDCD\r\n			 \r\n		\r\n		\r\n			26\r\n			Nguyễn Hà My\r\n			12B5\r\n			Khuyến Khích\r\n			GDCD\r\n			 \r\n		\r\n		\r\n			27\r\n			Phan Văn Thắng\r\n			12A1\r\n			Ba\r\n			Hóa học\r\n			 \r\n		\r\n		\r\n			28\r\n			Phạm Thị Trà My\r\n			12B1\r\n			Khuyến Khích\r\n			Hóa học\r\n			 \r\n		\r\n		\r\n			29\r\n			Hoàng Bích Thủy\r\n			12B1\r\n			Khuyến Khích\r\n			Hóa học\r\n			 \r\n		\r\n		\r\n			30\r\n			Lê Tùng Dương\r\n			12B2\r\n			Khuyến Khích\r\n			Hóa học\r\n			 \r\n		\r\n		\r\n			31\r\n			Bùi Anh Tuấn\r\n			12A4\r\n			Khuyến Khích\r\n			Hóa học\r\n			 \r\n		\r\n		\r\n			32\r\n			Vũ Thu Huyền\r\n			12A4\r\n			Khuyến Khích\r\n			Hóa học\r\n			 \r\n		\r\n		\r\n			33\r\n			Vũ Thùy Trang\r\n			12B6\r\n			Nhất\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			34\r\n			Hoàng Quỳnh Anh\r\n			12B6\r\n			Nhì\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			35\r\n			Nguyễn Thị Ánh Chi\r\n			12B6\r\n			Nhì\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			36\r\n			Huỳnh Ngọc Mai\r\n			12B4\r\n			Nhì\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			37\r\n			Lê Thị Nhung\r\n			12B6\r\n			Nhì\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			38\r\n			Ngô Quang Anh\r\n			12B6\r\n			Ba\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			39\r\n			Nghiêm Thị Tú Chi\r\n			12B6\r\n			Ba\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			40\r\n			Trần Thu Huyền\r\n			12B6\r\n			Ba\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			41\r\n			Phạm Thanh Ngân\r\n			11A3\r\n			Ba\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			42\r\n			Nguyễn Như Quỳnh\r\n			11A3\r\n			Ba\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			43\r\n			Lê Anh Đào\r\n			12B4\r\n			Khuyến Khích\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			44\r\n			Mạc Ngọc Hoài\r\n			12B6\r\n			Khuyến Khích\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			45\r\n			Nguyễn Thùy Linh\r\n			12B6\r\n			Khuyến Khích\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			46\r\n			Trần Thúy Hải Linh\r\n			11A3\r\n			Khuyến Khích\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			47\r\n			Nguyễn Thị Hồng Nhung\r\n			12B6\r\n			Khuyến Khích\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			48\r\n			Nguyễn Ngọc Oánh\r\n			12B6\r\n			Khuyến Khích\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			49\r\n			Hoàng Quỳnh Trang\r\n			11A3\r\n			Khuyến Khích\r\n			Lịch sử\r\n			 \r\n		\r\n		\r\n			50\r\n			Vũ Minh Ngọc\r\n			12A3\r\n			Khuyến Khích\r\n			Ngữ Văn\r\n			 \r\n		\r\n		\r\n			51\r\n			Đoàn Thu Hoài\r\n			12B4\r\n			Khuyến Khích\r\n			Ngữ Văn\r\n			 \r\n		\r\n		\r\n			52\r\n			Lê Ngọc Mai\r\n			12B1\r\n			Nhì\r\n			Sinh học\r\n			 \r\n		\r\n		\r\n			53\r\n			Nguyễn Thị Kim Trinh\r\n			12A2\r\n			Khuyến Khích\r\n			Sinh học\r\n			 \r\n		\r\n		\r\n			54\r\n			Chu Thị Ngọc Mai\r\n			11a2\r\n			Khuyến Khích\r\n			Sinh học\r\n			 \r\n		\r\n		\r\n			55\r\n			Nguyễn Phương Oanh\r\n			11b2\r\n			Khuyến Khích\r\n			Sinh học\r\n			 \r\n		\r\n		\r\n			56\r\n			Bùi Ngọc Anh\r\n			12B4\r\n			Nhì\r\n			Tiếng Anh\r\n			 \r\n		\r\n		\r\n			57\r\n			Đinh Nguyễn Bảo Phúc\r\n			12A4\r\n			Nhì\r\n			Tiếng Anh\r\n			 \r\n		\r\n		\r\n			58\r\n			Phạm Thị Hoài\r\n			12B2\r\n			Ba\r\n			Tiếng Anh\r\n			 \r\n		\r\n		\r\n			59\r\n			Trần Thị Kim Khánh\r\n			12B3\r\n			Ba\r\n			Tiếng Anh\r\n			 \r\n		\r\n		\r\n			60\r\n			Nguyễn Tuấn Hưng\r\n			11B4\r\n			Ba\r\n			Tiếng Anh\r\n			 \r\n		\r\n		\r\n			61\r\n			Vũ Thị Hoàng Ngân\r\n			12B3\r\n			Khuyến Khích\r\n			Tiếng Anh\r\n			 \r\n		\r\n		\r\n			62\r\n			Hoàng Phương Minh\r\n			12B4\r\n			Khuyến Khích\r\n			Tiếng Anh\r\n			 \r\n		\r\n		\r\n			63\r\n			Nguyễn Quốc Huy\r\n			11B4\r\n			Khuyến Khích\r\n			Tiếng Anh\r\n			 \r\n		\r\n		\r\n			64\r\n			Đoàn Mai Huyền\r\n			12B6\r\n			Khuyến Khích\r\n			Tiếng Anh\r\n			 \r\n		\r\n		\r\n			65\r\n			Nguyễn Ngọc Linh\r\n			12B3\r\n			Khuyến Khích\r\n			Tiếng Anh\r\n			 \r\n		\r\n		\r\n			66\r\n			Bùi Hoài Linh\r\n			11B5\r\n			Nhất\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			67\r\n			Phạm Thu Hà\r\n			11A5\r\n			Nhất\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			68\r\n			Lê Thị Ngọc Linh\r\n			11A5\r\n			Nhất\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			69\r\n			Từ Quang Tùng\r\n			11A5\r\n			Nhất\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			70\r\n			Tạ Mai An\r\n			11B5\r\n			Nhất\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			71\r\n			Tạ Đức Sơn\r\n			11B5\r\n			Nhất\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			72\r\n			Vũ Thị Thanh Xuân\r\n			11B5\r\n			Nhất\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			73\r\n			Trần Thị Quỳnh Anh\r\n			12A5\r\n			Nhì\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			74\r\n			Nguyễn Đức Hiếu\r\n			11A5\r\n			Ba\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			75\r\n			Hoàng Quỳnh Mai\r\n			11A5\r\n			Ba\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			76\r\n			Bùi Thị Linh Chi\r\n			11B5\r\n			Ba\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			77\r\n			Nguyễn Song Hào\r\n			12A5\r\n			Ba\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			78\r\n			Trịnh Linh Chi\r\n			11A5\r\n			Khuyến Khích\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			79\r\n			Nguyễn Anh Tú\r\n			11A5\r\n			Khuyến Khích\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			80\r\n			Nguyễn Bạch Cúc\r\n			11B5\r\n			Khuyến Khích\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			81\r\n			Bùi Phương Linh\r\n			11B5\r\n			Khuyến Khích\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			82\r\n			Hoàng Văn Dũng\r\n			10B5\r\n			Khuyến Khích\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			83\r\n			Hoàng Minh Đạt\r\n			10B5\r\n			Khuyến Khích\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			84\r\n			Nguyễn Khánh My\r\n			10B5\r\n			Khuyến Khích\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			85\r\n			Hoàng Minh Thoa\r\n			10B5\r\n			Khuyến Khích\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			86\r\n			Bùi Hải Yến\r\n			12A5\r\n			Khuyến Khích\r\n			Tiếng pháp\r\n			 \r\n		\r\n		\r\n			87\r\n			Nguyễn Đình Minh\r\n			12b2\r\n			Nhì\r\n			Toán\r\n			 \r\n		\r\n		\r\n			88\r\n			Đỗ Thế Mạnh\r\n			11a2\r\n			Nhì\r\n			Toán\r\n			 \r\n		\r\n		\r\n			89\r\n			Nguyễn Trung Hiếu\r\n			12b1\r\n			Ba\r\n			Toán\r\n			 \r\n		\r\n		\r\n			90\r\n			Đỗ Thúy An\r\n			12a2\r\n			Ba\r\n			Toán\r\n			 \r\n		\r\n		\r\n			91\r\n			Trần Hoàng Anh\r\n			12b2\r\n			Ba\r\n			Toán\r\n			 \r\n		\r\n		\r\n			92\r\n			Phạm Văn Nam\r\n			12b2\r\n			Khuyến Khích\r\n			Toán\r\n			 \r\n		\r\n		\r\n			93\r\n			Nguyễn Thùy Linh\r\n			12a4\r\n			Khuyến Khích\r\n			Toán\r\n			 \r\n		\r\n		\r\n			94\r\n			Phạm Trung Hiếu\r\n			12a4\r\n			Khuyến Khích\r\n			Toán\r\n			 \r\n		\r\n		\r\n			95\r\n			Lưu Trọng Toàn\r\n			12b2\r\n			Khuyến Khích\r\n			Toán\r\n			 \r\n		\r\n		\r\n			96\r\n			Nguyễn Khải Hà\r\n			12b2\r\n			Khuyến Khích\r\n			Toán\r\n			 \r\n		\r\n		\r\n			97\r\n			Dương Thị Hằng\r\n			12b2\r\n			Khuyến Khích\r\n			Toán\r\n			 \r\n		\r\n		\r\n			98\r\n			Bùi thị thu Trang\r\n			12b2\r\n			Khuyến Khích\r\n			Toán\r\n			 \r\n		\r\n		\r\n			99\r\n			Mạc Văn Nam\r\n			11a2\r\n			Khuyến Khích\r\n			Toán\r\n			 \r\n		\r\n		\r\n			100\r\n			Dương Đức Thắng\r\n			12a4\r\n			Nhì\r\n			Vật lý\r\n			 \r\n		\r\n		\r\n			101\r\n			Trần Hiền\r\n			12b2\r\n			Ba\r\n			Vật lý\r\n			 \r\n		\r\n		\r\n			102\r\n			Nguyễn Thị Hồng Hạnh\r\n			12b2\r\n			Khuyến Khích\r\n			Vật lý\r\n			 \r\n		\r\n		\r\n			103\r\n			Nguyễn Thị Thu Huyền\r\n			12b2\r\n			Khuyến Khích\r\n			Vật lý\r\n			 \r\n		\r\n		\r\n			104\r\n			Lại Thuỳ Linh\r\n			11a4\r\n			Khuyến Khích\r\n			Vật lý\r\n			 \r\n		\r\n		\r\n			105\r\n			Bùi Thanh Ngọc Nam\r\n			12b2\r\n			Khuyến Khích\r\n			Vật lý\r\n			 \r\n		\r\n		\r\n			106\r\n			Nguyễn Quỳnh Trang\r\n			12b2\r\n			Khuyến Khích\r\n			Vật lý\r\n			 \r\n		\r\n		\r\n			107\r\n			Đoàn Thị Hải Yến\r\n			12b2\r\n			Khuyến Khích\r\n			Vật lý\r\n			 \r\n		\r\n	\r\n\r\n\r\n '),
(89, 'Nhà trường thông báo: từ ngày 21/1/2016, vì thời tiết lạnh, hs tạm thời không phải mặc đồng phục cho đến khi nghỉ tết nguyên đán.'),
(90, 'Mai Tuấn Linh là học sinh lớp chuyên Pháp, em được biết đến là một học sinh với thành tích học tập tốt đều các môn, thường xuyên có mặt trong các kỳ thi tiếng Pháp của thành phố, của tỉnh, và luôn đạt giải cao. Thầy cô nhắc đến em luôn là một học sinh ưu tú, thông minh và có kỷ luật. Bạn bè quý mến Linh bởi sự hòa đồng, nhiệt tình . Người thân luôn tự hào về em bởi sự hiếu thảo và lòng trắc ẩn sâu sắc với những hoàn cảnh khó khăn.\r\n Với vốn tiếng Pháp thuộc loại ưu, em lựa chọn Le Cordon Bleu làm điểm đến cho con đường học tập tiếp theo của mình. Trường nổi tiếng về đào tạo Nhà Hàng – Khách Sạn, Du Lịch - Ẩm Thực. Được thành lập năm 1895 tại Paris – Pháp, có trụ sở trên 28 quốc gia. Tại Úc, trường có 2 cơ sở học nằm tại Adelaide và Sydney. Linh đã chọn học tại cơ sở Sydney, em chia sẻ ước mơ lớn nhất của em là được học tập tại Pháp và em cũng đã có trải nghiệm đáng quý 2 tháng tại đất nước này, càng vững hơn quyết định của mình là sẽ gắn bó lâu dài với Pháp quốc. Tuy nhiên điều kiện hiện tại chưa cho phép nên em lựa chọn Úc như một đòn bẩy cần thiết cho kế hoạch tương lai lâu dài của mình. Với thành tích học tập tốt Linh không khó để được trường Le Cordon Bleu lựa chọn.\r\n\r\n /uploads/news/2016_01/untitled.png untitled\r\n \r\n\r\n Linh chia sẻ, để có được tiền đề tốt như ngày hôm nay em đã được nhận sự dạy dỗ tận tình của thầy chủ nhiệm Quốc Đạt cùng các thầy cô giáo bộ môn cũng như sự động viên khích lệ từ bạn bè. Bên cạnh đó trong suốt quá trình học tập và lựa chọn hướng đi cho tương lai của mình em luôn nhận được sự hậu thuẫn từ gia đình, đặc biệt là ông bà ngoại, Linh nói: “Ông rất thương em, với em ông còn như một người bạn tri kỉ, ông là động lực rất lớn với em”. Để thực hiện được giấc mơ du học Linh còn nhận được sự trợ giúp từ phía Trung tâm tư vấn du học Panda, một trung tâm có uy tín tại thành phố Hạ Long. Em nói\r\n“Phía trước của em còn rất nhiều khó khăn, thử thách, em còn phải nỗ lực rất nhiều mới mong có thành tích tốt để không phụ lòng thầy cô, gia đình”.\r\n\r\n Cùng sang với em còn có bạn Tạ Quang Hoàng, học sinh lớp 12B1 do cô Nguyễn Thúy Hằng làm chủ nhiệm. Hoàng là một học sinh năng động và rất vui nhộn. Môn học sở trường của em là toán và hóa. Em rất yêu thích thể thao đặc biệt là môn bóng rổ nên được giao trọng trách làm đội phó câu lạc bộ bóng rổ của trường kiêm đảm nhiệm việc dạy cho các thành viên mới. Em cùng đội của mình thường xuyên tham gia các giải thi đấu thể thao của Tỉnh và Thành phố và luôn dành được các giải cao về cho trường. \r\n \r\n\r\n\r\n\r\n\r\n /uploads/news/2016_01/untitled_2.png Hoàng ngồi thứ 2 hàng thứ 1 từ phải sang\r\n(Hoàng ngồi thứ 2 hàng thứ 1 từ phải sang)\r\n\r\n\r\n\r\n\r\n Cũng với niềm đam mê chuyên ngành Quản trị du lịch - khách sạn , Hoàng đã lựa chọn Le Cordon Bleu làm điểm đến tiếp theo cho mình trên con đường phát triển sự nghiệp.Vốn là một câu học sinh năng động và dễ gần , Hoàng nhanh chóng hòa nhập với môi trường mới cũng như các bạn ở đây. Em chia sẻ rất thích thời tiết của Úc và môi trường học tập ở đây, việc học rất thoải mái và lớp học luôn sôi nổi.\r\n\r\n \r\n\r\n /uploads/news/2016_01/untitled_3.png ( Lớp học của Hoàng tại Úc )\r\n( Lớp học của Hoàng tại Úc )\r\n\r\n\r\n\r\n\r\n “Em mong muốn được gửi lời tri ân sâu sắc tới toàn thể thầy cô trường THPT Hòn Gai đặc biệt là cô giáo chủ nhiệm Nguyễn Thúy Hằng, cô luôn tâm lý với học sinh và tạo ra các giờ học cực kỳ thoải mái. Em cũng trân trọng tình bạn của tập thể 12B1 luôn dành cho em. Riêng với bố mẹ Hoàng có nói “Em sẽ học tập và sống tốt để không phụ long bố mẹ”. Em cũng cảm ơn các chị tư vấn viên của Trung tâm du học Panda đã đồng hành cùng em trong cuộc chinh phục đỉnh cao mới lần này, kết quả đến với em rất mỹ mãn, em đã là sinh viên trường Le Cordon Bleu “\r\n\r\n Cả Linh và Hoàng, 2 cậu học trò thông minh, năng động đã góp phần tạo nên hình ảnh ngôi trường THPT Hòn Gai đẹp đẽ hơn bằng chính cái tài và cái đức của các em. Hoàng và Linh đều muốn nhắn nhủ tới các học sinh khóa tiếp theo của trường “hãy nỗ lực không ngừng và dám theo đuổi ước mơ của mình, nhất định các bạn sẽ đạt được điều mình mong muốn”.'),
(91, 'SPEAKING ENGLISH IS QUITE INTERSETING\r\n Trường THPT Hòn Gai được lựa chọn là 1 trường điển hình về dạy và học ngoại ngữ cấp THPT của tỉnh Quảng Ninh. Ngoài việc thực hiện tốt công tác dạy và học tiếng Anh theo chương trình của Bộ GD&amp;ĐT thì việc tổ chức các hoạt động ngoài giờ lên lớp có sử dụng tiếng Anh là một việc làm hết sức cần thiết trong việc đổi mới cách dạy và cách học tiếng Anh hiệu quả.\r\n Chính vì vậy, tổ ngoại ngữ dưới sự chỉ đạo của Ban Giám Hiệu đã thành lập câu lạc bộ Tiếng Anh lấy tên là Hon Gai English Club. Câu lạc bộ sẽ được tổ chức 1 lần/tháng cho mỗi khối của học sinh cấp THPT. Lần đầu tiên CLB đã ra mắt vào thứ Tư ngày 31 tháng 12 năm 2014 với sự háo hức của cả thầy và trò trường THPT Hòn Gai.\r\n Đến tham dự với buổi sinh hoạt đầu tiên có hơn 80 học sinh tham gia. Đền dự và chỉ đạo các hoạt động của CLB có đại diện Tỉnh Đoàn Quảng Ninh, Thành Đoàn Hạ Long, Giáo viên người nước ngoài của trung tâm Ngoại Ngữ Shelton cùng Ban Giám Hiệu và các thầy cô trong tổ Ngoại Ngữ.\r\n /uploads/news/2016_01/2.jpg 2\r\n\r\nVới lối dẫn chương trình dí dỏm, hấp dẫn và cách thể hiện ngôn ngữ chuẩn xác, thành thục của hai MC đã lôi cuốn và thuyết phục cả đại biểu và học sinh từ đầu tới cuối.\r\nCác bạn học sinh tham gia nhiệt tình, mạnh dạn bàn luận, thể hiễn diễn thuyết bằng tiếng Anh thông qua các hoạt động đa dạng như: nhảy, hát, diễn kịch, thuyết trình, và chơi các trò chơi. Ngôn ngữ sử trong các hoạt động này đều bằng tiếng Anh và chủ yếu là hoạt động nhóm và các bạn đã thể hiện hào hứng và sôi động.\r\n /uploads/news/2016_01/3.jpg 3\r\n\r\nCâu lạc bộ Tiếng Anh của trường cũng là nơi để học sinh giao lưu học hỏi lẫn nhau và dần cải thiện khả năng nghe, nói Tiếng Anh. Qua đây, học sinh cảm thấy tự tin hơn khi giao tiếp trước đám đông.\r\n /uploads/news/2016_01/4.jpg 4\r\n\r\nBuổi sinh hoạt được dẫn dắt bởi hai MC do chính các em học sinh tự đảm trách. Điều này khiến các thành viên trong câu lạc bộ cảm thấy gần gũi và thoải mái hơn trong việc bày tỏ quan điểm, thái độ cùng phong thái khi tham gia các hoạt động do MC hướng dẫn.\r\n /uploads/news/2016_01/5.jpg 5\r\n\r\nBuổi ra mắt đầu tiên đã diễn ra rất thành công khi số lượng học sinh đến tham gia vượt qua dự kiến. Các em tham gia với thái độ hào hứng, cởi mở. Điều làm nên sự thành công cho buổi ra mắt đầu tiên này chính nằm ở sự chuẩn bị kỹ lưỡng giữa thầy và trò trong quá trình lên kế hoạch. Không thể không kể đến đó là sự nhiệt tình của các em học sinh khi tham gia hoạt động.\r\n /uploads/news/2016_01/bietthuhiendai3.jpg bietthuhiendai3\r\n\r\nĐối với loại hình không mới này nhưng là lần đầu tiên được áp dụng vào một trường THPT, mong rằng câu lạc bộ Tiếng Anh trường THPT Hòn Gai sẽ còn phát triển hơn nữa với nhiều hoạt động giúp các em học sinh nâng cao khả năng tiếng Anh.'),
(92, 'Tại quảng trường 30/10, các em học sinh của các lớp 8A2; 10A3 và đội Thanh niên xung kích trường THPT Hòn Gai cùng với các em học sinh của các trường trên địa bàn Thành phố đã nhiệt tình tham gia hưởng ứng tuần Lễ hội Hoa anh đào Hạ Long năm 2015. Các em học sinh đã được tham gia các trò chơi dân gian vô cùng độc đáo và thú vị như: kéo có, bắt trạch, đập niêu, đẩy gậy…\r\n Thông qua các trò chơi dân gian, các em đã hiểu biết thêm truyền thông văn hóa dân tộc và quảng bá các trò chơi này đến với các bạn bè quốc tế. Các em học sinh đã tham gia nhiệt tình, vô tư và đã cống hiến cho khán giả những giây phút vui vẻ, thoải mái.\r\n Buổi giao lưu hưởng ứng tuần Lễ hội Hoa anh đào Hạ Long năm 2015 với chủ đề Hòa bình - Hợp tác – Thịnh vượng đã kết thúc trong không khí vui tươi, hào hứng và tổng hợp các trò chơi thì đội các học sinh trường THPT Hòn Gai đã xuất sắc đạt giải ba toàn đoàn.\r\n Cũng vào sáng ngày 3/4/2015, tại Trung tâm tổ chức Hội nghị Thành phố, các em học sinh của hai lớp 10B1; 10B2 đã tham dự Hội nghị giới thiệu du học Nhật Bản với chủ để Chắp cánh ước mơ, kết nối thế giới. Qua tham dự Hội nghị, các em học sinh đã có thêm các thông tin về đất nước và con người Nhật Bản cũng như môi trường học tập bên nước bạn, các em học sinh cũng được hướng dẫn các điều kiện và thủ tục để có thể học tập và nghiên cứu tại một đất nước có nền giáo dục phát triển hàng đầu thế giới.\r\n Một số hình ảnh tham gia của các em học sinh.\r\n http://quangninh.edu.vn/c3hongai/uploads/news/2015_04/img20150403081058.jpg\r\n\r\nCác em học sinh lớp 8A2\r\n \r\n\r\n http://quangninh.edu.vn/c3hongai/uploads/news/2015_04/img20150403103112.jpg\r\n\r\nCác đội chơi hào hứng tham gia các trò chơi dân gian vui nhộn.\r\n \r\n\r\n http://quangninh.edu.vn/c3hongai/uploads/news/2015_04/img20150403105313.jpg\r\n\r\nNhững người chiến thắng trong trò chơi &quot;dừng hình&quot;\r\n \r\n\r\n http://quangninh.edu.vn/c3hongai/uploads/news/2015_04/img20150403105959.jpg\r\n\r\nKhi các trò chơi kết thúc, các đội đều có phần thưởng.'),
(93, ' Mở đầu chương trình là các tiết mục văn nghệ của các em học sinh trong đội văn nghệ xung kích của Đoàn trường.\r\n Cũng trong buổi lễ, đồng chí Đỗ Thị Thu đã có bài phát biểu ôn lại chặng đường 70 năm lịch sử hào hùng, vẻ vang của Quân đội nhân dân Việt Nam và có những lời căn dặn đối với thầy và trò Nhà trường cần phải cố gắng giảng dạy và học tập thật tốt xây dựng đất nước.\r\n Kết thúc buổi lễ, thay mặt các thầy cô giáo và các em học sinh, đồng chí Hiệu trưởng Nguyễn Linh đã có bó hoa tươi thắm tặng đồng chí Nguyễn Mạnh Hòa – nguyên là một người lính cụ Hồ và bây giờ là một chiến sĩ trên mặt trận văn hóa giảng dạy môn Vật lý tại trường. Với niềm hân hoan chào đón ngày kỷ niệm, đồng chí Nguyễn Mạnh Hòa cũng đã hát dành tặng các thầy cô giáo và các em học sinh những bài hát cách mạng “đi cùng năm tháng và không thể nào quên” hết sức ý nghĩa.\r\n\r\nMột số hình ảnh của buổi lễ:\r\n \r\n http://quangninh.edu.vn/c3hongai/uploads/news/2014_12/20141222_073148.jpg\r\n \r\n\r\nTiết mục văn nghệ của các em học sinh trong đội văn nghệ xung kích của Đoàn trường\r\n(Thục Trinh - lớp 12A5)\r\n \r\n\r\n http://quangninh.edu.vn/c3hongai/uploads/news/2014_12/20141222_075648.jpg\r\n \r\n\r\nTiết mục văn nghệ của các em học sinh trong đội văn nghệ xung kích của Đoàn trường\r\n \r\n\r\n http://quangninh.edu.vn/c3hongai/uploads/news/2014_12/20141222_073423.jpg\r\n \r\n\r\nĐ/c Đỗ Thị Thu - P. Hiệu trưởng Nhà trường ôn lại chặng đường 70 năm lịch sử hào hùng, vẻ vang\r\ncủa Quân đội nhân dân Việt Nam.\r\n \r\n\r\n http://quangninh.edu.vn/c3hongai/uploads/news/2014_12/20141222_074129_1.jpg\r\n \r\n\r\nĐ/c Hiệu trưởng Nguyễn Linh đã có bó hoa tươi thắm tặng đồng chí Nguyễn Mạnh Hòa.\r\n \r\n\r\n http://quangninh.edu.vn/c3hongai/uploads/news/2014_12/20141222_074415.jpg\r\n\r\nPhút ngẫu hứng của thầy Nguyễn Mạnh Hòa.\r\n\r\n\r\nBÀI PHÁT BIỂU CỦA ĐỒNG CHÍ ĐỖ THỊ THU - P. HIỆU TRƯỞNG\r\n\r\nDiễn văn chào mừng kỉ niệm ngày 22 – 12\r\n Kính thưa: - Các Thầy giáo, Cô giáo!\r\n - Các em học sinh thân mến!\r\n Ngày 22 – 12 – 1944, theo chỉ thị của Hồ Chí Minh, Đại tướng Võ Nguyên Giáp đọc lệnh thành lập Quân đội Nhân dân Việt Nam, đến nay đã tròn 70 năm. Hằng năm cứ đến ngày này, toàn thể quân và dân ta lại tổ chức trọng thể lễ kỉ niệm ngày ra đời của Quân đội nhân dân Việt Nam và ngày Quốc phòng toàn dân. Để biểu dương truyền thống chiến đấu kiên cường của quân và dân ta trong sự nghiệp chiến đấu, bảo vệ và xây dựng Đất nước. Quân đội nhân dân Việt Nam, từ nhân dân mà ra và chiến đấu vì nhân dân, vì độc lập tự do của Tổ quốc và dân tộc. Với vũ khí thô sơ chỉ là gậy gộc, giáo mác, trang bị thiếu thốn, quân đội ta đã nêu cao tinh thần yêu nước thương nhà, lòng căm thù giặc sâu sắc. Ngay từ những năm đầu, quân ta đã đánh cho thực dân Pháp thất bại phải rút về nước.\r\n Người lính Việt Nam trong kháng chiến chống Pháp với tên gọi bình dị mà đáng yêu như &quot;Anh vệ quốc quân&quot;, &quot;Anh bộ đội cụ Hồ&quot;, &quot;Những con người áo vải, chân không đi tìm giặc đánh&quot; đã vượt qua gian khổ, hi sinh tạo nên, hết &quot;chiến công này, đến chiến công khác mà đỉnh cao là chiến dịch Điện Biên Phủ lừng lẫy năm châu, chấn động địa cầu&quot;, buộc thực dân Pháp phải kí Hiệp định Giơ-ne-vơ năm 1954 và rút quân ra khỏi Đất nước ta, phải công nhận nước Việt Nam là nước độc lập tự do, có chủ quyền: Như nhà thơ Tố Hữu đã ca ngợi\r\n &quot;Chín năm làm một Điện Biên\r\n Nên vành hoa đỏ, nên thiên sử vàng&quot;\r\n Vinh quang đó trước hết thuộc về Quân đội Việt Nam anh hùng, dưới sự lãnh đạo của Đảng Cộng sản Việt Nam.\r\n Sau khi thực dân Pháp thất bại, đế quốc Mĩ lại xâm lược nước ta. Nhân dân ta và Quân đội ta, lại phải tiến hành cuộc kháng chiến chống Mĩ cứu nước với quy mô ác liệt nhất trong lịch sử dân tộc và nhân loại. Kẻ thù đế quốc Mĩ là kẻ thù nham hiểm, hung ác nhất, tàn bạo nhất. Nhưng với truyền thống anh hùng bốn nghìn năm dựng nước và giữ nước, với sự lãnh đạo sáng suốt của Đảng, với tinh thần đoàn kết quân dân một ý chí thực hiện lời dạy của Bác Hồ: &quot;Không có gì quý hơn độc lập tự do&quot;, quân dân ta đã bách chiến, bách thắng viết lên nhiều trang sử vàng chói lọi.\r\nLớp lớp các thế hệ con cháu, cầm súng lên đường tiếp bước các thế hệ cha anh đã tạo thành đội quân trùng trùng, điệp điệp:\r\n&quot;Lớp cha trước, lớp con sau\r\nĐã thành đồng chí chung câu quân hành&quot;\r\n Với bao binh chủng xuất hiện như: Lục quân, Hải quân, Không quân, Đội quân tóc dài, đấu tranh binh vận, chính trị rồi đấu tranh vũ trang...Thật chưa bao giờ lại sáng tạo, phong phú tràn đầy dũng khí, ý chí kiên cường với trận lịch sử “ Điện biên phủ trên không” 12 ngày đêm trên bầu trời Hà Nội và kết tinh là đỉnh là cao chiến dịch Hồ Chí Minh lịch sử.\r\n Đế quốc Mĩ và bọn tay sai thất trận, lại đạp lên nhau xéo chạy khỏi đất nước Việt Nam, buộc phải kí Hiệp định Pari thừa nhận chủ quyền thống nhất, độc lập toàn vẹn lãnh thổ Việt Nam.\r\n Kính thưa các Thầy giáo, Cô giáo và toàn thể các em!\r\n Trong kháng chiến chống Mĩ cứu nước, mái trường thân yêu của chúng ta đã trở thành pháo đài trên mặt trận văn hoá và có những đóng góp rất đáng tự hào.\r\n Nhiều Thầy giáo, Cô giáo và hàng trăm học sinh trường ta đãtừ bỏ ước mơ vào đại học, xếp bút nghiên tình nguyện lên đường đi chiến đấu. Các chiến sĩ trường ta dù ở binh chủng nào cũng chiến đấu anh hùng, lập nhiều chiến công. Có đồng chí đã trở thành anh hùng như đồng chí Đỗ Viết Cường có các đ/c đã hi sinh mãi mãi không bao giờ trở về, đó là các liệt sỹ: Vũ Minh Trí,Nguyễn văn Quang, Trần mạnh Dũng,Vũ Thành Tâm, Nguyễn văn Thuận, Nguyễn Văn Toàn, Đào tiến Lộc, Nguyễn Văn Thanh và nhiều liệt sỹ khác. Có những Thầy giáo sau khi hoàn thành nhiệm vụ chiến đấu, lại trở về với nhiệm vụ trồng người Như thầy giáo Nguyễn Mạnh Hòa giáo viên trường ta.\r\n Kinh thưa các Thầy giáo, Cô giáo và các em!\r\n Tự hào về Quân đội Việt Nam anh hùng, Thầy trò chúng ta càng phải tìm ra những bài học sâu sắc cho mình để vận dụng sáng tạo trong sự nghiệp giáo dục, khoa học, xây dựng con người mới trong sự nghiệp công nghiệp hoá, hiện đại hoá hôm nay.\r\n Trước hết, Thầy trò chúng ta phải học tập phẩm chất anh hùng, lý tưởng cao cả vì Nhân dân, vì Đất nước mà chiến đấu của người chiến sĩ Việt Nam. Sự lười biếng trong học tập, lao động, sự thiếu ý chí quyết tâm vươn lên trong nghiên cứu khoa học, trong tu dưỡng đạo đức, tài năng; rồi những tệ nạn xã hội như: Ma tuý, HIV/AIDS đang ngày đêm phá hoại cuộc sống của chúng ta còn ác liệt, tệ hại hơn cả bom đạn - đó là những kẻ thù giấu mặt, rất âm thầm nhưng lại có sức công phá, xói mòn chân lý, đạo lý đến mức ghê sợ. Vậy! chúng ta phải tỉnh táo, cảnh giác, học tập tinh thần người lính chiến đấu với những tệ nạn ấy, quyết không đầu hàng, khuất phục.\r\n Kính thưa các Thầy giáo, Cô giáo và các em!\r\n Kỉ niệm ngày thành lập Quân đội Nhân dân Việt Nam – ngày Quốc phòng toàn dân, năm nay, trường ta đang chuyển mình với vị thế, tầm vóc mới rất đáng phấn khởi, thành phố Hạ Long tỉnh Quảng Ninh cũng như bối cảnh chung của Đất nước đang chuyển biến tốt đẹp có nhiều hứa hẹn.\r\nQuê hương, Đất nước, tương lai cuộc sống đang cần đến các em. Các em phải sống, học tập, rèn luyện để đền đáp lại sự hi sinh xương máu của những chiến sĩ quân đội cho cuộc sống hoà bình, hạnh phúc hôm nay; để không khỏi hổ thẹn trước những mong mỏi, chờ đợi của Đất nước, của Nhân dân. Tương lai tươi sáng của thế kỉ 21 đang đón chào các em!\r\n Thay mặt các Thầy giáo, Cô giáo, tôi xin cảm ơn và chúc các Thầy giáo, Cô giáo, các em học sinh những lời chúc mừng tốt đẹp nhất.Trân trọng cảm ơn!( vỗ tay)\r\n Kính thưa các Thầy giáo, Cô giáo và các em!\r\n Trong niềm vui hân hoàn tự hào về người lính cụ Hồ, có những Thầy giáo, cô giáo sau khi hoàn thành nhiệm vụ chiến đấu lại trở về với nhiệm vụ trồng người ở trường ta. Tôi xin trân trọng giới thiệu và kính mời lên sân khấu cựu chiến binh: Đó là:Thầy Nguyễn Mạnh Hòa giáo viên môn Vật Lý.\r\n '),
(94, '- Thứ Hai: \r\n+ Sáng: Các lớp THPT Khối A tập quân sự từ 7h15 đến 10h00. Khối THCS đẩy giờ học từ tiết 1 đến tiết 4. \r\n\r\n+ Chiều: Các lớp THPT Khối B tập quân sự từ 13h30. Khối THCS học từ tiết 2 đến tiết 5. \r\n- Thứ 3: \r\n\r\n+ Sáng: Các lớp THPT Khối A tập quân sự từ 7h15. Khối THCS học bình thường theo TKB. \r\n\r\n+ Sáng: Từ 7h30 tập huấn về đưa bài viết và tài liệu lên trang web của trường (Mỗi tổ CM cử 1 GV tham gia tập huấn).\r\n\r\n+ Chiều: Các lớp THPT Khối B tập quân sự từ 13h30. Khối THCS học bình thường theo TKB. \r\n- Thứ 4: \r\n\r\n+ Sáng : Sơ kết trong học sinh từ 7h15. \r\n\r\n+ Chiều : Sơ kết trong giáo viên từ 14h00.\r\n\r\nHiệu trưởng\r\nNguyễn Linh');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_cat`
--

CREATE TABLE `pacorp_vi_news_cat` (
  `catid` smallint(5) UNSIGNED NOT NULL,
  `parentid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titlesite` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci,
  `descriptionhtml` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `viewdescription` tinyint(2) NOT NULL DEFAULT '0',
  `weight` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) UNSIGNED NOT NULL DEFAULT '3',
  `featured` int(11) NOT NULL,
  `newday` tinyint(2) UNSIGNED NOT NULL DEFAULT '2',
  `keywords` text COLLATE utf8mb4_unicode_ci,
  `admins` text COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edit_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `groups_view` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_news_cat`
--

INSERT INTO `pacorp_vi_news_cat` (`catid`, `parentid`, `title`, `titlesite`, `alias`, `description`, `descriptionhtml`, `image`, `viewdescription`, `weight`, `sort`, `lev`, `viewcat`, `numsubcat`, `subcatid`, `inhome`, `numlinks`, `featured`, `newday`, `keywords`, `admins`, `add_time`, `edit_time`, `groups_view`) VALUES
(9, 0, 'Hoạt động chuyên môn', 'Hoạt động chuyên môn', 'hoat-dong-chuyen-mon', 'Hoạt động chuyên môn', 'Hoạt động chuyên môn', '', 0, 3, 5, 0, 'viewcat_page_new', 3, '10,11,12', 1, 3, 0, 2, 'chuyên đề hòn gai, chuyên đề bộ môn hòn gai', '', 1450816866, 1450816866, '6'),
(10, 9, 'Chỉ đạo chuyên môn', 'Chỉ đạo chuyên môn', 'chi-dao-chuyen-mon', 'Chỉ đạo chuyên môn', 'Chỉ đạo chuyên môn', '', 0, 1, 6, 1, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Chỉ đạo chuyên môn', '', 1450816905, 1450816905, '6'),
(8, 0, 'Tin tức - Sự kiện', 'Tin hoạt động của nhà trường', 'tin-tuc-su-kien', 'Tin hoạt động của nhà trường', 'Tin hoạt động của nhà trường', '', 0, 1, 1, 0, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Hoạt động của trường hòn gai, hòn gai, thpt hòn gai', '', 1450816781, 1450817096, '6'),
(11, 9, 'Hoạt động tổ CM', 'Hoạt động các tổ chuyên môn', 'hoat-dong-to-cm', 'Hoạt động các tổ chuyên môn', 'Hoạt động các tổ chuyên môn', '', 0, 2, 7, 1, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Hoạt động các tổ chuyên môn', '', 1450816947, 1450816947, '6'),
(12, 9, 'Đội tuyển HSG', 'Đội tuyển HSG trường Hòn Gai', 'doi-tuyen-hsg', 'Đội tuyển HSG trường Hòn Gai', 'Đội tuyển HSG trường Hòn Gai', '', 0, 3, 8, 1, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Đội tuyển HSG trường Hòn Gai', '', 1450817001, 1450817001, '6'),
(13, 0, 'Thông báo', 'Thông báo của trường THPT Hòn Gai', 'thong-bao', 'Thông báo của trường THPT Hòn Gai', 'Thông báo của trường THPT Hòn Gai', '', 0, 2, 2, 0, 'viewcat_page_new', 2, '26,27', 1, 3, 0, 2, 'Thông báo của trường THPT Hòn Gai', '', 1450817145, 1450817145, '6'),
(14, 0, 'Hoạt động phong trào', 'Hoạt động phong trào trường THPT Hòn Gai', 'hoat-dong-phong-trao', 'Hoạt động phong trào trường THPT Hòn Gai', 'Hoạt động phong trào trường THPT Hòn Gai', '', 0, 4, 9, 0, 'viewcat_page_new', 3, '15,16,17', 1, 3, 0, 2, 'Hoạt động phong trào trường THPT Hòn Gai', '', 1450817184, 1450817184, '6'),
(15, 14, 'Công tác đoàn', 'Công tác đoàn trường THPT Hòn Gai', 'cong-tac-doan', 'Công tác đoàn trường THPT Hòn Gai', 'Công tác đoàn trường THPT Hòn Gai', '', 0, 1, 10, 1, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Công tác đoàn trường THPT Hòn Gai', '', 1450817214, 1450817214, '6'),
(16, 14, 'Hoạt động công đoàn', 'Hoạt động công đoàn', 'hoat-dong-cong-doan', 'Hoạt động công đoàn', 'Hoạt động công đoàn', '', 0, 2, 11, 1, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Hoạt động công đoàn', '', 1450817233, 1450817233, '6'),
(17, 14, 'Công tác đội', 'Công tác đội', 'cong-tac-doi', 'Công tác đội', 'Công tác đội', '', 0, 3, 12, 1, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Công tác đội', '', 1450817248, 1450817248, '6'),
(18, 0, 'Trường xưa', 'Chuyên mục trường xưa trường Hòn Gai', 'truong-xua', 'Chuyên mục trường xưa trường Hòn Gai', 'Chuyên mục trường xưa trường Hòn Gai', '', 0, 5, 13, 0, 'viewcat_page_new', 3, '19,20,25', 1, 3, 0, 2, 'Chuyên mục trường xưa trường Hòn Gai', '', 1450817638, 1450817638, '6'),
(19, 18, 'Cựu học sinh', 'Cựu học sinh trường THPT Hòn Gai', 'cuu-hoc-sinh', 'Cựu học sinh trường THPT Hòn Gai', 'Cựu học sinh trường THPT Hòn Gai', '', 0, 1, 14, 1, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Cựu học sinh trường THPT Hòn Gai', '', 1450817676, 1450817676, '6'),
(20, 18, 'Lưu bút học trò', 'Lưu bút học trò', 'luu-but-hoc-tro', 'Lưu bút học trò', 'Lưu bút học trò', '', 0, 2, 15, 1, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Lưu bút học trò', '', 1450817692, 1450817692, '6'),
(21, 0, 'Hợp tác Quốc tế', 'Hợp tác Quốc tế', 'hop-tac-quoc-te', 'Hợp tác Quốc tế', 'Hợp tác Quốc tế', '', 0, 6, 17, 0, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Hợp tác Quốc tế', '', 1450844832, 1450844832, '6'),
(22, 0, 'Gương mặt tiêu biểu', 'Gương mặt tiêu biểu trường THPT Hòn Gai', 'guong-mat-tieu-bieu', 'Gương mặt tiêu biểu trường THPT Hòn Gai', 'Gương mặt tiêu biểu trường THPT Hòn Gai', '', 0, 7, 18, 0, 'viewcat_page_new', 2, '23,24', 1, 3, 0, 2, 'Gương mặt tiêu biểu trường THPT Hòn Gai', '', 1450844871, 1450844871, '6'),
(23, 22, 'Học sinh tiêu biểu', 'Học sinh tiêu biểu', 'hoc-sinh-tieu-bieu', 'Học sinh tiêu biểu', 'Học sinh tiêu biểu', '', 0, 1, 19, 1, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Học sinh tiêu biểu', '', 1450844894, 1450844894, '6'),
(24, 22, 'Giáo viên tiêu biểu', 'Giáo viên tiêu biểu', 'giao-vien-tieu-bieu', 'Giáo viên tiêu biểu', 'Giáo viên tiêu biểu', '', 0, 2, 20, 1, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Giáo viên tiêu biểu', '', 1450844925, 1450844925, '6'),
(25, 18, 'Ký ức học trò', 'Ký ức học trò', 'ky-uc-hoc-tro', 'Ký ức học trò', 'Ký ức học trò', '', 0, 3, 16, 1, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Ký ức học trò', '', 1450882029, 1450882029, '6'),
(26, 13, 'Thông tin công khai', 'Thông tin công khai về các thông tin nhà trường THPT Hòn Gai', 'thong-tin-cong-khai', 'Thông tin công khai về các thông tin nhà trường THPT Hòn Gai', 'Thông tin công khai về các thông tin nhà trường THPT Hòn Gai', '', 0, 1, 3, 1, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'công khai tài chính, cong khai đội ngũ, công khai chất lượng', '', 1453352494, 1453352494, '6'),
(27, 13, 'Thông báo', 'Thông báo của trường THPT Hòn Gai', 'thong-bao-27', 'Thông báo của trường THPT Hòn Gai', 'Thông báo của trường THPT Hòn Gai', '', 0, 2, 4, 1, 'viewcat_page_new', 0, '', 1, 3, 0, 2, 'Thông báo của trường THPT Hòn Gai', '', 1453352550, 1453352550, '6');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_config_post`
--

CREATE TABLE `pacorp_vi_news_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_logs`
--

CREATE TABLE `pacorp_vi_news_logs` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `set_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_rows`
--

CREATE TABLE `pacorp_vi_news_rows` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `author` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_news_rows`
--

INSERT INTO `pacorp_vi_news_rows` (`id`, `catid`, `listcatid`, `topicid`, `admin_id`, `author`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(89, 27, '13,27', 0, 5, 'Admin', 7, 1453359849, 1454010226, 1, 1453359540, 0, 2, 'Thông báo về việc mặc đồng phục', 'thong-bao-ve-viec-mac-dong-phuc', 'Nhà trường thông báo:  từ ngày 21/1/2016, vì thời tiết lạnh, hs tạm thời không phải mặc đồng phục cho đến khi nghỉ tết nguyên đán.', '2015_12/images730419_dsc_1945.jpg', '', 1, 1, '6', 1, 198, 0, 0, 0),
(88, 8, '8,12', 1, 1, 'PDT', 5, 1451316832, 1453918545, 1, 1451315820, 0, 2, 'Trường THPT đạt thành tích cao trong kỳ thi chọn HSG cấp tỉnh năm 2015', 'truong-thpt-dat-thanh-tich-cao-trong-ky-thi-chon-hsg-cap-tinh-nam-2015', 'Trong kỳ thi chọn HSG cấp tỉnh THPT năm 2015 diễn ra ngày 8/12/2015, trường THPT Hòn Gai có 213 em tham gia dự thi ở 10 môn thi và đã đạt 107 giải, đứng thứ 3 toàn tỉnh.', '2015_12/bui-thu-thuy-giai-3-asean-2008.jpg', 'Bùi Thu Thủy &#40;trái&#41; đạt giải Ba ASEAN năm 2008', 1, 1, '6', 1, 293, 0, 0, 0),
(87, 8, '8', 0, 1, 'PDT', 5, 1451237022, 1451238598, 1, 1451235840, 0, 2, 'Trường THPT Hòn Gai tham gia cuộc thi KHKT cấp tỉnh dành cho học sinh trung học năm học 2015-2016', 'truong-thpt-tham-gia-cuoc-thi-khkt-cap-tinh-danh-cho-hoc-sinh-trung-hoc-nam-hoc-2015-2016', 'Trong các ngày 24, 25, 26/12/2015, tại trường trung học phổ thông Cẩm Phả, Sở Giáo dục và Đào tạo đã tổ chức Cuộc thi Khoa học kỹ thuật cấp tỉnh dành cho học sinh trung học năm học 2015-2016. Trường THPT Hòn Gai tham gia với 2 sản phẩm dự thi: Máy tập thể dục Power Plus và phần mềm Mê cung hóa học.', '2015_12/thi-khkt-2015-cap-tinh-1_1.jpg', 'Đại diện các thí sinh tham gia cuộc thi nhận cờ của Ban tổ chức', 1, 1, '6', 1, 246, 0, 0, 0),
(86, 25, '18,25', 0, 1, '', 4, 1450882922, 1450882922, 1, 1450882020, 0, 2, 'Bịn rịn lúc chia tay mái trường', 'bin-rin-luc-chia-tay-mai-truong', 'Những ngày này, nhiều trường THPT trên địa bàn TP Hạ Long tổ chức tổng kết năm học 2013-2014 và chia tay khối 12. Trong tà áo dài trắng tinh khôi, các nữ sinh Trường THPT Hòn Gai bịn rịn chia tay bạn bè, mái trường thân yêu. Những dòng lưu bút, những cái ôm thật chặt và cả những lời chúc thi tốt được gửi trao trong ngày chia xa.', '2015_12/images730386_dsc_1002.jpg', 'Bịn rịn lúc chia tay', 1, 1, '4', 1, 280, 0, 0, 0),
(84, 27, '13,27', 0, 1, 'Admin', 6, 1450819406, 1454010239, 1, 1450819020, 0, 2, 'Thời khóa biểu mới &#40;22&#x002F;12&#x002F;2015&#41;', 'thoi-khoa-bieu-moi-22-12-2015', 'Nhà trường thông báo thời khóa biểu Học kỳ 2 năm học 2015-2106 thực hiện từ ngày 22/12/2015', '2015_12/tkb.jpg', 'Thời khóa biểu', 1, 1, '6', 1, 401, 0, 0, 0),
(85, 8, '8', 0, 1, '', 3, 1450820291, 1450820866, 1, 1450819860, 0, 2, 'Giải Đẩy gậy Hội khỏe Phù Đổng tỉnh Quảng Ninh lần thứ IX - 2016', 'giai-day-gay-hoi-khoe-phu-dong-tinh-quang-ninh-lan-thu-ix-2016', 'Sáng 10/12/2015, tại Nhà Luyện tập và Thi đấu Thể dục thể thao tỉnh Quảng Ninh, Ban Tổ chức Hội khỏe Phù Đổng Tỉnh tổ chức Lễ khai mạc Giải Đẩy gậy Hội khỏe Phù Đổng tỉnh Quảng Ninh lần thứ IX.', '2015_12/day-gay-cap-tinh.jpg', 'Đẩy gậy cấp tỉnh', 1, 1, '6', 1, 226, 0, 0, 0),
(90, 23, '22,23', 0, 2, 'Admin', 8, 1454008983, 1454038548, 1, 1454008560, 0, 2, 'HAI HỌC SINH ƯU TÚ TRƯỜNG THPT HÒN GAI XUẤT SẮC ĐƯỢC NHẬN VÀO HỌC VIỆN DANH TIẾNG TẠI ÚC', 'hai-hoc-sinh-uu-tu-truong-thpt-hon-gai-xuat-sac-duoc-nhan-vao-hoc-vien-danh-tieng-tai-uc', 'Kết thúc khóa học 2013-2014 vừa qua trường THPT Hòn Gai vinh dự có 2 học sinh được nhận vào học viện Le Cordon Bleu, một trong những trường đào tạo chuyên về ngành Quản trị khách sạn du lịch tại Úc. Đó là em Mai Tuấn Linh lớp 12A5 và em Tạ Quang Hoàng lớp 12B1.', '2016_01/mai-tuan-linh.png', 'Mai Tuấn Linh', 1, 1, '4', 1, 205, 0, 0, 0),
(91, 11, '9,11', 2, 2, 'Nguyễn Thị Tuyết Anh', 9, 1454010143, 1454010143, 1, 1454009880, 0, 2, 'TRƯỜNG THPT HÒN GAI THÀNH LẬP CÂU LẠC BỘ TIẾNG ANH', 'truong-thpt-hon-gai-thanh-lap-cau-lac-bo-tieng-anh', 'Dưới sự chỉ đạo của Ban Giám Hiệu,tổ Ngoại ngữ đã thành lập câu lạc bộ Tiếng Anh lấy tên là Hon Gai English Club. Câu lạc bộ sẽ được tổ chức 1 lần/tháng cho mỗi khối của học sinh cấp THPT. Lần đầu tiên CLB đã ra mắt vào thứ Tư ngày 31 tháng 12 năm 2014 với sự háo hức của cả thầy và trò trường THPT Hòn Gai.', '2016_01/1.jpg', 'Thành lập CLB tiếng Anh', 1, 1, '6', 1, 173, 0, 0, 0),
(92, 8, '8', 0, 3, 'Nguyễn Khoa', 10, 1454032624, 1454033376, 1, 1454032440, 0, 2, 'HỌC SINH TRƯỜNG THPT HÒN GAI HƯỞNG ỨNG TUẦN LỄ HỘI HOA ANH ĐÀO HẠ LONG NĂM 2015', 'hoc-sinh-truong-thpt-hon-gai-huong-ung-tuan-le-hoi-hoa-anh-dao-ha-long-nam-2015', 'Thực hiện công văn số 1214/UBND của Thành phố Hạ Long ngày 31/3/2015, công văn số 633/SGD&ĐT-VP ngày 31/3/2015 của Sở GD Quảng Ninh về việc phối hợp phối hợp hỗ trợ lực lượng tham gia Lễ hội Hoa anh đào Hạ Long năm 2015, sáng ngày 3/4/2015, học sinh các lớp 8A2; 10A3; 10B1; 10B2 và đội Thanh niên xung kích trường THPT Hòn Gai đã tham gia một số hoạt động của Lễ hội Hoa anh đào năm Hạ Long năm 2015, như chơi các trò chơi dân gian và tham gia Hội nghị giới thiệu du học Nhật Bản.', '2016_01/img20150403105313.jpg', 'Học sinh trường THPT Hòn Gai tham gia lễ hội Hoa anh đào 2015', 1, 1, '4', 1, 124, 0, 0, 0),
(93, 8, '8', 0, 3, 'Nguyễn Khoa', 11, 1454033304, 1454033304, 1, 1454032860, 0, 2, 'LỄ KỶ NIỆM 70 NĂM THÀNH LẬP QUÂN ĐỘI NHÂN DÂN VIỆT NAM &#40;22&#x002F;12&#x002F;1944 - 22&#x002F;12&#x002F;2014&#41;', 'le-ky-niem-70-nam-thanh-lap-quan-doi-nhan-dan-viet-nam-22-12-1944-22-12-2014', 'Nhân dịp kỷ niệm 70 năm ngày thành lập Quân đội nhân dân Việt Nam và 25 năm ngày hội Quốc phòng toàn dân, giờ chào cờ đầu tuần sáng ngày 22/12/2014, trường THPT Hòn Gai tổ chức buổi lễ “Kỷ niệm 70 năm ngày thành lập quân đội nhân dân Việt Nam”.', '2016_01/20141222_075648.jpg', 'Văn nghệ chào mừng 70 năm ngày thành lập Quân đội nhân dân Việt Nam', 1, 1, '4', 1, 118, 0, 0, 0),
(94, 13, '13,27', 0, 2, 'Admin', 7, 1454128409, 1454132740, 1, 1454128080, 0, 2, 'Thông Báo KHẨN  về lịch tuần từ 01&#x002F;02-04&#x002F;02&#x002F;2016', 'thong-bao-khan-ve-lich-tuan-tu-01-02-04-02-2016', 'Theo dự báo thời tiết thứ 2 có mưa nhỏ, nhà trường đổi Lễ sơ kết HK1 vào ngày thứ 4. Kế hoạch cụ thể như sau:', '2016_01/thong-bao-khan.jpg', 'Thông báo khẩn', 1, 1, '6', 1, 202, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_sources`
--

CREATE TABLE `pacorp_vi_news_sources` (
  `sourceid` mediumint(8) UNSIGNED NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `add_time` int(11) UNSIGNED NOT NULL,
  `edit_time` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_news_sources`
--

INSERT INTO `pacorp_vi_news_sources` (`sourceid`, `title`, `link`, `logo`, `weight`, `add_time`, `edit_time`) VALUES
(1, 'vnexpress.net', 'http://vnexpress.net', '', 1, 1430433433, 1430433433),
(2, 'dantri.com.vn', 'http://dantri.com.vn', '', 2, 1430433742, 1430433742),
(3, 'Công thông tin SGD', '', '', 3, 1450820291, 1450820291),
(4, 'Báo Quảng Ninh', '', '', 4, 1450882922, 1450882922),
(5, 'Admin', '', '', 5, 1451237022, 1451237022),
(6, 'Bộ phận TKB.', '', '', 6, 1453352605, 1453352605),
(7, 'BGH', '', '', 7, 1454006856, 1454006856),
(8, 'Quangninh.edu.vn', '', '', 8, 1454008983, 1454008983),
(9, 'Tổ Ngoại ngữ', '', '', 9, 1454010143, 1454010143),
(10, 'Đoàn trường THPT Hòn Gai', '', '', 10, 1454032624, 1454032624),
(11, 'Nguyễn Trọng Nghĩa - Bí thư Đoàn trường', '', '', 11, 1454033304, 1454033304);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_tags`
--

CREATE TABLE `pacorp_vi_news_tags` (
  `tid` mediumint(8) UNSIGNED NOT NULL,
  `numnews` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_news_tags`
--

INSERT INTO `pacorp_vi_news_tags` (`tid`, `numnews`, `alias`, `image`, `description`, `keywords`) VALUES
(1, 1, 'hsg-cấp-tỉnh', '', '', 'hsg cấp tỉnh'),
(2, 1, 'thông-báo', '', '', 'thông báo');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_tags_id`
--

CREATE TABLE `pacorp_vi_news_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_news_tags_id`
--

INSERT INTO `pacorp_vi_news_tags_id` (`id`, `tid`, `keyword`) VALUES
(88, 1, 'hsg cấp tỉnh'),
(94, 2, 'thông báo');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_news_topics`
--

CREATE TABLE `pacorp_vi_news_topics` (
  `topicid` smallint(5) UNSIGNED NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_news_topics`
--

INSERT INTO `pacorp_vi_news_topics` (`topicid`, `title`, `alias`, `image`, `description`, `weight`, `keywords`, `add_time`, `edit_time`) VALUES
(1, 'HSG', 'HSG', '', 'HSG', 1, 'HSG', 1451316832, 1451316832),
(2, 'CLB', 'CLB', '', 'CLB', 2, 'CLB', 1454010143, 1454010143);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_page`
--

CREATE TABLE `pacorp_vi_page` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_page_config`
--

CREATE TABLE `pacorp_vi_page_config` (
  `config_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_page_config`
--

INSERT INTO `pacorp_vi_page_config` (`config_name`, `config_value`) VALUES
('viewtype', '0'),
('facebookapi', ''),
('per_page', '20'),
('news_first', '0'),
('related_articles', '5');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_photos_album`
--

CREATE TABLE `pacorp_vi_photos_album` (
  `album_id` mediumint(8) UNSIGNED NOT NULL,
  `category_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_keyword` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `model` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `capturedate` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `capturelocal` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `folder` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `layout` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `num_photo` mediumint(3) UNSIGNED NOT NULL DEFAULT '0',
  `viewed` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `weight` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `allow_rating` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `favorite` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `groups_view` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `author` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `author_modify` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `allow_comment` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `date_added` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `date_modified` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_photos_album`
--

INSERT INTO `pacorp_vi_photos_album` (`album_id`, `category_id`, `name`, `alias`, `description`, `meta_title`, `meta_description`, `meta_keyword`, `tag`, `model`, `capturedate`, `capturelocal`, `folder`, `layout`, `num_photo`, `viewed`, `weight`, `allow_rating`, `total_rating`, `click_rating`, `favorite`, `status`, `groups_view`, `author`, `author_modify`, `allow_comment`, `hitscm`, `date_added`, `date_modified`) VALUES
(1, 1, 'GIẢI BÓNG NÉM NỮ 2016', 'giai-bong-nem-nu-2016', 'Giải bóng ném nữ 2016', 'Giải bóng ném nữ 2016', 'Giải bóng ném nữ 2016', 'Giải bóng ném nữ 2016', '', '', '0', '', '2016/01/giai-bong-nem-nu-2016', 'body-right', 11, 4, 0, 1, 0, 0, 0, 1, '6', 2, 2, '6', 0, 1454007524, 1454007524),
(2, 3, 'Hoạt Động Của Tổ Thể Dục - Nhạc Họa', 'hoat-dong-cua-to-the-duc-nhac-hoa', 'Hoạt Động Của Tổ Chuyên Môn', '', '', '', '', '', '0', '', '2016/02/to-the-duc-nhac-hoa', '', 4, 2, 0, 1, 0, 0, 0, 1, '6', 7, 7, '6', 0, 1454383136, 1454383136),
(3, 3, 'to sn', 'to-sn', '', '', '', '', '', '', '0', '', '2016/02/to-sn', 'body-right', 1, 3, 0, 1, 0, 0, 0, 1, '6', 8, 8, '6', 0, 1454383347, 1454383347);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_photos_category`
--

CREATE TABLE `pacorp_vi_photos_category` (
  `category_id` smallint(5) UNSIGNED NOT NULL,
  `parent_id` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci,
  `meta_title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_keyword` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `sort_order` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `layout` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `viewcat` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) UNSIGNED NOT NULL DEFAULT '3',
  `num_album` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `groups_view` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `date_added` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `date_modified` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_photos_category`
--

INSERT INTO `pacorp_vi_photos_category` (`category_id`, `parent_id`, `name`, `alias`, `description`, `meta_title`, `meta_description`, `meta_keyword`, `weight`, `sort_order`, `lev`, `layout`, `viewcat`, `numsubcat`, `subcatid`, `inhome`, `status`, `numlinks`, `num_album`, `groups_view`, `date_added`, `date_modified`) VALUES
(1, 0, 'HOẠT ĐỘNG TẬP THỂ', 'hoat-dong-tap-the', 'Các hoạt động tập thể', 'Các hoạt động tập thể', 'Các hoạt động tập thể', 'Các hoạt động tập thể', 1, 1, 0, 'body-right', 'viewcat_grid', 0, '', 1, 1, 4, 1, '6', 1454007296, 1454007296),
(2, 0, 'HOẠT ĐỘNG ĐOÀN TN', 'hoat-dong-doan-tn', 'Hoạt động đoàn thanh niên', 'Hoạt động đoàn thanh niên', 'Hoạt động đoàn thanh niên', 'Hoạt động đoàn thanh niên', 2, 2, 0, 'body-right', 'viewcat_grid', 0, '', 1, 1, 4, 0, '6', 1454007333, 1454007333),
(3, 0, 'HOẠT ĐỘNG CHUYÊN MÔN', 'hoat-dong-chuyen-mon', 'Hoạt động chuyên môn', 'Hoạt động chuyên môn', 'Hoạt động chuyên môn', 'Hoạt động chuyên môn', 3, 3, 0, 'body-right', 'viewcat_grid', 0, '', 1, 1, 4, 2, '6', 1454007364, 1454007364),
(4, 0, 'HOẠT ĐỘNG CÔNG ĐOÀN', 'hoat-dong-cong-doan', 'Hoạt động công đoàn', 'Hoạt động công đoàn', 'Hoạt động công đoàn', 'Hoạt động công đoàn', 4, 4, 0, 'body-right', 'viewcat_grid', 0, '', 1, 1, 4, 0, '6', 1454007390, 1454007390);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_photos_rows`
--

CREATE TABLE `pacorp_vi_photos_rows` (
  `row_id` mediumint(8) UNSIGNED NOT NULL,
  `album_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `defaults` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `size` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `width` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `height` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `mime` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `file` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumb` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `favorite` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `viewed` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `date_added` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `date_modified` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_photos_rows`
--

INSERT INTO `pacorp_vi_photos_rows` (`row_id`, `album_id`, `name`, `description`, `defaults`, `size`, `width`, `height`, `mime`, `file`, `thumb`, `favorite`, `status`, `viewed`, `date_added`, `date_modified`) VALUES
(1, 1, '5.jpg', '', 0, 105407, 960, 538, 'image/jpeg', '2016/01/giai-bong-nem-nu-2016/5.jpg', '/2016/01/90x72-5.jpg', 0, 1, 20, 1454007524, 1454007524),
(2, 1, '6.jpg', '', 0, 115076, 960, 538, 'image/jpeg', '2016/01/giai-bong-nem-nu-2016/6.jpg', '/2016/01/90x72-6.jpg', 0, 1, 19, 1454007524, 1454007524),
(3, 1, '7.jpg', '', 0, 121317, 960, 538, 'image/jpeg', '2016/01/giai-bong-nem-nu-2016/7.jpg', '/2016/01/90x72-7.jpg', 0, 1, 19, 1454007524, 1454007524),
(4, 1, '8.jpg', '', 0, 93271, 960, 538, 'image/jpeg', '2016/01/giai-bong-nem-nu-2016/8.jpg', '/2016/01/90x72-8.jpg', 0, 1, 16, 1454007524, 1454007524),
(5, 1, '9.jpg', '', 0, 111724, 960, 538, 'image/jpeg', '2016/01/giai-bong-nem-nu-2016/9.jpg', '/2016/01/90x72-9.jpg', 0, 1, 17, 1454007524, 1454007524),
(6, 1, '10.jpg', '', 0, 108467, 960, 538, 'image/jpeg', '2016/01/giai-bong-nem-nu-2016/10.jpg', '/2016/01/90x72-10.jpg', 0, 1, 14, 1454007524, 1454007524),
(7, 1, '11.jpg', '', 0, 81262, 960, 538, 'image/jpeg', '2016/01/giai-bong-nem-nu-2016/11.jpg', '/2016/01/90x72-11.jpg', 0, 1, 14, 1454007524, 1454007524),
(8, 1, '1.jpg', '', 0, 96034, 960, 538, 'image/jpeg', '2016/01/giai-bong-nem-nu-2016/1.jpg', '/2016/01/90x72-1.jpg', 0, 1, 13, 1454007524, 1454007524),
(9, 1, '2.jpg', '', 0, 108554, 960, 538, 'image/jpeg', '2016/01/giai-bong-nem-nu-2016/2.jpg', '/2016/01/90x72-2.jpg', 0, 1, 14, 1454007524, 1454007524),
(10, 1, '3.jpg', '', 0, 108965, 960, 538, 'image/jpeg', '2016/01/giai-bong-nem-nu-2016/3.jpg', '/2016/01/90x72-3.jpg', 0, 1, 14, 1454007524, 1454007524),
(11, 1, '4.jpg', '', 1, 112592, 960, 538, 'image/jpeg', '2016/01/giai-bong-nem-nu-2016/4.jpg', '/2016/01/90x72-4.jpg', 0, 1, 15, 1454007524, 1454007524),
(12, 2, '1374256-10202209702946711-310742492-n.jpg', '', 0, 81883, 960, 638, 'image/jpeg', '2016/02/to-the-duc-nhac-hoa/1374256-10202209702946711-310742492-n.jpg', '/2016/02/90x72-1374256-10202209702946711-310742492-n.jpg', 0, 1, 9, 1454383136, 1454383136),
(13, 2, '12313618-773635319446637-4611555932033199105-n.jpg', '', 1, 109903, 960, 720, 'image/jpeg', '2016/02/to-the-duc-nhac-hoa/12313618-773635319446637-4611555932033199105-n.jpg', '/2016/02/90x72-12313618-773635319446637-4611555932033199105-n.jpg', 0, 1, 12, 1454383136, 1454383136),
(14, 2, '12494756-554990874666417-7554807202493373402-n.jpg', '', 0, 174238, 960, 540, 'image/jpeg', '2016/02/to-the-duc-nhac-hoa/12494756-554990874666417-7554807202493373402-n.jpg', '/2016/02/90x72-12494756-554990874666417-7554807202493373402-n.jpg', 0, 1, 13, 1454383136, 1454383136),
(15, 2, '12552782-554990834666421-8790197966392367828-n.jpg', '', 0, 162513, 960, 540, 'image/jpeg', '2016/02/to-the-duc-nhac-hoa/12552782-554990834666421-8790197966392367828-n.jpg', '/2016/02/90x72-12552782-554990834666421-8790197966392367828-n.jpg', 0, 1, 14, 1454383136, 1454383136),
(16, 3, 'Sngw.jpg', '', 1, 176545, 791, 529, 'image/jpeg', '2016/02/to-sn/Sngw.jpg', '/2016/02/90x72-sngw.jpg', 0, 1, 14, 1454383347, 1454383347);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_referer_stats`
--

CREATE TABLE `pacorp_vi_referer_stats` (
  `host` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_referer_stats`
--

INSERT INTO `pacorp_vi_referer_stats` (`host`, `total`, `month01`, `month02`, `month03`, `month04`, `month05`, `month06`, `month07`, `month08`, `month09`, `month10`, `month11`, `month12`, `last_update`) VALUES
('m.facebook.com', 182, 83, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1456546763),
('google.com', 104, 21, 83, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1456560689),
('lm.facebook.com', 25, 15, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1455897792),
('google.com.vn', 43, 3, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1456550203),
('facebook.com', 48, 35, 13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1456408928),
('coccoc.com', 11, 1, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1456454561),
('forum.nukeviet.vn', 88, 55, 33, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1454511129),
('l.facebook.com', 4, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1455059759),
('fb.me', 3, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1454560290),
('', 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1454029076),
('google.com.tr', 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1454756174),
('whois.domaintools.com', 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1456288701),
('alexa.com', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1455255007),
('runotes.cloudns.org', 8, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1455967030);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_searchkeys`
--

CREATE TABLE `pacorp_vi_searchkeys` (
  `id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `skey` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_support`
--

CREATE TABLE `pacorp_vi_support` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_support`
--

INSERT INTO `pacorp_vi_support` (`id`, `title`) VALUES
(1, 'Văn phòng'),
(4, 'Đoàn thanh niên');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_support_rows`
--

CREATE TABLE `pacorp_vi_support_rows` (
  `id` mediumint(5) NOT NULL,
  `parentid` mediumint(5) UNSIGNED NOT NULL,
  `mid` smallint(5) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` int(11) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_support_rows`
--

INSERT INTO `pacorp_vi_support_rows` (`id`, `parentid`, `mid`, `title`, `photo`, `phone`, `email`, `skype`, `facebook`, `weight`, `status`) VALUES
(1, 0, 1, 'Hỗ trợ', '12438964_1239149622778201_1379376839578412410_n.jpg', '098373268', 'admin@thpthongai.edu.vn', 'phungdanhtu', 'https&#x3A;&#x002F;&#x002F;www.facebook.com&#x002F;phungdanhtu', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_tkblop`
--

CREATE TABLE `pacorp_vi_tkblop` (
  `id` int(4) NOT NULL,
  `lop` varchar(6) NOT NULL,
  `tiet` int(2) NOT NULL,
  `thu2` varchar(15) DEFAULT NULL,
  `thu3` varchar(15) DEFAULT NULL,
  `thu4` varchar(15) DEFAULT NULL,
  `thu5` varchar(15) DEFAULT NULL,
  `thu6` varchar(15) DEFAULT NULL,
  `thu7` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pacorp_vi_tkblop`
--

INSERT INTO `pacorp_vi_tkblop` (`id`, `lop`, `tiet`, `thu2`, `thu3`, `thu4`, `thu5`, `thu6`, `thu7`) VALUES
(1, '12A', 1, 'Chào cờ', 'Sinh vật', 'Ngoại ngữ', 'Toán', 'Văn học', 'Lịch sử'),
(2, '12A', 2, 'Toán', 'Hoá học', 'Ngoại ngữ', 'Toán', 'Địa lí', 'Sinh vật'),
(3, '12A', 3, 'Ngoại ngữ', 'GDCD', 'Văn học', 'Tin học', 'Vật lí', 'Địa lí'),
(4, '12A', 4, 'Vật lí', 'Toán', 'Văn học', 'KTCN', 'Vật lí', 'Hoá học'),
(5, '12A', 5, 'Sinh hoạt', 'Toán', '', '', '', ''),
(6, '12A', 6, 'Chào cờ', 'Toán', 'Toán', 'Ngoại ngữ', 'Địa lí', 'Hoá học'),
(7, '12A', 7, 'Ngoại ngữ', 'Toán', 'Toán', 'Ngoại ngữ', 'GDCD', 'Địa lí'),
(8, '12A', 8, 'Văn học', 'Vật lí', 'Vật lí', 'Toán', 'Văn học', 'Lịch sử'),
(9, '12A', 9, 'Văn học', 'KTCN', 'Sinh vật', 'Vật lí', 'Tin học', 'Sinh vật'),
(10, '12A', 10, 'Sinh hoạt', 'Hoá học', '', '', '', ''),
(11, '12B', 1, 'Chào cờ', 'Toán', 'Vật lí', 'Hoá học', 'Ngoại ngữ', 'Sinh vật'),
(12, '12B', 2, 'KTCN', 'Toán', 'Ngoại ngữ', 'Vật lí', 'Tin học', 'Vật lí'),
(13, '12B', 3, 'Sinh vật', 'Lịch sử', 'Địa lí', 'Ngoại ngữ', 'Địa lí', 'Văn học'),
(14, '12B', 4, 'Toán', 'Hoá học', 'Văn học', 'Toán', 'GDCD', 'Văn học'),
(15, '12B', 5, 'Sinh hoạt', 'Ngoại ngữ', 'Văn học', '', '', ''),
(16, '12B', 6, 'Chào cờ', 'Tin học', 'Văn học', 'Vật lí', 'Địa lí', 'Toán'),
(17, '12B', 7, 'Sinh vật', 'GDCD', 'Vật lí', 'Địa lí', 'Ngoại ngữ', 'Toán'),
(18, '12B', 8, 'Văn học', 'Toán', 'Ngoại ngữ', 'Hoá học', 'Toán', 'Sinh vật'),
(19, '12B', 9, 'Văn học', 'Vật lí', 'Văn học', 'Ngoại ngữ', 'Ngoại ngữ', 'Lịch sử'),
(20, '12B', 10, 'Sinh hoạt', 'Hoá học', 'KTCN', '', '', ''),
(21, '12C', 1, 'Chào cờ', 'Địa lí', 'Ngoại ngữ', 'Tin học', 'Sinh vật', 'Văn học'),
(22, '12C', 2, 'GDCD', 'Toán', 'Văn học', 'Ngoại ngữ', 'Ngoại ngữ', 'Lịch sử'),
(23, '12C', 3, 'Văn học', 'Hoá học', 'Toán', 'Ngoại ngữ', 'Vật lí', 'Toán'),
(24, '12C', 4, 'Văn học', 'Toán', 'Vật lí', 'Hoá học', 'Vật lí', 'Địa lí'),
(25, '12C', 5, 'Sinh hoạt', 'KTCN', 'Sinh vật', '', '', ''),
(26, '12C', 6, 'Chào cờ', 'Ngoại ngữ', 'Vật lí', 'Lịch sử', 'Văn học', 'Toán'),
(27, '12C', 7, 'Văn học', 'Ngoại ngữ', 'Ngoại ngữ', 'Hoá học', 'Văn học', 'Toán'),
(28, '12C', 8, 'Toán', 'Toán', 'Văn học', 'GDCD', 'Địa lí', 'Vật lí'),
(29, '12C', 9, 'KTCN', 'Tin học', 'Sinh vật', 'Sinh vật', 'Hoá học', 'Vật lí'),
(30, '12C', 10, 'Sinh hoạt', 'Địa lí', 'Ngoại ngữ', '', '', ''),
(31, '12D', 1, 'Chào cờ', 'Vật lí', 'Vật lí', 'Ngoại ngữ', 'Ngoại ngữ', 'Toán'),
(32, '12D', 2, 'Hoá học', 'Sinh vật', 'Sinh vật', 'Địa lí', 'GDCD', 'Toán'),
(33, '12D', 3, 'Văn học', 'KTCN', 'Vật lí', 'Hoá học', 'Toán', 'Văn học'),
(34, '12D', 4, 'Văn học', 'Địa lí', 'Ngoại ngữ', 'Lịch sử', 'Toán', 'Văn học'),
(35, '12D', 5, 'Sinh hoạt', 'Tin học', 'Ngoại ngữ', '', '', ''),
(36, '12D', 6, 'Chào cờ', 'Văn học', 'Toán', 'GDCD', 'Hoá học', 'Vật lí'),
(37, '12D', 7, 'Địa lí', 'Văn học', 'Lịch sử', 'Ngoại ngữ', 'Ngoại ngữ', 'Vật lí'),
(38, '12D', 8, 'Vật lí', 'Toán', 'Toán', 'Sinh vật', 'Ngoại ngữ', 'Văn học'),
(39, '12D', 9, 'Văn học', 'Toán', 'KTCN', 'Ngoại ngữ', 'Tin học', 'Hoá học'),
(40, '12D', 10, 'Sinh hoạt', 'Địa lí', 'Sinh vật', '', '', ''),
(41, '11A', 1, 'Chào cờ', 'Văn học', 'KTCN', 'KTCN', 'Hoá học', 'Vật lí'),
(42, '11A', 2, 'Toán', 'Văn học', 'Vật lí', 'Ngoại ngữ', 'Sinh vật', 'Hoá học'),
(43, '11A', 3, 'Toán', 'Ngoại ngữ', 'Vật lí', 'Ngoại ngữ', 'Tin học', 'Hoá học'),
(44, '11A', 4, 'Địa lí', 'GDCD', 'Toán', 'Tin học', 'Văn học', 'Vật lí'),
(45, '11A', 5, 'Sinh hoạt', 'Toán', 'Lịch sử', 'Sinh vật', '', ''),
(46, '11A', 6, 'Chào cờ', 'KTCN', 'Toán', 'Toán', 'Tin học', 'Hoá học'),
(47, '11A', 7, 'Văn học', 'Ngoại ngữ', 'Toán', 'Toán', 'Hoá học', 'Lịch sử'),
(48, '11A', 8, 'KTCN', 'Tin học', 'Ngoại ngữ', 'Vật lí', 'GDCD', 'Vật lí'),
(49, '11A', 9, 'Sinh vật', 'Văn học', 'Vật lí', 'Vật lí', 'Sinh vật', 'Hoá học'),
(50, '11A', 10, 'Sinh hoạt', 'Văn học', 'Ngoại ngữ', 'Địa lí', '', ''),
(51, '11B', 1, 'Chào cờ', 'GDCD', 'Địa lí', 'Sinh vật', 'Văn học', 'Hoá học'),
(52, '11B', 2, 'Ngoại ngữ', 'Tin học', 'KTCN', 'Hoá học', 'Hoá học', 'KTCN'),
(53, '11B', 3, 'Văn học', 'Toán', 'Lịch sử', 'Toán', 'Ngoại ngữ', 'Vật lí'),
(54, '11B', 4, 'Văn học', 'Toán', 'Toán', 'Tin học', 'Ngoại ngữ', 'Vật lí'),
(55, '11B', 5, 'Sinh hoạt', 'Vật lí', 'Toán', '', '', ''),
(56, '11B', 6, 'Chào cờ', 'Văn học', 'KTCN', 'Hoá học', 'Hoá học', 'Tin học'),
(57, '11B', 7, 'Vật lí', 'Văn học', 'Toán', 'Sinh vật', 'Vật lí', 'Hoá học'),
(58, '11B', 8, 'Ngoại ngữ', 'Toán', 'Toán', 'Toán', 'Vật lí', 'Lịch sử'),
(59, '11B', 9, 'Địa lí', 'Tin học', 'Ngoại ngữ', 'Toán', 'Văn học', 'KTCN'),
(60, '11B', 10, 'Sinh hoạt', 'GDCD', 'Ngoại ngữ', '', '', ''),
(61, '11C', 1, 'Chào cờ', 'Sinh vật', 'Sinh vật', 'Địa lí', 'Văn học', 'Toán'),
(62, '11C', 2, 'Vật lí', 'Ngoại ngữ', 'KTNN', 'GDCD', 'Văn học', 'Toán'),
(63, '11C', 3, 'Vật lí', 'Tin học', 'Ngoại ngữ', 'Toán', 'Hoá học', 'Văn học'),
(64, '11C', 4, 'Toán', 'KTNN', 'Hoá học', 'Toán', 'Lịch sử', 'Lịch sử'),
(65, '11C', 5, 'Sinh hoạt', 'Vật lí', 'Ngoại ngữ', 'Tin học', '', ''),
(66, '11C', 6, 'Chào cờ', 'Vật lí', 'Toán', 'Tin học', 'Lịch sử', 'Hoá học'),
(67, '11C', 7, 'Toán', 'Ngoại ngữ', 'Toán', 'Lịch sử', 'Văn học', 'KTNN'),
(68, '11C', 8, 'Văn học', 'Ngoại ngữ', 'KTNN', 'Vật lí', 'GDCD', 'Tin học'),
(69, '11C', 9, 'Văn học', 'Sinh vật', 'Ngoại ngữ', 'Sinh vật', 'Địa lí', 'Toán'),
(70, '11C', 10, 'Sinh hoạt', 'Toán', 'Hoá học', 'Vật lí', '', ''),
(71, '11D', 1, 'Chào cờ', 'Ngoại ngữ', 'Toán', 'Lịch sử', 'Toán', 'KTNN'),
(72, '11D', 2, 'Vật lí', 'Vật lí', 'Toán', 'Tin học', 'Tin học', 'Sinh vật'),
(73, '11D', 3, 'GDCD', 'KTNN', 'Hoá học', 'Địa lí', 'Văn học', 'Lịch sử'),
(74, '11D', 4, 'Vật lí', 'Hoá học', 'Ngoại ngữ', 'Ngoại ngữ', 'Văn học', 'Toán'),
(75, '11D', 5, 'Sinh hoạt', 'Toán', 'Văn học', 'Ngoại ngữ', '', ''),
(76, '11D', 6, 'Chào cờ', 'Tin học', 'Toán', 'Văn học', 'Ngoại ngữ', 'Toán'),
(77, '11D', 7, 'Vật lí', 'KTNN', 'Địa lí', 'Văn học', 'Vật lí', 'Toán'),
(78, '11D', 8, 'Vật lí', 'Ngoại ngữ', 'Ngoại ngữ', 'Tin học', 'Lịch sử', 'Hoá học'),
(79, '11D', 9, 'Lịch sử', 'Ngoại ngữ', 'Hoá học', 'Toán', 'GDCD', 'Sinh vật'),
(80, '11D', 10, 'Sinh hoạt', 'KTNN', 'Văn học', 'Toán', '', ''),
(81, '10A', 1, 'Toán', 'Hoá học', 'Toán', 'Ngoại ngữ', 'Tin học', 'Văn học'),
(82, '10A', 2, 'Toán', 'Toán', 'Toán', 'Ngoại ngữ', 'Ngoại ngữ', 'Văn học'),
(83, '10A', 3, 'Văn học', 'Lịch sử', 'Hoá học', 'Sinh vật', 'Vật lí', 'Hoá học'),
(84, '10A', 4, 'Chào cờ', 'Vật lí', 'KTCN', '', 'KTCN', 'GDCD'),
(85, '10A', 5, 'Sinh hoạt', 'Tin học', 'Địa lí', '', 'Vật lí', ''),
(86, '10A', 6, 'Vật lí', 'Sinh vật', 'Toán', 'Toán', 'Toán', 'Tin học'),
(87, '10A', 7, 'Vật lí', 'Ngoại ngữ', 'Hoá học', 'KTCN', 'GDCD', 'Địa lí'),
(88, '10A', 8, 'Lịch sử', 'Toán', 'Hoá học', 'Ngoại ngữ', 'KTCN', 'Văn học'),
(89, '10A', 9, 'Chào cờ', 'Tin học', 'Toán', '', 'Văn học', 'Văn học'),
(90, '10A', 10, 'Sinh hoạt', 'Hoá học', 'Vật lí', '', 'Ngoại ngữ', ''),
(91, '10B', 1, 'Tin học', 'Vật lí', 'Ngoại ngữ', 'Vật lí', 'Văn học', 'GDCD'),
(92, '10B', 2, 'Văn học', 'Hoá học', 'Tin học', 'Toán', 'Văn học', 'Lịch sử'),
(93, '10B', 3, 'Vật lí', 'Hoá học', 'KTCN', 'Toán', 'Ngoại ngữ', 'Địa lí'),
(94, '10B', 4, 'Chào cờ', 'Toán', 'Ngoại ngữ', '', 'KTCN', 'Sinh vật'),
(95, '10B', 5, 'Sinh hoạt', 'Toán', 'Hoá học', '', 'Toán', ''),
(96, '10B', 6, 'Hoá học', 'Toán', 'Hoá học', 'Tin học', 'Ngoại ngữ', 'Văn học'),
(97, '10B', 7, 'Hoá học', 'Vật lí', 'Ngoại ngữ', 'Toán', 'Tin học', 'Văn học'),
(98, '10B', 8, 'Văn học', 'Địa lí', 'Vật lí', 'Toán', 'GDCD', 'Lịch sử'),
(99, '10B', 9, 'Chào cờ', 'Toán', 'Vật lí', '', 'Ngoại ngữ', 'Toán'),
(100, '10B', 10, 'Sinh hoạt', 'Sinh vật', 'KTCN', '', 'KTCN', ''),
(101, '10C', 1, 'Văn học', 'Toán', 'Vật lí', 'Văn học', 'KTCN', 'Hoá học'),
(102, '10C', 2, 'Tin học', 'Toán', 'Vật lí', 'Văn học', 'Ngoại ngữ', 'Hoá học'),
(103, '10C', 3, 'Lịch sử', 'Hoá học', 'Toán', 'Tin học', 'Toán', 'Sinh vật'),
(104, '10C', 4, 'Chào cờ', 'Ngoại ngữ', 'KTCN', '', 'Toán', 'Địa lí'),
(105, '10C', 5, 'Sinh hoạt', 'Vật lí', 'Ngoại ngữ', '', 'GDCD', ''),
(106, '10C', 6, 'Vật lí', 'Toán', 'Hoá học', 'Ngoại ngữ', 'Văn học', 'Vật lí'),
(107, '10C', 7, 'Lịch sử', 'Hoá học', 'Hoá học', 'Ngoại ngữ', 'Văn học', 'Tin học'),
(108, '10C', 8, 'Toán', 'Toán', 'Toán', 'Văn học', 'Tin học', 'Vật lí'),
(109, '10C', 9, 'Chào cờ', 'Địa lí', 'Toán', '', 'GDCD', 'Sinh vật'),
(110, '10C', 10, 'Sinh hoạt', 'Ngoại ngữ', 'KTCN', '', 'KTCN', ''),
(111, '10D', 1, 'KTNN', 'GDCD', 'Tin học', 'Ngoại ngữ', 'Địa lí', 'Sinh vật'),
(112, '10D', 2, 'Văn học', 'Tin học', 'Hoá học', 'Ngoại ngữ', 'Vật lí', 'KTNN'),
(113, '10D', 3, 'Văn học', 'Vật lí', 'Văn học', 'Toán', 'Ngoại ngữ', 'Toán'),
(114, '10D', 4, 'Chào cờ', 'Lịch sử', 'Toán', '', 'Ngoại ngữ', 'Toán'),
(115, '10D', 5, 'Sinh hoạt', 'Vật lí', 'Toán', '', 'Hoá học', 'Lịch sử'),
(116, '10D', 6, 'Văn học', 'Tin học', 'Vật lí', 'Toán', 'Vật lí', 'Lịch sử'),
(117, '10D', 7, 'Văn học', 'Toán', 'Tin học', 'Ngoại ngữ', 'GDCD', 'Toán'),
(118, '10D', 8, 'KTNN', 'Toán', 'Hoá học', 'Văn học', 'Địa lí', 'Toán'),
(119, '10D', 9, 'Chào cờ', 'Lịch sử', 'Ngoại ngữ', '', 'Ngoại ngữ', 'KTNN'),
(120, '10D', 10, 'Sinh hoạt', 'Hoá học', 'Ngoại ngữ', '', 'Ngoại ngữ', 'Sinh vật');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_1`
--

CREATE TABLE `pacorp_vi_videos_1` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `admin_name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `author` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `artist` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `vid_path` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `vid_type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgfile` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_videos_1`
--

INSERT INTO `pacorp_vi_videos_1` (`id`, `catid`, `listcatid`, `admin_id`, `admin_name`, `author`, `artist`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `vid_path`, `vid_type`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(2, 1, '1', 2, 'admin2 ', '', '', 1, 1454560149, 1454560149, 1, 1454560020, 0, 2, '&#91;Sơ kết HKI 2015-2016&#93; Nhảy hiện đại', 'so-ket-hki-2015-2016-nhay-hien-dai', '&#91;Sơ kết HKI 2015-2016&#93; Nhảy hiện đại', 'https://youtu.be/IYJbR51yKxI', '2', 'http://img.youtube.com/vi/IYJbR51yKxI/0.jpg', '&#91;Sơ kết HKI 2015-2016&#93; Nhảy hiện đại', 3, 1, '6', 1, 149, 0, 0, 0),
(3, 1, '1', 2, 'admin2 ', '', '', 1, 1454561418, 1454561418, 1, 1454561280, 0, 2, '&#91;Văn nghệ sơ kết HKI&#93; - Năm mới bình an', 'van-nghe-so-ket-hki-nam-moi-binh-an', '&#91;Văn nghệ sơ kết HKI&#93; - Năm mới bình an', 'https://youtu.be/_vkRQYNUcC8', '2', 'http://img.youtube.com/vi/_vkRQYNUcC8/0.jpg', '&#91;Văn nghệ sơ kết HKI&#93; - Năm mới bình an', 3, 1, '4', 1, 55, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_2`
--

CREATE TABLE `pacorp_vi_videos_2` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `admin_name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `author` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `artist` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `vid_path` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `vid_type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgfile` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_videos_2`
--

INSERT INTO `pacorp_vi_videos_2` (`id`, `catid`, `listcatid`, `admin_id`, `admin_name`, `author`, `artist`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `vid_path`, `vid_type`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(1, 2, '2', 1, 'admin ', '', '', 0, 1454234804, 1454234804, 1, 1454234760, 0, 2, '&#91;12B4&#93; - Bảo vệ môi trường', '12b4-bao-ve-moi-truong', 'Thông điệp: Hãy bảo vệ môi trường để cuộc sống tốt đẹp hơn được các bạn lớp 12B trường THPT Hòn Gai truyền tải qua vở kịch sinh động và vui nhộn, phù hợp với lứa tuổi học trò hiện nay.', 'https://youtu.be/wGNSlJ7Ry1I', '2', 'http://img.youtube.com/vi/wGNSlJ7Ry1I/0.jpg', '', 3, 1, '4', 1, 17, 0, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_3`
--

CREATE TABLE `pacorp_vi_videos_3` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `admin_name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `author` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `artist` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `vid_path` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `vid_type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgfile` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_4`
--

CREATE TABLE `pacorp_vi_videos_4` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `admin_name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `author` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `artist` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `vid_path` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `vid_type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgfile` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_admins`
--

CREATE TABLE `pacorp_vi_videos_admins` (
  `userid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_videos_admins`
--

INSERT INTO `pacorp_vi_videos_admins` (`userid`, `catid`, `admin`, `add_content`, `pub_content`, `edit_content`, `del_content`, `app_content`) VALUES
(6, 0, 1, 1, 1, 1, 1, 0),
(5, 0, 1, 1, 1, 1, 1, 0),
(7, 0, 1, 1, 1, 1, 1, 0),
(8, 0, 1, 1, 1, 1, 1, 0),
(9, 0, 1, 1, 1, 1, 1, 0),
(10, 0, 1, 1, 1, 1, 1, 0),
(11, 0, 1, 1, 1, 1, 1, 0),
(12, 0, 1, 1, 1, 1, 1, 0),
(14, 0, 1, 1, 1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_block`
--

CREATE TABLE `pacorp_vi_videos_block` (
  `bid` smallint(5) UNSIGNED NOT NULL,
  `id` int(11) UNSIGNED NOT NULL,
  `weight` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_videos_block`
--

INSERT INTO `pacorp_vi_videos_block` (`bid`, `id`, `weight`) VALUES
(1, 3, 3),
(1, 2, 2),
(1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_block_cat`
--

CREATE TABLE `pacorp_vi_videos_block_cat` (
  `bid` smallint(5) UNSIGNED NOT NULL,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_videos_block_cat`
--

INSERT INTO `pacorp_vi_videos_block_cat` (`bid`, `adddefault`, `numbers`, `title`, `alias`, `image`, `description`, `weight`, `keywords`, `add_time`, `edit_time`) VALUES
(1, 0, 4, 'Video mới', 'Video-moi', '', '', 1, '', 1457538636, 1457538636);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_bodyhtml_1`
--

CREATE TABLE `pacorp_vi_videos_bodyhtml_1` (
  `id` int(11) UNSIGNED NOT NULL,
  `bodyhtml` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourcetext` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_videos_bodyhtml_1`
--

INSERT INTO `pacorp_vi_videos_bodyhtml_1` (`id`, `bodyhtml`, `sourcetext`, `copyright`, `allowed_send`, `allowed_save`, `gid`) VALUES
(1, 'Thông điệp: Hãy bảo vệ môi trường để cuộc sống tốt đẹp hơn được các bạn lớp 12B trường THPT Hòn Gai truyền tải qua vở kịch sinh động và vui nhộn, phù hợp với lứa tuổi học trò hiện nay.', '', 0, 1, 1, 0),
(2, '&#91;Sơ kết HKI 2015-2016&#93; Nhảy hiện đại', 'Admin', 0, 1, 1, 0),
(3, '&#91;Văn nghệ sơ kết HKI&#93; - Năm mới bình an', 'Admin', 0, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_bodytext`
--

CREATE TABLE `pacorp_vi_videos_bodytext` (
  `id` int(11) UNSIGNED NOT NULL,
  `bodytext` mediumtext COLLATE utf8mb4_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_videos_bodytext`
--

INSERT INTO `pacorp_vi_videos_bodytext` (`id`, `bodytext`) VALUES
(1, 'Thông điệp: Hãy bảo vệ môi trường để cuộc sống tốt đẹp hơn được các bạn lớp 12B trường THPT Hòn Gai truyền tải qua vở kịch sinh động và vui nhộn, phù hợp với lứa tuổi học trò hiện nay.'),
(2, '&#91;Sơ kết HKI 2015-2016&#93; Nhảy hiện đại'),
(3, '&#91;Văn nghệ sơ kết HKI&#93; - Năm mới bình an');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_cat`
--

CREATE TABLE `pacorp_vi_videos_cat` (
  `catid` smallint(5) UNSIGNED NOT NULL,
  `parentid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titlesite` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci,
  `descriptionhtml` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `viewdescription` tinyint(2) NOT NULL DEFAULT '0',
  `weight` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) UNSIGNED NOT NULL DEFAULT '3',
  `newday` tinyint(2) UNSIGNED NOT NULL DEFAULT '2',
  `featured` int(11) NOT NULL DEFAULT '0',
  `keywords` text COLLATE utf8mb4_unicode_ci,
  `admins` text COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edit_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `groups_view` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_videos_cat`
--

INSERT INTO `pacorp_vi_videos_cat` (`catid`, `parentid`, `title`, `titlesite`, `alias`, `description`, `descriptionhtml`, `image`, `viewdescription`, `weight`, `sort`, `lev`, `viewcat`, `numsubcat`, `subcatid`, `inhome`, `numlinks`, `newday`, `featured`, `keywords`, `admins`, `add_time`, `edit_time`, `groups_view`) VALUES
(1, 0, 'Sự kiện', 'Sự kiện', 'su-kien', '', '', '', 0, 1, 1, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', 1454234760, 1454234760, '6'),
(2, 0, 'Ngoại khóa', '', 'Ngoai-khoa', '', '', '', 0, 2, 2, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', 1454234766, 1454234766, '6'),
(3, 0, 'Công tác phong trào', 'Công tác phong trào', 'cong-tac-phong-trao', 'Công tác phong trào', 'Công tác phong trào', '', 0, 3, 3, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 0, 'Công tác phong trào', '', 1454560602, 1454560602, '6'),
(4, 0, 'Hoạt động Dạy-Học', 'Hoạt động Dạy-Học', 'hoat-dong-day-hoc', 'Hoạt động Dạy-Học', 'Hoạt động Dạy-Học', '', 0, 4, 4, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 0, 'Hoạt động Dạy-Học', '', 1454560624, 1454560624, '6');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_config_post`
--

CREATE TABLE `pacorp_vi_videos_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_videos_config_post`
--

INSERT INTO `pacorp_vi_videos_config_post` (`group_id`, `addcontent`, `postcontent`, `editcontent`, `delcontent`) VALUES
(1, 0, 0, 0, 0),
(2, 0, 0, 0, 0),
(3, 0, 0, 0, 0),
(4, 0, 0, 0, 0),
(5, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_logs`
--

CREATE TABLE `pacorp_vi_videos_logs` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `set_time` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_playlist`
--

CREATE TABLE `pacorp_vi_videos_playlist` (
  `playlist_id` smallint(5) UNSIGNED NOT NULL,
  `id` int(11) UNSIGNED NOT NULL,
  `playlist_sort` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_playlist_cat`
--

CREATE TABLE `pacorp_vi_videos_playlist_cat` (
  `playlist_id` smallint(5) UNSIGNED NOT NULL,
  `userid` smallint(5) UNSIGNED NOT NULL,
  `status` smallint(5) UNSIGNED NOT NULL DEFAULT '1',
  `private_mode` smallint(5) UNSIGNED NOT NULL DEFAULT '1',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text COLLATE utf8mb4_unicode_ci,
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `favorite` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_rows`
--

CREATE TABLE `pacorp_vi_videos_rows` (
  `id` int(11) UNSIGNED NOT NULL,
  `catid` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `listcatid` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `admin_name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `author` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `artist` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edittime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `exptime` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `archive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `vid_path` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `vid_type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgfile` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `allowed_comm` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_videos_rows`
--

INSERT INTO `pacorp_vi_videos_rows` (`id`, `catid`, `listcatid`, `admin_id`, `admin_name`, `author`, `artist`, `sourceid`, `addtime`, `edittime`, `status`, `publtime`, `exptime`, `archive`, `title`, `alias`, `hometext`, `vid_path`, `vid_type`, `homeimgfile`, `homeimgalt`, `homeimgthumb`, `inhome`, `allowed_comm`, `allowed_rating`, `hitstotal`, `hitscm`, `total_rating`, `click_rating`) VALUES
(1, 2, '2', 1, 'admin ', '', '', 0, 1454234804, 1454234804, 1, 1454234760, 0, 2, '&#91;12B4&#93; - Bảo vệ môi trường', '12b4-bao-ve-moi-truong', 'Thông điệp: Hãy bảo vệ môi trường để cuộc sống tốt đẹp hơn được các bạn lớp 12B trường THPT Hòn Gai truyền tải qua vở kịch sinh động và vui nhộn, phù hợp với lứa tuổi học trò hiện nay.', 'https://youtu.be/wGNSlJ7Ry1I', '2', 'http://img.youtube.com/vi/wGNSlJ7Ry1I/0.jpg', '', 3, 1, '4', 1, 17, 0, 5, 1),
(2, 1, '1', 2, 'admin2 ', '', '', 1, 1454560149, 1454560149, 1, 1454560020, 0, 2, '&#91;Sơ kết HKI 2015-2016&#93; Nhảy hiện đại', 'so-ket-hki-2015-2016-nhay-hien-dai', '&#91;Sơ kết HKI 2015-2016&#93; Nhảy hiện đại', 'https://youtu.be/IYJbR51yKxI', '2', 'http://img.youtube.com/vi/IYJbR51yKxI/0.jpg', '&#91;Sơ kết HKI 2015-2016&#93; Nhảy hiện đại', 3, 1, '6', 1, 149, 0, 0, 0),
(3, 1, '1', 2, 'admin2 ', '', '', 1, 1454561418, 1454561418, 1, 1454561280, 0, 2, '&#91;Văn nghệ sơ kết HKI&#93; - Năm mới bình an', 'van-nghe-so-ket-hki-nam-moi-binh-an', '&#91;Văn nghệ sơ kết HKI&#93; - Năm mới bình an', 'https://youtu.be/_vkRQYNUcC8', '2', 'http://img.youtube.com/vi/_vkRQYNUcC8/0.jpg', '&#91;Văn nghệ sơ kết HKI&#93; - Năm mới bình an', 3, 1, '4', 1, 55, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_sources`
--

CREATE TABLE `pacorp_vi_videos_sources` (
  `sourceid` mediumint(8) UNSIGNED NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `logo` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `add_time` int(11) UNSIGNED NOT NULL,
  `edit_time` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_videos_sources`
--

INSERT INTO `pacorp_vi_videos_sources` (`sourceid`, `title`, `link`, `logo`, `weight`, `add_time`, `edit_time`) VALUES
(1, 'Admin', '', '', 1, 1454560149, 1454560149);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_tags`
--

CREATE TABLE `pacorp_vi_videos_tags` (
  `tid` mediumint(8) UNSIGNED NOT NULL,
  `numnews` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci,
  `keywords` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_videos_tags`
--

INSERT INTO `pacorp_vi_videos_tags` (`tid`, `numnews`, `alias`, `image`, `description`, `keywords`) VALUES
(1, 1, 'nhảy-hiện-đại-trường-hòn-gai', '', '', 'nhảy hiện đại trường hòn gai'),
(2, 1, 'van-ngh-so-ket-hki', '', '', 'van ngh so ket hki'),
(3, 1, 'tết-2016', '', '', 'tết 2016'),
(4, 1, 'chúc-tết-2016', '', '', 'chúc tết 2016'),
(5, 1, 'văn-nghệ-thpt-hòn-gai', '', '', 'văn nghệ thpt hòn gai');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_videos_tags_id`
--

CREATE TABLE `pacorp_vi_videos_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_videos_tags_id`
--

INSERT INTO `pacorp_vi_videos_tags_id` (`id`, `tid`, `keyword`) VALUES
(2, 1, 'nhảy hiện đại trường hòn gai'),
(2, 2, 'van ngh so ket hki'),
(3, 3, 'tết 2016'),
(3, 4, 'chúc tết 2016'),
(3, 5, 'văn nghệ thpt hòn gai');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_weblinks_cat`
--

CREATE TABLE `pacorp_vi_weblinks_cat` (
  `catid` mediumint(8) UNSIGNED NOT NULL,
  `parentid` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `catimage` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) UNSIGNED NOT NULL DEFAULT '3',
  `keywords` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(11) UNSIGNED NOT NULL,
  `edit_time` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_weblinks_cat`
--

INSERT INTO `pacorp_vi_weblinks_cat` (`catid`, `parentid`, `title`, `catimage`, `alias`, `description`, `weight`, `inhome`, `numlinks`, `keywords`, `add_time`, `edit_time`) VALUES
(1, 0, 'cxvcxv', '', 'cxvcxv', '', 1, 1, 3, '', 1453707393, 1453707393);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_weblinks_config`
--

CREATE TABLE `pacorp_vi_weblinks_config` (
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_weblinks_config`
--

INSERT INTO `pacorp_vi_weblinks_config` (`name`, `value`) VALUES
('intro', ''),
('numcat', '2'),
('showsub', '1'),
('numsub', '2'),
('numinsub', '1'),
('showcatimage', '0'),
('per_page', '20'),
('numsubcat', '2'),
('shownumsubcat', '1'),
('sort', 'asc'),
('showlinkimage', '1'),
('showdes', '1'),
('sortoption', 'byid'),
('imgwidth', '100'),
('imgheight', '74'),
('timeout', '1');

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_weblinks_report`
--

CREATE TABLE `pacorp_vi_weblinks_report` (
  `id` int(11) DEFAULT NULL,
  `type` int(1) DEFAULT NULL,
  `report_time` int(11) NOT NULL,
  `report_userid` int(11) NOT NULL,
  `report_ip` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_browse_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_browse_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_os_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_os_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_weblinks_rows`
--

CREATE TABLE `pacorp_vi_weblinks_rows` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `catid` mediumint(9) NOT NULL,
  `author` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1|1',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `urlimg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `edit_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_weblinks_rows`
--

INSERT INTO `pacorp_vi_weblinks_rows` (`id`, `catid`, `author`, `title`, `alias`, `url`, `urlimg`, `admin_phone`, `admin_email`, `note`, `description`, `add_time`, `edit_time`, `hits_total`, `status`) VALUES
(1, 1, '1|1', 'dsfds', 'dsfds', 'http://news.vn/', '', '0', '0', '', 'ds', 1453707401, 1453707401, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_xep_hang_thi_dua`
--

CREATE TABLE `pacorp_vi_xep_hang_thi_dua` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stt1` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stt2` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stt3` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenlop1` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenlop2` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenlop3` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `diemtb1` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `diemtb2` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `diemtb3` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `diemtb4` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `xephang1` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `xephang2` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `xephang3` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `xephang4` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `others` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_xep_hang_thi_dua`
--

INSERT INTO `pacorp_vi_xep_hang_thi_dua` (`id`, `title`, `alias`, `stt1`, `stt2`, `stt3`, `tenlop1`, `tenlop2`, `tenlop3`, `diemtb1`, `diemtb2`, `diemtb3`, `diemtb4`, `xephang1`, `xephang2`, `xephang3`, `xephang4`, `others`, `weight`, `admin_id`, `add_time`, `edit_time`, `status`) VALUES
(1, 'Bảng xếp hạng tuần &#40;từ 01&#x002F;02 - 07&#x002F;02&#41;', 'Bang-xep-hang-tuan-tu-01-02-07-02', '1', '2', '3', 'a1', 'a2', 'a3', '1', '2', '3', '', '1', '2', '3', '', '4;a4;4;4|5;a5;5;5|6;a6;6;6', 1, 1, 1453901359, 1453912083, 1),
(3, 'Bảng xếp hạng tuần &#40;từ 09&#x002F;02 - 18&#x002F;02&#41;', 'Bang-xep-hang-tuan-tu-09-02-18-02', '1', '2', '3', 'a1', 'a2', 'a3', '10', '9.5', '8', '', '1', '2', '3', '', '4;a4;7.5;4|5;a5;7;5|6;a6;7;6|7;a7;7;7', 2, 1, 1453912396, 1456991659, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pacorp_vi_xep_hang_thi_dua_config`
--

CREATE TABLE `pacorp_vi_xep_hang_thi_dua_config` (
  `config_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pacorp_vi_xep_hang_thi_dua_config`
--

INSERT INTO `pacorp_vi_xep_hang_thi_dua_config` (`config_name`, `config_value`) VALUES
('viewtype', '0'),
('facebookapi', ''),
('per_page', '20'),
('news_first', '0'),
('related_articles', '5');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pacorp_authors`
--
ALTER TABLE `pacorp_authors`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `pacorp_authors_config`
--
ALTER TABLE `pacorp_authors_config`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `keyname` (`keyname`);

--
-- Indexes for table `pacorp_authors_module`
--
ALTER TABLE `pacorp_authors_module`
  ADD PRIMARY KEY (`mid`),
  ADD UNIQUE KEY `module` (`module`);

--
-- Indexes for table `pacorp_banip`
--
ALTER TABLE `pacorp_banip`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ip` (`ip`);

--
-- Indexes for table `pacorp_banners_click`
--
ALTER TABLE `pacorp_banners_click`
  ADD KEY `bid` (`bid`),
  ADD KEY `click_day` (`click_day`),
  ADD KEY `click_ip` (`click_ip`),
  ADD KEY `click_country` (`click_country`),
  ADD KEY `click_browse_key` (`click_browse_key`),
  ADD KEY `click_os_key` (`click_os_key`);

--
-- Indexes for table `pacorp_banners_clients`
--
ALTER TABLE `pacorp_banners_clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `full_name` (`full_name`);

--
-- Indexes for table `pacorp_banners_plans`
--
ALTER TABLE `pacorp_banners_plans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `title` (`title`);

--
-- Indexes for table `pacorp_banners_rows`
--
ALTER TABLE `pacorp_banners_rows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid` (`pid`),
  ADD KEY `clid` (`clid`);

--
-- Indexes for table `pacorp_config`
--
ALTER TABLE `pacorp_config`
  ADD UNIQUE KEY `lang` (`lang`,`module`,`config_name`);

--
-- Indexes for table `pacorp_cookies`
--
ALTER TABLE `pacorp_cookies`
  ADD UNIQUE KEY `cookiename` (`name`,`domain`,`path`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `pacorp_counter`
--
ALTER TABLE `pacorp_counter`
  ADD UNIQUE KEY `c_type` (`c_type`,`c_val`);

--
-- Indexes for table `pacorp_cronjobs`
--
ALTER TABLE `pacorp_cronjobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `is_sys` (`is_sys`);

--
-- Indexes for table `pacorp_extension_files`
--
ALTER TABLE `pacorp_extension_files`
  ADD PRIMARY KEY (`idfile`);

--
-- Indexes for table `pacorp_googleplus`
--
ALTER TABLE `pacorp_googleplus`
  ADD PRIMARY KEY (`gid`),
  ADD UNIQUE KEY `idprofile` (`idprofile`);

--
-- Indexes for table `pacorp_groups`
--
ALTER TABLE `pacorp_groups`
  ADD PRIMARY KEY (`group_id`),
  ADD UNIQUE KEY `ktitle` (`title`,`idsite`),
  ADD KEY `exp_time` (`exp_time`);

--
-- Indexes for table `pacorp_groups_users`
--
ALTER TABLE `pacorp_groups_users`
  ADD PRIMARY KEY (`group_id`,`userid`);

--
-- Indexes for table `pacorp_language`
--
ALTER TABLE `pacorp_language`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `filelang` (`idfile`,`lang_key`);

--
-- Indexes for table `pacorp_language_file`
--
ALTER TABLE `pacorp_language_file`
  ADD PRIMARY KEY (`idfile`),
  ADD UNIQUE KEY `module` (`module`,`admin_file`);

--
-- Indexes for table `pacorp_logs`
--
ALTER TABLE `pacorp_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pacorp_notification`
--
ALTER TABLE `pacorp_notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pacorp_plugin`
--
ALTER TABLE `pacorp_plugin`
  ADD PRIMARY KEY (`pid`),
  ADD UNIQUE KEY `plugin_file` (`plugin_file`);

--
-- Indexes for table `pacorp_sessions`
--
ALTER TABLE `pacorp_sessions`
  ADD UNIQUE KEY `session_id` (`session_id`),
  ADD KEY `onl_time` (`onl_time`);

--
-- Indexes for table `pacorp_setup`
--
ALTER TABLE `pacorp_setup`
  ADD UNIQUE KEY `lang` (`lang`,`module`);

--
-- Indexes for table `pacorp_setup_extensions`
--
ALTER TABLE `pacorp_setup_extensions`
  ADD UNIQUE KEY `title` (`type`,`title`),
  ADD KEY `id` (`id`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `pacorp_setup_language`
--
ALTER TABLE `pacorp_setup_language`
  ADD PRIMARY KEY (`lang`);

--
-- Indexes for table `pacorp_upload_dir`
--
ALTER TABLE `pacorp_upload_dir`
  ADD PRIMARY KEY (`did`),
  ADD UNIQUE KEY `name` (`dirname`);

--
-- Indexes for table `pacorp_upload_file`
--
ALTER TABLE `pacorp_upload_file`
  ADD UNIQUE KEY `did` (`did`,`title`),
  ADD KEY `userid` (`userid`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `pacorp_users`
--
ALTER TABLE `pacorp_users`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `md5username` (`md5username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idsite` (`idsite`);

--
-- Indexes for table `pacorp_users_config`
--
ALTER TABLE `pacorp_users_config`
  ADD PRIMARY KEY (`config`);

--
-- Indexes for table `pacorp_users_field`
--
ALTER TABLE `pacorp_users_field`
  ADD PRIMARY KEY (`fid`),
  ADD UNIQUE KEY `field` (`field`);

--
-- Indexes for table `pacorp_users_info`
--
ALTER TABLE `pacorp_users_info`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `pacorp_users_openid`
--
ALTER TABLE `pacorp_users_openid`
  ADD PRIMARY KEY (`opid`),
  ADD KEY `userid` (`userid`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `pacorp_users_question`
--
ALTER TABLE `pacorp_users_question`
  ADD PRIMARY KEY (`qid`),
  ADD UNIQUE KEY `title` (`title`,`lang`);

--
-- Indexes for table `pacorp_users_reg`
--
ALTER TABLE `pacorp_users_reg`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `login` (`username`),
  ADD UNIQUE KEY `md5username` (`md5username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `pacorp_vi_about`
--
ALTER TABLE `pacorp_vi_about`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_about_config`
--
ALTER TABLE `pacorp_vi_about_config`
  ADD UNIQUE KEY `config_name` (`config_name`);

--
-- Indexes for table `pacorp_vi_blocks_groups`
--
ALTER TABLE `pacorp_vi_blocks_groups`
  ADD PRIMARY KEY (`bid`),
  ADD KEY `theme` (`theme`),
  ADD KEY `module` (`module`),
  ADD KEY `position` (`position`),
  ADD KEY `exp_time` (`exp_time`);

--
-- Indexes for table `pacorp_vi_blocks_weight`
--
ALTER TABLE `pacorp_vi_blocks_weight`
  ADD UNIQUE KEY `bid` (`bid`,`func_id`);

--
-- Indexes for table `pacorp_vi_cbdoan`
--
ALTER TABLE `pacorp_vi_cbdoan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pacorp_vi_cbdoan_chucvu`
--
ALTER TABLE `pacorp_vi_cbdoan_chucvu`
  ADD PRIMARY KEY (`macvu`);

--
-- Indexes for table `pacorp_vi_cbdoan_donvi`
--
ALTER TABLE `pacorp_vi_cbdoan_donvi`
  ADD PRIMARY KEY (`madvi`);

--
-- Indexes for table `pacorp_vi_comment`
--
ALTER TABLE `pacorp_vi_comment`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `mod_id` (`module`,`area`,`id`),
  ADD KEY `post_time` (`post_time`);

--
-- Indexes for table `pacorp_vi_contact_department`
--
ALTER TABLE `pacorp_vi_contact_department`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `full_name` (`full_name`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_contact_reply`
--
ALTER TABLE `pacorp_vi_contact_reply`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `pacorp_vi_contact_send`
--
ALTER TABLE `pacorp_vi_contact_send`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_name` (`sender_name`);

--
-- Indexes for table `pacorp_vi_download`
--
ALTER TABLE `pacorp_vi_download`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `alias` (`alias`),
  ADD KEY `catid` (`catid`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `pacorp_vi_download_categories`
--
ALTER TABLE `pacorp_vi_download_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_download_config`
--
ALTER TABLE `pacorp_vi_download_config`
  ADD UNIQUE KEY `config_name` (`config_name`);

--
-- Indexes for table `pacorp_vi_download_report`
--
ALTER TABLE `pacorp_vi_download_report`
  ADD UNIQUE KEY `fid` (`fid`),
  ADD KEY `post_time` (`post_time`);

--
-- Indexes for table `pacorp_vi_download_tags`
--
ALTER TABLE `pacorp_vi_download_tags`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `pacorp_vi_download_tmp`
--
ALTER TABLE `pacorp_vi_download_tmp`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`),
  ADD KEY `catid` (`catid`);

--
-- Indexes for table `pacorp_vi_faq`
--
ALTER TABLE `pacorp_vi_faq`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `alias` (`alias`),
  ADD KEY `catid` (`catid`);

--
-- Indexes for table `pacorp_vi_faq_categories`
--
ALTER TABLE `pacorp_vi_faq_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_faq_config`
--
ALTER TABLE `pacorp_vi_faq_config`
  ADD UNIQUE KEY `config_name` (`config_name`);

--
-- Indexes for table `pacorp_vi_laws_cat`
--
ALTER TABLE `pacorp_vi_laws_cat`
  ADD PRIMARY KEY (`catid`),
  ADD UNIQUE KEY `alias` (`alias`),
  ADD KEY `parentid` (`parentid`);

--
-- Indexes for table `pacorp_vi_laws_field`
--
ALTER TABLE `pacorp_vi_laws_field`
  ADD PRIMARY KEY (`fieldid`),
  ADD UNIQUE KEY `alias` (`alias`),
  ADD KEY `parentid` (`parentid`);

--
-- Indexes for table `pacorp_vi_laws_organ`
--
ALTER TABLE `pacorp_vi_laws_organ`
  ADD PRIMARY KEY (`organid`),
  ADD UNIQUE KEY `alias` (`alias`),
  ADD KEY `parentid` (`parentid`);

--
-- Indexes for table `pacorp_vi_laws_room`
--
ALTER TABLE `pacorp_vi_laws_room`
  ADD PRIMARY KEY (`roomid`),
  ADD UNIQUE KEY `alias` (`alias`),
  ADD KEY `parentid` (`parentid`);

--
-- Indexes for table `pacorp_vi_laws_rows`
--
ALTER TABLE `pacorp_vi_laws_rows`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_lichct`
--
ALTER TABLE `pacorp_vi_lichct`
  ADD PRIMARY KEY (`nid`);

--
-- Indexes for table `pacorp_vi_lichct_config`
--
ALTER TABLE `pacorp_vi_lichct_config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pacorp_vi_lichct_part`
--
ALTER TABLE `pacorp_vi_lichct_part`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `full_name` (`full_name`);

--
-- Indexes for table `pacorp_vi_menu`
--
ALTER TABLE `pacorp_vi_menu`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `pacorp_vi_menu_rows`
--
ALTER TABLE `pacorp_vi_menu_rows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parentid` (`parentid`,`mid`);

--
-- Indexes for table `pacorp_vi_modfuncs`
--
ALTER TABLE `pacorp_vi_modfuncs`
  ADD PRIMARY KEY (`func_id`),
  ADD UNIQUE KEY `func_name` (`func_name`,`in_module`),
  ADD UNIQUE KEY `alias` (`alias`,`in_module`);

--
-- Indexes for table `pacorp_vi_modthemes`
--
ALTER TABLE `pacorp_vi_modthemes`
  ADD UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`);

--
-- Indexes for table `pacorp_vi_modules`
--
ALTER TABLE `pacorp_vi_modules`
  ADD PRIMARY KEY (`title`);

--
-- Indexes for table `pacorp_vi_news_8`
--
ALTER TABLE `pacorp_vi_news_8`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_9`
--
ALTER TABLE `pacorp_vi_news_9`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_10`
--
ALTER TABLE `pacorp_vi_news_10`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_11`
--
ALTER TABLE `pacorp_vi_news_11`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_12`
--
ALTER TABLE `pacorp_vi_news_12`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_13`
--
ALTER TABLE `pacorp_vi_news_13`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_14`
--
ALTER TABLE `pacorp_vi_news_14`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_15`
--
ALTER TABLE `pacorp_vi_news_15`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_16`
--
ALTER TABLE `pacorp_vi_news_16`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_17`
--
ALTER TABLE `pacorp_vi_news_17`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_18`
--
ALTER TABLE `pacorp_vi_news_18`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_19`
--
ALTER TABLE `pacorp_vi_news_19`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_20`
--
ALTER TABLE `pacorp_vi_news_20`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_21`
--
ALTER TABLE `pacorp_vi_news_21`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_22`
--
ALTER TABLE `pacorp_vi_news_22`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_23`
--
ALTER TABLE `pacorp_vi_news_23`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_24`
--
ALTER TABLE `pacorp_vi_news_24`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_25`
--
ALTER TABLE `pacorp_vi_news_25`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_26`
--
ALTER TABLE `pacorp_vi_news_26`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_27`
--
ALTER TABLE `pacorp_vi_news_27`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_admins`
--
ALTER TABLE `pacorp_vi_news_admins`
  ADD UNIQUE KEY `userid` (`userid`,`catid`);

--
-- Indexes for table `pacorp_vi_news_block`
--
ALTER TABLE `pacorp_vi_news_block`
  ADD UNIQUE KEY `bid` (`bid`,`id`);

--
-- Indexes for table `pacorp_vi_news_block_cat`
--
ALTER TABLE `pacorp_vi_news_block_cat`
  ADD PRIMARY KEY (`bid`),
  ADD UNIQUE KEY `title` (`title`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_news_bodyhtml_1`
--
ALTER TABLE `pacorp_vi_news_bodyhtml_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pacorp_vi_news_bodytext`
--
ALTER TABLE `pacorp_vi_news_bodytext`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pacorp_vi_news_cat`
--
ALTER TABLE `pacorp_vi_news_cat`
  ADD PRIMARY KEY (`catid`),
  ADD UNIQUE KEY `alias` (`alias`),
  ADD KEY `parentid` (`parentid`);

--
-- Indexes for table `pacorp_vi_news_config_post`
--
ALTER TABLE `pacorp_vi_news_config_post`
  ADD PRIMARY KEY (`group_id`);

--
-- Indexes for table `pacorp_vi_news_logs`
--
ALTER TABLE `pacorp_vi_news_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `pacorp_vi_news_rows`
--
ALTER TABLE `pacorp_vi_news_rows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `topicid` (`topicid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_news_sources`
--
ALTER TABLE `pacorp_vi_news_sources`
  ADD PRIMARY KEY (`sourceid`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `pacorp_vi_news_tags`
--
ALTER TABLE `pacorp_vi_news_tags`
  ADD PRIMARY KEY (`tid`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_news_tags_id`
--
ALTER TABLE `pacorp_vi_news_tags_id`
  ADD UNIQUE KEY `id_tid` (`id`,`tid`),
  ADD KEY `tid` (`tid`);

--
-- Indexes for table `pacorp_vi_news_topics`
--
ALTER TABLE `pacorp_vi_news_topics`
  ADD PRIMARY KEY (`topicid`),
  ADD UNIQUE KEY `title` (`title`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_page`
--
ALTER TABLE `pacorp_vi_page`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_page_config`
--
ALTER TABLE `pacorp_vi_page_config`
  ADD UNIQUE KEY `config_name` (`config_name`);

--
-- Indexes for table `pacorp_vi_photos_album`
--
ALTER TABLE `pacorp_vi_photos_album`
  ADD PRIMARY KEY (`album_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_photos_category`
--
ALTER TABLE `pacorp_vi_photos_category`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `alias` (`alias`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `pacorp_vi_photos_rows`
--
ALTER TABLE `pacorp_vi_photos_rows`
  ADD PRIMARY KEY (`row_id`);

--
-- Indexes for table `pacorp_vi_referer_stats`
--
ALTER TABLE `pacorp_vi_referer_stats`
  ADD UNIQUE KEY `host` (`host`),
  ADD KEY `total` (`total`);

--
-- Indexes for table `pacorp_vi_searchkeys`
--
ALTER TABLE `pacorp_vi_searchkeys`
  ADD KEY `id` (`id`),
  ADD KEY `skey` (`skey`),
  ADD KEY `search_engine` (`search_engine`);

--
-- Indexes for table `pacorp_vi_support`
--
ALTER TABLE `pacorp_vi_support`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `pacorp_vi_support_rows`
--
ALTER TABLE `pacorp_vi_support_rows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parentid` (`parentid`,`mid`);

--
-- Indexes for table `pacorp_vi_tkblop`
--
ALTER TABLE `pacorp_vi_tkblop`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pacorp_vi_videos_1`
--
ALTER TABLE `pacorp_vi_videos_1`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_videos_2`
--
ALTER TABLE `pacorp_vi_videos_2`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_videos_3`
--
ALTER TABLE `pacorp_vi_videos_3`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_videos_4`
--
ALTER TABLE `pacorp_vi_videos_4`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_videos_admins`
--
ALTER TABLE `pacorp_vi_videos_admins`
  ADD UNIQUE KEY `userid` (`userid`,`catid`);

--
-- Indexes for table `pacorp_vi_videos_block`
--
ALTER TABLE `pacorp_vi_videos_block`
  ADD UNIQUE KEY `bid` (`bid`,`id`);

--
-- Indexes for table `pacorp_vi_videos_block_cat`
--
ALTER TABLE `pacorp_vi_videos_block_cat`
  ADD PRIMARY KEY (`bid`),
  ADD UNIQUE KEY `title` (`title`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_videos_bodyhtml_1`
--
ALTER TABLE `pacorp_vi_videos_bodyhtml_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pacorp_vi_videos_bodytext`
--
ALTER TABLE `pacorp_vi_videos_bodytext`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pacorp_vi_videos_cat`
--
ALTER TABLE `pacorp_vi_videos_cat`
  ADD PRIMARY KEY (`catid`),
  ADD UNIQUE KEY `alias` (`alias`),
  ADD KEY `parentid` (`parentid`);

--
-- Indexes for table `pacorp_vi_videos_config_post`
--
ALTER TABLE `pacorp_vi_videos_config_post`
  ADD PRIMARY KEY (`group_id`);

--
-- Indexes for table `pacorp_vi_videos_logs`
--
ALTER TABLE `pacorp_vi_videos_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sid` (`sid`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `pacorp_vi_videos_playlist`
--
ALTER TABLE `pacorp_vi_videos_playlist`
  ADD UNIQUE KEY `playlist_id` (`playlist_id`,`id`);

--
-- Indexes for table `pacorp_vi_videos_playlist_cat`
--
ALTER TABLE `pacorp_vi_videos_playlist_cat`
  ADD PRIMARY KEY (`playlist_id`),
  ADD UNIQUE KEY `title` (`title`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_videos_rows`
--
ALTER TABLE `pacorp_vi_videos_rows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `author` (`author`),
  ADD KEY `title` (`title`),
  ADD KEY `addtime` (`addtime`),
  ADD KEY `publtime` (`publtime`),
  ADD KEY `exptime` (`exptime`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_videos_sources`
--
ALTER TABLE `pacorp_vi_videos_sources`
  ADD PRIMARY KEY (`sourceid`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `pacorp_vi_videos_tags`
--
ALTER TABLE `pacorp_vi_videos_tags`
  ADD PRIMARY KEY (`tid`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_videos_tags_id`
--
ALTER TABLE `pacorp_vi_videos_tags_id`
  ADD UNIQUE KEY `sid` (`id`,`tid`);

--
-- Indexes for table `pacorp_vi_weblinks_cat`
--
ALTER TABLE `pacorp_vi_weblinks_cat`
  ADD PRIMARY KEY (`catid`),
  ADD UNIQUE KEY `parentid` (`parentid`,`title`);

--
-- Indexes for table `pacorp_vi_weblinks_config`
--
ALTER TABLE `pacorp_vi_weblinks_config`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `pacorp_vi_weblinks_report`
--
ALTER TABLE `pacorp_vi_weblinks_report`
  ADD KEY `id` (`id`);

--
-- Indexes for table `pacorp_vi_weblinks_rows`
--
ALTER TABLE `pacorp_vi_weblinks_rows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catid` (`catid`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `pacorp_vi_xep_hang_thi_dua`
--
ALTER TABLE `pacorp_vi_xep_hang_thi_dua`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Indexes for table `pacorp_vi_xep_hang_thi_dua_config`
--
ALTER TABLE `pacorp_vi_xep_hang_thi_dua_config`
  ADD UNIQUE KEY `config_name` (`config_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pacorp_authors_config`
--
ALTER TABLE `pacorp_authors_config`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_authors_module`
--
ALTER TABLE `pacorp_authors_module`
  MODIFY `mid` mediumint(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `pacorp_banip`
--
ALTER TABLE `pacorp_banip`
  MODIFY `id` mediumint(8) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_banners_clients`
--
ALTER TABLE `pacorp_banners_clients`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_banners_plans`
--
ALTER TABLE `pacorp_banners_plans`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pacorp_banners_rows`
--
ALTER TABLE `pacorp_banners_rows`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `pacorp_cronjobs`
--
ALTER TABLE `pacorp_cronjobs`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pacorp_extension_files`
--
ALTER TABLE `pacorp_extension_files`
  MODIFY `idfile` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_googleplus`
--
ALTER TABLE `pacorp_googleplus`
  MODIFY `gid` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_groups`
--
ALTER TABLE `pacorp_groups`
  MODIFY `group_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `pacorp_language`
--
ALTER TABLE `pacorp_language`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_language_file`
--
ALTER TABLE `pacorp_language_file`
  MODIFY `idfile` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_logs`
--
ALTER TABLE `pacorp_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;
--
-- AUTO_INCREMENT for table `pacorp_notification`
--
ALTER TABLE `pacorp_notification`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pacorp_plugin`
--
ALTER TABLE `pacorp_plugin`
  MODIFY `pid` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pacorp_upload_dir`
--
ALTER TABLE `pacorp_upload_dir`
  MODIFY `did` mediumint(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;
--
-- AUTO_INCREMENT for table `pacorp_users`
--
ALTER TABLE `pacorp_users`
  MODIFY `userid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `pacorp_users_field`
--
ALTER TABLE `pacorp_users_field`
  MODIFY `fid` mediumint(8) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_users_question`
--
ALTER TABLE `pacorp_users_question`
  MODIFY `qid` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `pacorp_users_reg`
--
ALTER TABLE `pacorp_users_reg`
  MODIFY `userid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_about`
--
ALTER TABLE `pacorp_vi_about`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `pacorp_vi_blocks_groups`
--
ALTER TABLE `pacorp_vi_blocks_groups`
  MODIFY `bid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `pacorp_vi_cbdoan`
--
ALTER TABLE `pacorp_vi_cbdoan`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `pacorp_vi_cbdoan_chucvu`
--
ALTER TABLE `pacorp_vi_cbdoan_chucvu`
  MODIFY `macvu` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `pacorp_vi_cbdoan_donvi`
--
ALTER TABLE `pacorp_vi_cbdoan_donvi`
  MODIFY `madvi` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `pacorp_vi_comment`
--
ALTER TABLE `pacorp_vi_comment`
  MODIFY `cid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_contact_department`
--
ALTER TABLE `pacorp_vi_contact_department`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `pacorp_vi_contact_reply`
--
ALTER TABLE `pacorp_vi_contact_reply`
  MODIFY `rid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_contact_send`
--
ALTER TABLE `pacorp_vi_contact_send`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_download`
--
ALTER TABLE `pacorp_vi_download`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pacorp_vi_download_categories`
--
ALTER TABLE `pacorp_vi_download_categories`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `pacorp_vi_download_tags`
--
ALTER TABLE `pacorp_vi_download_tags`
  MODIFY `did` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_download_tmp`
--
ALTER TABLE `pacorp_vi_download_tmp`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_faq`
--
ALTER TABLE `pacorp_vi_faq`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_faq_categories`
--
ALTER TABLE `pacorp_vi_faq_categories`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_laws_cat`
--
ALTER TABLE `pacorp_vi_laws_cat`
  MODIFY `catid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pacorp_vi_laws_field`
--
ALTER TABLE `pacorp_vi_laws_field`
  MODIFY `fieldid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pacorp_vi_laws_organ`
--
ALTER TABLE `pacorp_vi_laws_organ`
  MODIFY `organid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pacorp_vi_laws_room`
--
ALTER TABLE `pacorp_vi_laws_room`
  MODIFY `roomid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pacorp_vi_laws_rows`
--
ALTER TABLE `pacorp_vi_laws_rows`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `pacorp_vi_lichct`
--
ALTER TABLE `pacorp_vi_lichct`
  MODIFY `nid` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pacorp_vi_lichct_config`
--
ALTER TABLE `pacorp_vi_lichct_config`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pacorp_vi_lichct_part`
--
ALTER TABLE `pacorp_vi_lichct_part`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pacorp_vi_menu`
--
ALTER TABLE `pacorp_vi_menu`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pacorp_vi_menu_rows`
--
ALTER TABLE `pacorp_vi_menu_rows`
  MODIFY `id` mediumint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=174;
--
-- AUTO_INCREMENT for table `pacorp_vi_modfuncs`
--
ALTER TABLE `pacorp_vi_modfuncs`
  MODIFY `func_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=191;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_8`
--
ALTER TABLE `pacorp_vi_news_8`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_9`
--
ALTER TABLE `pacorp_vi_news_9`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_10`
--
ALTER TABLE `pacorp_vi_news_10`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_11`
--
ALTER TABLE `pacorp_vi_news_11`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_12`
--
ALTER TABLE `pacorp_vi_news_12`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_13`
--
ALTER TABLE `pacorp_vi_news_13`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_14`
--
ALTER TABLE `pacorp_vi_news_14`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_15`
--
ALTER TABLE `pacorp_vi_news_15`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_16`
--
ALTER TABLE `pacorp_vi_news_16`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_17`
--
ALTER TABLE `pacorp_vi_news_17`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_18`
--
ALTER TABLE `pacorp_vi_news_18`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_19`
--
ALTER TABLE `pacorp_vi_news_19`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_20`
--
ALTER TABLE `pacorp_vi_news_20`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_21`
--
ALTER TABLE `pacorp_vi_news_21`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_22`
--
ALTER TABLE `pacorp_vi_news_22`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_23`
--
ALTER TABLE `pacorp_vi_news_23`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_24`
--
ALTER TABLE `pacorp_vi_news_24`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_25`
--
ALTER TABLE `pacorp_vi_news_25`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_26`
--
ALTER TABLE `pacorp_vi_news_26`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_27`
--
ALTER TABLE `pacorp_vi_news_27`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_block_cat`
--
ALTER TABLE `pacorp_vi_news_block_cat`
  MODIFY `bid` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_cat`
--
ALTER TABLE `pacorp_vi_news_cat`
  MODIFY `catid` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_logs`
--
ALTER TABLE `pacorp_vi_news_logs`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_rows`
--
ALTER TABLE `pacorp_vi_news_rows`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_sources`
--
ALTER TABLE `pacorp_vi_news_sources`
  MODIFY `sourceid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_tags`
--
ALTER TABLE `pacorp_vi_news_tags`
  MODIFY `tid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `pacorp_vi_news_topics`
--
ALTER TABLE `pacorp_vi_news_topics`
  MODIFY `topicid` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `pacorp_vi_page`
--
ALTER TABLE `pacorp_vi_page`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_photos_album`
--
ALTER TABLE `pacorp_vi_photos_album`
  MODIFY `album_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pacorp_vi_photos_category`
--
ALTER TABLE `pacorp_vi_photos_category`
  MODIFY `category_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pacorp_vi_photos_rows`
--
ALTER TABLE `pacorp_vi_photos_rows`
  MODIFY `row_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `pacorp_vi_support`
--
ALTER TABLE `pacorp_vi_support`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pacorp_vi_support_rows`
--
ALTER TABLE `pacorp_vi_support_rows`
  MODIFY `id` mediumint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pacorp_vi_tkblop`
--
ALTER TABLE `pacorp_vi_tkblop`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;
--
-- AUTO_INCREMENT for table `pacorp_vi_videos_1`
--
ALTER TABLE `pacorp_vi_videos_1`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pacorp_vi_videos_2`
--
ALTER TABLE `pacorp_vi_videos_2`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pacorp_vi_videos_3`
--
ALTER TABLE `pacorp_vi_videos_3`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_videos_4`
--
ALTER TABLE `pacorp_vi_videos_4`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_videos_block_cat`
--
ALTER TABLE `pacorp_vi_videos_block_cat`
  MODIFY `bid` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pacorp_vi_videos_cat`
--
ALTER TABLE `pacorp_vi_videos_cat`
  MODIFY `catid` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pacorp_vi_videos_logs`
--
ALTER TABLE `pacorp_vi_videos_logs`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_videos_playlist_cat`
--
ALTER TABLE `pacorp_vi_videos_playlist_cat`
  MODIFY `playlist_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacorp_vi_videos_rows`
--
ALTER TABLE `pacorp_vi_videos_rows`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pacorp_vi_videos_sources`
--
ALTER TABLE `pacorp_vi_videos_sources`
  MODIFY `sourceid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pacorp_vi_videos_tags`
--
ALTER TABLE `pacorp_vi_videos_tags`
  MODIFY `tid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `pacorp_vi_weblinks_cat`
--
ALTER TABLE `pacorp_vi_weblinks_cat`
  MODIFY `catid` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pacorp_vi_weblinks_rows`
--
ALTER TABLE `pacorp_vi_weblinks_rows`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pacorp_vi_xep_hang_thi_dua`
--
ALTER TABLE `pacorp_vi_xep_hang_thi_dua`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
