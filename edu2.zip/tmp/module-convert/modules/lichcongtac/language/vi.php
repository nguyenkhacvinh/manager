<?php

/**
* @Project NUKEVIET 3.0 LICH CONG TAC
* @Author PHAN DINH BAO (baocatg@gmail.com)
* @Copyright (C) 2010
* @Language Vietnamese
* @Createdate Dec 16, 2010, 08:01:47 PM
*/

 if (!defined( 'NV_MAINFILE' )) {
 die('Stop!!!');
}

$lang_translator['author'] ="PHAN DINH BAO (baocatg@gmail.com)";
$lang_translator['createdate'] ="16/12/2010, 15:22";
$lang_translator['copyright'] ="@Copyright (C) 2010";
$lang_translator['info'] ="";
$lang_translator['langtype'] ="lang_module";

$lang_module['calendar'] = "Lịch công tác";
$lang_module['contentwork'] = "Danh sách công việc";

$lang_module['fromdate'] = "Từ ngày ";
$lang_module['todate'] = " đến ngày ";

$lang_module['today'] = " Hôm nay ";
$lang_module['cur_week'] = " Tuần này ";
$lang_module['cur_month'] = " Tháng này ";
$lang_module['search_per_page'] = "Số công việc hiển thị";
$lang_module['group_user_action'] = "Nhóm người thực hiện";
$lang_module['user_action'] = "Người thực hiện";
$lang_module['all_group'] = "Tất cả các nhóm";
$lang_module['select_user_action'] = "Chọn người thực hiện";

$lang_module['submitview'] = "Xem lịch";

$lang_module['datetime'] = "Thời gian";
$lang_module['content'] = "Nội dung";
$lang_module['user_action'] = "Người thực hiện";
$lang_module['place'] = "Địa điểm";
$lang_module['description'] = "Ghi chú";

$lang_module['Mon'] = "Thứ hai";
$lang_module['Tue'] = "Thứ ba";
$lang_module['Wed'] = "Thứ tư";
$lang_module['Thu'] = "Thứ năm";
$lang_module['Fri'] = "Thứ sáu";
$lang_module['Sat'] = "Thứ bảy";
$lang_module['Sun'] = "Chủ nhật";

$lang_module['to'] = " đến ";
$lang_module['To'] = "Đến";
?>