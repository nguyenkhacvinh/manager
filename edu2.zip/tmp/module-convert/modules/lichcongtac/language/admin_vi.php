<?php

/**
* @Project NUKEVIET 3.0
* @Author VINADES.,JSC (contact@vinades.vn)
* @Copyright (C) 2010 VINADES.,JSC. All rights reserved
* @Language Vietnamese
* @Createdate May 31, 2010, 08:01:47 PM
*/

 if (! defined('NV_ADMIN') or ! defined('NV_MAINFILE')){
 die('Stop!!!');
}

$lang_translator['author'] ="PHAN DINH BAO (baocatg@gmail.com)";
$lang_translator['createdate'] ="16/12/2010, 15:22";
$lang_translator['copyright'] ="@Copyright (C) 2010";
$lang_translator['info'] ="";
$lang_translator['langtype'] ="lang_module";

$lang_module['content_add'] = "Thêm công việc";
$lang_module['setting'] = "Cấu hình module";
$lang_module['content_list'] = "Danh sách công việc";
$lang_module['group_user_action'] = "Nhóm người thực hiện";
$lang_module['action'] = "Thực hiện";
$lang_module['user_action'] = "Người thực hiện";
$lang_module['search_per_page'] = "Số công việc hiển thị";
$lang_module['all_group'] = "Tất cả các nhóm";
$lang_module['select_user_action'] = "Chọn người thực hiện";
$lang_module['content'] = "Nội dung";
$lang_module['date'] = "Ngày";
$lang_module['time'] = "Thời gian";
$lang_module['time1'] = "Buổi sáng";
$lang_module['time2'] = "Buổi chiều";
$lang_module['place'] = "Địa điểm";
$lang_module['description'] = "Ghi chú";
$lang_module['from'] = "Từ ";
$lang_module['to'] = "Đến ";

$lang_module['save'] = "Lưu lại";
$lang_module['edit'] = "Sửa đổi";
$lang_module['edit0'] = "Sửa";
$lang_module['add'] = "Thêm mới";
$lang_module['add0'] = "Thêm";
$lang_module['delete'] = "Xóa";
$lang_module['edit/delete'] = "Sửa/Xóa";
$lang_module['edit_content'] = "Sửa công việc";
$lang_module['add_content'] = "Thêm mới công việc";

$lang_module['noajax'] = "Trình duyệt của bạn không hỗ trợ AJAX";
$lang_module['confirmdelete'] = "Bạn thực sự muốn xóa? Nếu đồng ý, tất cả dữ liệu liên quan sẽ bị xóa. Bạn sẽ không thể phục hồi chúng lại sau này.";

$lang_module['error0'] = "Chưa có ngày thực hiện";
$lang_module['error1'] = "Thời gian thực hiện không hợp lệ";
$lang_module['error2'] = "Chưa có địa điểm thực hiện";
$lang_module['error3'] = "Chưa có nội dung công việc";
$lang_module['error4'] = "Chưa có người thực hiện";
$lang_module['error5'] = "";
$lang_module['error6'] = "";
$lang_module['error7'] = "";
$lang_module['error8'] = "";
$lang_module['error9'] = "";
$lang_module['error10'] = "";

$lang_module['W0'] = "Chủ nhật";
$lang_module['W1'] = "Thứ hai";
$lang_module['W2'] = "Thứ ba";
$lang_module['W3'] = "Thứ tư";
$lang_module['W4'] = "Thứ năm";
$lang_module['W5'] = "Thứ sáu";
$lang_module['W6'] = "Thứ bảy";

?>