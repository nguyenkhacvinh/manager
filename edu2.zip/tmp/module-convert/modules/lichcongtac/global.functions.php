<?php

/**
 * @Project NUKEVIET 3.0 LICH CONG TAC
 * @Author PHAN DINH BAO (baocatg@gmail.com)
 * @copyright 2010
 * @createdate 12/16/2010 0:51
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

//load config
$module_config = array();
$sql = "SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data . "_config`";
$result = $db->sql_query( $sql );
while ( $r = $db->sql_fetchrow($result) )
{
	$module_config[ $r['tenthamso'] ] = $r['giatri'];
}

function user_of_group( $groupid ){

	global $db, $lang_module;
	
	$sql = "select users from ". NV_GROUPS_GLOBALTABLE . " where (group_id = $groupid) ";
	$result = $db->sql_query( $sql );
	$r = $db->sql_fetchrow( $result );
	
	echo "<select name='user_action' id='user_action'>";
	echo "<option value ='0'>" . $lang_module['select_user_action'] . "</option>";
	
	if( $r ){

		$sql = "select userid, full_name from ". NV_USERS_GLOBALTABLE . " where userid IN(" . $r['users'] . ") ";
		
	} else {
	
		$sql = "select userid, full_name from ". NV_USERS_GLOBALTABLE;
	
	}
		$result = $db->sql_query( $sql );
		while ( $r = $db->sql_fetchrow($result) ){
		
			echo "<option value ='" . $r['userid'] . "'>" . $r['full_name'] . "</option>";
		
		}
	

	echo "</select>\n";
}

function nv_edit_work ( $id )
{
    global $lang_global, $module_name;
    $link = "<span class=\"edit_icon\"><a href=\"" . NV_BASE_ADMINURL . "index.php?" . NV_NAME_VARIABLE . "=" . $module_name . "&" . NV_OP_VARIABLE . "=content&amp;id=" . $id . "\">" . $lang_global['edit'] . "</a></span>";
    return $link;
}

function nv_delete_work ( $id )
{
    global $lang_global, $module_name;
    $link = "<span class=\"delete_icon\"><a href=\"javascript:void(0);\" onclick='nv_delete_work($id)'>" . $lang_global['delete'] . "</a></span>";
    return $link;
}

?>