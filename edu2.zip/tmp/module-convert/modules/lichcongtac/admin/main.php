<?php

/**
 * @Project NUKEVIET 3.0
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2010 VINADES.,JSC. All rights reserved
 * @Createdate 2-9-2010 14:43
 */
if ( ! defined( 'NV_IS_LICHCONGTAC_ADMIN' ) ) die( 'Stop!!!' );
$page_title = $lang_module['content_list'];

if( $nv_Request->get_int('groupid','post',-1) != -1 ){
	user_of_group( $nv_Request->get_int('groupid','post',0) );exit;
}

if( $nv_Request->get_int('deleteid','post',-1) != -1 ){
	$sql = "DELETE FROM `" . NV_PREFIXLANG . "_" . $module_data . "` WHERE `id`= " . $nv_Request->get_int('deleteid','post');
	$db->sql_query( $sql );exit;
}

$group_user = $nv_Request->get_int( 'group_user', 'post,get', 0 );
$user_action = $nv_Request->get_int( 'user_action', 'post,get', 0 );
$per_page = $nv_Request->get_int( 'per_page', 'post,get', $module_config['socongviechienthi'] );
$page = $nv_Request->get_int( 'page', 'post,get', 0 );

$form = $list = $generate_page = "";

$my_head .= "<script type='text/javascript' >\nvar noAjax = '" . $lang_module['noajax'] . "';\nvar confirmDelete = '" . $lang_module['confirmdelete'] . "';\n</script>\n";

//from
$action = NV_BASE_ADMINURL . "index.php?" . NV_NAME_VARIABLE . "=" . $module_name . "&amp;" . NV_OP_VARIABLE . "=" . $op;

$sql_group = "select group_id, title, exp_time, users, public, act  from ". NV_GROUPS_GLOBALTABLE;
$result = $db->sql_query( $sql_group );

$form .= "<form method='post' name='timkiemnhanh' action='$action' enctype='multipart/form-data'>";
$form .= "<table border='0' cellspacing='0' cellpadding='0'><tr>";

$form .= "<td width = '130'>" . $lang_module['group_user_action'] . ": </td>";

$form .= "<td width = '190'><select name='group_user' id = 'group_user' onchange='timkiemnhanh.submit();'>";

$form .= "<option value='0'>".$lang_module['all_group']."</option>";

while( $rows = $db->sql_fetchrow($result) )
{
	if ( $group_user == $rows['group_id'] ){
		
		$form .= "<option value='" . $rows['group_id'] . "' selected>" . $rows['title'] . "</option>";
	
	}else{
			
		$form .= "<option value='" . $rows['group_id'] . "'>" . $rows['title'] . "</option>";	
			
	}
}
$form .= "</select></td>";

$form .= "<td width = '95'>" . $lang_module['user_action'] . ": </td>";
$form .= "<td id='user_action_id'><select name='user_action' id='user_action' onchange='timkiemnhanh.submit();'>";

$form .= "<option value ='0'>" . $lang_module['select_user_action'] . "</option>";

$sql = "select users from ". NV_GROUPS_GLOBALTABLE . " where (group_id = $group_user) ";
$result = $db->sql_query( $sql );
$r = $db->sql_fetchrow( $result );
if( $r ){
	
	$sql = "select userid, full_name from ". NV_USERS_GLOBALTABLE . " where userid IN(" . $r['users'] . ") ";

} else {

	$sql = "select userid, full_name from ". NV_USERS_GLOBALTABLE;

}
	$result = $db->sql_query( $sql );
	while ( $r = $db->sql_fetchrow($result) ){
		
		if ( $user_action == $r['userid']) {
			
			$form .= "<option value ='" . $r['userid'] . "' selected>" . $r['full_name'] . "</option>";
		
		}else {
		
			$form .= "<option value ='" . $r['userid'] . "'>" . $r['full_name'] . "</option>";
		
		}
		
	}

$form .= "</select></td>";

$form .= "<td width = '130'>" . $lang_module['search_per_page'] . ": </td>";
$form .= "<td><select name='per_page' onchange='timkiemnhanh.submit();'>";
$i = 10;
while( $i <= 500 ){
	$form .= "<option value='$i' " . ( ( $i == $per_page ) ? " selected='selected'" : "" ) . "> $i </option>";
	$i += 10;
}
$form .= "</select></td>";

$form .= "</tr></table>";
$form .= "</form>";

//List
$work = work_of_group_user( $group_user, $user_action, $page );

$list .= "<form name='block_list'><table class='tab1'>";

$list .= "<thead><tr align='center'>";
//$list .= "<td><input name='check_all[]' type='checkbox' value='yes' onclick='nv_checkAll(this.form, 'idcheck[]', 'check_all[]',this.checked);'></td>";
$list .= "<td>" . $lang_module['date'] . "</td>";
$list .= "<td>" . $lang_module['time'] . "</td>";
$list .= "<td>" . $lang_module['content'] . "</td>";
$list .= "<td>" . $lang_module['user_action'] . "</td>";
$list .= "<td>" . $lang_module['place'] . "</td>";
$list .= "<td>" . $lang_module['description'] . "</td>";
$list .= "<td>" . $lang_module['edit/delete'] . "</td>";
$list .= "</tr></thead>";

if ( !empty($work) ){
	
	$n = count( $work );
	for( $i = 1 ; $i < $n ; $i++ ){
	
		$class = ( $i % 2 == 1 ) ? "" : " class='second' ";
		
		$list .= "<tbody $class><tr>";
		$list .= "<td>" . date( 'd/m/Y' , $work[$i]['ngay']) . "</td>";
		$list .= "<td>" . date( 'H:i' , $work[$i]['giobatdau']) . " - " . date( 'H:i' , $work[$i]['gioketthuc']) . "</td>";
		$list .= "<td>" . $work[$i]['noidung'] . "</td>";
		$list .= "<td>" . $work[$i]['tennguoithuchien'] . "</td>";
		$list .= "<td>" . $work[$i]['diadiem'] . "</td>";
		$list .= "<td>" . $work[$i]['ghichu'] . "</td>";
		$list .= "<td>" . nv_edit_work( $work[$i]['id'] ) . " - " . nv_delete_work( $work[$i]['id'] ) . "</td>";
		$list .= "</tr></tbody>";
		
	}

	$base_url = $action . "&group_user=$group_user&user_action=$user_action&per_page=$per_page";
	$generate_page = nv_generate_page( $base_url, $work[0], $per_page, $page );
	$generate_page = "<br><p align='center'>" . $generate_page . "</p>\n";
}
$list .= "</table></form>";

$contents .= $form . $list . $generate_page;

include ( NV_ROOTDIR . "/includes/header.php" );
echo nv_admin_theme( $contents );
include ( NV_ROOTDIR . "/includes/footer.php" );

?>