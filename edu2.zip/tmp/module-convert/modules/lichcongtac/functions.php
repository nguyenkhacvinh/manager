<?php

/**
 * @Project NUKEVIET 3.0 LICHCONGTAC
 * @Author PHAN DINH BAO, CATG (baocatg@gmail.com)
 * @copyright 2010
 * @createdate 16/12/2010
 */
if ( ! defined( 'NV_SYSTEM' ) ) die( 'Stop!!!' );

define( 'NV_IS_MOD_LICHCONGTAC', true );

require_once ( NV_ROOTDIR . "/modules/" . $module_file . "/global.functions.php" );

function work_of_group_user( $groupid , $userid , $fromdate , $todate , $page = 0 ){

	global $db, $module_config, $module_data;
	
	$work = array();
	
	unset( $m );
    preg_match( "/^([0-9]{1,2})\.([0-9]{1,2})\.([0-9]{4})$/", $fromdate, $m );
    $fromdate = mktime( 0, 0, 0, $m[2], $m[1], $m[3] );
	
	unset( $m );
    preg_match( "/^([0-9]{1,2})\.([0-9]{1,2})\.([0-9]{4})$/", $todate, $m );
    $todate = mktime( 0, 0, 0, $m[2], $m[1], $m[3] );
	
	$select = $from = $where = $limit = $orderby = "";
	$select = "SELECT id, ngay, giobatdau, gioketthuc, noidung, diadiem, ghichu, full_name as tennguoithuchien ";
	$from = " FROM `" . NV_PREFIXLANG . "_" . $module_data . "` l, " . NV_USERS_GLOBALTABLE . " u ";
	$where = " WHERE (l.nguoithuchien = u.userid) AND (l.ngay>=$fromdate) AND (l.ngay<=$todate) ";
	$orderby = " ORDER BY ngay, nguoithuchien ";
	$limit = " LIMIT $page," . $module_config['socongviechienthi'];
	
	$sql = $select . $from;
	
	if( $userid ){
	
		$where .= " AND (l.nguoithuchien IN( $userid )) ";
	
	} else if ( $groupid ) {
	
		$s = "select users from ". NV_GROUPS_GLOBALTABLE . " WHERE group_id = $groupid";
		$result = $db->sql_query( $s );
		$r = $db->sql_fetchrow( $result );
		
		
		if( $r ){
			
			if ( !empty( $r['users'] ) ){
			
				$where .= " AND (nguoithuchien IN(" . $r['users'] . ")) ";
				
			}else{
			
				$sql = "";
			
			}
		
		}
	
	}
	
	if ( !empty( $sql ) ){
	
		$sql .= $where . $orderby;
		$result = $db->sql_query( $sql );
		$work[0] = $db->sql_numrows( $result );
		
		$sql .= $limit;
		$result = $db->sql_query( $sql );

		while ( $r = $db->sql_fetchrow( $result ) ){
		
			$work[] = $r;
			
		}
	}

	return $work;
}

function create_select_date( $datetime , $selected = '2'){

	
	
}
?>