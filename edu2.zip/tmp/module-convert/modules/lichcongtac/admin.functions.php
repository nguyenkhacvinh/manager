<?php
/**
 * @Project NUKEVIET 3.0 LICH CONG TAC
 * @Author PHAN DINH BAO (baocatg@gmail.com)
 * @copyright 2010
 * @createdate 16/12/2010 2:29
 */
if ( ! defined( 'NV_ADMIN' ) or ! defined( 'NV_MAINFILE' ) or ! defined( 'NV_IS_MODADMIN' ) ) die( 'Stop!!!' );

$submenu['content'] = $lang_module['content_add'];
$submenu['setting'] = $lang_module['setting'];

$allow_func = array( 
    'main','content','setting'
);

define( 'NV_IS_LICHCONGTAC_ADMIN', true );

require_once ( NV_ROOTDIR . "/modules/" . $module_file . "/global.functions.php" );

function create_select_hour( $name , $selectvalue ){

	$select = "<select name='$name' id='$name'>\n";
	$i = -1;
	
	while( ++$i < 24 ){
	
		if( $i == $selectvalue ){
		
			$select .= "<option value='$i' selected>" . substr('0'.$i,-2,2) . "</option>\n";
			
		}else{
		
			$select .= "<option value='$i'>" . substr('0'.$i,-2,2) . "</option>\n";
			
		}
	}
	
	$select .= "</select>\n";
	
	return $select;
}

function create_select_min( $name , $step , $selectvalue){

	$select = "<select name='$name' id='$name'>\n";
	$i = 0;
	
	while( $i<60 ){
	
		if( $i == $selectvalue ){
		
			$select .= "<option value='$i' selected>" . substr('0'.$i,-2,2) . "</option>\n";
			
		}else{
		
			$select .= "<option value='$i'>" . substr('0'.$i,-2,2) . "</option>\n";
			
		}
		
		$i += $step;
	}
	$select .= "</select>\n";
	
	return $select;
}

function create_select_time( $name , $step , $selectvalue ){
	$select = "<select name='$name' id='$name'>";
	$h = 0;
	$m = 0;
	$t = "";
	
	while( $h < 24 ){
		
		$t = substr('0'.$h,-2,2) . ":" . substr('0'.$m,-2,2);
		
		if( $t == $selectvalue ){
		
			$select .= "<option value='$t' selected>$t</option>";
			
		}else{
			
			$select .= "<option value='$t'>$t</option>";
			
		}
		$m += $step;
		if( $m >= 60 ) $m = 0;
		if( $m == 0 ) $h++;
	}
	$select .= "</select>";
	
	return $select;
}

function work_of_group_user( $groupid, $userid, $page = 0 ){
	
	global $db, $module_config, $module_data;
	
	$work = array();
	
	$sql = "SELECT id, ngay, giobatdau, gioketthuc, noidung, diadiem, ghichu, full_name as tennguoithuchien FROM `" ;
	$sql .= NV_PREFIXLANG . "_" . $module_data . "` l, " . NV_USERS_GLOBALTABLE . " u WHERE (l.nguoithuchien = u.userid) ";
	
	$where = $orderby = $limit = "" ;
	$limit = " LIMIT $page," . $module_config['socongviechienthi'];
	
	if( $userid ){
	
		$where .= " AND (nguoithuchien IN( $userid )) ";
		
	}else if ( $groupid ) {
	
		$s = "select users from ". NV_GROUPS_GLOBALTABLE . " WHERE group_id = $groupid";
		$result = $db->sql_query( $s );
		$r = $db->sql_fetchrow( $result );
		
		
		if( $r ){
			
			if ( !empty( $r['users'] ) ){
			
				$where .= " AND (nguoithuchien IN(" . $r['users'] . ")) ";
				
			}else{
			
				$sql = "";
			
			}
		
		}
	}
	
	if ( !empty( $sql ) ){
	
		$sql .= $where . "ORDER BY l.ngay DESC ";
		$result = $db->sql_query( $sql );
		$work[0] = $db->sql_numrows( $result );
		
		$sql .= $limit;
		$result = $db->sql_query( $sql );
		while ( $r = $db->sql_fetchrow( $result ) ){
			
			$work[] = $r;
			
		}
	}

	return $work;
}


?>