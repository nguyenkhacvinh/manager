/* *
 * @Project NUKEVIET 3.0 LICH CONG TAC
 * @Author PHAN DINH BAO (baocatg@gmail.com)
 * @Copyright ( C ) 2010 
 * @Createdate 16/12/2010
 */
 
//ajax
var xmlHttp=GetXmlHttpObject();
function GetXmlHttpObject()
{
	xmlHttp=null;
	try{
		xmlHttp=new XMLHttpRequest();
	}catch(e){
		try{
			xmlHttp= new ActiveXObject("Msxml2.XMLHTTP");
		}catch(e){
			xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
	}
	return xmlHttp;
}

function stateChanged(){
    if((xmlHttp.readyState==4)&&(xmlHttp.status == 200)){
        document.getElementById("user_action_id").innerHTML=xmlHttp.responseText;
		
    }
}

function user_of_group(groupID){
	if(xmlHttp==null){
        alert(noAjax);
        return;
    }
	xmlHttp.open("POST",window.location);
	xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xmlHttp.onreadystatechange = stateChanged;
	xmlHttp.send('groupid='+groupID);
}

function stateDeleted(){
    if((xmlHttp.readyState==4)&&(xmlHttp.status == 200)){
		window.location = window.location;
    }
}

function nv_delete_work(workID){
	if(xmlHttp==null){
		alert(noAjax);
        return;
    }
	if (confirm(confirmDelete + workID)) { 
		xmlHttp.open("POST",window.location);
		xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		xmlHttp.onreadystatechange = stateDeleted;
		xmlHttp.send('deleteid='+workID);
	}
}