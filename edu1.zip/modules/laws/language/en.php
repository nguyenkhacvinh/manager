<?php

/**
 * @Project NUKEVIET 4.x
 * @Author PCD-GROUP (contact@dinhpc.com)
 * @Copyright (C) 2015 PCD-GROUP. All rights reserved
 * @Update to 4.x webvang (hoang.nguyen@webvang.vn)
 * @License GNU/GPL version 2 or any later version
 * @Createdate Fri, 29 May 2015 07:49:53 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$lang_translator['author'] = 'PCD-GROUP (contact@dinhpc.com)';
$lang_translator['createdate'] = '29/05/2015, 07:49';
$lang_translator['copyright'] = '@Copyright (C) 2015 VINADES.,JSC. All rights reserved';
$lang_translator['info'] = '';
$lang_translator['langtype'] = 'lang_module';

$lang_module['main'] = "Main";
$lang_module['view'] = "View";
$lang_module['viewcat'] = "Viewcat";
$lang_module['viewroom'] = "Viewroom";
$lang_module['viewfield'] = "Viewfield";
$lang_module['vieworgan'] = "Vieworgan";
$lang_module['search'] = "Search";
$lang_module['content'] = "Content";
$lang_module['down'] = "Down";
