<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2015 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Wed, 01 Apr 2015 18:51:25 GMT
 */

if (! defined('NV_ADMIN')) {
    die('Stop!!!');
}

$submenu['cat'] = $lang_module['faq_catmanager'];
$submenu['config'] = $lang_module['config'];
