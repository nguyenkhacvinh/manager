<?php
/**
** @Project: NUKEVIET NOTICE
** @Author: Webvang (hoang.nguyen@webvang.vn)
** @Copyright: webvang
** @Craetdate: 18.09.2015
*/

if ( ! defined( 'NV_ADMIN' ) or ! defined( 'NV_MAINFILE' )) die( 'Stop!!!' );

$module_version = array( 
    "name" => "Lichcongtac", //
	"modfuncs" => "main", //
	"is_sysmod" => 0, //
	"virtual" => 0, //
	"version" => "4.0.0", //
	"date" => "Fri, 18 Sep 2015", //
	"author" => "webvang (hoang.nguyen@webvang.vn)", //
	"note" => ""
);