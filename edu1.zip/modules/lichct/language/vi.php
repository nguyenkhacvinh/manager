<?php
/**
** @Project: NUKEVIET NOTICE
** @Author: Webvang (hoang.nguyen@webvang.vn)
** @Copyright: webvang
** @Craetdate: 18.09.2015
*/

if (!defined( 'NV_MAINFILE' )) {
 die('Stop!!!');
}

$lang_translator['author'] ="VINADES.,JSC (contact@vinades.vn)";
$lang_translator['createdate'] ="04/03/2010, 15:22";
$lang_translator['copyright'] ="@Copyright (C) 2010 VINADES.,JSC. All rights reserved";
$lang_translator['info'] ="";
$lang_translator['langtype'] ="lang_module";

$lang_module['notice_title'] = "Lịch công tác";
$lang_module['notice01'] = "Lịch làm việc tuần";
$lang_module['notice02'] = "Từ ngày";
$lang_module['notice03'] = "đến ngày";
$lang_module['notice04'] = "Chọn tuần";
$lang_module['notice05'] = "Tuần";
$lang_module['notice06'] = "Xem lịch";
$lang_module['notice07'] = "Sáng";
$lang_module['notice08'] = "Chiều";
$lang_module['notice09'] = "Thứ 2";
$lang_module['notice10'] = "Thứ 3";
$lang_module['notice11'] = "Thứ 4";
$lang_module['notice12'] = "Thứ 5";
$lang_module['notice13'] = "Thứ 6";
$lang_module['notice14'] = "Thứ 7";
$lang_module['notice15'] = "Chủ nhật";
$lang_module['notice16'] = "Chủ nhật";
$lang_module['notice0'] = "";$lang_module['notice0'] = "";$lang_module['notice0'] = "";$lang_module['notice0'] = "";$lang_module['notice0'] = "";$lang_module['notice0'] = "";$lang_module['notice0'] = "";$lang_module['notice0'] = "";$lang_module['notice0'] = "";$lang_module['notice0'] = "";$lang_module['notice0'] = "";