<?php

/**
 * @Project NUKEVIET 3.0 LICH CONG TAC
 * @Author PHAN DINH BAO (baocatg@gmail.com)
 * @Copyright (C) 2010
 * @Createdate 16-12-2010 20:59
 */

if ( ! defined( 'NV_IS_FILE_MODULES' ) ) die( 'Stop!!!' );

$sql_drop_module = array();

$sql_drop_module[] = "DROP TABLE IF EXISTS `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "`";
$sql_drop_module[] = "DROP TABLE IF EXISTS `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_config`";

$sql_create_module = $sql_drop_module;

$sql_create_module[] = "CREATE TABLE `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ngay` int(11) unsigned NOT NULL,
  `giobatdau` int(11) unsigned NOT NULL,
  `gioketthuc` int(11) unsigned NOT NULL,
  `noidung` varchar(500) NOT NULL,
  `diadiem` varchar(100) NOT NULL,
  `nguoithuchien` int(11) unsigned NOT NULL,
  `nguoilaplich` int(11) unsigned NOT NULL,
  `thoigianlap` int(11) unsigned NOT NULL,
  `ghichu` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM";

$sql_create_module[] = "CREATE TABLE `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_config` (
  `tenthamso` varchar(50) NOT NULL,
  `tenthamsodaydu` varchar(255) NOT NULL,
  `giatri` varchar(255) NOT NULL,
  UNIQUE KEY `tenthamso` (`tenthamso`)
) ENGINE=MyISAM";

$sql_create_module[] = "INSERT INTO `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_config` VALUES ('buoisang', 'Buổi sáng', '07:00-11:30')";
$sql_create_module[] = "INSERT INTO `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_config` VALUES ('buoichieu', 'Buổi chiều', '13:30-17:00')";
$sql_create_module[] = "INSERT INTO `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_config` VALUES ('cangay', 'Cả ngày', '07:00-17:30')";
$sql_create_module[] = "INSERT INTO `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_config` VALUES ('socongviechienthi', 'Số công việc hiển thị trong một trang', '50')";
$sql_create_module[] = "INSERT INTO `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_config` VALUES ('ngaydautuan', 'Ngày đầu tuần', '2')";
$sql_create_module[] = "INSERT INTO `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_config` VALUES ('ngaydauthang', 'Ngày đầu tháng', '1')";
$sql_create_module[] = "INSERT INTO `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_config` VALUES ('chithanhvienduocxem', 'Chỉ có thành viên được xem lịch', '1')";

?>