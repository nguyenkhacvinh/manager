<?php

/**
 * @Project NUKEVIET 3.0 LICH CONG TAC
 * @Author PHAN DINH BAO (baocatg@gmail.com)
 * @Copyright (C) 2010
 * @Createdate 22-12-2010
 */
if ( ! defined( 'NV_IS_LICHCONGTAC_ADMIN' ) ) die( 'Stop!!!' );
if ( defined( 'NV_EDITOR' ) )
{
    require_once ( NV_ROOTDIR . '/' . NV_EDITORSDIR . '/' . NV_EDITOR . '/nv.php' );
}


if( $nv_Request->get_int('groupid','post',-1) != -1 ){
	user_of_group( $nv_Request->get_int('groupid','post',0) );exit;
}

$id = $nv_Request->get_int( 'id', 'post,get', 0 );

if ( $id )
{
    $query = "SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data . "` WHERE `id`=" . $id;
    $result = $db->sql_query( $query );
    $numrows = $db->sql_numrows( $result );
    if ( empty( $numrows ) )
    {
        Header( "Location: " . NV_BASE_ADMINURL . "index.php?" . NV_NAME_VARIABLE . "=" . $module_name );
        die();
    }
    $row = $db->sql_fetchrow( $result );
    define( 'IS_EDIT', true );
    $page_title = $lang_module['edit_content'];
    $action = NV_BASE_ADMINURL . "index.php?" . NV_NAME_VARIABLE . "=" . $module_name . "&amp;" . NV_OP_VARIABLE . "=" . $op . "&amp;id=" . $id;
}
else
{
    $page_title = $lang_module['add_content'];
    $action = NV_BASE_ADMINURL . "index.php?" . NV_NAME_VARIABLE . "=" . $module_name . "&amp;" . NV_OP_VARIABLE . "=" . $op;
}

$error = "";

//Lay cac thong tin duoc submit hoac mac dinh
$date_action = filter_text_input('date_action','post','');
if( empty( $date_action ) ) $date_action = date('d.m.Y');
$time1 = $nv_Request->get_int('checktime1','post',0);
$time2 = $nv_Request->get_int('checktime2','post',0);
$hour1 = $nv_Request->get_int('hourfrom','post',0);
$hour2 = $nv_Request->get_int('hourto','post',0);
$min1 = $nv_Request->get_int('minfrom','post',0);
$min2 = $nv_Request->get_int('minto','post',0);
$diadiem = filter_text_input('place','post','');
$groupuser = $nv_Request->get_int('user_group','post',0);
$nguoithuchien = $nv_Request->get_int('user_action','post',0);
$ghichu = filter_text_textarea('description','', NV_ALLOWED_HTML_TAGS);
$noidung = nv_editor_filter_textarea( 'content' , '' , NV_ALLOWED_HTML_TAGS );
$nguoilaplich = $admin_info['userid'];
$thoigianlap = NV_CURRENTTIME;

$time1checked = $time2checked = '';


if ($nv_Request->get_int('save', 'post,get', 0) == 1)
{
    unset( $m );
    preg_match( "/^([0-9]{1,2})\.([0-9]{1,2})\.([0-9]{4})$/", $date_action, $m );
    $ngaythuchien = mktime( 0, 0, 0, $m[2], $m[1], $m[3] );
	
	if( $time1 == 1 && $time2 == 1){
	
		$time = split( '[:-]' , $module_config['buoisang'] );
		$hour1 = $time[0];
		$min1 = $time[1];
		$time = split( '[:-]' , $module_config['buoichieu'] );
		$hour2 = $time[2];
		$min2 = $time[3];
		
		$time1checked = $time2checked = 'checked';
		
	}else if ( $time1 == 1 ){
	
		$time = split( '[:-]' , $module_config['buoisang'] );
		$hour1 = $time[0];
		$min1 = $time[1];
		$hour2 = $time[2];
		$min2 = $time[3];
		
		$time1checked = 'checked';
		
	}else if( $time2 == 1 ){
	
		$time = split( '[:-]' , $module_config['buoichieu'] );
		$hour1 = $time[0];
		$min1 = $time[1];
		$hour2 = $time[2];
		$min2 = $time[3];
		
		$time2checked = 'checked';
		
	}
	
	$giobatdau = mktime( $hour1, $min1, 0, $m[2], $m[1], $m[3] );
	$gioketthuc = mktime( $hour2, $min2, 0, $m[2], $m[1], $m[3] );
	
	if( empty($ngaythuchien) ){
	
		$error = $lang_module['error0'];
		
	} else if( $giobatdau >= $gioketthuc) {
	
		$error = $lang_module['error1'];
		
	} else if ( empty($diadiem) ){
		
		$error = $lang_module['error2'];
		
	} else if ( strip_tags( $noidung ) == "") {
	
		$error = $lang_module['error3'];
		
	} else if ( $nguoithuchien == 0) {
		
		$error = $lang_module['error4'];
		
	} else {
	
		$noidung = nv_editor_nl2br( $noidung );
		
		if ( defined( 'IS_EDIT' ) )
        {
			nv_insert_logs( NV_LANG_DATA, $module_name, 'log_edit_lichcongtac', "lichcongtacid ".$id, $admin_info['userid'] );
			$query = "UPDATE`" . NV_PREFIXLANG . "_" . $module_data . "` SET 
            `ngay`=$ngaythuchien, `giobatdau` =  $giobatdau, `gioketthuc`= $gioketthuc, `noidung`= '$noidung' ,
			`diadiem`='$diadiem', `nguoithuchien`=$nguoithuchien, `nguoilaplich`=$nguoilaplich,
			`thoigianlap`=$thoigianlap, `ghichu`= '$ghichu' WHERE `id` = $id ";
		}
		else
		{
			nv_insert_logs( NV_LANG_DATA, $module_name, 'log_add_lichcongtac', " ", $admin_info['userid'] );
			$query = "INSERT INTO " . NV_PREFIXLANG . "_" . $module_data .
			" VALUES(NULL,$ngaythuchien,$giobatdau,$gioketthuc,'$noidung','$diadiem',$nguoithuchien,$nguoilaplich,$thoigianlap,'$ghichu')";
		}
		
		$db->sql_query( $query );
        Header( "Location: " . NV_BASE_ADMINURL . "index.php?" . NV_NAME_VARIABLE . "=" . $module_name . "&" . NV_OP_VARIABLE . "=main" );
        exit();
	}
	
}
else
{
	
	if ( defined( 'IS_EDIT' ) )
    {
        $date_action = date( 'd.m.Y', $row['ngay'] );
        $hour1 = date( 'H' , $row['giobatdau'] );
		$min1 = date( 'i' , $row['giobatdau'] );
		$hour2 = date( 'H' , $row['gioketthuc'] );
		$min2 = date( 'i' , $row['gioketthuc'] );
		$hm = $hour1 . ":" . $min1 . "-" . $hour2 . ":" . $min2;
		if( $hm == $module_config['cangay'] )
		{
			
			$time1checked = $time2checked = 'checked';
			
		}else if ( $hm == $module_config['buoisang'] ){
		
			$time1checked =  'checked';
			
		}else if ( $hm == $module_config['buoichieu'] ){
		
			$time2checked =  'checked';
			
		}
		$diadiem = $row['diadiem'];
		$ghichu = $row['ghichu'];
        $noidung = nv_editor_br2nl( $row['noidung'] );
		$nguoithuchien = $row['nguoithuchien'];
		$sql = "select group_id, users from ". NV_GROUPS_GLOBALTABLE;
		$result = $db->sql_query( $sql );
		while( $r = $db->sql_fetchrow($result) ){
		
			$u = split( '[,]' , $r['users'] );
			$n = count($u);
			$i = 0;
			for( $i = 0 ; $i < $n ; $i++ ){
				if( $u[$i] == $nguoithuchien )
				{
					
					$groupuser = $r['group_id'];
					break;
				}
			}
			if( $i < $n ) break;
		}
    }
	
}

if ( ! empty( $noidung ) ) $bodytext = nv_htmlspecialchars( $noidung );

if ( ! empty( $error ) )
{
    $contents .= "<div class=\"quote\" style=\"width:780px;\">\n";
    $contents .= "<blockquote class=\"error\"><span>" . $error . "</span></blockquote>\n";
    $contents .= "</div>\n";
    $contents .= "<div class=\"clear\"></div>\n";
}
//global $my_head;
$my_head .= "<script type='text/javascript' > var noAjax = '" . $lang_module['noajax'] . "';</script>\n";
$my_head .= "<script type='text/javascript' src=\"" . NV_BASE_SITEURL . "js/popcalendar/popcalendar.js\"> </script>\n";

$contents .= "<form action=\"" . $action . "\" method=\"post\">\n";
$contents .= "<table border='0' cellspacing='0' cellpadding='0'>";
//ngay
$contents .= "<tr><td width='100'>" . $lang_module['date'] . ": </td><td colspan='2'><input value='$date_action' type='text' name='date_action' id='date_action' maxlength='10' readonly='readonly' style='width:90px'>";
$contents .= "<img src=\"" . NV_BASE_SITEURL . "images/calendar.jpg\" widht=\"18\" style=\"cursor: pointer; vertical-align: middle;\" onclick=\"popCalendar.show(this, 'date_action', 'dd.mm.yyyy', true);\" alt=\"\" height=\"17\"></td></tr>\n";
//thoigian
$contents .= "<tr><td>" . $lang_module['time'] . ": </td><td>\n";
$contents .= "<input type='checkbox' name='checktime1' id='checktime1' value='1' $time1checked>" . $lang_module['time1'];
$contents .= "<br><input type='checkbox' name='checktime2' id='checktime2' value='1' $time2checked>" . $lang_module['time2'];
$contents .= "</td><td>" . $lang_module['from'] . create_select_hour('hourfrom',$hour1) . create_select_min('minfrom',15,$min1);
$contents .= $lang_module['to'] . create_select_hour('hourto',$hour2) . create_select_min('minto',15,$min2) . "</td></tr>";
//dia diem
$contents .= "<tr><td>" . $lang_module['place'] . ": </td><td colspan='2'>\n";
$contents .= "<input value='$diadiem' type='text' maxlength='100' name='place' id='place' style='width:100%'>";
$contents .= "</td></tr>\n";
// nguoi thuc hien
$contents .= "<tr><td>" . $lang_module['action'] . ": </td><td>\n";

$contents .= "<select name='user_group' id='user_group' onchange='user_of_group(this.value);'>";

$contents .= "<option value='0'>" . $lang_module['all_group'] . "</option>";

$sql_group = "select group_id, title, exp_time, users, public, act  from ". NV_GROUPS_GLOBALTABLE;
$result = $db->sql_query( $sql_group );

while( $r = $db->sql_fetchrow($result) )
{
	//if ( $groupuser == 0 ) $groupuser = $r['group_id'];
	
	if( $groupuser == $r['group_id']){
	
		$contents .= "<option value='" . $r['group_id'] . "' selected>" . $r['title'] . "</option>";

	}else{
	
		$contents .= "<option value='" . $r['group_id'] . "'>" . $r['title'] . "</option>";
	
	}
}

$contents .= "</select></td><td id='user_action_id'><select name='user_action' id ='user_action'>";

$contents .= "<option value ='0'>" . $lang_module['select_user_action'] . "</option>";

$sql = "select users from ". NV_GROUPS_GLOBALTABLE . " where (group_id = $groupuser) ";
$result = $db->sql_query( $sql );
$r = $db->sql_fetchrow( $result );
if( $r ){
	
	$sql = "select userid, full_name from ". NV_USERS_GLOBALTABLE . " where userid IN(" . $r['users'] . ") ";

} else {

	$sql = "select userid, full_name from ". NV_USERS_GLOBALTABLE;

}
	$result = $db->sql_query( $sql );
	while ( $r = $db->sql_fetchrow($result) ){
		
		if ( $nguoithuchien == $r['userid']) {
			
			$contents .= "<option value ='" . $r['userid'] . "' selected>" . $r['full_name'] . "</option>";
		
		}else {
		
			$contents .= "<option value ='" . $r['userid'] . "'>" . $r['full_name'] . "</option>";
		
		}
		
	}


$contents .= "</select></td></tr>\n";
//noi dung
$contents .= "<tr><td>" . $lang_module['content'] . ": </td><td colspan='2'>\n";
if ( defined( 'NV_EDITOR' ) and function_exists( 'nv_aleditor' ) )
{
    $contents .= nv_aleditor( "content", '100%', '200px', $noidung );
}
else
{
    $contents .= "<textarea style='width:100%;height:200px' name='content' id='content'>$noidung</textarea>";
}
$contents .= "</td></tr>\n";
//ghi chu
$contents .= "<tr><td>" . $lang_module['description'] . ": </td><td colspan='2'>\n";
$contents .= "<textarea name='description' id ='description' style='width:100%'>$ghichu</textarea>";
$contents .= "</td></tr>\n";
//luu
$contents .= "<tr><td colspan='3' align='center'><input type='submit' name='submit1' value='" .$lang_module['save']. "'></td></tr>";
$contents .= "<input name='save' type='hidden' value='1'>\n";
$contents .= "</table>";
$contents .= "</form>";

include ( NV_ROOTDIR . "/includes/header.php" );
echo nv_admin_theme( $contents );
include ( NV_ROOTDIR . "/includes/footer.php" );

?> 