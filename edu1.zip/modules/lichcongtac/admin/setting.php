<?php

/**
 * @Project NUKEVIET 3.0 LICH CONG TAC
 * @Author PHAN DINH BAO (baocatg@gmail.com)
 * @Copyright (C) 2010 
 * @Createdate 16-12-2010
 */

if ( ! defined( 'NV_IS_LICHCONGTAC_ADMIN' ) ) die( 'Stop!!!' );

$page_title = $lang_module['setting'];

$savesetting = $nv_Request->get_int( 'savesetting', 'post', 0 );
if ( ! empty( $savesetting ) )
{
    $array_config = array();
    $shour1 = $nv_Request->get_int( 'shour1', 'post', 0 );
	$shour2 = $nv_Request->get_int( 'shour2', 'post', 0 );
	$smin1 = $nv_Request->get_int( 'smin1', 'post', 0 );
	$smin2 = $nv_Request->get_int( 'smin2', 'post', 0 );
	$chour1 = $nv_Request->get_int( 'chour1', 'post', 0 );
	$chour2 = $nv_Request->get_int( 'chour2', 'post', 0 );
	$cmin1 = $nv_Request->get_int( 'cmin1', 'post', 0 );
	$cmin2 = $nv_Request->get_int( 'cmin2', 'post', 0 );
	
	$array_config['buoisang'] = substr('0'.$shour1,-2,2) . ":" . substr('0'.$smin1,-2,2) . "-" . substr('0'.$shour2,-2,2) . ":" . substr('0'.$smin1,-2,2);
	$array_config['buoichieu'] = substr('0'.$chour1,-2,2) . ":" . substr('0'.$cmin1,-2,2) . "-" . substr('0'.$chour2,-2,2) . ":" . substr('0'.$cmin1,-2,2);
	$array_config['socongviechienthi'] = $nv_Request->get_int( 'socongviechienthi', 'post', 0 );
	$array_config['ngaydautuan'] = $nv_Request->get_int( 'ngaydautuan', 'post', 0 );
	$array_config['ngaydauthang'] = $nv_Request->get_int( 'ngaydauthang', 'post', 0 );
	$array_config['chithanhvienduocxem'] = $nv_Request->get_int( 'chithanhvienduocxem', 'post', 0 );
    
	foreach ( $array_config as $config_name => $config_value )
    {
        $query = "UPDATE " . NV_PREFIXLANG . "_" . $module_data . "_config";
		$query .= "SET giatri = " . $db->dbescape( $config_value ) . " WHERE tenthamso = " . $db->dbescape( $config_name );
        $db->sql_query( $query );
    }
    
    Header( "Location: " . NV_BASE_ADMINURL . "index.php?" . NV_NAME_VARIABLE . "=" . $module_name . "&" . NV_OP_VARIABLE . "=" . $op . "&rand=" . nv_genpass() );
    die();
}

$sql = "SELECT * FROM " . NV_PREFIXLANG . "_" . $module_data . "_config";
$result = $db->sql_query($sql);

$module_config = array();

while ( $r = $db->sql_fetchrow($result) ){

	$module_config[ $r['tenthamso'] ] = $r;

}

$contents .= "<form action=\"" . NV_BASE_ADMINURL . "index.php\" method=\"post\">";
$contents .= "<input type=\"hidden\" name =\"" . NV_NAME_VARIABLE . "\"value=\"" . $module_name . "\" />";
$contents .= "<input type=\"hidden\" name =\"" . NV_OP_VARIABLE . "\"value=\"" . $op . "\" />";
$contents .= "<table summary=\"\" class=\"tab1\">\n";

$contents .= "<tbody><tr>\n";
$contents .= "<td width='210'>" . $module_config['buoisang']['tenthamsodaydu'] . "</td>\n";
	$time = split( '[:-]' , $module_config['buoisang']['giatri'] );
	$hour1 = $time[0];
	$min1 = $time[1];
	$hour2 = $time[2];
	$min2 = $time[3];
$contents .= "<td>" . $lang_module['from'] . create_select_hour('shour1',$hour1) . create_select_min('smin1',15,smin1);
$contents .= $lang_module['to'] . create_select_hour('shour2',shour2) . create_select_min('smin2',15,smin2);
$contents .="</td>\n";
$contents .= "</tr></tbody>\n";

$contents .= "<tbody class=\"second\"><tr>\n";
$contents .= "<td>" . $module_config['buoichieu']['tenthamsodaydu'] . "</td>\n";
	$time = split( '[:-]' , $module_config['buoichieu']['giatri'] );
	$hour1 = $time[0];
	$min1 = $time[1];
	$hour2 = $time[2];
	$min2 = $time[3];
$contents .= "<td>" . $lang_module['from'] . create_select_hour('chour1',$hour1) . create_select_min('cmin1',15,$min1);
$contents .= $lang_module['to'] . create_select_hour('chour2',$hour2) . create_select_min('cmin2',15,$min2);
$contents .="</td>\n";
$contents .= "</tr></tbody>\n";

$contents .= "<tbody><tr>\n";
$contents .= "<td>" . $module_config['ngaydautuan']['tenthamsodaydu'] . "</td>\n";
$contents .= "<td><select name = 'ngaydautuan' id = 'ngaydautuan'>\n"; 
for( $i = 0 ; $i <= 6 ; $i++ ){
	if( $i == $module_config['ngaydautuan']['giatri'] )
	{
		$contents .= "<option value ='$i' selected>" . $lang_module['W'.$i] . "</option>\n";
	}else{
		$contents .= "<option value ='$i'>" . $lang_module['W'.$i] . "</option>\n";
	}
}
$contents .="</select></td>\n";
$contents .= "</tr></tbody>\n";

$contents .= "<tbody class=\"second\"><tr>\n";
$contents .= "<td>" . $module_config['ngaydauthang']['tenthamsodaydu'] . "</td>\n";
$contents .= "<td><select name = 'ngaydauthang' id = 'ngaydauthang'>\n"; 
for( $i = 1 ; $i <= 31 ; $i++ ){
	if( $i == $module_config['ngaydauthang']['giatri'] )
	{
		$contents .= "<option value ='$i' selected>$i</option>\n";
	}else{
		$contents .= "<option value ='$i'>$i</option>\n";
	}
}
$contents .="</select></td>\n";
$contents .= "</tr></tbody>\n";

$contents .= "<tbody><tr>\n";
$contents .= "<td>" . $module_config['socongviechienthi']['tenthamsodaydu'] . "</td>\n";
$contents .= "<td><select name = 'socongviechienthi' id = 'socongviechienthi'>\n"; 
$i = 10;
while( $i <= 500 ){
	$contents .= "<option value='$i' " . ( ( $i == $module_config['socongviechienthi']['giatri'] ) ? " selected='selected'" : "" ) . "> $i </option>";
	$i += 10;
}
$contents .="</select></td>\n";
$contents .= "</tr></tbody>\n";

$contents .= "<tbody class=\"second\"><tr>\n";
$contents .= "<td>" . $module_config['chithanhvienduocxem']['tenthamsodaydu'] . "</td>\n";
$contents .= "<td><input type='checkbox' name = 'chithanhvienduocxem' id = 'chithanhvienduocxem' value='1' " . (( $module_config['chithanhvienduocxem']['giatri'])? "checked" : "") . " ></td>\n";
$contents .= "</tr></tbody>\n";

$contents .= "<tbody><tr>\n";
$contents .= "<td align='center' colspan='2'><input type='submit' value=' " . $lang_module['save'] . " ' name='submit1'>
				  <input type='hidden' value='1' name='savesetting'></td>\n";
$contents .= "</tr></tbody>\n";

$contents .= "</table>\n";
$contents .= "</form>\n";

include ( NV_ROOTDIR . "/includes/header.php" );
echo nv_admin_theme( $contents );
include ( NV_ROOTDIR . "/includes/footer.php" );
?>