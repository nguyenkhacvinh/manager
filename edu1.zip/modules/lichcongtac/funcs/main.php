<?php

/**
 * @Project NUKEVIET 3.0 LICH CONG TAC
 * @Author PHAN DINH BAO (baocatg@gmail.com)
 * @Copyright (C) 2010
 * @Createdate 16-12-2010 0:14
 */

if ( ! defined( 'NV_IS_MOD_LICHCONGTAC' ) ) die( 'Stop!!!' );

$xtpl = new XTemplate( "main.tpl", NV_ROOTDIR . "/themes/" . $module_info['template'] . "/modules/" . $module_file );

$my_head .= "<script type='text/javascript' src=\"" . NV_BASE_SITEURL . "js/popcalendar/popcalendar.js\"> </script>\n";

$action = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name;

$week[0] = "Sunday";
$week[1] = "Monday";
$week[2] = "Tuesday";
$week[3] = "Wednesday";
$week[4] = "Thursday";
$week[5] = "Friday";
$week[6] = "Saturday";

$group_user = $nv_Request->get_int( 'group_user', 'post,get', 0 );
$user_action = $nv_Request->get_int( 'user_action', 'post,get', 0 );
$per_page = $nv_Request->get_int( 'per_page', 'post,get', $module_config['socongviechienthi'] );
$page = $nv_Request->get_int( 'page', 'post,get', 0 );

$fromdate = $nv_Request->get_string( 'fromdate', 'post,get', date( 'd.m.Y' , strtotime('last ' . $week[ $module_config['ngaydautuan'] ] , time()) ) );
$i = ( ($module_config['ngaydautuan'] - 1) < 0 ) ? $module_config['ngaydautuan'] - 1 + 7 : $module_config['ngaydautuan'] - 1;
$todate = $nv_Request->get_string( 'todate', 'post,get', date( 'd.m.Y' , strtotime('next ' . $week[$i] , time()) ) );

$viewtoday = $nv_Request->get_string( 'viewtoday', 'post,get', '' );
$viewweek = $nv_Request->get_string( 'viewweek', 'post,get', '' );
$viewmonth = $nv_Request->get_string( 'viewmonth', 'post,get', '' );

if( !empty($viewtoday) ){

	$fromdate = date( 'd.m.Y' );
	$todate = date( 'd.m.Y' );
	
} else if ( !empty($viewweek) ){

	if ($module_config['ngaydautuan'] == date('w')){
	
		$fromdate = date( 'd.m.Y' , strtotime($week[ $module_config['ngaydautuan'] ] , time() ));
	}
	else{
		$fromdate = date( 'd.m.Y' , strtotime('last ' . $week[ $module_config['ngaydautuan'] ] , time() ));
	}
	$i = ( ($module_config['ngaydautuan'] - 1) < 0 ) ? $module_config['ngaydautuan'] - 1 + 7 : $module_config['ngaydautuan'] - 1;
	$todate = date( 'd.m.Y' , strtotime('next ' . $week[$i], time()) );
} else if ( !empty($viewmonth) ){

	$date_cur = date('j');
	
	if( $date_cur >= $module_config['ngaydauthang'] ){
	
		$firstday = mktime( 0 , 0 , 0 , date('n') , $module_config['ngaydauthang'] , date('Y') );
		$fromdate = date( 'd.m.Y' , $firstday );
		$todate = date( 'd.m.Y' , strtotime( '+1 month -1 second' , $firstday ) );
	
	}else {
	
		$firstday = mktime( 0 , 0 , 0 , date('n') , $module_config['ngaydauthang'] , date('Y') );
		$firstday = strtotime( '-1 month' , $firstday );
		$fromdate = date( 'd.m.Y' , $firstday );
		$todate = date( 'd.m.Y' , strtotime( '+1 month -1 second' , $firstday ) );
		
	}

}

$contents .= "<table border='0' cellspacing='0' cellpadding='0'>\n";
//phan tren
$contents .= "<tr><td>\n";

$contents .= "<form method='post' name='timkiemnhanh' action='$action' enctype='multipart/form-data'>";
$contents .= "<table border ='0' cellspacing='0' cellpadding='0'>\n";

//group
$contents .= "<td>" . $lang_module['group_user_action'] . ": </td>";
$contents .= "<td><select name='group_user' id = 'group_user' onchange='timkiemnhanh.submit();'>";

$contents .= "<option value='0'>".$lang_module['all_group']."</option>";

$sql_group = "select group_id, title, exp_time, users, public, act  from ". NV_GROUPS_GLOBALTABLE;
$result = $db->sql_query( $sql_group );
while( $rows = $db->sql_fetchrow($result) )
{
	if ( $group_user == $rows['group_id'] ){
		
		$contents .= "<option value='" . $rows['group_id'] . "' selected>" . $rows['title'] . "</option>";
	
	}else{
			
		$contents .= "<option value='" . $rows['group_id'] . "'>" . $rows['title'] . "</option>";	
			
	}
}
$contents .= "</select></td>";

//user
$contents .= "<td>" . $lang_module['user_action'] . ": </td>";
$contents .= "<td id='user_action_id'><select name='user_action' id='user_action' onchange='timkiemnhanh.submit();'>";

$contents .= "<option value ='0'>" . $lang_module['select_user_action'] . "</option>";

$sql = "select users from ". NV_GROUPS_GLOBALTABLE . " where (group_id = $group_user) ";
$result = $db->sql_query( $sql );
$r = $db->sql_fetchrow( $result );
if( $r ){
	
	$sql = "select userid, full_name from ". NV_USERS_GLOBALTABLE . " where userid IN(" . $r['users'] . ") ";

} else {

	$sql = "select userid, full_name from ". NV_USERS_GLOBALTABLE;

}
	$result = $db->sql_query( $sql );
	while ( $r = $db->sql_fetchrow($result) ){
		
		if ( $user_action == $r['userid']) {
			
			$contents .= "<option value ='" . $r['userid'] . "' selected>" . $r['full_name'] . "</option>";
		
		}else {
		
			$contents .= "<option value ='" . $r['userid'] . "'>" . $r['full_name'] . "</option>";
		
		}
		
	}

$contents .= "</select>";

//so dong
$contents .= "<td align='right'>" . $lang_module['search_per_page'];
$contents .= " <select name='per_page' onchange='timkiemnhanh.submit();'>";
$i = 10;
while( $i <= 500 ){
	$contents .= "<option value='$i' " . ( ( $i == $per_page ) ? " selected='selected'" : "" ) . "> $i </option>";
	$i += 10;
}
$contents .= "</select></td>";

$contents .= "</tr>\n";

//date
$contents .= "<tr>\n";

$contents .= "<td colspan='2'> " . $lang_module['submitview'];
$contents .= ": <input type = 'submit' name = 'viewtoday' value = '" . $lang_module['today'] . "'>";
$contents .= " <input type = 'submit' name = 'viewweek' value = '" . $lang_module['cur_week'] . "'>";
$contents .= " <input type = 'submit' name = 'viewmonth' value = '" . $lang_module['cur_month'] . "'>";
$contents . "</td>\n";

$contents .= "<td colspan='3'>" . $lang_module['fromdate'] . "<input value='$fromdate' type='text' name='fromdate' id='fromdate' maxlength='10' readonly='readonly' style='width:90px'>\n";
$contents .= "<img src=\"" . NV_BASE_SITEURL . "images/calendar.jpg\" widht=\"18\" style=\"cursor: pointer; vertical-align: middle;\" onclick=\"popCalendar.show(this, 'fromdate', 'dd.mm.yyyy', true);\" alt=\"\" height=\"17\">\n";
$contents .= $lang_module['todate'] . "<input value='$todate' type='text' name='todate' id='todate' maxlength='10' readonly='readonly' style='width:90px'>\n";
$contents .= "<img src=\"" . NV_BASE_SITEURL . "images/calendar.jpg\" widht=\"18\" style=\"cursor: pointer; vertical-align: middle;\" onclick=\"popCalendar.show(this, 'todate', 'dd.mm.yyyy', true);\" alt=\"\" height=\"17\">\n";
$contents .= "<input type = 'submit' value = '" . $lang_module['submitview'] . "' name = 'submit1' id = 'submit1'></td>\n";
$contents .= "</tr>\n";

$contents .= "</table></form>\n";

$contents .= "</td></tr>\n";
//phan lich
$contents .= "<tr><td>\n";

$work = work_of_group_user( $group_user , $user_action , $fromdate , $todate , $page );

$xtpl->assign( 'HEADER' , $lang_module );
$xtpl->parse('main.header');

if ( !empty($work) ){

	$n = count( $work );
	
	$rowspan1 = $rowspan2 = 1;
	
	$class = " class='first' ";
	
	$i = 1;
	while($i < $n){
	
		$ii = $i;
		
		while( (++$ii < $n)  && (date( 'd/m/Y' , $work[$i]['ngay'] ) == date( 'd/m/Y' , $work[$ii]['ngay'] )) ){
			$rowspan1++;
		}
		
		$vi_ngay = $lang_module[ date( 'D' , $work[$i]['ngay'] ) ] . "<br>" . date( 'd/m/Y' , $work[$i]['ngay'] );
			
		$xtpl->assign( 'ROWSPAN1' , $rowspan1 );
		$xtpl->assign( 'DATE' , $vi_ngay);
		$xtpl->parse('main.row.date');
		
		$ii = 0 ;
		while ( $ii < $rowspan1 ){
		
			$j = $ii;
			
			while( (++$j < $rowspan1) && ($work[$i+$ii]['tennguoithuchien']  == $work[$i+$j]['tennguoithuchien'] ) ){
				$rowspan2++;
			}
			
			for( $j = 0 ; $j < $rowspan2 ; $j++ ){
			
				$work[$i+$ii+$j]['giobatdau'] = date( 'H:i' , $work[$i+$ii+$j]['giobatdau'] );
				$work[$i+$ii+$j]['gioketthuc'] = date( 'H:i' , $work[$i+$ii+$j]['gioketthuc'] );
				$xtpl->assign( 'CLASS' , $class );
				$xtpl->assign( 'BODY' , $work[$i+$ii+$j] );
				
				if( $j == 0 ) {
					$xtpl->assign( 'ROWSPAN2' , $rowspan2 );
					$xtpl->assign( 'USER' , $work[$i+$ii]['tennguoithuchien'] );
					$xtpl->parse('main.row.user');
				
					
				}
				$xtpl->parse('main.row');
			}
			
			if ( $class == " class='first' " ) $class = " class='second' "; else $class = " class='first' ";
			
			$ii += $rowspan2;
			$rowspan2 = 1;
			
		}
		
		$i += $rowspan1;
		$rowspan1 = 1;
	}

	$base_url = $action . "&group_user=$group_user&user_action=$user_action&fromdate=$fromdate&todate=$todate&per_page=$per_page";
	$generate_page = nv_generate_page( $base_url, $work[0], $per_page, $page );
	
}



$xtpl->parse('main');
$contents .= $xtpl->text('main');
	

$contents .= "</td></tr>\n";
//phan duoi
$contents .= "<tr><td align='center'>" . $generate_page;
$contents .= "</td></tr>\n";
$contents .= "</table>";

include ( NV_ROOTDIR . "/includes/header.php" );
echo nv_site_theme( $contents );
include ( NV_ROOTDIR . "/includes/footer.php" );

?>