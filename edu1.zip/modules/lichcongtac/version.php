<?php

/**
 * @Project NUKEVIET 3.0 LICH CONG TAC
 * @Author PHAN DINH BAO (baocatg@gmail.com)
 * @copyright 2010
 * @createdate 16/12/2010
 */

if ( ! defined( 'NV_ADMIN' ) or ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$module_version = array( 
    "name" => "LICH CONG TAC", // Tieu de module
	"modfuncs" => "main", // Cac function co block ex:main,viewcat,topic,detail,search
	"is_sysmod" => 0, // 1:0 => Co phai la module he thong hay khong
	"virtual" => 0, // 1:0 => Co cho phep ao hao module hay khong
	"version" => "3.0.01", // Phien ban cua modle
	"date" => "Fri, 16 DEC 2010 09:47:15 GMT", // Ngay phat hanh phien ban
	"author" => "PHAN DINH BAO (baocatg@gmail.com)", // Tac gia
	"note" => "" // Ghi chu
);

?>